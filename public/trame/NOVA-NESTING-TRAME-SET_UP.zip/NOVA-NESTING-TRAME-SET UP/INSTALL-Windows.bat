@echo off
setlocal
title Install NOVA Trame Studio
set "SRC=%~dp0com.nova.tramestudio"
set "DST=%APPDATA%\Adobe\CEP\extensions\com.nova.tramestudio"

if not exist "%SRC%\CSXS\manifest.xml" goto nosrc

echo [1/2] Allowing Photoshop to run unsigned panels...
for %%V in (6 7 8 9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo [2/2] Copying the plugin into the CEP extensions folder...
if exist "%DST%" rmdir /s /q "%DST%"
xcopy "%SRC%" "%DST%\" /E /I /Y /Q >nul
if errorlevel 1 goto copyfail

echo.
echo Installation complete.
echo Quit and reopen Photoshop, then go to:
echo   Window - Extensions (legacy) - NOVA Trame Studio
echo On Photoshop older than 2021, the menu is Window - Extensions.
echo.
echo If the panel says "Could not reach the license server", use
echo "Offline activation" inside the panel.
goto end

:nosrc
echo Could not find the com.nova.tramestudio folder.
echo Please unzip the whole package, then run this file again.
goto end

:copyfail
echo Copy failed. Please close Photoshop and run this file again.

:end
echo.
pause
