KICH HOAT
- Panel kiem tra license qua internet. Neu panel bao loi ket noi,
  bam "Kich hoat ngoai tuyen" trong panel, mo trang kich hoat tren trinh duyet,
  nhap key + ma may, roi dan ma nhan duoc vao panel.

PHIEN BAN 1.1.0
- Them license: nhap key, hoac dung thu 7 ngay (1 lan/may).
- Key co the la Monthly, Yearly, Yearly Pro. Yearly Pro mo tat ca 130 kieu.
- Panel kiem tra license khi mo. Khi het han, panel hien thong bao va link gia han.
- Can ket noi internet de kich hoat. Sau khi kiem tra thanh cong, panel chay ngoai tuyen toi da 24 gio.
- Ho tro Photoshop CC 2015 tro len.

NOVA Trame Studio 1.0.1 (ban CEP, chi danh cho DTF) - Photoshop CC 2015 den nay
Khong can Creative Cloud.

MOI TRONG BAN 1.0.1
- Nhom "Mau" (trame CMYK, mau spot) chi hien khi chon "DTF ao trang".
  Dang o kieu mau ma chuyen sang ao den thi plugin tu quay ve kieu dung truoc do.
- Sau khi ap dung, file ket qua co them layer "preview solid" o duoi cung
  (nen den cho ao den, nen trang cho ao trang) de xem giong tren ao.
  NHO TAT (an con mat) layer "preview solid" truoc khi xuat file in.

TU BAN 1.0
- Nhom moi "Vintage" gom 30 hieu ung (tong cong 130 kieu):
  Anh sepia, Anh o vang, Phim cu xuoc, Ao giat bac, In lua cu, Con dau cao su, Ao band 80s,
  Surf 70s, Poster co dong, Khac go, Khac linoleum, Bao cu, Truyen tranh co, Polaroid phai,
  Kodachrome, Cross-process, Lomo, Cyanotype, Duotone nau, In lech khuon, Nhan hop diem,
  Son troc, Gi set, Bac nang, Muc loang, Letterpress, Varsity 2 mau, Tem khac, Bang VHS, Ao thrift.
- Thanh truot "Cuong do" o the Tuy chon hieu ung chinh muc do cu/mon/phai.
- Kieu 1 mau (Con dau, Band 80s, Khac go, Linocut, Bao cu, Tem khac...): doi mau muc o the Tuy chon.
  Tren ao den, neu chon mau muc toi thi plugin tu doi sang mau kem de con nhin thay.

TU BAN 0.9
- 4 ngon ngu: English (mac dinh), Tieng Viet, Thai, Espanol. Doi o o chon EN/VI/TH/ES tren cung.
  Panel Xem truoc doi ngon ngu theo panel chinh.
- O xem truoc quay ve panel chinh trong khoang 1 giay khi tat panel Xem truoc.
- Menu panel Xem truoc doi ten: Window > Extensions > NOVA Trame Preview

TU BAN 0.8
- Du 100 kieu trame (them 29: Vuong bo goc, Co 4 la, Hoa 6 canh, Banh rang, Giot nuoc, Bia ban,
  O vuong long, Mua ngau nhien, Tam giac loan, Te bao, Huong duong, Ma Morse, Mat cao, Gach xay,
  Luoi to ong, Vuong dong tam, Song bien Nhat, Mang nhen, Dan ro, Thep gan, Van ngua, Da bao,
  Van da, Ran ri, Ky hoa, Duotone, Cham cau vong, Cham RGB LED, Son xit)
- Tab "1 . Tao file" dua len dau; tab Hieu ung cu gop vao Tao thanh muc "Vien & bong cho layer"
- Tat panel Xem truoc thi o xem truoc tu quay ve panel chinh (trong khoang 3 giay)

TU BAN 0.7
- 2 PANEL: "NOVA Trame Studio" (chinh) va "NOVA Trame - Xem truoc" (anh xem truoc rieng).
  Mo panel Xem truoc bang nut o canh "Tu cap nhat", hoac menu Window > Extensions.
  Keo panel Xem truoc dat canh panel chinh: chinh thong so ben duoi van thay anh.
- LPI TU DONG THEO KHO IN (DTF):
    canh dai <= 15 cm (logo nguc) : 45 LPI
    <= 32 cm (A4, 25x30)         : 40 LPI
    <= 45 cm (30x40, A3)         : 35 LPI
    lon hon                      : 30 LPI
  Tu doc kho file dang mo; tao file moi theo kho cung tu dat. Keo LPI tay thi giu gia tri cua ban,
  bam "Dung goi y" de quay lai.
- DAU RA DTF: Cham nho nhat (mm) de bot keo bam duoc, To dac tu (%), lop trang.
- Bo phan in lua.
- Nhom XU HUONG (15 hieu ung): Soc hoang hon, Cham chuyen huong, Muc nut, Khac tien giay,
  Stencil, Pixel 1-bit, Chu ASCII, Glitch, Riso 2 mau, Pop-art 2 mau, Pixel 8-bit,
  Vintage bac mau, Ao giac 70s, Anh nhiet, Neon vien.
- Sua: xem truoc DTF ao den truoc day bi dao sang/toi (ket qua ap dung van dung).

CAI DAT
- Windows: giai nen ca thu muc, nhap dup INSTALL-Windows.bat
- Mac: nhap chuot phai INSTALL-Mac.command > Open
Neu da cai ban cu, chi can chay lai file cai la len ban moi.
Sau khi cai, dong va mo lai Photoshop: Window > Extensions (legacy) > NOVA Trame Studio

GO CAI DAT: chay UNINSTALL-Windows.bat.
KHI CO LOI: bam vao dong trang thai duoi nut Ap dung > Sao chep nhat ky, gui noi dung do.
