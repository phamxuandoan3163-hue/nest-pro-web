ACTIVATION
- The panel verifies the license online. If the panel shows a connection error,
  click "Offline activation" in the panel, open the activation page in a browser,
  enter your key + device code, and paste the returned code.

VERSION 1.3.2
- When working offline, if the computer's date/time has been set back, the panel shows
  "Wrong date/time" and pauses. Set the correct date/time (or connect to the internet)
  and it works again, no new activation needed.
- Fixed: offline activation was lost after reopening Photoshop.
- A panel left open now re-checks the license each time you click Apply.

VERSION 1.3.1
- Larger logo in the panel header.

VERSION 1.3.0
- The Update button now downloads, checks and installs the new version for you.
  Quit Photoshop completely and reopen it afterwards. If automatic update is not possible,
  the button opens the download page as before.

VERSION 1.2.1
- New NOVA Nesting AI | TRAME logo in the panel header.

VERSION 1.2.0
- The panel shows a notice when a new version is available, with a Download button.
  To update: download the new zip, unzip it and run the installer again. Your license is kept.

VERSION 1.1.0
- License: enter a key, or start a 7-day trial (once per computer).
- Plans: Monthly, Yearly (94 styles), Yearly Pro (all 130 styles). Free trial opens the basic group.
- The panel checks the license each time it opens. When it expires, the panel shows a notice and a renewal link.
- Internet is needed to activate. After a successful check the panel works offline for up to 24 hours.
- Works with Photoshop CC 2015 and later.

NOVA Trame Studio 1.0.1 - DTF halftone plugin for Photoshop CC 2015 and later
No Creative Cloud needed.

INSTALL
- Windows: unzip the whole folder, double-click INSTALL-Windows.bat
- Mac: right-click INSTALL-Mac.command > Open
Then restart Photoshop and open:
  Window > Extensions (legacy) > NOVA Trame Studio
  Window > Extensions (legacy) > NOVA Trame Preview   (optional preview panel)

LANGUAGE
English by default. Switch to Vietnamese, Thai or Spanish with the EN/VI/TH/ES box at the top.
The Preview panel follows the main panel's language.

WHAT IT DOES
- 1 . New file: create a document by print size; the DTF LPI is set automatically for that size.
- 2 . DTF halftone: 130 halftone styles and effects (including 30 Vintage effects) for black or white shirts, with live preview,
  minimum dot size for DTF adhesive powder, and an automatic white underbase on black shirts.

UNINSTALL: run UNINSTALL-Windows.bat
IF SOMETHING FAILS: click the status line under the Apply button > Copy the log and send it.

NEW IN 1.0.1
- The "Color" group (CMYK halftone, spot colors) only appears for "DTF white shirt".
- After applying, the result gets a bottom layer named "preview solid" (black or white, matching the shirt tab)
  so you can see it as on the shirt. TURN OFF the "preview solid" layer before exporting the print file.
