/* NOVA Trame Studio: update notice.
 * On each open the panel reads latest.json from the website (published next to the
 * installer zip) and compares it with its own version. It never downloads or installs
 * anything itself: it only tells the user and opens the download link in the browser.
 */
(function (root) {
  // Bump this together with CSXS/manifest.xml and public/trame/latest.json on the website.
  var VERSION = "1.2.1";
  var LATEST_URL = "https://www.ainovanesting.pro/trame/latest.json";
  var DEFAULT_DOWNLOAD = "https://www.ainovanesting.pro/trame/NOVA-NESTING-TRAME-SET_UP.zip";
  var DISMISS_KEY = "nvt.update.dismissed";

  // Compare "1.2.0" style versions: >0 if a is newer than b.
  function compare(a, b) {
    var pa = String(a).split("."), pb = String(b).split(".");
    for (var i = 0; i < Math.max(pa.length, pb.length); i++) {
      var x = parseInt(pa[i] || "0", 10) || 0, y = parseInt(pb[i] || "0", 10) || 0;
      if (x !== y) return x - y;
    }
    return 0;
  }

  // Only open download links on our own site, whatever latest.json says.
  function safeUrl(u) {
    return /^https:\/\/(www\.)?ainovanesting\.pro\//.test(String(u || "")) ? String(u) : DEFAULT_DOWNLOAD;
  }

  function getNode(url, hops, cb) {
    var https = require("https");
    var req = https.get(url, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && hops > 0) {
        res.resume();
        var next = res.headers.location;
        if (next.charAt(0) === "/") next = url.replace(/^(https:\/\/[^/]+).*$/, "$1") + next;
        getNode(next, hops - 1, cb);
        return;
      }
      var text = "";
      res.setEncoding("utf8");
      res.on("data", function (c) { text += c; });
      res.on("end", function () {
        var data = null;
        try { data = JSON.parse(text); } catch (e) {}
        cb(res.statusCode === 200 ? data : null);
      });
    });
    req.on("error", function () { cb(null); });
    req.setTimeout(10000, function () { try { req.abort(); } catch (e) {} });
  }

  function getXhr(url, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.timeout = 10000;
    xhr.onload = function () {
      var data = null;
      try { data = JSON.parse(xhr.responseText); } catch (e) {}
      cb(xhr.status === 200 ? data : null);
    };
    xhr.onerror = xhr.ontimeout = function () { cb(null); };
    xhr.send();
  }

  // cb({ newer: bool, latest: "1.3.0", url: "...", dismissed: bool }) or cb(null) when offline.
  function check(cb) {
    var url = LATEST_URL + "?t=" + Date.now();
    var done = false;
    function finish(data) {
      if (done) return;
      done = true;
      if (!data || !data.version) { cb(null); return; }
      var dismissed = null;
      try { dismissed = localStorage.getItem(DISMISS_KEY); } catch (e) {}
      cb({
        newer: compare(data.version, VERSION) > 0,
        latest: String(data.version),
        url: safeUrl(data.download_url),
        dismissed: dismissed === String(data.version)
      });
    }
    try {
      if (typeof require === "function") {
        getNode(url, 3, function (data) { if (data) finish(data); else getXhr(url, finish); });
        return;
      }
    } catch (e) {}
    getXhr(url, finish);
  }

  function dismiss(version) {
    try { localStorage.setItem(DISMISS_KEY, String(version)); } catch (e) {}
  }

  // "1.2.0" -> "1.2", "1.2.3" -> "1.2.3"
  function shortVersion(v) { return String(v).replace(/\.0$/, ""); }

  root.NovaUpdate = { version: VERSION, shortVersion: shortVersion, check: check, dismiss: dismiss, compare: compare };
})(window);
