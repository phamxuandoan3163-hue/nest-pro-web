/* NOVA Trame Studio: update notice and one-click update.
 *
 * On each open the panel reads latest.json from the website and compares it with its own
 * version. When a newer version exists it can either
 *   - install it for the user (Update button): download the zip from our own site, check its
 *     SHA-256 against latest.json, check the package, back up the current files, copy the new
 *     files over this panel's folder and roll back if anything fails; or
 *   - fall back to opening the download link in the browser (older latest.json without a
 *     checksum, no Node.js, or any failure).
 * The new version only runs after Photoshop is restarted.
 *
 * Written in plain ES5 for the old Node.js that ships with older Photoshop versions.
 */
(function (root) {
  // Bump this together with CSXS/manifest.xml and public/trame/latest.json on the website.
  var VERSION = "1.3.2";
  var BUNDLE_ID = "com.nova.tramestudio";
  var LATEST_URL = "https://www.ainovanesting.pro/trame/latest.json";
  var DEFAULT_DOWNLOAD = "https://www.ainovanesting.pro/trame/NOVA-NESTING-TRAME-SET_UP.zip";
  var DISMISS_KEY = "nvt.update.dismissed";
  var MAX_ZIP_BYTES = 40 * 1024 * 1024;       // the real package is about 0.5 MB
  var MAX_UNPACKED_BYTES = 120 * 1024 * 1024;
  var MAX_ENTRIES = 2000;

  // ----- helpers -------------------------------------------------------------------------
  function nodeMod(name) {
    try { if (typeof require === "function") return require(name); } catch (e) {}
    return null;
  }

  // Compare "1.2.0" style versions: >0 if a is newer than b.
  function compare(a, b) {
    var pa = String(a).split("."), pb = String(b).split(".");
    for (var i = 0; i < Math.max(pa.length, pb.length); i++) {
      var x = parseInt(pa[i] || "0", 10) || 0, y = parseInt(pb[i] || "0", 10) || 0;
      if (x !== y) return x - y;
    }
    return 0;
  }

  // "1.2.0" -> "1.2", "1.2.3" -> "1.2.3"
  function shortVersion(v) { return String(v).replace(/\.0$/, ""); }

  function isLoopback(u) { return /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//.test(String(u || "")); }
  function isOurSite(u) { return /^https:\/\/(www\.)?ainovanesting\.pro\//.test(String(u || "")); }

  // The folder this panel runs from (the same value main.js uses).
  function extDir() {
    try {
      var p = decodeURI(root.__adobe_cep__.getSystemPath("extension"));
      var win = (root.navigator && root.navigator.platform || "").indexOf("Win") >= 0;
      p = win ? p.replace("file:///", "") : p.replace("file://", "");
      return p.replace(/[\\\/]+$/, "");
    } catch (e) { return null; }
  }

  // Testing only: a file update-test.json next to index.html can point the check at a server on
  // this computer (http://localhost/... or http://127.0.0.1/...). Anything else is ignored.
  var testCfg = null;
  (function loadTestConfig() {
    try {
      var fs = nodeMod("fs"), dir = extDir();
      if (!fs || !dir) return;
      var cfg = JSON.parse(fs.readFileSync(dir + "/update-test.json", "utf8"));
      if (cfg && isLoopback(cfg.latest_url)) testCfg = cfg;
    } catch (e) {}
  })();

  // Only download from our own site (or, in test mode, from this computer), whatever latest.json says.
  function safeUrl(u) {
    u = String(u || "");
    if (isOurSite(u)) return u;
    if (testCfg && isLoopback(u)) return u;
    return DEFAULT_DOWNLOAD;
  }

  function validSha(s) { return /^[0-9a-f]{64}$/i.test(String(s || "")); }

  // ----- reading latest.json -------------------------------------------------------------
  function getNode(url, hops, cb) {
    var https = nodeMod(/^http:/.test(url) ? "http" : "https");
    if (!https) { cb(null); return; }
    var req = https.get(url, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && hops > 0) {
        res.resume();
        var next = res.headers.location;
        if (next.charAt(0) === "/") next = url.replace(/^(https?:\/\/[^/]+).*$/, "$1") + next;
        getNode(next, hops - 1, cb);
        return;
      }
      var text = "";
      res.setEncoding("utf8");
      res.on("data", function (c) { text += c; });
      res.on("end", function () {
        var data = null;
        try { data = JSON.parse(text); } catch (e) {}
        cb(res.statusCode === 200 ? data : null);
      });
    });
    req.on("error", function () { cb(null); });
    req.setTimeout(10000, function () { try { req.abort(); } catch (e) {} });
  }

  function getXhr(url, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.timeout = 10000;
    xhr.onload = function () {
      var data = null;
      try { data = JSON.parse(xhr.responseText); } catch (e) {}
      cb(xhr.status === 200 ? data : null);
    };
    xhr.onerror = xhr.ontimeout = function () { cb(null); };
    xhr.send();
  }

  // Can this computer install updates by itself? Needs Node.js, a known folder and a checksum.
  function canInstall(data) {
    return !!(data && validSha(data.sha256) && nodeMod("https") && nodeMod("fs") && nodeMod("zlib") &&
              nodeMod("crypto") && nodeMod("os") && extDir());
  }

  // cb({ newer: bool, latest: "1.3.0", url: "...", sha256: "...", canAuto: bool, dismissed: bool }) or cb(null) when offline.
  function check(cb) {
    var url = (testCfg ? testCfg.latest_url : LATEST_URL) + "?t=" + Date.now();
    var done = false;
    function finish(data) {
      if (done) return;
      done = true;
      if (!data || !data.version) { cb(null); return; }
      var dismissed = null;
      try { dismissed = localStorage.getItem(DISMISS_KEY); } catch (e) {}
      cb({
        newer: compare(data.version, VERSION) > 0,
        latest: String(data.version),
        url: safeUrl(data.download_url),
        sha256: validSha(data.sha256) ? String(data.sha256).toLowerCase() : "",
        canAuto: canInstall(data),
        dismissed: dismissed === String(data.version)
      });
    }
    try {
      if (typeof require === "function") {
        getNode(url, 3, function (data) { if (data) finish(data); else getXhr(url, finish); });
        return;
      }
    } catch (e) {}
    getXhr(url, finish);
  }

  function dismiss(version) {
    try { localStorage.setItem(DISMISS_KEY, String(version)); } catch (e) {}
  }

  // ----- downloading ---------------------------------------------------------------------
  function fail(code, message) { var e = new Error(message || code); e.code = code; return e; }
  // Only our own error codes reach the panel; a Node.js error (EISDIR, EPERM...) becomes the given default.
  function asError(e, dflt) {
    return (e && /^(network|hash|zip|manifest|write|unsupported)$/.test(e.code)) ? e : fail(dflt, e && e.message);
  }

  // Downloads url into a Buffer. Follows up to 3 redirects, only to allowed locations.
  function download(url, hops, cb) {
    var mod = nodeMod(/^http:/.test(url) ? "http" : "https");
    if (!mod) { cb(fail("unsupported", "no http module")); return; }
    var finished = false;
    function end(err, buf) { if (finished) return; finished = true; cb(err, buf); }
    var req = mod.get(url, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        if (hops <= 0) { end(fail("network", "too many redirects")); return; }
        var next = res.headers.location;
        if (next.charAt(0) === "/") next = url.replace(/^(https?:\/\/[^/]+).*$/, "$1") + next;
        if (safeUrl(next) !== next) { end(fail("network", "redirect to a location that is not allowed")); return; }
        download(next, hops - 1, end);
        return;
      }
      if (res.statusCode !== 200) { res.resume(); end(fail("network", "HTTP " + res.statusCode)); return; }
      var len = parseInt(res.headers["content-length"] || "0", 10);
      if (len > MAX_ZIP_BYTES) { res.resume(); end(fail("zip", "download is too large")); return; }
      var chunks = [], total = 0;
      res.on("data", function (c) {
        total += c.length;
        if (total > MAX_ZIP_BYTES) { try { req.abort(); } catch (e) {} end(fail("zip", "download is too large")); return; }
        chunks.push(c);
      });
      res.on("end", function () { end(null, Buffer.concat(chunks)); });
      res.on("error", function () { end(fail("network", "connection lost")); });
    });
    req.on("error", function () { end(fail("network", "no connection")); });
    req.setTimeout(30000, function () { try { req.abort(); } catch (e) {} end(fail("network", "timed out")); });
  }

  // ----- reading the zip (stored and deflate entries, no zip64, no encryption) -----------
  var crcTable = null;
  function crc32(buf) {
    if (!crcTable) {
      crcTable = [];
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        crcTable[n] = c >>> 0;
      }
    }
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < buf.length; i++) crc = crcTable[(crc ^ buf[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  // A zip entry name may not leave the folder it is extracted to.
  function safeEntryName(name) {
    var n = String(name).replace(/\\/g, "/");
    if (!n || n.indexOf("\0") >= 0 || n.charAt(0) === "/" || /^[A-Za-z]:/.test(n)) return null;
    var parts = n.split("/");
    for (var i = 0; i < parts.length; i++) if (parts[i] === "..") return null;
    return n;
  }

  // Returns [{ name, data }] for every file entry, or throws an error with code "zip".
  function readZip(buf) {
    var zlib = nodeMod("zlib");
    if (!zlib) throw fail("unsupported", "no zlib");
    var eocd = -1;
    for (var i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
      if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw fail("zip", "not a zip file");
    var count = buf.readUInt16LE(eocd + 10), cdSize = buf.readUInt32LE(eocd + 12), cdOff = buf.readUInt32LE(eocd + 16);
    if (count === 0xFFFF || cdOff === 0xFFFFFFFF || cdSize === 0xFFFFFFFF) throw fail("zip", "zip64 is not supported");
    if (count < 1 || count > MAX_ENTRIES) throw fail("zip", "unexpected number of files");
    var out = [], p = cdOff, unpacked = 0;
    for (var e = 0; e < count; e++) {
      if (p + 46 > buf.length || buf.readUInt32LE(p) !== 0x02014b50) throw fail("zip", "damaged directory");
      var flags = buf.readUInt16LE(p + 8), method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16);
      var csize = buf.readUInt32LE(p + 20), usize = buf.readUInt32LE(p + 24);
      var nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32);
      var lho = buf.readUInt32LE(p + 42);
      var rawName = buf.toString("utf8", p + 46, p + 46 + nlen);
      p += 46 + nlen + xlen + clen;
      if (/\/$/.test(rawName)) continue;                       // folder entry
      if (flags & 1) throw fail("zip", "encrypted files are not supported");
      var name = safeEntryName(rawName);
      if (name === null) throw fail("zip", "unsafe file name");
      unpacked += usize;
      if (unpacked > MAX_UNPACKED_BYTES) throw fail("zip", "package is too large");
      if (lho + 30 > buf.length || buf.readUInt32LE(lho) !== 0x04034b50) throw fail("zip", "damaged file header");
      var start = lho + 30 + buf.readUInt16LE(lho + 26) + buf.readUInt16LE(lho + 28);
      if (start + csize > buf.length) throw fail("zip", "truncated file");
      var raw = buf.slice(start, start + csize), data;
      if (method === 0) data = raw;
      else if (method === 8) { try { data = zlib.inflateRawSync(raw); } catch (er) { throw fail("zip", "damaged file data"); } }
      else throw fail("zip", "unsupported compression");
      if (data.length !== usize || crc32(data) !== crc) throw fail("zip", "checksum mismatch inside the package");
      out.push({ name: name, data: data });
    }
    return out;
  }

  // Finds the plugin folder inside the package and returns { "relative/path": Buffer }.
  function packageFiles(entries, expectVersion) {
    var prefix = null, i;
    for (i = 0; i < entries.length; i++) {
      var m = /^(.*?)com\.nova\.tramestudio\/CSXS\/manifest\.xml$/.exec(entries[i].name);
      if (m) { prefix = m[1] + "com.nova.tramestudio/"; break; }
    }
    if (prefix === null) throw fail("manifest", "plugin folder not found in the package");
    var files = {}, manifest = null;
    for (i = 0; i < entries.length; i++) {
      if (entries[i].name.indexOf(prefix) !== 0) continue;
      var rel = entries[i].name.slice(prefix.length);
      if (!rel) continue;
      files[rel] = entries[i].data;
      if (rel === "CSXS/manifest.xml") manifest = entries[i].data.toString("utf8");
    }
    var id = /ExtensionBundleId="([^"]+)"/.exec(manifest || ""), ver = /ExtensionBundleVersion="([^"]+)"/.exec(manifest || "");
    if (!id || id[1] !== BUNDLE_ID) throw fail("manifest", "package is for a different plugin");
    if (!ver || ver[1] !== String(expectVersion)) throw fail("manifest", "package version does not match");
    if (compare(ver[1], VERSION) <= 0) throw fail("manifest", "package is not newer");
    if (!files["index.html"] || !files["main.js"] || !files["update.js"]) throw fail("manifest", "package is incomplete");
    return files;
  }

  // ----- installing ----------------------------------------------------------------------
  function mkdirp(dir) {
    var fs = nodeMod("fs"), path = nodeMod("path");
    if (fs.existsSync(dir)) return;
    mkdirp(path.dirname(dir));
    try { fs.mkdirSync(dir); } catch (e) { if (!fs.existsSync(dir)) throw e; }
  }

  // Every file below dir as "relative/path" (forward slashes).
  function listFiles(dir, base, acc) {
    var fs = nodeMod("fs"), names = fs.readdirSync(dir);
    acc = acc || []; base = base || "";
    for (var i = 0; i < names.length; i++) {
      var full = dir + "/" + names[i], st = fs.statSync(full);
      if (st.isDirectory()) listFiles(full, base + names[i] + "/", acc);
      else acc.push(base + names[i]);
    }
    return acc;
  }

  function removeEmptyDirs(dir) {
    var fs = nodeMod("fs"), names;
    try { names = fs.readdirSync(dir); } catch (e) { return; }
    for (var i = 0; i < names.length; i++) {
      var full = dir + "/" + names[i];
      try { if (fs.statSync(full).isDirectory()) { removeEmptyDirs(full); if (fs.readdirSync(full).length === 0) fs.rmdirSync(full); } } catch (e) {}
    }
  }

  // Makes dir contain exactly the given files (relative path -> Buffer). Files that are not in the
  // set are deleted, like the installer which replaces the whole folder.
  function applyFiles(dir, files) {
    var fs = nodeMod("fs"), path = nodeMod("path"), rel;
    for (rel in files) {
      if (!Object.prototype.hasOwnProperty.call(files, rel)) continue;
      var target = dir + "/" + rel;
      mkdirp(path.dirname(target));
      fs.writeFileSync(target, files[rel]);
    }
    var existing = listFiles(dir);
    for (var i = 0; i < existing.length; i++) {
      if (!Object.prototype.hasOwnProperty.call(files, existing[i])) fs.unlinkSync(dir + "/" + existing[i]);
    }
    removeEmptyDirs(dir);
  }

  function readTree(dir) {
    var fs = nodeMod("fs"), files = listFiles(dir), out = {};
    for (var i = 0; i < files.length; i++) out[files[i]] = fs.readFileSync(dir + "/" + files[i]);
    return out;
  }

  // info: { latest, url, sha256 }. opts: { onStep(name), extDir }. cb(err) with err.code set on failure.
  // Nothing in the panel folder changes unless every check has passed; if copying fails the old files are restored.
  function install(info, cb, opts) {
    opts = opts || {};
    var step = opts.onStep || function () {};
    var fs = nodeMod("fs"), crypto = nodeMod("crypto"), dir = opts.extDir || extDir();
    if (!fs || !crypto || !nodeMod("zlib") || !nodeMod("path") || !dir) { cb(fail("unsupported", "Node.js is not available")); return; }
    if (!info || !validSha(info.sha256) || !info.latest) { cb(fail("unsupported", "no checksum to verify")); return; }
    var url = safeUrl(info.url);
    if (url !== info.url) { cb(fail("network", "download location is not allowed")); return; }
    var manifestPath = dir + "/CSXS/manifest.xml", current;
    try { current = fs.readFileSync(manifestPath, "utf8"); } catch (e) { cb(fail("unsupported", "panel folder not found")); return; }
    if (current.indexOf('ExtensionBundleId="' + BUNDLE_ID + '"') < 0) { cb(fail("unsupported", "unexpected panel folder")); return; }

    step("download");
    download(url, 3, function (err, buf) {
      if (err) { cb(err); return; }
      step("install");
      var files, backup;
      try {
        if (crypto.createHash("sha256").update(buf).digest("hex") !== String(info.sha256).toLowerCase()) throw fail("hash", "checksum mismatch");
        files = packageFiles(readZip(buf), info.latest);
        backup = readTree(dir);                                   // in memory: the panel is small
      } catch (e) { cb(asError(e, "zip")); return; }
      try {
        applyFiles(dir, files);
        var written = fs.readFileSync(manifestPath, "utf8");
        if (written.indexOf('ExtensionBundleVersion="' + info.latest + '"') < 0) throw fail("write", "version check after copying failed");
      } catch (e) {
        try { applyFiles(dir, backup); } catch (e2) {}            // roll back to the files we started with
        cb(asError(e, "write"));
        return;
      }
      cb(null);
    });
  }

  root.NovaUpdate = {
    version: VERSION, shortVersion: shortVersion, check: check, dismiss: dismiss, compare: compare,
    install: install,
    // exposed for the offline test of this file
    _readZip: readZip, _packageFiles: packageFiles, _crc32: crc32
  };
})(typeof window !== "undefined" ? window : this);
