﻿/*
 * NOVA Trame Studio 0.9 - phần xử lý chạy trong Photoshop (ExtendScript).
 * Chạy được trên Photoshop CC 2015 (16.0) trở lên. Chỉ dùng cú pháp ES3.
 * Mỗi hàm công khai trả về chuỗi: dòng đầu "OK" hoặc "ERR", các dòng sau là nhật ký.
 * Dòng bắt đầu bằng "DATA|" là dữ liệu cho panel.
 */
var NOVA = (function () {
    var LOG = [];
    /* Đa ngôn ngữ: câu tiếng Việt là khóa; panel gửi mã ngôn ngữ trong mỗi lệnh (o.lang). */
    var LANG = "en";
    var HT = {"(host.jsx dòng {0})": {"en": "(host.jsx line {0})", "th": "(host.jsx บรรทัด {0})", "es": "(host.jsx línea {0})"}, "Chưa có tài liệu nào đang mở.": {"en": "No document is open.", "th": "ยังไม่มีเอกสารเปิดอยู่", "es": "No hay ningún documento abierto."}, "Màu không hợp lệ: {0}": {"en": "Invalid color: {0}", "th": "สีไม่ถูกต้อง: {0}", "es": "Color no válido: {0}"}, "Đã áp ngưỡng {0}": {"en": "Threshold applied: {0}", "th": "ใช้เกณฑ์ {0} แล้ว", "es": "Umbral aplicado: {0}"}, "Chuyển Bitmap: {0}": {"en": "Bitmap conversion: {0}", "th": "แปลงเป็น Bitmap: {0}", "es": "Conversión a mapa de bits: {0}"}, "Halftone {0}: {1} LPI, {2} độ": {"en": "Halftone {0}: {1} LPI, {2}°", "th": "ฮาล์ฟโทน {0}: {1} LPI, {2}°", "es": "Trama {0}: {1} LPI, {2}°"}, "Lớp trắng (underbase)": {"en": "White underbase", "th": "ชั้นขาวรองพื้น (underbase)", "es": "Base blanca (underbase)"}, "Vùng chọn rỗng sau khi co {0} px, lớp trắng để trống. Hãy giảm độ co.": {"en": "Selection is empty after a {0} px choke; the underbase is blank. Reduce the choke.", "th": "การเลือกว่างหลังหด {0} px ชั้นขาวจึงว่าง ลดค่าการหด", "es": "La selección queda vacía tras contraer {0} px; la base está vacía. Reduce la contracción."}, "Đã tạo lớp trắng (co {0} px)": {"en": "White underbase created (choke {0} px)", "th": "สร้างชั้นขาวแล้ว (หด {0} px)", "es": "Base blanca creada (contracción {0} px)"}, "Thiết kế (trame)": {"en": "Design (halftone)", "th": "ดีไซน์ (ฮาล์ฟโทน)", "es": "Diseño (trama)"}, "DTF: kết quả ở tài liệu \"{0}\". Xuất PNG trong suốt để đưa vào RIP.": {"en": "DTF: result is in document \"{0}\". Export a transparent PNG for your RIP.", "th": "DTF: ผลลัพธ์อยู่ในเอกสาร \"{0}\" ส่งออก PNG โปร่งใสเพื่อใช้กับ RIP", "es": "DTF: el resultado está en el documento \"{0}\". Exporta un PNG transparente para tu RIP."}, "Hãy chuyển file sang RGB, CMYK hoặc Grayscale trước.": {"en": "Convert the file to RGB, CMYK or Grayscale first.", "th": "แปลงไฟล์เป็น RGB, CMYK หรือ Grayscale ก่อน", "es": "Convierte primero el archivo a RGB, CMYK o escala de grises."}, "Nguồn: {0}": {"en": "Source: {0}", "th": "ต้นฉบับ: {0}", "es": "Origen: {0}"}, "Màu áo": {"en": "Shirt color", "th": "สีเสื้อ", "es": "Color de camiseta"}, "Không tìm thấy tài liệu gốc \"{0}\" (đã bị đóng?).": {"en": "Source document \"{0}\" not found (was it closed?).", "th": "ไม่พบเอกสารต้นฉบับ \"{0}\" (ถูกปิดไปแล้วหรือไม่?)", "es": "No se encuentra el documento de origen \"{0}\" (¿se cerró?)."}, "Không thấy file trame tạm: {0}": {"en": "Temporary halftone file not found: {0}", "th": "ไม่พบไฟล์ฮาล์ฟโทนชั่วคราว: {0}", "es": "No se encuentra el archivo temporal de trama: {0}"}, "Kích thước trame khác tài liệu gốc.": {"en": "Halftone size differs from the source document.", "th": "ขนาดฮาล์ฟโทนต่างจากเอกสารต้นฉบับ", "es": "El tamaño de la trama difiere del documento de origen."}, "Không thấy file tạm: {0}": {"en": "Temporary file not found: {0}", "th": "ไม่พบไฟล์ชั่วคราว: {0}", "es": "No se encuentra el archivo temporal: {0}"}, "Trame màu ({0})": {"en": "Color halftone ({0})", "th": "ฮาล์ฟโทนสี ({0})", "es": "Trama de color ({0})"}, "Trame màu: kết quả ở tài liệu \"{0}\". Xuất PNG trong suốt để đưa vào RIP.": {"en": "Color halftone: result is in document \"{0}\". Export a transparent PNG for your RIP.", "th": "ฮาล์ฟโทนสี: ผลลัพธ์อยู่ในเอกสาร \"{0}\" ส่งออก PNG โปร่งใสเพื่อใช้กับ RIP", "es": "Trama de color: el resultado está en el documento \"{0}\". Exporta un PNG transparente para tu RIP."}, "Nền trắng": {"en": "White background", "th": "พื้นขาว", "es": "Fondo blanco"}, "Hãy chọn một layer thường làm họa tiết (không phải Background).": {"en": "Select a regular layer as the pattern (not Background).", "th": "เลือกเลเยอร์ปกติเป็นลาย (ไม่ใช่ Background)", "es": "Selecciona una capa normal como motivo (no el Fondo)."}, "Layer họa tiết rỗng.": {"en": "The pattern layer is empty.", "th": "เลเยอร์ลายว่างเปล่า", "es": "La capa del motivo está vacía."}, "Lưới cần {0} bản sao (quá 400). Hãy tăng khoảng cách hoặc dùng họa tiết lớn hơn.": {"en": "The grid needs {0} copies (over 400). Increase the gap or use a larger motif.", "th": "กริดต้องใช้ {0} สำเนา (เกิน 400) เพิ่มระยะห่างหรือใช้ลายที่ใหญ่ขึ้น", "es": "La cuadrícula necesita {0} copias (más de 400). Aumenta la separación o usa un motivo mayor."}, "Họa tiết lặp": {"en": "Repeat pattern", "th": "ลายซ้ำ", "es": "Patrón repetido"}, "Đã tạo {0} bản sao trong nhóm \"{1}\" (bước {2}x{3} px).": {"en": "Created {0} copies in group \"{1}\" (step {2}x{3} px).", "th": "สร้าง {0} สำเนาในกลุ่ม \"{1}\" แล้ว (ระยะ {2}x{3} px)", "es": "Se crearon {0} copias en el grupo \"{1}\" (paso {2}x{3} px)."}, "Hãy chọn một layer thường (không phải Background).": {"en": "Select a regular layer (not Background).", "th": "เลือกเลเยอร์ปกติ (ไม่ใช่ Background)", "es": "Selecciona una capa normal (no el Fondo)."}, "Viền sticker": {"en": "Sticker outline", "th": "ขอบสติกเกอร์", "es": "Contorno de pegatina"}, "Đã tạo viền sticker {0} px dưới layer \"{1}\".": {"en": "Created a {0} px sticker outline under layer \"{1}\".", "th": "สร้างขอบสติกเกอร์ {0} px ใต้เลเยอร์ \"{1}\" แล้ว", "es": "Se creó un contorno de {0} px bajo la capa \"{1}\"."}, "Kích thước hoặc DPI không hợp lệ.": {"en": "Invalid size or DPI.", "th": "ขนาดหรือ DPI ไม่ถูกต้อง", "es": "Tamaño o DPI no válidos."}, "Nền đen": {"en": "Black background", "th": "พื้นดำ", "es": "Fondo negro"}, "Đã tạo: {0}": {"en": "Created: {0}", "th": "สร้างแล้ว: {0}", "es": "Creado: {0}"}, "Hãy chọn một layer thường (không phải Background hay nhóm).": {"en": "Select a regular layer (not Background or a group).", "th": "เลือกเลเยอร์ปกติ (ไม่ใช่ Background หรือกลุ่ม)", "es": "Selecciona una capa normal (no el Fondo ni un grupo)."}, "Chưa chọn hiệu ứng nào.": {"en": "No effect selected.", "th": "ยังไม่ได้เลือกเอฟเฟกต์", "es": "No hay ningún efecto seleccionado."}, "Đã áp hiệu ứng cho layer \"{0}\"": {"en": "Effects applied to layer \"{0}\"", "th": "ใช้เอฟเฟกต์กับเลเยอร์ \"{0}\" แล้ว", "es": "Efectos aplicados a la capa \"{0}\""}, "Đã thêm layer \"preview solid\" (nền {0}) để xem. NHỚ TẮT layer này trước khi xuất file in.": {"en": "Added layer \"preview solid\" ({0} background) for viewing. TURN THIS LAYER OFF before exporting the print file.", "th": "เพิ่มเลเยอร์ \"preview solid\" (พื้น{0}) ไว้ดูผล ต้องปิดเลเยอร์นี้ก่อนส่งออกไฟล์พิมพ์", "es": "Se añadió la capa \"preview solid\" (fondo {0}) para ver el resultado. DESACTIVA esta capa antes de exportar el archivo de impresión."}, "đen": {"en": "black", "th": "ดำ", "es": "negro"}, "trắng": {"en": "white", "th": "ขาว", "es": "blanco"}};
    function L(src, args) {
        var out = src, e = HT[src];
        if (LANG !== "vi" && e && e[LANG]) out = e[LANG];
        if (args) for (var i = 0; i < args.length; i++) out = out.split("{" + i + "}").join(String(args[i]));
        return out;
    }
    function log(m) { LOG.push(m); }
    function c(x) { return charIDToTypeID(x); }

    function run(fn, o) {
        LOG = [];
        LANG = (o && o.lang) || "en";
        var oldUnits = app.preferences.rulerUnits;
        var oldDlg = app.displayDialogs;
        var ok = true;
        try {
            app.preferences.rulerUnits = Units.PIXELS;
            app.displayDialogs = DialogModes.NO;
            fn(o || {});
        } catch (e) {
            ok = false;
            log("✖ " + e.message + (e.line ? " " + L("(host.jsx dòng {0})", [e.line]) : ""));
        }
        try { app.preferences.rulerUnits = oldUnits; app.displayDialogs = oldDlg; } catch (e2) {}
        return (ok ? "OK" : "ERR") + "\n" + LOG.join("\n");
    }

    function requireDoc() {
        if (!app.documents.length) throw new Error(L("Chưa có tài liệu nào đang mở."));
        return app.activeDocument;
    }

    function modeName(d) { return String(d.mode).replace("DocumentMode.", ""); }

    function info(d) {
        var w = Math.round(d.width.as("px")), h = Math.round(d.height.as("px")), r = d.resolution;
        var bits = String(d.bitsPerChannel).replace("BitsPerChannelType.", "");
        return d.name + " - " + w + "x" + h + " px (" + (w / r * 2.54).toFixed(1) + "x" + (h / r * 2.54).toFixed(1) +
            " cm) - " + Math.round(r) + " DPI - " + modeName(d) + " " + bits + " - " + d.layers.length + " layer";
    }

    function hasBackground(d) {
        try { return d.backgroundLayer ? true : false; } catch (e) { return false; }
    }

    function solid(r, g, b) {
        var col = new SolidColor();
        col.rgb.red = r; col.rgb.green = g; col.rgb.blue = b;
        return col;
    }
    function gray(v) { return solid(v, v, v); }

    function hexColor(hex) {
        var h = String(hex).replace("#", "");
        if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
        var n = parseInt(h, 16);
        if (isNaN(n) || h.length !== 6) throw new Error(L("Màu không hợp lệ: {0}", [hex]));
        return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    }

    function addFillLayer(d, col, name, toBottom) {
        var l = d.artLayers.add();
        l.name = name;
        d.selection.selectAll();
        d.selection.fill(col);
        d.selection.deselect();
        if (toBottom) l.move(d, ElementPlacement.PLACEATEND);
        return l;
    }

    function selectTransparency() {
        var desc = new ActionDescriptor();
        var r1 = new ActionReference();
        r1.putProperty(c("Chnl"), c("fsel"));
        desc.putReference(c("null"), r1);
        var r2 = new ActionReference();
        r2.putEnumerated(c("Chnl"), c("Chnl"), c("Trsp"));
        desc.putReference(c("T   "), r2);
        executeAction(c("setd"), desc, DialogModes.NO);
    }

    function baseName(n) { return String(n).replace(/\.[^.]+$/, ""); }

    function tempFolder() {
        var f = new Folder(Folder.temp.fsName + "/nova-trame");
        if (!f.exists) f.create();
        return f;
    }

    var SHAPES = {
        round: BitmapHalfToneType.ROUND, ellipse: BitmapHalfToneType.ELLIPSE, line: BitmapHalfToneType.LINE,
        square: BitmapHalfToneType.SQUARE, diamond: BitmapHalfToneType.DIAMOND, cross: BitmapHalfToneType.CROSS
    };

    /* Áp kiểu trame gốc của Photoshop cho tài liệu Grayscale 8-bit. Trả về true nếu đã thành Bitmap. */
    function applyStyle(d, o) {
        if (o.kind === "threshold") {
            d.activeLayer.threshold(Math.max(1, Math.min(255, Math.round(o.level))));
            log(L("Đã áp ngưỡng {0}", [Math.round(o.level)]));
            return false;
        }
        var opt = new BitmapConversionOptions();
        opt.resolution = d.resolution;
        if (o.kind === "bitmap") {
            opt.method = o.method === "patternDither" ? BitmapConversionType.PATTERNDITHER : BitmapConversionType.DIFFUSIONDITHER;
            log(L("Chuyển Bitmap: {0}", [o.method]));
        } else {
            opt.method = BitmapConversionType.HALFTONESCREEN;
            opt.frequency = o.lpi;
            opt.angle = o.angle;
            opt.shape = SHAPES[o.shape];
            log(L("Halftone {0}: {1} LPI, {2} độ", [o.shape, o.lpi, o.angle]));
        }
        d.changeMode(ChangeMode.BITMAP, opt);
        return true;
    }

    function underbase(d, choke) {
        d.activeLayer = d.layers[0];
        selectTransparency();
        if (choke > 0) d.selection.contract(new UnitValue(choke, "px"));
        var l = d.artLayers.add();
        l.name = L("Lớp trắng (underbase)");
        try {
            d.selection.fill(gray(255));
        } catch (e) {
            log("⚠ " + L("Vùng chọn rỗng sau khi co {0} px, lớp trắng để trống. Hãy giảm độ co.", [choke]));
        }
        d.selection.deselect();
        l.move(d, ElementPlacement.PLACEATEND);
        d.activeLayer = d.layers[0];
        log(L("Đã tạo lớp trắng (co {0} px)", [choke]));
    }

    /* Hoàn thiện DTF: ht là tài liệu chứa trame (grayscale hoặc RGB), src là tài liệu gốc còn mở. */
    /* Layer nền màu áo để xem kết quả. Phải tắt trước khi xuất file in. */
    function previewSolid(d, target) {
        var black = target === "dtfBlack";
        app.activeDocument = d;
        var keep = d.activeLayer;
        addFillLayer(d, gray(black ? 0 : 255), "preview solid", true);
        try { d.activeLayer = keep; } catch (e) { d.activeLayer = d.layers[0]; }
        log(L("Đã thêm layer \"preview solid\" (nền {0}) để xem. NHỚ TẮT layer này trước khi xuất file in.", [L(black ? "đen" : "trắng")]));
    }

    function dtfFinish(ht, src, o) {
        if (ht.mode != DocumentMode.RGB) ht.changeMode(ChangeMode.RGB);
        app.activeDocument = ht;
        // Áo đen: đục vùng tối (đảo kênh sáng). Áo trắng: đục vùng sáng.
        // keepInk: file trame do panel tạo, chấm đen = phần được in -> xóa chỗ trắng.
        // Kiểu gốc Photoshop (áo đen): chấm đen nằm ở vùng tối -> xóa chỗ chấm.
        ht.selection.load(ht.channels[0], SelectionType.REPLACE, !o.keepInk && o.target === "dtfBlack");
        var a = ht.channels.add();
        a.name = "NOVA Trame";
        ht.selection.store(a, SelectionType.REPLACE);
        ht.selection.deselect();
        ht.activeChannels = ht.componentChannels;
        a.visible = false;

        // Lấy hình màu từ file gốc.
        app.activeDocument = src;
        var col = src.duplicate("nova-tmp-color", false);
        col.flatten();
        col.artLayers[0].isBackgroundLayer = false;
        col.artLayers[0].duplicate(ht, ElementPlacement.PLACEATBEGINNING);
        col.close(SaveOptions.DONOTSAVECHANGES);

        // Đục lỗ hình màu theo kênh trame.
        app.activeDocument = ht;
        var design = ht.layers[0];
        design.name = L("Thiết kế (trame)");
        ht.activeLayer = design;
        ht.selection.load(ht.channels.getByName("NOVA Trame"), SelectionType.REPLACE, false);
        ht.selection.clear();
        ht.selection.deselect();
        try { ht.backgroundLayer.remove(); }
        catch (e) { if (ht.layers.length > 1) ht.layers[ht.layers.length - 1].remove(); }
        ht.channels.getByName("NOVA Trame").remove();
        ht.activeLayer = ht.layers[0];

        if (o.underbase) underbase(ht, Math.max(0, o.choke));
        ht.activeLayer = ht.layers[0];
        log(L("DTF: kết quả ở tài liệu \"{0}\". Xuất PNG trong suốt để đưa vào RIP.", [ht.name]));
        previewSolid(ht, o.target);
    }

    /* Trame bằng bộ lọc gốc của Photoshop. */
    function trame(o) {
        var src = requireDoc();
        if (src.mode == DocumentMode.BITMAP || src.mode == DocumentMode.INDEXEDCOLOR) {
            throw new Error(L("Hãy chuyển file sang RGB, CMYK hoặc Grayscale trước."));
        }
        log(L("Nguồn: {0}", [info(src)]));

        var ht = src.duplicate(baseName(src.name) + " - trame " + o.style, false);
        if (!hasBackground(ht)) addFillLayer(ht, o.target === "dtfBlack" ? gray(0) : gray(255), L("Màu áo"), true);
        ht.flatten();
        if (ht.bitsPerChannel != BitsPerChannelType.EIGHT) ht.bitsPerChannel = BitsPerChannelType.EIGHT;
        if (ht.mode != DocumentMode.GRAYSCALE) ht.changeMode(ChangeMode.GRAYSCALE);
        var isBitmap = applyStyle(ht, o);

        if (o.target === "screen") {
            if (isBitmap && o.keepGray) ht.changeMode(ChangeMode.GRAYSCALE);
            log("In lụa: kết quả ở tài liệu \"" + ht.name + "\"");
            return;
        }
        if (isBitmap) ht.changeMode(ChangeMode.GRAYSCALE);
        dtfFinish(ht, src, o);
    }

    /* Xuất ảnh gộp (giữ trong suốt) ra PNG tạm cho panel xử lý. maxDim = 0 nghĩa là giữ nguyên cỡ. */
    function exportImage(o) {
        var src = requireDoc();
        if (src.mode == DocumentMode.BITMAP || src.mode == DocumentMode.INDEXEDCOLOR) {
            throw new Error(L("Hãy chuyển file sang RGB, CMYK hoặc Grayscale trước."));
        }
        var w = Math.round(src.width.as("px")), h = Math.round(src.height.as("px"));
        var dup = src.duplicate("nova-export", true);
        if (dup.mode != DocumentMode.RGB) dup.changeMode(ChangeMode.RGB);
        if (dup.bitsPerChannel != BitsPerChannelType.EIGHT) dup.bitsPerChannel = BitsPerChannelType.EIGHT;
        var ox = 0, oy = 0;
        if (o.crop) {
            // cận cảnh: cắt một vùng ở đúng độ phân giải in (không thu nhỏ)
            var cw = Math.min(w, Math.round(o.crop.size)), ch = Math.min(h, Math.round(o.crop.size));
            ox = Math.max(0, Math.min(w - cw, Math.round(o.crop.cx * w - cw / 2)));
            oy = Math.max(0, Math.min(h - ch, Math.round(o.crop.cy * h - ch / 2)));
            dup.crop([new UnitValue(ox, "px"), new UnitValue(oy, "px"), new UnitValue(ox + cw, "px"), new UnitValue(oy + ch, "px")]);
        } else if (o.maxDim > 0 && (w > o.maxDim || h > o.maxDim)) {
            var s = o.maxDim / (w > h ? w : h);
            dup.resizeImage(new UnitValue(Math.round(w * s), "px"), new UnitValue(Math.round(h * s), "px"),
                undefined, ResampleMethod.BICUBIC);
        }
        var f = new File(tempFolder().fsName + "/nova-src.png");
        var po = new PNGSaveOptions();
        po.compression = 6;
        po.interlaced = false;
        dup.saveAs(f, po, true, Extension.LOWERCASE);
        dup.close(SaveOptions.DONOTSAVECHANGES);
        app.activeDocument = src;
        log("DATA|" + f.fsName + "|" + w + "|" + h + "|" + Math.round(src.resolution) + "|" + src.name + "|" + ox + "|" + oy);
    }

    /* Nhận file trame đen trắng do panel kết xuất, hoàn thiện theo mục đích in. */
    function applyTrameFile(o) {
        var src;
        try { src = app.documents.getByName(o.srcName); }
        catch (e) { throw new Error(L("Không tìm thấy tài liệu gốc \"{0}\" (đã bị đóng?).", [o.srcName])); }
        var f = new File(o.path);
        if (!f.exists) throw new Error(L("Không thấy file trame tạm: {0}", [o.path]));
        var ht = app.open(f);
        try { ht.resizeImage(undefined, undefined, o.dpi, ResampleMethod.NONE); } catch (e2) {}
        if (Math.round(ht.width.as("px")) != Math.round(src.width.as("px"))) {
            log("⚠ " + L("Kích thước trame khác tài liệu gốc."));
        }
        if (o.target === "screen") {
            if (ht.mode != DocumentMode.GRAYSCALE) ht.changeMode(ChangeMode.GRAYSCALE);
            if (!o.keepGray) {
                var bo = new BitmapConversionOptions();
                bo.resolution = o.dpi;
                bo.method = BitmapConversionType.HALFTHRESHOLD;
                ht.changeMode(ChangeMode.BITMAP, bo);
            }
            log("In lụa: kết quả ở tài liệu \"" + ht.name + "\"");
            return;
        }
        dtfFinish(ht, src, o);
    }

    /* Mở PNG tạm, đổi DPI, đổi tên thành tài liệu mới; trả về tài liệu. */
    function openTemp(path, dpi, name) {
        var f = new File(path);
        if (!f.exists) throw new Error(L("Không thấy file tạm: {0}", [path]));
        var tmp = app.open(f);
        try { tmp.resizeImage(undefined, undefined, dpi, ResampleMethod.NONE); } catch (e) {}
        var d = tmp.duplicate(name, false);
        tmp.close(SaveOptions.DONOTSAVECHANGES);
        app.activeDocument = d;
        return d;
    }

    function layerFromBackground(d, name) {
        var l = d.layers[0];
        if (l.isBackgroundLayer) l.isBackgroundLayer = false;
        l.name = name;
        return l;
    }

    /* Trame màu cho DTF: ảnh RGBA đã ghép 4 màu, chỗ không có mực là trong suốt. */
    function applyColorFile(o) {
        var d = openTemp(o.path, o.dpi, baseName(o.srcName) + " - trame mau " + o.style);
        layerFromBackground(d, L("Trame màu ({0})", [o.style]));
        if (o.target === "dtfBlack" && o.underbase) underbase(d, Math.max(0, o.choke));
        d.activeLayer = d.layers[0];
        log(L("Trame màu: kết quả ở tài liệu \"{0}\". Xuất PNG trong suốt để đưa vào RIP.", [d.name]));
        previewSolid(d, o.target);
    }

    /* In lụa: mỗi màu một phim (đen trên trắng) thành từng layer, chế độ Multiply để xem chồng. */
    function applyFilms(o) {
        var d = openTemp(o.paths[0], o.dpi, baseName(o.srcName) + " - phim tach mau");
        layerFromBackground(d, o.names[0]);
        d.layers[0].blendMode = BlendMode.MULTIPLY;
        for (var i = 1; i < o.paths.length; i++) {
            var src = openTemp(o.paths[i], o.dpi, "nova-film-" + i);
            var l = layerFromBackground(src, o.names[i]);
            l.duplicate(d, ElementPlacement.PLACEATBEGINNING);
            src.close(SaveOptions.DONOTSAVECHANGES);
            app.activeDocument = d;
            d.layers[0].blendMode = BlendMode.MULTIPLY;
        }
        addFillLayer(d, gray(255), L("Nền trắng"), true);
        d.activeLayer = d.layers[0];
        log("In lụa: " + o.paths.length + " phim tách màu ở tài liệu \"" + d.name + "\" (mỗi layer một phim).");
    }

    /* Nhân bản layer đang chọn thành lưới phủ kín tài liệu. */
    function makePattern(o) {
        var d = requireDoc();
        var l = d.activeLayer;
        if (l.typename !== "ArtLayer" || l.isBackgroundLayer) {
            throw new Error(L("Hãy chọn một layer thường làm họa tiết (không phải Background)."));
        }
        var b = l.bounds;
        var x1 = b[0].as("px"), y1 = b[1].as("px"), x2 = b[2].as("px"), y2 = b[3].as("px");
        var w = x2 - x1, h = y2 - y1;
        if (w < 1 || h < 1) throw new Error(L("Layer họa tiết rỗng."));
        var stepX = w + Math.max(0, o.gapX), stepY = h + Math.max(0, o.gapY);
        var docW = d.width.as("px"), docH = d.height.as("px");
        var rStart = Math.ceil((-y1 - h) / stepY), rEnd = Math.floor((docH - y1) / stepY);
        var total = 0, r, cs, ce, cnt;
        for (r = rStart; r <= rEnd; r++) {
            var off = ((r % 2 + 2) % 2) * stepX * (o.offset / 100);
            cs = Math.ceil((-x1 - off - w) / stepX); ce = Math.floor((docW - x1 - off) / stepX);
            total += (ce - cs + 1);
        }
        if (total > 400) throw new Error(L("Lưới cần {0} bản sao (quá 400). Hãy tăng khoảng cách hoặc dùng họa tiết lớn hơn.", [total]));
        var grp = d.layerSets.add();
        grp.name = L("Họa tiết lặp");
        cnt = 0;
        for (r = rStart; r <= rEnd; r++) {
            var offX = ((r % 2 + 2) % 2) * stepX * (o.offset / 100);
            cs = Math.ceil((-x1 - offX - w) / stepX); ce = Math.floor((docW - x1 - offX) / stepX);
            for (var cI = cs; cI <= ce; cI++) {
                if (cI === 0 && r === 0 && offX === 0) continue; // vị trí gốc đã có layer gốc
                var cp = l.duplicate(grp, ElementPlacement.INSIDE);
                cp.translate(new UnitValue(cI * stepX + offX, "px"), new UnitValue(r * stepY, "px"));
                cnt++;
            }
        }
        log(L("Đã tạo {0} bản sao trong nhóm \"{1}\" (bước {2}x{3} px).", [cnt, grp.name, Math.round(stepX), Math.round(stepY)]));
    }

    /* Viền sticker quanh layer đang chọn. */
    function makeSticker(o) {
        var d = requireDoc();
        var l = d.activeLayer;
        if (l.typename !== "ArtLayer" || l.isBackgroundLayer) {
            throw new Error(L("Hãy chọn một layer thường (không phải Background)."));
        }
        var size = Math.max(1, o.size);
        selectTransparency();
        d.selection.expand(new UnitValue(size, "px"));
        if (o.smooth > 0) d.selection.smooth(o.smooth);
        var rgb = hexColor(o.color);
        var nl = d.artLayers.add();
        nl.name = L("Viền sticker");
        d.selection.fill(solid(rgb[0], rgb[1], rgb[2]));
        d.selection.deselect();
        nl.move(l, ElementPlacement.PLACEAFTER);
        d.activeLayer = l;
        log(L("Đã tạo viền sticker {0} px dưới layer \"{1}\".", [size, l.name]));
    }

    function newDoc(o) {
        if (!(o.w > 0 && o.h > 0 && o.dpi > 0)) throw new Error(L("Kích thước hoặc DPI không hợp lệ."));
        var mode = o.mode === "CMYK" ? NewDocumentMode.CMYK : o.mode === "GRAY" ? NewDocumentMode.GRAYSCALE : NewDocumentMode.RGB;
        var fill = o.bg === "white" ? DocumentFill.WHITE : DocumentFill.TRANSPARENT;
        var d = app.documents.add(new UnitValue(o.w, "cm"), new UnitValue(o.h, "cm"), o.dpi,
            "NOVA " + o.w + "x" + o.h + "cm", mode, fill);
        if (o.bg === "black") addFillLayer(d, gray(0), L("Nền đen"), false);
        log(L("Đã tạo: {0}", [info(d)]));
    }

    function rgbDesc(rgb) {
        var d = new ActionDescriptor();
        d.putDouble(c("Rd  "), rgb[0]);
        d.putDouble(c("Grn "), rgb[1]);
        d.putDouble(c("Bl  "), rgb[2]);
        return d;
    }

    function effects(o) {
        var d = requireDoc();
        if (d.activeLayer.typename !== "ArtLayer" || d.activeLayer.isBackgroundLayer) {
            throw new Error(L("Hãy chọn một layer thường (không phải Background hay nhóm)."));
        }
        if (!o.stroke && !o.shadow) throw new Error(L("Chưa chọn hiệu ứng nào."));
        var fx = new ActionDescriptor();
        fx.putUnitDouble(c("Scl "), c("#Prc"), 100);
        if (o.stroke) {
            var st = new ActionDescriptor();
            st.putBoolean(c("enab"), true);
            st.putEnumerated(c("Styl"), c("FStl"), stringIDToTypeID(o.strokePos));
            st.putEnumerated(c("PntT"), c("FrFl"), c("SClr"));
            st.putEnumerated(c("Md  "), c("BlnM"), c("Nrml"));
            st.putUnitDouble(c("Opct"), c("#Prc"), 100);
            st.putUnitDouble(c("Sz  "), c("#Pxl"), o.strokeSize);
            st.putObject(c("Clr "), c("RGBC"), rgbDesc(hexColor(o.strokeColor)));
            fx.putObject(c("FrFX"), c("FrFX"), st);
        }
        if (o.shadow) {
            var sh = new ActionDescriptor();
            sh.putBoolean(c("enab"), true);
            sh.putEnumerated(c("Md  "), c("BlnM"), c("Mltp"));
            sh.putObject(c("Clr "), c("RGBC"), rgbDesc([0, 0, 0]));
            sh.putUnitDouble(c("Opct"), c("#Prc"), o.shOpacity);
            sh.putBoolean(c("uglg"), false);
            sh.putUnitDouble(c("lagl"), c("#Ang"), o.shAngle);
            sh.putUnitDouble(c("Dstn"), c("#Pxl"), o.shDist);
            sh.putUnitDouble(c("Ckmt"), c("#Pxl"), 0);
            sh.putUnitDouble(c("blur"), c("#Pxl"), o.shBlur);
            sh.putUnitDouble(c("Nose"), c("#Prc"), 0);
            sh.putBoolean(c("AntA"), false);
            var curve = new ActionDescriptor();
            curve.putString(c("Nm  "), "Linear");
            sh.putObject(c("TrnS"), c("ShpC"), curve);
            sh.putBoolean(stringIDToTypeID("layerConceals"), true);
            fx.putObject(c("DrSh"), c("DrSh"), sh);
        }
        var desc = new ActionDescriptor();
        var ref = new ActionReference();
        ref.putProperty(c("Prpr"), c("Lefx"));
        ref.putEnumerated(c("Lyr "), c("Ordn"), c("Trgt"));
        desc.putReference(c("null"), ref);
        desc.putObject(c("T   "), c("Lefx"), fx);
        executeAction(c("setd"), desc, DialogModes.NO);
        log(L("Đã áp hiệu ứng cho layer \"{0}\"", [d.activeLayer.name]));
    }

    return {
        ping: function () { return "OK\nPhotoshop " + app.version; },
        info: function () {
            return run(function () {
                var d = requireDoc();
                log(info(d));
                var r = d.resolution;
                log("DATA|" + (d.width.as("px") / r * 2.54).toFixed(2) + "|" + (d.height.as("px") / r * 2.54).toFixed(2) + "|" + Math.round(r));
            });
        },
        trame: function (o) { return run(trame, o); },
        exportImage: function (o) { return run(exportImage, o); },
        applyTrameFile: function (o) { return run(applyTrameFile, o); },
        applyColorFile: function (o) { return run(applyColorFile, o); },
        applyFilms: function (o) { return run(applyFilms, o); },
        makePattern: function (o) { return run(makePattern, o); },
        makeSticker: function (o) { return run(makeSticker, o); },
        newDoc: function (o) { return run(newDoc, o); },
        effects: function (o) { return run(effects, o); }
    };
})();
