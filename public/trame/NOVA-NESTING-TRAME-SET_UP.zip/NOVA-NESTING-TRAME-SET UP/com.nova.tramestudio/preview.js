/*
 * NOVA Trame Studio 0.9 - panel Xem trước.
 * Nhận ảnh từ panel chính qua sự kiện CEP (đường dẫn file PNG tạm), gửi lại lệnh làm mới / đổi chế độ.
 * ES5 để chạy được trên CEP cũ.
 */
(function () {
  var cep = window.__adobe_cep__;
  var state = { zoom: "fit", natW: 0, natH: 0 };
  function $(id) { return document.getElementById(id); }
  function T(src, args) { return window.NovaI18n ? window.NovaI18n.t(src, args) : src; }
  function each(list, fn) { Array.prototype.forEach.call(list, fn); }
  function show(id, on) { var el = $(id); if (on) el.classList.remove("hidden"); else el.classList.add("hidden"); }

  function send(type, data) {
    try {
      var env = JSON.parse(cep.getHostEnvironment());
      cep.dispatchEvent({ type: type, scope: "APPLICATION", appId: env.appId,
        extensionId: "com.nova.tramestudio.preview", data: JSON.stringify(data || {}) });
    } catch (e) {}
  }
  function on(type, fn) {
    try {
      cep.addEventListener(type, function (ev) {
        var d = ev && ev.data;
        if (typeof d === "string") { try { d = JSON.parse(d); } catch (e) { d = {}; } }
        fn(d || {});
      });
    } catch (e) {}
  }

  function applyZoom() {
    var img = $("pImg"), st = $("pStage");
    if (state.zoom === "fit") { st.className = "stage fit"; img.style.width = ""; img.style.height = ""; return; }
    st.className = "stage";
    var k = parseFloat(state.zoom);
    img.style.width = Math.round(state.natW * k) + "px";
    img.style.height = Math.round(state.natH * k) + "px";
  }

  function update(d) {
    if (!d.path) return;
    var r = window.cep && window.cep.fs ? window.cep.fs.readFile(d.path, window.cep.encoding.Base64) : null;
    if (!r || r.err !== 0) { $("pSub").textContent = T("Không đọc được ảnh xem trước."); return; }
    var img = $("pImg");
    img.onload = function () { state.natW = img.naturalWidth; state.natH = img.naturalHeight; applyZoom(); };
    img.src = "data:image/png;base64," + r.data;
    show("pImg", true);
    show("pWaiting", false);
    $("pTitle").textContent = d.label || T("Xem trước");
    $("pSub").textContent = [d.target, d.lpi, (d.w && d.h ? d.w + "×" + d.h + " px" : "")].filter(function (x) { return x; }).join(" · ");
    show("pWarn", !!d.warn);
    each(document.querySelectorAll(".pvm"), function (b) {
      if (b.getAttribute("data-mode") === d.mode) b.classList.add("active"); else b.classList.remove("active");
    });
  }

  function applyTheme() {
    try {
      var c = JSON.parse(cep.getHostEnvironment()).appSkinInfo.panelBackgroundColor.color;
      if ((c.red + c.green + c.blue) / 3 > 150) document.body.classList.add("light"); else document.body.classList.remove("light");
    } catch (e) {}
  }

  each(document.querySelectorAll(".pvm"), function (b) {
    b.addEventListener("click", function () {
      $("pSub").textContent = T("Đang lấy hình…");
      send("com.nova.trame.preview.cmd", { cmd: "mode", mode: b.getAttribute("data-mode") });
    });
  });
  each(document.querySelectorAll(".zb"), function (b) {
    b.addEventListener("click", function () {
      state.zoom = b.getAttribute("data-z");
      each(document.querySelectorAll(".zb"), function (x) { if (x === b) x.classList.add("active"); else x.classList.remove("active"); });
      applyZoom();
    });
  });
  $("pRefresh").addEventListener("click", function () {
    $("pSub").textContent = T("Đang lấy hình…");
    send("com.nova.trame.preview.cmd", { cmd: "refresh" });
  });

  on("com.nova.trame.preview.update", function (d) { if (d.lang) setLang(d.lang); update(d); });
  // đổi ngôn ngữ theo panel chính
  function setLang(l) {
    if (!window.NovaI18n || window.NovaI18n.lang === l) return;
    window.NovaI18n.set(l);
    window.NovaI18n.apply(document.body);
  }
  on("com.nova.trame.lang", function (d) { if (d.lang) setLang(d.lang); });
  // panel chính mở sau -> chào lại để nhận ảnh
  on("com.nova.trame.main.ready", function () { if (visible) send("com.nova.trame.preview.hello", {}); });

  /*
   * Nhịp tim: Photoshop có thể đóng panel mà không kịp báo. Panel chính không nhận nhịp tim
   * trong vài giây sẽ tự đưa ô xem trước về chỗ cũ.
   */
  var visible = true, lastSent = 0;
  function bye() { send("com.nova.trame.preview.bye", {}); }
  /*
   * Nhịp tim gửi từ vòng vẽ màn hình (requestAnimationFrame): khi Photoshop ẩn hoặc đóng panel,
   * vòng vẽ dừng hẳn nên nhịp tim dừng theo -> panel chính biết ngay để đưa ô xem trước về.
   * (setInterval vẫn chạy cả khi panel bị ẩn nên không dùng được.)
   */
  function beat(ts) {
    var now = Date.now();
    if (visible && !document.hidden && now - lastSent > 350) {
      lastSent = now;
      send("com.nova.trame.preview.alive", {});
    }
    window.requestAnimationFrame(beat);
  }
  window.requestAnimationFrame(beat);
  on("com.adobe.csxs.events.WindowVisibilityChanged", function (d) {
    var v = d === true || d === "true" || (d && (d.data === true || d.data === "true"));
    visible = !!v;
    if (visible) send("com.nova.trame.preview.hello", {}); else bye();
  });
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) bye(); else if (visible) send("com.nova.trame.preview.hello", {});
  });
  window.addEventListener("beforeunload", bye);
  window.addEventListener("pagehide", bye);
  window.addEventListener("unload", bye);

  applyTheme();
  try { cep.addEventListener("com.adobe.csxs.events.ThemeColorChanged", applyTheme); } catch (e) {}
  send("com.nova.trame.preview.hello", {});
})();
