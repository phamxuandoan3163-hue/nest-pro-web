/*
 * NOVA Trame Studio - engine xử lý pixel (ES5, chạy trong panel CEP lẫn Node để test).
 * Mọi hàm làm việc trên mảng phẳng; "dark" là độ đậm 0..1 (1 = đen tuyền).
 */
(function (root, factory) {
  var E = factory();
  // In CEP mixed-context both `module` and `window` exist, so expose on both:
  if (typeof module === "object" && module.exports) module.exports = E;
  if (root) root.NovaEngine = E;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  var E = {};

  /* Ghép ảnh RGBA lên nền màu áo, trả về độ đậm từng pixel. */
  E.darkness = function (rgba, w, h, shirt) {
    var out = new Float32Array(w * h);
    for (var i = 0, p = 0; i < out.length; i++, p += 4) {
      var a = rgba[p + 3] / 255;
      var r = rgba[p] * a + shirt[0] * (1 - a);
      var g = rgba[p + 1] * a + shirt[1] * (1 - a);
      var b = rgba[p + 2] * a + shirt[2] * (1 - a);
      out[i] = 1 - (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    }
    return out;
  };

  /* Ghép ảnh RGBA lên nền màu áo, trả về RGB 8-bit (để hiển thị xem trước). */
  E.composite = function (rgba, w, h, shirt) {
    var out = new Uint8Array(w * h * 3);
    for (var i = 0, p = 0, q = 0; i < w * h; i++, p += 4, q += 3) {
      var a = rgba[p + 3] / 255;
      out[q] = Math.round(rgba[p] * a + shirt[0] * (1 - a));
      out[q + 1] = Math.round(rgba[p + 1] * a + shirt[1] * (1 - a));
      out[q + 2] = Math.round(rgba[p + 2] * a + shirt[2] * (1 - a));
    }
    return out;
  };

  /* Hàm điểm cho halftone: giá trị nhỏ được tô mực trước. u, v trong [-1, 1]. */
  function spot(shape, u, v) {
    var au = u < 0 ? -u : u, av = v < 0 ? -v : v;
    switch (shape) {
      case "round":   return (u * u + v * v) / 2;
      case "square":  var m = au > av ? au : av; return m * m;
      case "diamond": return (au + av) / 2;
      case "ellipse": return (u * u + (v * 1.7) * (v * 1.7)) / 3;
      case "line":    return av;
      case "cross":   return au < av ? au : av;
      case "triangle":
        // Tam giác đều đỉnh hướng lên; chuẩn hóa để vùng đen 100% phủ kín ô.
        var t1 = v, t2 = 0.866 * u - 0.5 * v, t3 = -0.866 * u - 0.5 * v;
        var tm = t1 > t2 ? t1 : t2; if (t3 > tm) tm = t3;
        return tm / 1.366;
      case "star":
        // Ngôi sao 5 cánh: bán kính thay đổi theo góc.
        var r = Math.sqrt(u * u + v * v);
        var g = 0.62 + 0.38 * Math.cos(5 * Math.atan2(u, -v));
        return r / g;
      case "euclid":
        // Chấm Euclid kinh điển: tròn ở vùng sáng, bàn cờ ở 50%, lỗ tròn ở vùng tối.
        return au + av <= 1 ? (u * u + v * v) - 1 : 1 - ((au - 1) * (au - 1) + (av - 1) * (av - 1));
      case "dash":     var dm = au * 0.4 > av ? au * 0.4 : av; return dm;
      case "hexagon":  var hx = 0.866 * au + 0.5 * av; return hx > av ? hx : av;
      case "donut":    return Math.abs(Math.sqrt(u * u + v * v) - 0.55);
      case "roundsq":   return Math.pow(au * au * au * au + av * av * av * av, 0.25);
      case "clover":    var rc = Math.sqrt(u * u + v * v), tc = Math.atan2(v, u); return rc / (0.5 + 0.5 * Math.abs(Math.cos(2 * tc)));
      case "flower":    var rf = Math.sqrt(u * u + v * v), tf = Math.atan2(v, u); return rf / (0.62 + 0.38 * Math.abs(Math.cos(3 * tf)));
      case "gear":      var rg = Math.sqrt(u * u + v * v), tg = Math.atan2(v, u); return rg / (0.84 + 0.16 * (Math.cos(8 * tg) > 0 ? 1 : -1));
      case "drop":
        // giọt nước: đáy tròn, đỉnh nhọn hướng lên
        var rd = Math.sqrt(u * u + v * v), td = Math.atan2(-v, u);
        return rd / (0.42 + 0.58 * Math.pow((1 - Math.sin(td)) / 2, 1.4));
      case "bullseye":  var rb = Math.sqrt(u * u + v * v); return rb - 0.11 * Math.cos(rb * 15);
      case "squarering": var mq = au > av ? au : av; return Math.abs(mq - 0.55);
      case "heart":
        // Trái tim: chia bán kính cho đường bao trái tim theo góc.
        var hy = -v + 0.25, th = Math.atan2(hy, u), sth = Math.sin(th), cth = Math.cos(th);
        var rh = (sth * Math.sqrt(Math.abs(cth))) / (sth + 1.4) - 2 * sth + 2;
        return Math.sqrt(u * u + hy * hy) / (rh * 0.36);
    }
    return (u * u + v * v) / 2;
  }

  /*
   * Bảng hiệu chỉnh tông: với mỗi độ đậm 0..255, tìm ngưỡng spot sao cho tỉ lệ diện tích ô
   * được tô đúng bằng độ đậm. Lấy mẫu hàm điểm trên lưới 128×128 rồi lấy phân vị.
   */
  var LUT_CACHE = {};
  var STIPPLE_LUT = null;
  function toneLut(shape) {
    if (LUT_CACHE[shape]) return LUT_CACHE[shape];
    var N = 128, vals = new Float32Array(N * N), k = 0;
    for (var j = 0; j < N; j++) {
      for (var i = 0; i < N; i++) {
        vals[k++] = spot(shape, ((i + 0.5) / N) * 2 - 1, ((j + 0.5) / N) * 2 - 1);
      }
    }
    Array.prototype.sort.call(vals, function (a, b) { return a - b; });
    var lut = new Float32Array(256);
    for (var q = 0; q < 256; q++) {
      if (q === 0) { lut[q] = -1; continue; }
      if (q === 255) { lut[q] = 2; continue; }
      var idx = Math.round(q / 255 * vals.length);
      // ngưỡng nằm giữa hai mẫu kề nhau để "spot < ngưỡng" chọn đúng idx mẫu
      lut[q] = idx >= vals.length ? 2 : (idx <= 0 ? -1 : (vals[idx - 1] + vals[idx]) / 2);
    }
    LUT_CACHE[shape] = lut;
    return lut;
  }

  /* Độ mực theo khoảng cách tới tâm chấm trong lưới lục giác (tổ ong). */
  var HEX_R = 1 / Math.sqrt(3); // bán kính ô lục giác khi khoảng cách chấm = 1
  function hexThresholdR2(dark) {
    // Bán kính chấm sao cho tỉ lệ phủ xấp xỉ bằng độ đậm; chấm chạm nhau ở 90.7%.
    var g;
    if (dark <= 0.9069) g = dark / 1.2092;
    else g = 0.75 + (dark - 0.9069) / (1 - 0.9069) * 0.25;
    return g * HEX_R * HEX_R;
  }

  /* Tách ảnh RGBA (ghép trên nền trắng) thành 4 kênh độ đậm C, M, Y, K. gcr: 0..1 lượng đen thay thế. */
  E.cmyk = function (rgba, w, h, gcr) {
    var n = w * h, C = new Float32Array(n), M = new Float32Array(n), Y = new Float32Array(n), K = new Float32Array(n);
    if (gcr === undefined) gcr = 1;
    for (var i = 0, p = 0; i < n; i++, p += 4) {
      var a = rgba[p + 3] / 255;
      var r = 1 - a + a * rgba[p] / 255, g = 1 - a + a * rgba[p + 1] / 255, b = 1 - a + a * rgba[p + 2] / 255;
      var mx = r > g ? r : g; if (b > mx) mx = b;
      var k = (1 - mx) * gcr;
      var d = 1 - k;
      if (d < 1e-4) { C[i] = 0; M[i] = 0; Y[i] = 0; K[i] = 1; continue; }
      var c = (1 - r - k) / d, m = (1 - g - k) / d, y = (1 - b - k) / d;
      C[i] = c < 0 ? 0 : c > 1 ? 1 : c;
      M[i] = m < 0 ? 0 : m > 1 ? 1 : m;
      Y[i] = y < 0 ? 0 : y > 1 ? 1 : y;
      K[i] = k;
    }
    return { c: C, m: M, y: Y, k: K };
  };

  /* Chỉ tách một kênh ("c","m","y","k") để tiết kiệm bộ nhớ với ảnh lớn. */
  E.cmykChannel = function (rgba, w, h, gcr, ch) {
    var n = w * h, out = new Float32Array(n);
    if (gcr === undefined) gcr = 1;
    for (var i = 0, p = 0; i < n; i++, p += 4) {
      var a = rgba[p + 3] / 255;
      var r = 1 - a + a * rgba[p] / 255, g = 1 - a + a * rgba[p + 1] / 255, b = 1 - a + a * rgba[p + 2] / 255;
      var mx = r > g ? r : g; if (b > mx) mx = b;
      var k = (1 - mx) * gcr;
      if (ch === "k") { out[i] = k; continue; }
      var d = 1 - k;
      if (d < 1e-4) continue;
      var v = (1 - (ch === "c" ? r : ch === "m" ? g : b) - k) / d;
      out[i] = v < 0 ? 0 : v > 1 ? 1 : v;
    }
    return out;
  };

  /*
   * Ghép các kênh trame thành ảnh màu RGBA trong suốt. inks: [{ink:Uint8Array, rgb:[r,g,b]}].
   * Mực chồng nhau nhân màu (multiply). Chỗ không có mực: alpha = 0.
   */
  E.compositeInks = function (inks, w, h) {
    var n = w * h, out = new Uint8ClampedArray(n * 4);
    for (var i = 0, p = 0; i < n; i++, p += 4) {
      var r = 1, g = 1, b = 1, any = 0;
      for (var j = 0; j < inks.length; j++) {
        if (inks[j].ink[i]) {
          var c = inks[j].rgb;
          r *= c[0] / 255; g *= c[1] / 255; b *= c[2] / 255; any = 1;
        }
      }
      if (any) { out[p] = Math.round(r * 255); out[p + 1] = Math.round(g * 255); out[p + 2] = Math.round(b * 255); out[p + 3] = 255; }
    }
    return out;
  };

  E.KERNELS = {
    fs:       { div: 16, pts: [[1, 0, 7], [-1, 1, 3], [0, 1, 5], [1, 1, 1]] },
    atkinson: { div: 8,  pts: [[1, 0, 1], [2, 0, 1], [-1, 1, 1], [0, 1, 1], [1, 1, 1], [0, 2, 1]] },
    stucki:   { div: 42, pts: [[1, 0, 8], [2, 0, 4], [-2, 1, 2], [-1, 1, 4], [0, 1, 8], [1, 1, 4], [2, 1, 2],
                               [-2, 2, 1], [-1, 2, 2], [0, 2, 4], [1, 2, 2], [2, 2, 1]] },
    jarvis:   { div: 48, pts: [[1, 0, 7], [2, 0, 5], [-2, 1, 3], [-1, 1, 5], [0, 1, 7], [1, 1, 5], [2, 1, 3],
                               [-2, 2, 1], [-1, 2, 3], [0, 2, 5], [1, 2, 3], [2, 2, 1]] }
  };

  function bayerMatrix(n) {
    var m = [[0]];
    while (m.length < n) {
      var k = m.length, nm = [];
      for (var y = 0; y < 2 * k; y++) {
        nm[y] = [];
        for (var x = 0; x < 2 * k; x++) {
          nm[y][x] = 4 * m[y % k][x % k] + [[0, 2], [3, 1]][(y / k) | 0][(x / k) | 0];
        }
      }
      m = nm;
    }
    return m;
  }

  /*
   * Kết xuất trame. spec:
   *   { t:"halftone", shape, periodPx, angleDeg }
   *   { t:"diffusion", kernel }
   *   { t:"ordered", n }
   *   { t:"random", seed }
   *   { t:"threshold", level }  // level: độ đậm 0..1, đậm hơn thì tô mực
   *   { t:"hex", periodPx, angleDeg }          // chấm tròn lưới tổ ong
   *   { t:"rings"|"spiral"|"radial", periodPx } // tâm ở giữa ảnh
   *   { t:"wave"|"hatch", periodPx, angleDeg }
   * Trả về Uint8Array (1 = mực).
   */
  function renderCore(spec, dark, w, h) {
    var ink = new Uint8Array(w * h);
    var FR = spec.frame, fw = FR ? FR.fw : w, fh = FR ? FR.fh : h, fox = FR ? FR.ox : 0, foy = FR ? FR.oy : 0;
    var x, y, i;

    if (spec.t === "halftone") {
      var period = spec.periodPx > 0.5 ? spec.periodPx : 0.5;
      var rad = (spec.angleDeg || 0) * Math.PI / 180;
      var ca = Math.cos(rad), sa = Math.sin(rad);
      var tl = toneLut(spec.shape);
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          var dh = dark[i];
          if (dh <= 0) continue;
          if (dh >= 0.995) { ink[i] = 1; continue; }
          var gx0 = x + 0.5 + fox, gy0 = y + 0.5 + foy;
          var rx = (gx0 * ca + gy0 * sa) / period;
          var ry = (-gx0 * sa + gy0 * ca) / period;
          var u = (rx - Math.floor(rx)) * 2 - 1;
          var v = (ry - Math.floor(ry)) * 2 - 1;
          if (spec.jitter) {
            // mỗi ô xoay một góc ngẫu nhiên -> chấm trông tự nhiên, không thẳng hàng
            var ja = hash2(Math.floor(rx), Math.floor(ry), 91) * 6.2832, jc = Math.cos(ja), js = Math.sin(ja);
            var ju = u * jc - v * js; v = u * js + v * jc; u = ju;
          }
          if (spot(spec.shape, u, v) < tl[(dh * 255 + 0.5) | 0]) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "hex") {
      // Lưới tổ ong: a1 = (1,0), a2 = (1/2, √3/2), xoay theo angleDeg.
      var hp = spec.periodPx > 0.5 ? spec.periodPx : 0.5;
      var hr = (spec.angleDeg || 0) * Math.PI / 180, hc = Math.cos(hr), hs = Math.sin(hr);
      var SQ3 = Math.sqrt(3), lut = new Float32Array(256);
      for (var li = 0; li < 256; li++) lut[li] = hexThresholdR2(li / 255);
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          var dv = dark[i];
          if (dv <= 0) continue;
          if (dv >= 0.995) { ink[i] = 1; continue; }
          var px = ((x + 0.5 + fox) * hc + (y + 0.5 + foy) * hs) / hp;
          var py = (-(x + 0.5 + fox) * hs + (y + 0.5 + foy) * hc) / hp;
          var bj = py * 2 / SQ3, bi = px - bj / 2;
          var fi = Math.floor(bi), fj = Math.floor(bj), best = 9;
          for (var di = 0; di <= 1; di++) {
            for (var dj = 0; dj <= 1; dj++) {
              var ci = fi + di, cj = fj + dj;
              var qx = px - (ci + cj / 2), qy = py - cj * SQ3 / 2;
              var dd = qx * qx + qy * qy;
              if (dd < best) best = dd;
            }
          }
          if (best < lut[(dv * 255) | 0]) ink[i] = 1;
        }
      }
      return ink;
    }

    // Các kiểu dạng đường: tính "pha" rồi tô nét có độ dày tỉ lệ độ đậm.
    if (spec.t === "rings" || spec.t === "spiral" || spec.t === "wave" || spec.t === "radial" || spec.t === "hatch" ||
        spec.t === "squarerings" || spec.t === "spiderweb") {
      var pp = spec.periodPx > 0.5 ? spec.periodPx : 0.5;
      var cxp = fw / 2 - fox, cyp = fh / 2 - foy;
      var ar = (spec.angleDeg || 0) * Math.PI / 180, ac = Math.cos(ar), as = Math.sin(ar);
      var spokes = Math.max(12, Math.round(Math.PI * Math.min(fw, fh) * 0.5 / pp));
      // Nhiều tâm: spec.centers = [{x, y (0..1 theo khung), r (tỉ lệ cạnh ngắn), dir (±1)}]
      var radialish = spec.t === "rings" || spec.t === "spiral" || spec.t === "radial" || spec.t === "squarerings" || spec.t === "spiderweb";
      var cen = radialish && spec.centers && spec.centers.length ? spec.centers : null;
      var mn = Math.min(fw, fh), ncx, ncy, ncr, ncd, nsp, nc = 0;
      if (cen) {
        nc = cen.length;
        ncx = new Float32Array(nc); ncy = new Float32Array(nc); ncr = new Float32Array(nc); ncd = new Float32Array(nc); nsp = new Float32Array(nc);
        for (var q0 = 0; q0 < nc; q0++) {
          ncx[q0] = cen[q0].x * fw - fox; ncy[q0] = cen[q0].y * fh - foy; ncr[q0] = 1 / Math.max(1, cen[q0].r * mn);
          ncd[q0] = cen[q0].dir < 0 ? -1 : 1;
          nsp[q0] = Math.max(8, Math.round(Math.PI * cen[q0].r * mn / pp));
        }
      }
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          var dk = dark[i];
          if (dk <= 0) continue;
          if (dk >= 0.995) { ink[i] = 1; continue; }
          var X = x + 0.5 - cxp, Y = y + 0.5 - cyp, ph, dir = 1, spk = spokes;
          if (cen) {
            // vùng thuộc về tâm có khoảng cách/bán kính nhỏ nhất -> tâm to lấn tâm nhỏ
            var bq = 0, bv = 1e9;
            for (var q1 = 0; q1 < nc; q1++) {
              var ex = x + 0.5 - ncx[q1], ey = y + 0.5 - ncy[q1], ev = (ex * ex + ey * ey) * ncr[q1] * ncr[q1];
              if (ev < bv) { bv = ev; bq = q1; }
            }
            X = x + 0.5 - ncx[bq]; Y = y + 0.5 - ncy[bq]; dir = ncd[bq]; spk = nsp[bq];
          }
          if (spec.t === "rings") ph = Math.sqrt(X * X + Y * Y) / pp;
          else if (spec.t === "squarerings") ph = Math.max(Math.abs(X), Math.abs(Y)) / pp;
          else if (spec.t === "spiderweb") {
            // mạng nhện: vòng tròn + tia; hai lớp nét có tổng độ phủ = độ đậm
            var rw = Math.sqrt(X * X + Y * Y), f1w = rw / (pp * 1.6), f2w = (Math.atan2(Y, X) / (2 * Math.PI) + 0.5) * Math.max(8, spk * 0.5);
            var aw = 1 - Math.sqrt(1 - dk);
            if (Math.abs((f1w - Math.floor(f1w)) * 2 - 1) < aw || Math.abs((f2w - Math.floor(f2w)) * 2 - 1) < aw) ink[i] = 1;
            continue;
          }
          else if (spec.t === "spiral") ph = Math.sqrt(X * X + Y * Y) / pp + dir * Math.atan2(Y, X) / (2 * Math.PI);
          else if (spec.t === "radial") {
            // gần tâm các tia dồn quá dày -> dùng vòng tròn nhỏ làm lõi
            var rr0 = Math.sqrt(X * X + Y * Y);
            ph = rr0 < spk * pp / (2 * Math.PI) * 0.35 ? rr0 / pp : (Math.atan2(Y, X) / (2 * Math.PI) + 0.5) * spk;
          }
          else if (spec.t === "wave") {
            var wx = X * ac + Y * as, wy = -X * as + Y * ac;
            ph = (wy + pp * 0.45 * Math.sin(wx / (pp * 2.2))) / pp;
          } else { // hatch: lớp 1 theo góc, lớp 2 vuông góc chỉ xuất hiện ở vùng đậm
            var h1 = (X * ac + Y * as) / pp, h2 = (-X * as + Y * ac) / pp;
            var f1 = Math.abs((h1 - Math.floor(h1)) * 2 - 1), f2 = Math.abs((h2 - Math.floor(h2)) * 2 - 1);
            // Độ đậm ≤ 50%: chỉ một lớp nét. Trên 50%: lớp 1 giữ 50%, thêm lớp 2 để tổng phủ = độ đậm.
            if (dk <= 0.5) { if (f1 < dk) ink[i] = 1; }
            else if (f1 < 0.5 || f2 < dk * 2 - 1) ink[i] = 1;
            continue;
          }
          var fr = Math.abs((ph - Math.floor(ph)) * 2 - 1);
          if (fr < dk) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "diffusion") {
      var ker = E.KERNELS[spec.kernel] || E.KERNELS.fs;
      var pts = ker.pts, div = ker.div, np = pts.length;
      var buf = new Float32Array(dark); // bản sao để lan sai số
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          var oldv = buf[i];
          var newv = oldv >= 0.5 ? 1 : 0;
          if (newv) ink[i] = 1;
          var err = oldv - newv;
          if (err !== 0) {
            for (var k = 0; k < np; k++) {
              var nx = x + pts[k][0], ny = y + pts[k][1];
              if (nx >= 0 && nx < w && ny < h) buf[ny * w + nx] += err * pts[k][2] / div;
            }
          }
        }
      }
      return ink;
    }

    if (spec.t === "ordered") {
      var n = spec.n || 8, mat = bayerMatrix(n), n2 = n * n;
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          if ((mat[y % n][x % n] + 0.5) / n2 < dark[i]) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "random") {
      var seed = (spec.seed || 123456789) >>> 0;
      for (i = 0; i < dark.length; i++) {
        seed ^= seed << 13; seed >>>= 0;
        seed ^= seed >> 17;
        seed ^= seed << 5; seed >>>= 0;
        if ((seed % 10000) / 10000 < dark[i]) ink[i] = 1;
      }
      return ink;
    }

    if (spec.t === "threshold") {
      var lv = spec.level;
      for (i = 0; i < dark.length; i++) if (dark[i] >= lv) ink[i] = 1;
      return ink;
    }

    /* ---------- Kiểu dùng nhiễu (grunge, photocopy, hạt sần, mezzotint) ---------- */
    if (spec.t === "grain") {
      // Hạt sần vón cục: nhiễu nhiều tầng, kích thước hạt ~ periodPx.
      var gm = E.noiseMap(w, h, { scale: Math.max(1, spec.periodPx * 0.6), oct: 3, seed: spec.seed || 7, white: 0.35 });
      for (i = 0; i < dark.length; i++) if (gm[i] < dark[i]) ink[i] = 1;
      return ink;
    }
    if (spec.t === "mezzo") {
      // Mezzotint dạng sợi: nhiễu kéo dài theo chiều ngang.
      var mm = E.noiseMap(w, h, { scale: Math.max(0.7, spec.periodPx * 0.16), sx: 7, oct: 2, seed: 19, white: 0.2 });
      for (i = 0; i < dark.length; i++) if (mm[i] < dark[i]) ink[i] = 1;
      return ink;
    }
    if (spec.t === "photocopy") {
      // Ngưỡng gắt có rung nhiễu + hạt bắn, như bản photocopy.
      var pm = E.noiseMap(w, h, { scale: Math.max(1, spec.periodPx * 0.25), oct: 3, seed: 23, white: 0.5 });
      var lvp = spec.level === undefined ? 0.5 : spec.level, amp = spec.amp === undefined ? 0.45 : spec.amp;
      for (i = 0; i < dark.length; i++) if (dark[i] + (pm[i] - 0.5) * amp > lvp) ink[i] = 1;
      return ink;
    }

    if (spec.t === "stipple" && !spec.raw) {
      // Hiệu chỉnh tông một lần: đo độ phủ thực tế ở 33 mức trên mẫu nhỏ rồi đảo ngược.
      if (!STIPPLE_LUT) {
        var meas = [], S = 120, lvls = 33;
        for (var lq = 0; lq < lvls; lq++) {
          var tv = lq / (lvls - 1), td = new Float32Array(S * S);
          for (var tk = 0; tk < td.length; tk++) td[tk] = tv;
          var tink = renderCore({ t: "stipple", raw: true, periodPx: 12 }, td, S, S), tc = 0;
          for (tk = 0; tk < tink.length; tk++) tc += tink[tk];
          meas.push(tc / tink.length);
        }
        STIPPLE_LUT = new Float32Array(256);
        for (var tq = 0; tq < 256; tq++) {
          var want = tq / 255, j2 = 0;
          while (j2 < lvls - 2 && meas[j2 + 1] < want) j2++;
          var span0 = meas[j2 + 1] - meas[j2], fr0 = span0 > 0 ? (want - meas[j2]) / span0 : 0;
          fr0 = fr0 < 0 ? 0 : fr0 > 1 ? 1 : fr0;
          STIPPLE_LUT[tq] = (j2 + fr0) / (lvls - 1);
        }
      }
      var cd = new Float32Array(dark.length);
      for (i = 0; i < dark.length; i++) cd[i] = dark[i] >= 0.985 ? 1 : STIPPLE_LUT[(dark[i] * 255 + 0.5) | 0];
      return renderCore({ t: "stipple", raw: true, periodPx: spec.periodPx }, cd, w, h);
    }
    if (spec.t === "stipple") {
      // Chấm bút kim: chấm cùng cỡ, mật độ theo độ đậm. Mỗi ô nhỏ có 1 điểm ngẫu nhiên.
      var q = Math.max(1.5, spec.periodPx * 0.45), r0 = 0.62 * q;
      var gw = Math.ceil(w / q) + 2, gh = Math.ceil(h / q) + 2;
      var ptx = new Float32Array(gw * gh), pty = new Float32Array(gw * gh), on = new Uint8Array(gw * gh);
      var prad = new Float32Array(gw * gh);
      for (var gy = 0; gy < gh; gy++) {
        for (var gx = 0; gx < gw; gx++) {
          var gi = gy * gw + gx;
          var sx0 = (gx - 1 + hash2(gx, gy, 1)) * q, sy0 = (gy - 1 + hash2(gx, gy, 2)) * q;
          ptx[gi] = sx0; pty[gi] = sy0;
          var sxi = sx0 < 0 ? 0 : sx0 >= w ? w - 1 : sx0 | 0, syi = sy0 < 0 ? 0 : sy0 >= h ? h - 1 : sy0 | 0;
          var dd0 = dark[syi * w + sxi];
          // bù chồng chấm: phủ ≈ 1 - e^(-1.2·A). A ≤ 1: bật bớt chấm; A > 1: bật hết và phóng to chấm.
          var A = -Math.log(1 - Math.min(dd0, 0.985)) / 1.21;
          on[gi] = hash2(gx, gy, 3) < A ? 1 : 0;
          var rr = A > 1 ? r0 * Math.pow(A, 0.3) : r0;
          prad[gi] = rr * rr;
        }
      }
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          if (dark[i] <= 0) continue;
          if (dark[i] >= 0.985) { ink[i] = 1; continue; }
          var cgx = ((x / q) | 0) + 1, cgy = ((y / q) | 0) + 1;
          for (var oy = -2; oy <= 2 && !ink[i]; oy++) {
            for (var ox = -2; ox <= 2; ox++) {
              var gj = (cgy + oy) * gw + (cgx + ox);
              if (gj < 0 || gj >= on.length || !on[gj]) continue;
              var ddx = x + 0.5 - ptx[gj], ddy = y + 0.5 - pty[gj];
              if (ddx * ddx + ddy * ddy < prad[gj]) { ink[i] = 1; break; }
            }
          }
        }
      }
      return ink;
    }

    if (spec.t === "celldot") {
      // Chấm tròn hoàn hảo theo độ đậm TRUNG BÌNH của từng ô (như bộ lọc Color Halftone).
      var cp = spec.periodPx > 1 ? spec.periodPx : 1;
      var cr = (spec.angleDeg || 0) * Math.PI / 180, cc = Math.cos(cr), cs = Math.sin(cr);
      var corners = [[0, 0], [w, 0], [0, h], [w, h]], imin = 1e9, imax = -1e9, jmin = 1e9, jmax = -1e9;
      for (var k0 = 0; k0 < 4; k0++) {
        var X0 = corners[k0][0], Y0 = corners[k0][1];
        var ii = Math.floor((X0 * cc + Y0 * cs) / cp), jj = Math.floor((-X0 * cs + Y0 * cc) / cp);
        if (ii < imin) imin = ii; if (ii > imax) imax = ii; if (jj < jmin) jmin = jj; if (jj > jmax) jmax = jj;
      }
      imin--; jmin--; imax++; jmax++;
      var cw = imax - imin + 1, ch = jmax - jmin + 1;
      var sum = new Float32Array(cw * ch), cnt = new Float32Array(cw * ch);
      var cidx = new Int32Array(w * h), cu = new Float32Array(w * h), cv = new Float32Array(w * h);
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          var rx2 = ((x + 0.5) * cc + (y + 0.5) * cs) / cp, ry2 = (-(x + 0.5) * cs + (y + 0.5) * cc) / cp;
          var fi2 = Math.floor(rx2), fj2 = Math.floor(ry2);
          var id = (fj2 - jmin) * cw + (fi2 - imin);
          cidx[i] = id; cu[i] = (rx2 - fi2) * 2 - 1; cv[i] = (ry2 - fj2) * 2 - 1;
          sum[id] += dark[i]; cnt[id]++;
        }
      }
      var tlc = toneLut(spec.shape || "round");
      for (i = 0; i < w * h; i++) {
        var av = sum[cidx[i]] / cnt[cidx[i]];
        if (av <= 0.002) continue;
        if (av >= 0.995 || spot(spec.shape || "round", cu[i], cv[i]) < tlc[(av * 255 + 0.5) | 0]) ink[i] = 1;
      }
      return ink;
    }

    if (spec.t === "contour") {
      // Đường đồng mức: các đường nối điểm cùng độ đậm, như bản đồ địa hình.
      var lv = spec.levels || 10, lw = Math.max(1, spec.periodPx * 0.18);
      var sm = boxBlur(dark, w, h, Math.max(1, Math.round(spec.periodPx * 0.3)));
      for (y = 1, i = w + 1; y < h - 1; y++, i += 2) {
        for (x = 1; x < w - 1; x++, i++) {
          var f = sm[i] * lv, frc = f - Math.round(f);
          var gxv = (sm[i + 1] - sm[i - 1]) * lv / 2, gyv = (sm[i + w] - sm[i - w]) * lv / 2;
          var gg = Math.sqrt(gxv * gxv + gyv * gyv);
          if (gg > 1e-5 && Math.abs(frc) / gg < lw / 2 && sm[i] > 0.02) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "squiggle") {
      // Sóng điều biến: các hàng ngang lượn sóng, vùng đậm sóng dày hơn.
      var sp = Math.max(2, spec.periodPx), amp2 = sp * 0.42, slw = Math.max(0.6, sp * 0.13);
      var rows = Math.ceil(h / sp) + 1, fmax = 2 * Math.PI / Math.max(2, sp * 0.45);
      var phs = new Float32Array(rows * w);
      for (var r0 = 0; r0 < rows; r0++) {
        var yc = Math.min(h - 1, Math.round((r0 + 0.5) * sp)), acc = 0;
        for (x = 0; x < w; x++) { acc += fmax * dark[yc * w + x]; phs[r0 * w + x] = acc; }
      }
      for (y = 0, i = 0; y < h; y++) {
        var r1 = Math.floor(y / sp), base0 = (r1 + 0.5) * sp;
        if (r1 >= rows) r1 = rows - 1;
        for (x = 0; x < w; x++, i++) {
          var yc2 = Math.min(h - 1, Math.round(base0)), dsq = dark[yc2 * w + x];
          var ph0 = phs[r1 * w + x];
          var yy0 = base0 + amp2 * Math.min(1, dsq * 1.6) * Math.sin(ph0);
          var slope = amp2 * Math.min(1, dsq * 1.6) * Math.cos(ph0) * fmax * dsq;
          if (Math.abs(y + 0.5 - yy0) / Math.sqrt(1 + slope * slope) < slw * (0.6 + dsq)) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "truchet" || spec.t === "fishscale" || spec.t === "polardots" || spec.t === "brick" ||
        spec.t === "seigaiha" || spec.t === "weave" || spec.t === "diamondplate" || spec.t === "lattice") {
      var tp = spec.periodPx > 1 ? spec.periodPx : 1;
      var lutT = FIELD_LUT[spec.t] || (FIELD_LUT[spec.t] = fieldLut(spec.t));
      var cxq = fw / 2 - fox, cyq = fh / 2 - foy;
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          var dq = dark[i];
          if (dq <= 0) continue;
          if (dq >= 0.995) { ink[i] = 1; continue; }
          var fv;
          if (spec.t === "polardots") {
            var PX = x + 0.5 - cxq, PY = y + 0.5 - cyq, pr = Math.sqrt(PX * PX + PY * PY) / tp;
            var ring = Math.round(pr), nseg = Math.max(1, Math.round(2 * Math.PI * ring));
            var pa = (Math.atan2(PY, PX) / (2 * Math.PI) + 0.5) * nseg;
            var pu = (pr - ring) * 2, pv = (pa - Math.round(pa)) * 2 * (ring === 0 ? 0 : 1);
            fv = (pu * pu + pv * pv) / 2;
          } else {
            var sxc = spec.t === "brick" ? 2 : 1;
            var gx2 = (x + 0.5 + fox) / (tp * sxc), gy2 = (y + 0.5 + foy) / tp, ci0 = Math.floor(gy2);
            if ((spec.t === "fishscale" || spec.t === "seigaiha" || spec.t === "brick") && (ci0 & 1)) gx2 += 0.5;
            fv = fieldValue(spec.t, gx2 - Math.floor(gx2), gy2 - ci0, Math.floor(gx2), ci0);
          }
          if (fv < lutT[(dq * 255 + 0.5) | 0]) ink[i] = 1;
        }
      }
      return ink;
    }

    // Các kiểu đường biến dạng: tính "pha", nét dày theo độ đậm (phủ mực chính xác).
    if (spec.t === "zigzag" || spec.t === "wood" || spec.t === "fingerprint" || spec.t === "bulge" ||
        spec.t === "twirl" || spec.t === "interference" || spec.t === "zebra" || spec.t === "marble") {
      var fp = spec.periodPx > 0.5 ? spec.periodPx : 0.5;
      var ccx = fw / 2 - fox, ccy = fh / 2 - foy, RR = Math.min(fw, fh) * 0.45;
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          var de = dark[i];
          if (de <= 0) continue;
          if (de >= 0.995) { ink[i] = 1; continue; }
          var XX = x + 0.5 - ccx, YY = y + 0.5 - ccy, phz, frz;
          if (spec.t === "zebra") {
            // vằn ngựa: sọc chéo bị uốn mạnh bởi nhiễu
            var zn = fbm((XX + fox) / (fp * 7), (YY + foy) / (fp * 7), 801, 3);
            phz = ((XX + YY * 0.35) / fp) * 0.45 + zn * 5.5;
          } else if (spec.t === "marble") {
            // vân đá cẩm thạch: vân mảnh uốn lượn
            var mn2 = fbm((XX + fox) / (fp * 12), (YY + foy) / (fp * 12), 811, 4);
            phz = (XX * 0.6 + YY) / (fp * 1.4) + mn2 * 9;
          } else if (spec.t === "zigzag") {
            var tz = XX / (fp * 1.5); tz = Math.abs(tz - Math.floor(tz) - 0.5) * 2;
            phz = (YY + tz * fp * 0.9) / fp;
          } else if (spec.t === "wood") {
            var wn = fbm(XX / (fp * 9), YY / (fp * 3), 5, 3);
            phz = Math.sqrt((XX + RR * 1.6) * (XX + RR * 1.6) * 0.15 + YY * YY) / fp + wn * 4;
          } else if (spec.t === "fingerprint") {
            var fn = fbm(XX / (fp * 6), YY / (fp * 6), 9, 2);
            phz = Math.sqrt(XX * XX * 1.35 + YY * YY) / fp + fn * 2.5 + Math.atan2(YY, XX) / (2 * Math.PI) * 0.0;
          } else if (spec.t === "bulge") {
            var rb = Math.sqrt(XX * XX + YY * YY) / RR, kb = rb < 1 ? (1 - rb * rb) : 0;
            phz = (YY * (1 - 0.55 * kb)) / fp;
          } else if (spec.t === "twirl") {
            var rt = Math.sqrt(XX * XX + YY * YY), at = 2.2 * Math.exp(-rt / (RR * 0.6));
            var ct = Math.cos(at), st = Math.sin(at);
            phz = (-XX * st + YY * ct) / fp;
          } else { // interference: tổng 2 hệ vòng tròn lệch tâm, phân bố đều hóa
            var d1 = Math.sqrt((XX + RR * 0.35) * (XX + RR * 0.35) + YY * YY) / fp;
            var d2 = Math.sqrt((XX - RR * 0.35) * (XX - RR * 0.35) + YY * YY) / fp;
            var a1 = Math.abs((d1 - Math.floor(d1)) * 2 - 1), a2 = Math.abs((d2 - Math.floor(d2)) * 2 - 1);
            var sAvg = (a1 + a2) / 2;
            frz = sAvg < 0.5 ? 2 * sAvg * sAvg : 1 - 2 * (1 - sAvg) * (1 - sAvg);
            if (frz < de) ink[i] = 1;
            continue;
          }
          frz = Math.abs((phz - Math.floor(phz)) * 2 - 1);
          if (frz < de) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "honeycomb") {
      // lưới tổ ong: vẽ đường viền các ô lục giác, nét dày theo độ đậm
      var hp2 = spec.periodPx > 1 ? spec.periodPx * 1.6 : 1.6, SQ = Math.sqrt(3);
      var lutH = FIELD_LUT.honeycomb || (FIELD_LUT.honeycomb = hexBorderLut());
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var dh2 = dark[i];
        if (dh2 <= 0) continue;
        if (dh2 >= 0.995) { ink[i] = 1; continue; }
        if (hexBorder((x + 0.5 + fox) / hp2, (y + 0.5 + foy) / hp2) < lutH[(dh2 * 255 + 0.5) | 0]) ink[i] = 1;
      }
      return ink;
    }

    if (spec.t === "voronoidots" || spec.t === "leopard") {
      // tế bào / da báo: mỗi ô một điểm ngẫu nhiên, chấm (hoặc vòng đốm) to theo độ đậm tại điểm đó
      var vc = Math.max(2, spec.periodPx * (spec.t === "leopard" ? 2.2 : 1));
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var dv2 = dark[i];
        if (dv2 <= 0) continue;
        if (dv2 >= 0.995) { ink[i] = 1; continue; }
        var vx = (x + 0.5 + fox) / vc, vy = (y + 0.5 + foy) / vc, vx0 = Math.floor(vx), vy0 = Math.floor(vy), b1 = 9, b2 = 9;
        for (var oy2 = -1; oy2 <= 1; oy2++) for (var ox2 = -1; ox2 <= 1; ox2++) {
          var gx4 = vx0 + ox2, gy4 = vy0 + oy2, px4 = gx4 + 0.15 + 0.7 * hash2(gx4, gy4, 501), py4 = gy4 + 0.15 + 0.7 * hash2(gx4, gy4, 503);
          var d4 = (vx - px4) * (vx - px4) + (vy - py4) * (vy - py4);
          if (d4 < b1) { b2 = b1; b1 = d4; } else if (d4 < b2) b2 = d4;
        }
        var r4 = Math.sqrt(b1);
        if (spec.t === "voronoidots") {
          // diện tích ô ~ 1 nên bán kính = √(độ đậm / π); vùng đậm thì chấm nối nhau
          if (r4 < Math.sqrt(dv2 / Math.PI) * 1.05 || Math.sqrt(b2) - r4 < (dv2 - 0.7) * 0.6) ink[i] = 1;
        } else {
          // đốm báo: vòng đốm không đều quanh điểm, giữa đốm rỗng ở vùng sáng
          var irr = 0.06 * (vnoise(vx * 3, vy * 3, 509) - 0.5);
          var ringR = 0.3 + irr, wR = dv2 * 0.3;
          if (Math.abs(r4 - ringR) < wR || r4 < (dv2 - 0.55) * 0.7) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "sunflower") {
      // hướng dương: chấm xếp theo góc vàng 137,5° tỏa từ giữa hình
      var sc = Math.max(1, spec.periodPx * 0.62), GA = 2.39996323, scx = fw / 2, scy = fh / 2;
      var Rmax = Math.sqrt(scx * scx + scy * scy) + sc * 2, N = Math.ceil((Rmax / sc) * (Rmax / sc));
      var bsz = Math.max(2, spec.periodPx), gw2 = Math.ceil(fw / bsz) + 2, gh2 = Math.ceil(fh / bsz) + 2;
      var heads = new Int32Array(gw2 * gh2).fill(-1), next = new Int32Array(N), pxs = new Float32Array(N), pys = new Float32Array(N), np2 = 0;
      for (var k5 = 0; k5 < N; k5++) {
        var rr5 = sc * Math.sqrt(k5 + 0.5), th5 = k5 * GA, X5 = scx + rr5 * Math.cos(th5), Y5 = scy + rr5 * Math.sin(th5);
        if (X5 < -bsz || Y5 < -bsz || X5 > fw + bsz || Y5 > fh + bsz) continue;
        var cell5 = (Math.floor(Y5 / bsz) + 1) * gw2 + (Math.floor(X5 / bsz) + 1);
        if (cell5 < 0 || cell5 >= heads.length) continue;
        pxs[np2] = X5; pys[np2] = Y5; next[np2] = heads[cell5]; heads[cell5] = np2; np2++;
      }
      var cellA = Math.PI * sc * sc; // diện tích mỗi điểm chiếm
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var ds = dark[i];
        if (ds <= 0) continue;
        if (ds >= 0.995) { ink[i] = 1; continue; }
        var AX = x + 0.5 + fox, AY = y + 0.5 + foy, best5 = 1e9;
        var cx5 = Math.floor(AX / bsz) + 1, cy5 = Math.floor(AY / bsz) + 1;
        for (var oy5 = -1; oy5 <= 1; oy5++) for (var ox5 = -1; ox5 <= 1; ox5++) {
          var c5 = (cy5 + oy5) * gw2 + (cx5 + ox5);
          if (c5 < 0 || c5 >= heads.length) continue;
          for (var q5 = heads[c5]; q5 >= 0; q5 = next[q5]) {
            var e5 = (AX - pxs[q5]) * (AX - pxs[q5]) + (AY - pys[q5]) * (AY - pys[q5]);
            if (e5 < best5) best5 = e5;
          }
        }
        if (best5 < ds * cellA / Math.PI * 1.08) ink[i] = 1;
      }
      return ink;
    }

    if (spec.t === "morse") {
      // mã Morse: hàng gạch và chấm; vùng sáng gạch ngắn, vùng đậm gạch dài và dày
      var mp = Math.max(2, spec.periodPx);
      for (y = 0, i = 0; y < h; y++) {
        var MY = (y + 0.5 + foy) / mp, row = Math.floor(MY), fv5 = Math.abs((MY - row) * 2 - 1);
        for (x = 0; x < w; x++, i++) {
          var dm = dark[i];
          if (dm <= 0) continue;
          if (dm >= 0.995) { ink[i] = 1; continue; }
          var thick = Math.max(0.45, dm), lenFrac = Math.min(1, dm / 0.45);
          var MX = (x + 0.5 + fox) / (mp * (hash2(row, 1, 601) < 0.5 ? 1.4 : 2.6)) + hash2(row, 2, 603);
          var seg = Math.floor(MX), fx5 = MX - seg, kind = hash2(seg, row, 607);
          var segLen = (kind < 0.4 ? 0.35 : 0.85) * lenFrac + (dm > 0.45 ? (dm - 0.45) : 0);
          if (fv5 < thick && fx5 < segLen) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "camo") {
      // rằn ri: các mảng loang to, phân bố đều nên độ phủ đúng bằng độ đậm
      var cm = E.noiseMap(w, h, { scale: Math.max(3, spec.periodPx * 2.4), oct: 3, seed: 701, white: 0, ox: fox, oy: foy });
      for (i = 0; i < dark.length; i++) if (cm[i] < dark[i]) ink[i] = 1;
      return ink;
    }

    if (spec.t === "sketch") {
      // ký họa bút chì: nét viền + gạch chéo ở vùng tối
      var kp = Math.max(2, spec.periodPx), ks = boxBlur(dark, w, h, Math.max(1, Math.round(kp * 0.2)));
      for (y = 1, i = w + 1; y < h - 1; y++, i += 2) for (x = 1; x < w - 1; x++, i++) {
        var gxk = ks[i + 1] - ks[i - 1], gyk = ks[i + w] - ks[i - w], gk = Math.sqrt(gxk * gxk + gyk * gyk);
        if (gk > 0.09) { ink[i] = 1; continue; }
        var dk3 = ks[i];
        if (dk3 > 0.35) {
          var h1k = ((x + 0.5 + fox) + (y + 0.5 + foy)) / kp, f1k = Math.abs((h1k - Math.floor(h1k)) * 2 - 1);
          var cov = (dk3 - 0.35) / 0.65;
          if (f1k < cov * 0.6) ink[i] = 1;
          if (dk3 > 0.65) {
            var h2k = ((x + 0.5 + fox) - (y + 0.5 + foy)) / kp, f2k = Math.abs((h2k - Math.floor(h2k)) * 2 - 1);
            if (f2k < (dk3 - 0.65) * 1.4) ink[i] = 1;
          }
        }
      }
      return ink;
    }

    /* ---------- Mặt nạ theo xu hướng áo thun (DTF: giữ màu, đục lỗ) ---------- */
    if (spec.t === "dotfade") {
      // Chấm chuyển dần theo hướng (không phụ thuộc tông ảnh), chỉ trong vùng có hình.
      var dr = (spec.angleDeg || 90) * Math.PI / 180, dcx = Math.cos(dr), dcy = Math.sin(dr);
      var c0 = 0, c1 = 0, cs0 = [[0, 0], [fw, 0], [0, fh], [fw, fh]];
      c0 = 1e9; c1 = -1e9;
      for (var k1 = 0; k1 < 4; k1++) { var pr0 = cs0[k1][0] * dcx + cs0[k1][1] * dcy; if (pr0 < c0) c0 = pr0; if (pr0 > c1) c1 = pr0; }
      var dd2 = new Float32Array(w * h);
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        if (dark[i] <= 0.02) continue;
        var tt = ((x + 0.5 + fox) * dcx + (y + 0.5 + foy) * dcy - c0) / (c1 - c0);
        dd2[i] = 1 - tt;
      }
      return renderCore({ t: "halftone", shape: spec.shape || "round", periodPx: spec.periodPx, angleDeg: 45, frame: spec.frame }, dd2, w, h);
    }

    if (spec.t === "sunset") {
      // Sọc hoàng hôn thập niên 70: nửa dưới hình bị cắt bởi các sọc ngang, khe hở to dần xuống dưới.
      var B = Math.max(2, spec.periodPx * 2.6), st = spec.start === undefined ? 0.42 : spec.start;
      for (y = 0, i = 0; y < h; y++) {
        var Y0 = y + 0.5 + foy, g = (Y0 / fh - st) / (1 - st);
        g = g < 0 ? 0 : g > 1 ? 1 : g;
        var gap = g * 0.82, fry = Y0 / B - Math.floor(Y0 / B);
        for (x = 0; x < w; x++, i++) if (dark[i] > 0.02 && fry >= gap) ink[i] = 1;
      }
      return ink;
    }

    if (spec.t === "crack") {
      // Mực nứt kiểu áo in lâu năm: các vết nứt theo ô Voronoi, vùng sáng nứt nhiều hơn.
      var C = Math.max(4, spec.periodPx * 4.2);
      for (y = 0, i = 0; y < h; y++) {
        for (x = 0; x < w; x++, i++) {
          if (dark[i] <= 0.02) continue;
          var ax = (x + 0.5 + fox) / C, ay = (y + 0.5 + foy) / C, cx0 = Math.floor(ax), cy0 = Math.floor(ay);
          var f1 = 9, f2 = 9;
          for (var jy = -1; jy <= 1; jy++) for (var jx = -1; jx <= 1; jx++) {
            var gx = cx0 + jx, gy = cy0 + jy;
            var qx = gx + hash2(gx, gy, 41), qy = gy + hash2(gx, gy, 43);
            var dq = (ax - qx) * (ax - qx) + (ay - qy) * (ay - qy);
            if (dq < f1) { f2 = f1; f1 = dq; } else if (dq < f2) f2 = dq;
          }
          var edge = Math.sqrt(f2) - Math.sqrt(f1);
          var wcr = 0.045 + 0.09 * (1 - dark[i]) + 0.05 * (hash2(cx0, cy0, 47) - 0.5);
          if (edge > wcr) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "engrave") {
      // Khắc tiền giấy: đường kẻ uốn theo khối sáng tối, dày mỏng theo độ đậm.
      var ep = spec.periodPx > 0.5 ? spec.periodPx : 0.5, er = (spec.angleDeg || 0) * Math.PI / 180, ec = Math.cos(er), es = Math.sin(er);
      var esm = boxBlur(dark, w, h, Math.max(1, Math.round(ep * 1.5)));
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var de2 = dark[i];
        if (de2 <= 0) continue;
        if (de2 >= 0.995) { ink[i] = 1; continue; }
        var phe = (-(x + 0.5 + fox) * es + (y + 0.5 + foy) * ec) / ep + esm[i] * 2.2;
        if (Math.abs((phe - Math.floor(phe)) * 2 - 1) < de2) ink[i] = 1;
      }
      return ink;
    }

    if (spec.t === "stencil") {
      // Stencil 3 tông kiểu graffiti: tối = đặc, trung tính = gạch chéo, sáng = bỏ trống.
      var sp2 = Math.max(2, spec.periodPx), lv1 = spec.level === undefined ? 0.6 : spec.level;
      var ssm = boxBlur(dark, w, h, Math.max(1, Math.round(sp2 * 0.25)));
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var sv = ssm[i];
        if (sv >= lv1) ink[i] = 1;
        else if (sv >= lv1 * 0.5) {
          var hs2 = ((x + 0.5 + fox) + (y + 0.5 + foy)) / sp2;
          if (hs2 - Math.floor(hs2) < 0.5) ink[i] = 1;
        }
      }
      return ink;
    }

    if (spec.t === "pixel1") {
      // Khảm pixel 1-bit: ô vuông to bật/tắt theo độ đậm trung bình, rung Bayer giữa các ô.
      var pb = Math.max(1, spec.periodPx * 0.9), bm = bayerMatrix(4);
      var bw = Math.ceil((w + fox % pb) / pb) + 1, bh = Math.ceil((h + foy % pb) / pb) + 1;
      var bsum = new Float32Array(bw * bh), bcnt = new Float32Array(bw * bh), bidx = new Int32Array(w * h);
      var bx0 = Math.floor(fox / pb), by0 = Math.floor(foy / pb);
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var bi = (Math.floor((y + foy) / pb) - by0) * bw + (Math.floor((x + fox) / pb) - bx0);
        bidx[i] = bi; bsum[bi] += dark[i]; bcnt[bi]++;
      }
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var gbx = Math.floor((x + fox) / pb), gby = Math.floor((y + foy) / pb);
        var avb = bsum[bidx[i]] / bcnt[bidx[i]];
        if (avb > (bm[((gby % 4) + 4) % 4][((gbx % 4) + 4) % 4] + 0.5) / 16) ink[i] = 1;
      }
      return ink;
    }

    if (spec.t === "ascii") {
      // Chữ ASCII / chữ tùy chọn: mỗi ô chọn ký tự có độ phủ gần với độ đậm trung bình.
      var G = spec.glyphs;
      if (!G || !G.levels || !G.levels.length) throw new Error("Thiếu bộ ký tự cho kiểu Chữ ASCII.");
      var cs3 = G.cell, nl = G.levels.length;
      var aw = Math.ceil(w / cs3) + 2, ah = Math.ceil(h / cs3) + 2, asum = new Float32Array(aw * ah), acnt = new Float32Array(aw * ah);
      var ax0 = Math.floor(fox / cs3), ay0 = Math.floor(foy / cs3);
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var ai = (Math.floor((y + foy) / cs3) - ay0) * aw + (Math.floor((x + fox) / cs3) - ax0);
        asum[ai] += dark[i]; acnt[ai]++;
      }
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var gx3 = Math.floor((x + fox) / cs3), gy3 = Math.floor((y + foy) / cs3);
        var a3 = asum[(gy3 - ay0) * aw + (gx3 - ax0)] / acnt[(gy3 - ay0) * aw + (gx3 - ax0)];
        if (a3 <= 0.02) continue;
        // chọn ký tự có độ phủ gần nhất (levels đã sắp theo độ phủ)
        var best3 = 0, bd3 = 9;
        for (var q3 = 0; q3 < nl; q3++) { var e3 = Math.abs(G.cover[q3] - a3); if (e3 < bd3) { bd3 = e3; best3 = q3; } }
        var lx = (x + fox) - gx3 * cs3, ly = (y + foy) - gy3 * cs3;
        if (G.levels[best3][(ly | 0) * cs3 + (lx | 0)]) ink[i] = 1;
      }
      return ink;
    }

    throw new Error("Kiểu trame không hỗ trợ: " + spec.t);
  }

  /* Bọc ngoài: hiệu ứng mờ dần, chấm âm, bong tróc áp được cho mọi kiểu. */
  E.render = function (spec, dark, w, h) {
    var d = dark, i, n = w * h;
    if (spec.fade) {
      // Mờ dần: độ đậm giảm về 0 theo hướng (bottom/top/edge) trên quãng fade (0..1 kích thước ảnh).
      d = new Float32Array(n);
      var FR2 = spec.frame, FW = FR2 ? FR2.fw : w, FH = FR2 ? FR2.fh : h, OX = FR2 ? FR2.ox : 0, OY = FR2 ? FR2.oy : 0;
      var span = spec.fade, cx = FW / 2 - OX, cy = FH / 2 - OY;
      for (var y = 0, k = 0; y < h; y++) {
        for (var x = 0; x < w; x++, k++) {
          var t;
          var ay = y + OY;
          if (spec.fadeDir === "top") t = ay / (FH * span);
          else if (spec.fadeDir === "edge") {
            var ex = (x + 0.5 - cx) / (FW / 2), ey = (y + 0.5 - cy) / (FH / 2);
            t = (1 - Math.sqrt(ex * ex + ey * ey)) / span;
          } else t = (FH - ay) / (FH * span);
          d[k] = dark[k] * (t > 1 ? 1 : t < 0 ? 0 : t);
        }
      }
    }
    if (spec.minDot || spec.maxDot) {
      // DTF: bột keo cần chấm đủ lớn. Chấm nhỏ hơn mức tối thiểu: dưới một nửa thì bỏ, còn lại nâng lên mức tối thiểu.
      // Vùng đậm hơn ngưỡng tô đặc thành nền đặc (tránh lỗ li ti không in được).
      var mnD = spec.minDot || 0, mxD = spec.maxDot || 1, src = d;
      d = new Float32Array(n);
      for (i = 0; i < n; i++) {
        var v = src[i];
        if (v < mnD) v = v < mnD * 0.5 ? 0 : mnD;
        if (v > mxD) v = 1;
        d[i] = v;
      }
    }
    if (spec.invert) {
      // Chấm âm: chấm trắng (lỗ) trên nền mực. Tính trame cho phần sáng rồi đảo.
      var inv = new Float32Array(n);
      for (i = 0; i < n; i++) inv[i] = d[i] > 0.002 ? 1 - d[i] : 0;
      var holes = renderCore(spec, inv, w, h), ink0 = new Uint8Array(n);
      for (i = 0; i < n; i++) ink0[i] = d[i] > 0.002 && !holes[i] ? 1 : 0;
      return spec.distress ? distress(ink0, w, h, spec) : ink0;
    }
    var ink = renderCore(spec, d, w, h);
    return spec.distress ? distress(ink, w, h, spec) : ink;
  };

  /* Bong tróc (grunge): xóa mực theo vết loang lớn + hạt nhỏ. amount 0..1. */
  function distress(ink, w, h, spec) {
    var p = spec.periodPx || 8;
    var FR3 = spec.frame, bmin = FR3 ? Math.min(FR3.fw, FR3.fh) : Math.min(w, h);
    var big = E.noiseMap(w, h, { scale: Math.max(4, bmin / 14), oct: 4, seed: 101, white: 0.0, ox: FR3 ? FR3.ox : 0, oy: FR3 ? FR3.oy : 0 });
    var fine = E.noiseMap(w, h, { scale: Math.max(1, p * 0.3), oct: 2, seed: 202, white: 0.6 });
    var a = spec.distress;
    for (var i = 0; i < ink.length; i++) {
      if (!ink[i]) continue;
      // vết loang lớn quyết định vùng mòn, hạt nhỏ làm mép rỗ
      var m = big[i] * 0.7 + fine[i] * 0.3;
      if (m < a) ink[i] = 0;
    }
    return ink;
  }

  /* ---------- Nhiễu ---------- */
  function hash2(i, j, seed) {
    var h = (Math.imul(i | 0, 374761393) + Math.imul(j | 0, 668265263) + Math.imul(seed | 0, 1442695041)) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  function vnoise(x, y, seed) {
    var xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    var u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    var a = hash2(xi, yi, seed), b = hash2(xi + 1, yi, seed), c = hash2(xi, yi + 1, seed), d = hash2(xi + 1, yi + 1, seed);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  function fbm(x, y, seed, oct) {
    var s = 0, a = 0.5, f = 1, n = 0;
    for (var o = 0; o < oct; o++) { s += a * vnoise(x * f, y * f, seed + o * 31); n += a; a *= 0.5; f *= 2.03; }
    return s / n;
  }

  /*
   * Bản đồ nhiễu đã cân bằng: giá trị phân bố đều 0..1, nên "nhiễu < độ đậm" cho đúng tỉ lệ phủ mực.
   * o: { scale (px), sx (kéo dãn ngang), oct, seed, white (tỉ lệ nhiễu trắng trộn vào) }
   */
  E.noiseMap = function (w, h, o) {
    var n = w * h, out = new Float32Array(n), sc = o.scale || 4, sx = o.sx || 1, wh = o.white || 0;
    var seed = o.seed || 1, oct = o.oct || 2, ox = o.ox || 0, oy = o.oy || 0;
    for (var y = 0, i = 0; y < h; y++) {
      for (var x = 0; x < w; x++, i++) {
        var v = fbm((x + ox) / (sc * sx), (y + oy) / sc, seed, oct);
        if (wh > 0) v = v * (1 - wh) + hash2(x, y, seed + 977) * wh;
        out[i] = v;
      }
    }
    // cân bằng histogram (4096 mức)
    var B = 4096, hist = new Uint32Array(B), mn = Infinity, mx = -Infinity, k;
    for (k = 0; k < n; k++) { if (out[k] < mn) mn = out[k]; if (out[k] > mx) mx = out[k]; }
    var rng = mx - mn || 1;
    var bin = new Uint16Array(n);
    for (k = 0; k < n; k++) { var b = ((out[k] - mn) / rng * (B - 1)) | 0; bin[k] = b; hist[b]++; }
    var cdf = new Float32Array(B), acc = 0;
    for (k = 0; k < B; k++) { cdf[k] = (acc + hist[k] / 2) / n; acc += hist[k]; }
    for (k = 0; k < n; k++) out[k] = cdf[bin[k]];
    return out;
  };

  function boxBlur(src, w, h, r) {
    var tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, s, k, d = 2 * r + 1;
    for (y = 0; y < h; y++) {
      s = 0;
      for (k = -r; k <= r; k++) s += src[y * w + Math.min(w - 1, Math.max(0, k))];
      for (x = 0; x < w; x++) {
        tmp[y * w + x] = s / d;
        s += src[y * w + Math.min(w - 1, x + r + 1)] - src[y * w + Math.max(0, x - r)];
      }
    }
    for (x = 0; x < w; x++) {
      s = 0;
      for (k = -r; k <= r; k++) s += tmp[Math.min(h - 1, Math.max(0, k)) * w + x];
      for (y = 0; y < h; y++) {
        out[y * w + x] = s / d;
        s += tmp[Math.min(h - 1, y + r + 1) * w + x] - tmp[Math.max(0, y - r) * w + x];
      }
    }
    return out;
  }

  /* Trường giá trị cho kiểu dạng ô đặc biệt (truchet, vảy cá); u,v trong [0,1). */
  function fieldValue(t, u, v, ci, cj) {
    if (t === "brick") {
      // gạch xây: mạch vữa là phần in (ô rộng gấp đôi cao)
      var bxd = Math.min(u, 1 - u) * 2, byd = Math.min(v, 1 - v);
      return bxd < byd ? bxd : byd;
    }
    if (t === "seigaiha") {
      // sóng biển Nhật: nhiều vòng cung đồng tâm trong mỗi vảy
      var su = u - 0.5, sv = v - 1.0, sr = Math.sqrt(su * su + sv * sv);
      return Math.abs(sr * 3.2 - Math.round(sr * 3.2)) + (sr > 1.0 ? 0.6 : 0);
    }
    if (t === "weave") {
      // đan rổ: khối 2×2, xen kẽ sọc ngang và sọc dọc
      var blk = (Math.floor(u * 2) + Math.floor(v * 2)) & 1, q = blk ? u * 4 : v * 4;
      return Math.abs((q - Math.floor(q)) * 2 - 1);
    }
    if (t === "diamondplate") {
      // thép gân chống trượt: gạch ngắn nghiêng ±45° xen kẽ
      var dpu = (u * 2 - Math.floor(u * 2)) * 2 - 1, dpv = (v * 2 - Math.floor(v * 2)) * 2 - 1;
      var sgn = ((Math.floor(u * 2) + Math.floor(v * 2)) & 1) ? 1 : -1;
      var ra = (dpu + sgn * dpv) * 0.7071, rb2 = (-sgn * dpu + dpv) * 0.7071;
      var aa2 = Math.abs(ra) * 0.42, bb3 = Math.abs(rb2);
      return aa2 > bb3 ? aa2 : bb3;
    }
    if (t === "lattice") {
      // mắt cáo: lưới chéo hai chiều
      var l1 = Math.abs(((u + v) - Math.floor(u + v)) * 2 - 1), l2 = Math.abs(((u - v) - Math.floor(u - v)) * 2 - 1);
      return l1 < l2 ? l1 : l2;
    }
    if (t === "truchet") {
      // Hai cung 1/4 tròn nối giữa các cạnh, hướng ngẫu nhiên theo ô -> mê cung.
      if (hash2(ci, cj, 77) < 0.5) u = 1 - u;
      var a = Math.abs(Math.sqrt(u * u + v * v) - 0.5), b = Math.abs(Math.sqrt((1 - u) * (1 - u) + (1 - v) * (1 - v)) - 0.5);
      return a < b ? a : b;
    }
    // vảy cá: các cung tròn tâm ở đáy ô, hàng lẻ lệch nửa ô
    var du = u - 0.5, dv = v - 1.0, r = Math.sqrt(du * du + dv * dv);
    return Math.abs(r - 0.55) + (r > 1.05 ? 1 : 0);
  }
  var FIELD_LUT = {};
  /* Khoảng cách tới viền ô lục giác (0 = trên viền), toạ độ theo đơn vị khoảng cách ô. */
  function hexBorder(px, py) {
    var SQ3 = 1.7320508, bj = py * 2 / SQ3, bi = px - bj / 2, fi = Math.floor(bi), fj = Math.floor(bj), best = 9, bx = 0, by = 0;
    for (var di = -1; di <= 2; di++) for (var dj = -1; dj <= 2; dj++) {
      var ci = fi + di, cj = fj + dj, qx = px - (ci + cj / 2), qy = py - cj * SQ3 / 2, dd = qx * qx + qy * qy;
      if (dd < best) { best = dd; bx = qx; by = qy; }
    }
    var ax = Math.abs(bx), ay = Math.abs(by);
    // ô lục giác đỉnh nhọn hướng lên; bán kính trong = 0.5
    var hd = Math.max(ay * 0.8660 + ax * 0.5, ax);
    return 0.5 - hd;
  }
  function hexBorderLut() {
    var vals = [], N = 140;
    for (var j = 0; j < N; j++) for (var i = 0; i < N; i++) vals.push(hexBorder((i + 0.5) / N * 2, (j + 0.5) / N * 1.7320508));
    vals.sort(function (a, b) { return a - b; });
    var lut = new Float32Array(256);
    for (var q = 0; q < 256; q++) {
      if (q === 0) { lut[q] = -1; continue; }
      if (q === 255) { lut[q] = 9; continue; }
      var idx = Math.round(q / 255 * vals.length);
      lut[q] = idx >= vals.length ? 9 : (vals[idx - 1] + vals[idx]) / 2;
    }
    return lut;
  }
  function fieldLut(t) {
    var N = 96, vals = [], j, i;
    if (t === "polardots") {
      for (j = 0; j < N; j++) for (i = 0; i < N; i++) {
        var pu = ((i + 0.5) / N) * 2 - 1, pv = ((j + 0.5) / N) * 2 - 1; vals.push((pu * pu + pv * pv) / 2);
      }
    } else {
      for (var c = 0; c < 4; c++) for (j = 0; j < N; j++) for (i = 0; i < N; i++) vals.push(fieldValue(t, (i + 0.5) / N, (j + 0.5) / N, c, c * 3 + 1));
    }
    vals.sort(function (a, b) { return a - b; });
    var lut = new Float32Array(256);
    for (var q = 0; q < 256; q++) {
      if (q === 0) { lut[q] = -1; continue; }
      if (q === 255) { lut[q] = 9; continue; }
      var idx = Math.round(q / 255 * vals.length);
      lut[q] = idx >= vals.length ? 9 : (vals[idx - 1] + vals[idx]) / 2;
    }
    return lut;
  }


  /*
   * Tách màu spot (index): tìm "colors" màu chủ đạo bằng k-means, mỗi pixel nhận 1 màu.
   * o: { colors, shirt:[r,g,b] (màu áo, coi như "không in"), dither:"none"|"grain"|"diffusion", grainPx, palette (tùy chọn) }
   * Trả về { palette:[[r,g,b]...], labels:Uint8Array (255 = không in) }.
   */
  E.indexColor = function (rgba, w, h, o) {
    var n = w * h, shirt = o.shirt, i, p, k;
    var bgc = shirt || [255, 255, 255];
    var px = new Float32Array(n * 3), solid = new Uint8Array(n);
    for (i = 0, p = 0; i < n; i++, p += 4) {
      var a = rgba[p + 3] / 255;
      px[i * 3] = rgba[p] * a + bgc[0] * (1 - a);
      px[i * 3 + 1] = rgba[p + 1] * a + bgc[1] * (1 - a);
      px[i * 3 + 2] = rgba[p + 2] * a + bgc[2] * (1 - a);
      solid[i] = rgba[p + 3] > 8 ? 1 : 0;
    }
    var pal = o.palette ? o.palette.slice() : kmeans(px, solid, n, o.colors || 4, shirt);
    var P = pal.slice();
    if (shirt) P.push(shirt);              // màu áo là một "màu" để hòa trộn ra nền
    var shirtIdx = shirt ? P.length - 1 : -1;
    var labels = new Uint8Array(n), m = P.length;
    var g = o.dither === "grain" ? E.noiseMap(w, h, { scale: Math.max(1, o.grainPx || 3), oct: 2, seed: 61, white: 0.45 }) : null;
    var err = o.dither === "diffusion" ? new Float32Array(px) : null;
    for (var y = 0, idx = 0; y < h; y++) {
      for (var x = 0; x < w; x++, idx++) {
        if (!solid[idx]) { labels[idx] = 255; continue; }
        var r = err ? err[idx * 3] : px[idx * 3], gg = err ? err[idx * 3 + 1] : px[idx * 3 + 1], b = err ? err[idx * 3 + 2] : px[idx * 3 + 2];
        var b1 = 0, b2 = 0, d1 = 1e12, d2 = 1e12;
        for (k = 0; k < m; k++) {
          var dr = r - P[k][0], dg = gg - P[k][1], db = b - P[k][2], dd = dr * dr * 0.3 + dg * dg * 0.59 + db * db * 0.11;
          if (dd < d1) { d2 = d1; b2 = b1; d1 = dd; b1 = k; } else if (dd < d2) { d2 = dd; b2 = k; }
        }
        var pick = b1;
        if (g && m > 1) {
          // chiếu màu lên đoạn nối 2 màu gần nhất, chọn màu thứ 2 theo xác suất -> hạt sần chuyển tiếp
          var A = P[b1], B = P[b2], ex = B[0] - A[0], ey = B[1] - A[1], ez = B[2] - A[2];
          var L = ex * ex + ey * ey + ez * ez;
          var t = L > 0 ? ((r - A[0]) * ex + (gg - A[1]) * ey + (b - A[2]) * ez) / L : 0;
          if (t > 0 && g[idx] < t) pick = b2;
        }
        if (err) {
          var er = r - P[pick][0], eg = gg - P[pick][1], eb = b - P[pick][2];
          var nb = [[1, 0, 7], [-1, 1, 3], [0, 1, 5], [1, 1, 1]];
          for (k = 0; k < 4; k++) {
            var nx = x + nb[k][0], ny = y + nb[k][1];
            if (nx < 0 || nx >= w || ny >= h) continue;
            var q = (ny * w + nx) * 3, f = nb[k][2] / 16;
            err[q] += er * f; err[q + 1] += eg * f; err[q + 2] += eb * f;
          }
        }
        labels[idx] = pick === shirtIdx ? 255 : pick;
      }
    }
    return { palette: pal, labels: labels };
  };

  /* Ghép kết quả tách màu spot thành RGBA trong suốt. */
  E.indexComposite = function (res, w, h) {
    var n = w * h, out = new Uint8ClampedArray(n * 4);
    for (var i = 0, p = 0; i < n; i++, p += 4) {
      var l = res.labels[i];
      if (l === 255) continue;
      var c = res.palette[l];
      out[p] = c[0]; out[p + 1] = c[1]; out[p + 2] = c[2]; out[p + 3] = 255;
    }
    return out;
  };

  function kmeans(px, solid, n, K, shirt) {
    // lấy mẫu tối đa 30000 pixel có nội dung (bỏ pixel gần màu áo nếu có)
    var step = Math.max(1, Math.floor(n / 30000)), S = [], i, k, it;
    for (i = 0; i < n; i += step) {
      if (!solid[i]) continue;
      var r = px[i * 3], g = px[i * 3 + 1], b = px[i * 3 + 2];
      if (shirt) { var dr = r - shirt[0], dg = g - shirt[1], db = b - shirt[2]; if (dr * dr + dg * dg + db * db < 900) continue; }
      S.push([r, g, b]);
    }
    if (!S.length) return [[0, 0, 0]];
    K = Math.min(K, S.length);
    // khởi tạo k-means++ có hạt giống cố định
    var C = [S[Math.floor(hash2(1, 2, 3) * S.length)].slice()], D = new Float64Array(S.length);
    while (C.length < K) {
      var tot = 0;
      for (i = 0; i < S.length; i++) {
        var best = 1e12;
        for (k = 0; k < C.length; k++) {
          var e0 = S[i][0] - C[k][0], e1 = S[i][1] - C[k][1], e2 = S[i][2] - C[k][2], dd = e0 * e0 + e1 * e1 + e2 * e2;
          if (dd < best) best = dd;
        }
        D[i] = best; tot += best;
      }
      var target = hash2(C.length, 9, 5) * tot, acc = 0;
      for (i = 0; i < S.length; i++) { acc += D[i]; if (acc >= target) break; }
      C.push(S[Math.min(i, S.length - 1)].slice());
    }
    for (it = 0; it < 14; it++) {
      var sum = [], cnt = [];
      for (k = 0; k < K; k++) { sum.push([0, 0, 0]); cnt.push(0); }
      for (i = 0; i < S.length; i++) {
        var bk = 0, bd = 1e12;
        for (k = 0; k < K; k++) {
          var f0 = S[i][0] - C[k][0], f1 = S[i][1] - C[k][1], f2 = S[i][2] - C[k][2], fd = f0 * f0 + f1 * f1 + f2 * f2;
          if (fd < bd) { bd = fd; bk = k; }
        }
        sum[bk][0] += S[i][0]; sum[bk][1] += S[i][1]; sum[bk][2] += S[i][2]; cnt[bk]++;
      }
      for (k = 0; k < K; k++) if (cnt[k]) C[k] = [sum[k][0] / cnt[k], sum[k][1] / cnt[k], sum[k][2] / cnt[k]];
    }
    // bỏ các màu gần trùng nhau (ảnh có ít màu hơn số yêu cầu)
    var out = [];
    for (k = 0; k < C.length; k++) {
      var c = [Math.round(C[k][0]), Math.round(C[k][1]), Math.round(C[k][2])], dup = false;
      for (var j = 0; j < out.length; j++) {
        var q0 = c[0] - out[j][0], q1 = c[1] - out[j][1], q2 = c[2] - out[j][2];
        if (q0 * q0 + q1 * q1 + q2 * q2 < 100) { dup = true; break; }
      }
      if (!dup) out.push(c);
    }
    return out;
  }

  /*
   * Tạo bố cục nhiều tâm cho Vòng tròn / Xoắn ốc / Tỏa tia.
   * n: số tâm, seed: hạt giống, vary: 0..1 độ chênh lệch kích thước, aspect: w/h của ảnh.
   * Đặt tâm lần lượt từ to đến nhỏ, ưu tiên chỗ còn trống để các vòng phân bố đều.
   */
  E.makeCenters = function (n, seed, vary, aspect) {
    n = Math.max(1, Math.min(60, n | 0));
    if (n === 1) return [{ x: 0.5, y: 0.5, r: 0.7, dir: 1 }];
    aspect = aspect || 1;
    var ax = aspect >= 1 ? aspect : 1, ay = aspect >= 1 ? 1 : 1 / aspect; // khung theo đơn vị cạnh ngắn
    var base = Math.sqrt(ax * ay / (n * Math.PI)) * 1.25, out = [], k;
    var radii = [];
    for (k = 0; k < n; k++) radii.push(base * (1 + vary * 0.9 * (hash2(k, 3, seed) * 2 - 1)) * (k === 0 ? 1 + vary * 0.6 : 1));
    radii.sort(function (a, b) { return b - a; });
    for (k = 0; k < n; k++) {
      var best = null, bestScore = -1e9;
      for (var t = 0; t < 40; t++) {
        var px = hash2(k * 97 + t, 11, seed) * ax, py = hash2(k * 97 + t, 13, seed) * ay, score = 1e9;
        for (var j = 0; j < out.length; j++) {
          var dx = px - out[j].px, dy = py - out[j].py;
          var gap = Math.sqrt(dx * dx + dy * dy) - out[j].r * 0.8 - radii[k] * 0.8;
          if (gap < score) score = gap;
        }
        // ưu tiên không dính sát mép quá
        var edge = Math.min(px, py, ax - px, ay - py) + radii[k] * 0.35;
        if (edge < score) score = edge;
        if (score > bestScore) { bestScore = score; best = { px: px, py: py, r: radii[k] }; }
      }
      out.push(best);
    }
    return out.map(function (c, i) {
      return { x: c.px / ax, y: c.py / ay, r: c.r, dir: hash2(i, 29, seed) < 0.5 ? -1 : 1 };
    });
  };

  /*
   * Hiệu ứng màu: trả về ảnh RGBA mới (chỗ không in có alpha = 0).
   * o: { amt 0..1, colorA, colorB [r,g,b], periodPx, frame {ox,oy,fw,fh} }
   */
  E.fx = function (kind, rgba, w, h, o) {
    if (kind.indexOf("v_") === 0) return E.vintage(kind, rgba, w, h, o);
    var n = w * h, out = new Uint8ClampedArray(n * 4), i, p, x, y;
    var F = o.frame || { ox: 0, oy: 0, fw: w, fh: h }, amt = o.amt === undefined ? 0.5 : o.amt;
    var A = o.colorA || [255, 64, 160], B = o.colorB || [0, 120, 200], per = Math.max(1, o.periodPx || 6);
    function lum(q) { return (0.299 * rgba[q] + 0.587 * rgba[q + 1] + 0.114 * rgba[q + 2]) / 255; }
    function sample(sx, sy) { // lấy mẫu có kẹp biên
      sx = sx < 0 ? 0 : sx >= w ? w - 1 : sx | 0; sy = sy < 0 ? 0 : sy >= h ? h - 1 : sy | 0;
      return (sy * w + sx) * 4;
    }

    if (kind === "glitch") {
      // Lệch kênh RGB + các dải ngang bị xô lệch ngẫu nhiên (kiểu Y2K / VHS).
      var sh = Math.round(amt * 0.018 * F.fw), bandH = Math.max(2, F.fh * 0.022);
      for (y = 0; y < h; y++) {
        var band = Math.floor((y + F.oy) / bandH), r0 = hash2(band, 5, 71);
        var off = r0 < 0.28 * amt + 0.05 ? Math.round((hash2(band, 6, 73) - 0.5) * amt * 0.12 * F.fw) : 0;
        var scan = ((y + F.oy) % 3 === 0) ? 0.82 : 1;
        for (x = 0; x < w; x++) {
          p = (y * w + x) * 4;
          var qr = sample(x + off - sh, y), qg = sample(x + off, y), qb = sample(x + off + sh, y);
          var ar = rgba[qr + 3], ag = rgba[qg + 3], ab = rgba[qb + 3];
          out[p] = rgba[qr] * scan; out[p + 1] = rgba[qg + 1] * scan; out[p + 2] = rgba[qb + 2] * scan;
          out[p + 3] = Math.max(ar, ag, ab);
          // kênh lệch ra ngoài nền trong suốt: tô màu kênh đó lên nền đen
          if (out[p + 3] && ag < 128) { out[p] = ar > 127 ? rgba[qr] : 0; out[p + 1] = 0; out[p + 2] = ab > 127 ? rgba[qb + 2] : 0; }
        }
      }
      return out;
    }

    if (kind === "riso" || kind === "popart") {
      // Tách ảnh thành 2 mực (A, B) theo mô hình nhân màu, rồi tạo hạt (riso) hoặc chấm (pop-art).
      var la = [-Math.log(Math.max(A[0], 8) / 255), -Math.log(Math.max(A[1], 8) / 255), -Math.log(Math.max(A[2], 8) / 255)];
      var lb = [-Math.log(Math.max(B[0], 8) / 255), -Math.log(Math.max(B[1], 8) / 255), -Math.log(Math.max(B[2], 8) / 255)];
      var aa = la[0] * la[0] + la[1] * la[1] + la[2] * la[2], bb = lb[0] * lb[0] + lb[1] * lb[1] + lb[2] * lb[2];
      var ab2 = la[0] * lb[0] + la[1] * lb[1] + la[2] * lb[2], det = aa * bb - ab2 * ab2 || 1e-6;
      var dA = new Float32Array(n), dB = new Float32Array(n), dK = new Float32Array(n);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        var al = rgba[p + 3] / 255;
        if (al < 0.03) continue;
        var v0 = -Math.log(Math.max(1 - al + al * rgba[p] / 255, 0.02)), v1 = -Math.log(Math.max(1 - al + al * rgba[p + 1] / 255, 0.02)),
            v2 = -Math.log(Math.max(1 - al + al * rgba[p + 2] / 255, 0.02));
        var pa = v0 * la[0] + v1 * la[1] + v2 * la[2], pb2 = v0 * lb[0] + v1 * lb[1] + v2 * lb[2];
        var ca = (bb * pa - ab2 * pb2) / det, cb = (aa * pb2 - ab2 * pa) / det;
        dA[i] = ca < 0 ? 0 : ca > 1 ? 1 : ca; dB[i] = cb < 0 ? 0 : cb > 1 ? 1 : cb;
        // phần tối không diễn tả được bằng 2 mực -> thêm cả 2 (đậm hơn)
        var lu = lum(p) * al + (1 - al), deficit = 1 - lu - Math.max(dA[i], dB[i]) * 0.6;
        if (deficit > 0.35) { dA[i] = Math.min(1, dA[i] + deficit * 0.6); dB[i] = Math.min(1, dB[i] + deficit * 0.6); }
        dK[i] = 1;
      }
      var inkA, inkB, mis = Math.round(amt * 0.008 * F.fw);
      if (kind === "riso") {
        var gA = E.noiseMap(w, h, { scale: Math.max(0.7, per * 0.18), oct: 2, seed: 301, white: 0.55, ox: F.ox, oy: F.oy });
        var gB = E.noiseMap(w, h, { scale: Math.max(0.7, per * 0.18), oct: 2, seed: 307, white: 0.55, ox: F.ox, oy: F.oy });
        inkA = new Uint8Array(n); inkB = new Uint8Array(n);
        for (i = 0; i < n; i++) { if (gA[i] < dA[i]) inkA[i] = 1; if (gB[i] < dB[i]) inkB[i] = 1; }
      } else {
        inkA = E.render({ t: "halftone", shape: "round", periodPx: per, angleDeg: 15, frame: F }, dA, w, h);
        inkB = E.render({ t: "halftone", shape: "round", periodPx: per, angleDeg: 75, frame: F }, dB, w, h);
      }
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        p = i * 4;
        var ia = inkA[i], jx = x - mis, jy = y - mis;
        var ib = jx >= 0 && jy >= 0 ? inkB[jy * w + jx] : 0; // mực B in lệch khuôn
        if (!ia && !ib) continue;
        var r = 1, g = 1, b = 1;
        if (ia) { r *= A[0] / 255; g *= A[1] / 255; b *= A[2] / 255; }
        if (ib) { r *= B[0] / 255; g *= B[1] / 255; b *= B[2] / 255; }
        out[p] = r * 255; out[p + 1] = g * 255; out[p + 2] = b * 255; out[p + 3] = 255;
      }
      return out;
    }

    if (kind === "pixel8") {
      // Pixel 8-bit: lấy màu trung bình từng khối, giảm số mức màu.
      var bs = Math.max(1, per * 1.2), lvls = Math.max(2, Math.round(8 - amt * 5)), bx0 = Math.floor(F.ox / bs), by0 = Math.floor(F.oy / bs);
      var bw = Math.ceil(w / bs) + 2, bh = Math.ceil(h / bs) + 2, acc = new Float32Array(bw * bh * 5);
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        p = i * 4;
        var bi = ((Math.floor((y + F.oy) / bs) - by0) * bw + (Math.floor((x + F.ox) / bs) - bx0)) * 5;
        var a8 = rgba[p + 3] / 255;
        acc[bi] += rgba[p] * a8; acc[bi + 1] += rgba[p + 1] * a8; acc[bi + 2] += rgba[p + 2] * a8; acc[bi + 3] += a8; acc[bi + 4]++;
      }
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        p = i * 4;
        var bj = ((Math.floor((y + F.oy) / bs) - by0) * bw + (Math.floor((x + F.ox) / bs) - bx0)) * 5;
        if (acc[bj + 3] / acc[bj + 4] < 0.5) continue;
        for (var c = 0; c < 3; c++) {
          var v = acc[bj + c] / acc[bj + 3] / 255;
          out[p + c] = Math.round(Math.round(v * (lvls - 1)) / (lvls - 1) * 255);
        }
        out[p + 3] = 255;
      }
      return out;
    }

    if (kind === "vintage") {
      // Vintage bạc màu: giảm bão hòa, ngả ấm, mực mòn và nứt như áo giặt nhiều lần.
      var dk2 = new Float32Array(n);
      for (i = 0, p = 0; i < n; i++, p += 4) dk2[i] = rgba[p + 3] > 8 ? 1 : 0;
      var keep = E.render({ t: "crack", periodPx: per * 1.4, frame: F }, dk2, w, h);
      var big = E.noiseMap(w, h, { scale: Math.max(4, Math.min(F.fw, F.fh) / 12), oct: 4, seed: 401, ox: F.ox, oy: F.oy });
      var fine = E.noiseMap(w, h, { scale: Math.max(0.7, per * 0.2), oct: 2, seed: 409, white: 0.6, ox: F.ox, oy: F.oy });
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8 || !keep[i]) continue;
        if (big[i] * 0.65 + fine[i] * 0.35 < amt * 0.42) continue;
        var l2 = lum(p), sat = 1 - amt * 0.55;
        var rr = l2 * 255 + (rgba[p] - l2 * 255) * sat, gg = l2 * 255 + (rgba[p + 1] - l2 * 255) * sat, bb2 = l2 * 255 + (rgba[p + 2] - l2 * 255) * sat;
        // phủ một lớp màu kem ấm và nâng vùng tối (mực bạc)
        out[p] = rr * (1 - amt * 0.25) + 240 * amt * 0.25 + 18 * amt;
        out[p + 1] = gg * (1 - amt * 0.25) + 222 * amt * 0.25 + 12 * amt;
        out[p + 2] = bb2 * (1 - amt * 0.25) + 190 * amt * 0.25;
        out[p + 3] = rgba[p + 3];
      }
      return out;
    }

    if (kind === "trippy") {
      // Ảo giác thập niên 70: hình bị uốn sóng, lặp viền màu.
      var Aw = amt * 0.035 * F.fw, lam = Math.max(8, F.fw * 0.11);
      for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
        p = (y * w + x) * 4;
        var X0 = x + F.ox, Y0 = y + F.oy;
        var sx = x + Aw * Math.sin(2 * Math.PI * Y0 / lam), sy = y + Aw * 0.6 * Math.sin(2 * Math.PI * X0 / (lam * 1.3));
        var q = sample(sx, sy);
        if (rgba[q + 3] > 8) { out[p] = rgba[q]; out[p + 1] = rgba[q + 1]; out[p + 2] = rgba[q + 2]; out[p + 3] = rgba[q + 3]; continue; }
        // vầng lặp màu bên ngoài hình (echo)
        for (var e = 1; e <= 3; e++) {
          var q2 = sample(sx - e * Aw * 0.5, sy);
          if (rgba[q2 + 3] > 8 && ((e + Math.floor(Y0 / (lam * 0.08))) % 2 === 0)) {
            var t = e / 4; out[p] = A[0] * (1 - t) + B[0] * t; out[p + 1] = A[1] * (1 - t) + B[1] * t; out[p + 2] = A[2] * (1 - t) + B[2] * t; out[p + 3] = 255;
            break;
          }
        }
      }
      return out;
    }

    if (kind === "thermal") {
      // Ảnh nhiệt: độ sáng -> dải màu đen, tím, đỏ, cam, vàng, trắng.
      var pal = [[10, 10, 60], [80, 20, 140], [200, 30, 110], [250, 90, 30], [255, 200, 40], [255, 255, 230]];
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var tv = lum(p) * (pal.length - 1), k = Math.min(pal.length - 2, Math.floor(tv)), f = tv - k;
        for (var c2 = 0; c2 < 3; c2++) out[p + c2] = pal[k][c2] * (1 - f) + pal[k + 1][c2] * f;
        out[p + 3] = rgba[p + 3];
      }
      return out;
    }

    if (kind === "neon") {
      // Viền neon: dò cạnh của hình rồi phát sáng bằng màu A, lõi trắng.
      var L = new Float32Array(n);
      for (i = 0, p = 0; i < n; i++, p += 4) L[i] = lum(p) * (rgba[p + 3] / 255);
      var Ls = boxBlur(L, w, h, 1), Ed = new Float32Array(n);
      for (y = 1; y < h - 1; y++) for (x = 1; x < w - 1; x++) {
        i = y * w + x;
        var gx = Ls[i + 1] - Ls[i - 1], gy = Ls[i + w] - Ls[i - w];
        Ed[i] = Math.min(1, Math.sqrt(gx * gx + gy * gy) * 3.2);
      }
      var glow = boxBlur(Ed, w, h, Math.max(1, Math.round(per * 0.8)));
      var thr = 0.5 - amt * 0.3;
      for (i = 0, p = 0; i < n; i++, p += 4) {
        var core = Ed[i] > thr ? 1 : 0, gl = Math.min(1, glow[i] * 1.4);
        var al2 = Math.max(core, gl);
        if (al2 < 0.12) continue;
        out[p] = A[0] + (255 - A[0]) * core * 0.7; out[p + 1] = A[1] + (255 - A[1]) * core * 0.7; out[p + 2] = A[2] + (255 - A[2]) * core * 0.7;
        out[p + 3] = al2 >= 0.5 ? 255 : 0; // DTF cần alpha cứng
      }
      return out;
    }

    if (kind === "duotone") {
      // Duotone: ánh xạ độ sáng sang dải 2 màu (màu 1 = tối, màu 2 = sáng). Cường độ = độ tương phản.
      var con = 0.6 + amt * 1.2;
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var tl = (lum(p) - 0.5) * con + 0.5; tl = tl < 0 ? 0 : tl > 1 ? 1 : tl;
        out[p] = A[0] + (B[0] - A[0]) * tl; out[p + 1] = A[1] + (B[1] - A[1]) * tl; out[p + 2] = A[2] + (B[2] - A[2]) * tl;
        out[p + 3] = rgba[p + 3];
      }
      return out;
    }

    if (kind === "rainbowdots") {
      // Chấm cầu vồng: trame chấm tròn, màu chấm chạy theo dải cầu vồng chéo qua hình.
      var dd = new Float32Array(n);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        var a3 = rgba[p + 3] / 255;
        dd[i] = a3 < 0.03 ? 0 : (o.darkShirt ? lum(p) * a3 : (1 - lum(p)) * a3 + (a3 > 0.5 ? 0.04 : 0));
      }
      var dots = E.render({ t: "halftone", shape: "round", periodPx: per, angleDeg: 45, frame: F }, dd, w, h);
      var hueOff = amt * 360;
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        if (!dots[i]) continue;
        p = i * 4;
        var hu = (((x + F.ox) / F.fw + (y + F.oy) / F.fh) * 180 + hueOff) % 360, hh = hu / 60, ff = hh - Math.floor(hh);
        var tab = [[1, ff, 0], [1 - ff, 1, 0], [0, 1, ff], [0, 1 - ff, 1], [ff, 0, 1], [1, 0, 1 - ff]][Math.floor(hh) % 6];
        out[p] = 255 * tab[0]; out[p + 1] = 255 * tab[1]; out[p + 2] = 255 * tab[2]; out[p + 3] = 255;
      }
      return out;
    }

    if (kind === "rgbdots") {
      // Chấm RGB như màn hình LED: mỗi ô 3 chấm đỏ, lục, lam; cỡ chấm theo từng kênh màu. Hợp áo đen.
      var cp = per * 1.3;
      for (y = 0; y < h; y++) for (x = 0; x < w; x++) {
        p = (y * w + x) * 4;
        if (rgba[p + 3] < 8) continue;
        var cu = (x + 0.5 + F.ox) / cp, cv = (y + 0.5 + F.oy) / cp, fu = cu - Math.floor(cu), fv = cv - Math.floor(cv);
        var sub = Math.min(2, Math.floor(fu * 3)), lu2 = (fu * 3 - sub) * 2 - 1, lv2 = fv * 2 - 1;
        var val = rgba[p + sub] / 255, rad = Math.sqrt(val) * 0.95;
        if (lu2 * lu2 + (lv2 * 0.55) * (lv2 * 0.55) < rad * rad) {
          out[p] = sub === 0 ? 255 : 20; out[p + 1] = sub === 1 ? 255 : 20; out[p + 2] = sub === 2 ? 255 : 20; out[p + 3] = 255;
        }
      }
      return out;
    }

    if (kind === "spray") {
      // Sơn xịt graffiti: mép hình tan thành bụi sơn, có vệt sơn chảy xuống.
      var al = new Float32Array(n);
      for (i = 0; i < n; i++) al[i] = rgba[i * 4 + 3] / 255;
      var soft = boxBlur(al, w, h, Math.max(1, Math.round(per * (0.6 + amt))));
      var gn = E.noiseMap(w, h, { scale: Math.max(0.7, per * 0.12), oct: 1, seed: 901, white: 0.8, ox: F.ox, oy: F.oy });
      for (i = 0, p = 0; i < n; i++, p += 4) {
        var keep = al[i] > 0.5 ? (soft[i] > 0.97 || gn[i] < soft[i] * 1.05) : gn[i] < soft[i] * 0.55;
        if (!keep) continue;
        var src = rgba[p + 3] > 8 ? p : nearestSolid(i);
        if (src < 0) continue;
        out[p] = rgba[src]; out[p + 1] = rgba[src + 1]; out[p + 2] = rgba[src + 2]; out[p + 3] = 255;
      }
      // vệt sơn chảy: từ mép dưới của hình, một số cột chảy xuống
      var dripW = Math.max(1, Math.round(per * 0.35)), dripMax = F.fh * (0.04 + amt * 0.08);
      for (x = 0; x < w; x++) {
        var col = Math.floor((x + F.ox) / (dripW * 3));
        if (hash2(col, 3, 907) > 0.18 + amt * 0.2) continue;
        if (((x + F.ox) % (dripW * 3)) >= dripW) continue;
        var len = dripMax * (0.3 + 0.7 * hash2(col, 4, 911));
        for (y = 1; y < h; y++) {
          var q0 = ((y - 1) * w + x) * 4, q1 = (y * w + x) * 4;
          if (rgba[q0 + 3] > 128 && rgba[q1 + 3] <= 128) {
            var cR = rgba[q0], cG = rgba[q0 + 1], cB = rgba[q0 + 2];
            for (var k = 0; k < len && y + k < h; k++) {
              var q2 = ((y + k) * w + x) * 4;
              if (rgba[q2 + 3] > 128) break;
              out[q2] = cR; out[q2 + 1] = cG; out[q2 + 2] = cB; out[q2 + 3] = 255;
            }
          }
        }
      }
      return out;
      function nearestSolid(idx) {
        var yy = (idx / w) | 0, xx = idx % w;
        for (var r = 1; r < 6; r++) {
          var cand = [[xx + r, yy], [xx - r, yy], [xx, yy + r], [xx, yy - r]];
          for (var c = 0; c < 4; c++) {
            var X = cand[c][0], Y = cand[c][1];
            if (X >= 0 && X < w && Y >= 0 && Y < h && rgba[(Y * w + X) * 4 + 3] > 8) return (Y * w + X) * 4;
          }
        }
        return -1;
      }
    }

    throw new Error("Hiệu ứng màu không hỗ trợ: " + kind);
  };

  /*
   * 30 hiệu ứng vintage. Trả về RGBA (alpha 0 = không in).
   * o: { amt 0..1, colorA, colorB, periodPx (cỡ kết cấu), frame, darkShirt }
   */
  E.vintage = function (kind, rgba, w, h, o) {
    var n = w * h, out = new Uint8ClampedArray(n * 4), i, p, x, y, k;
    var F = o.frame || { ox: 0, oy: 0, fw: w, fh: h }, amt = o.amt === undefined ? 0.5 : o.amt;
    var A = o.colorA || [30, 30, 30], B = o.colorB || [240, 230, 210], per = Math.max(1, o.periodPx || 6);
    var dark = !!o.darkShirt;
    // áo đen: mực 1 màu tối sẽ không thấy -> đổi sang màu kem
    var INK = dark && (0.299 * A[0] + 0.587 * A[1] + 0.114 * A[2]) < 100 ? [238, 228, 205] : A;
    function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : v; }
    function lum(q) { return (0.299 * rgba[q] + 0.587 * rgba[q + 1] + 0.114 * rgba[q + 2]) / 255; }
    // mật độ mực của 1 màu: áo đen -> phần sáng in mực; áo trắng -> phần tối in mực
    function dens(q) { var a = rgba[q + 3] / 255; return a < 0.03 ? 0 : (dark ? lum(q) : 1 - lum(q)) * a; }
    function noise(sc, seed, white, oct) { return E.noiseMap(w, h, { scale: Math.max(0.7, sc), oct: oct || 2, seed: seed, white: (white || 0) * 0.5, ox: F.ox, oy: F.oy }); }
    function copyPx(q, r, g, b) { out[q] = clamp(r); out[q + 1] = clamp(g); out[q + 2] = clamp(b); out[q + 3] = rgba[q + 3]; }
    function sat(r, g, b, s) { var l = 0.299 * r + 0.587 * g + 0.114 * b; return [l + (r - l) * s, l + (g - l) * s, l + (b - l) * s]; }
    function gmap(l, stops) { // bản đồ dải màu theo độ sáng
      var t = l * (stops.length - 1), j = Math.min(stops.length - 2, Math.floor(t)), f = t - j, a = stops[j], b = stops[j + 1];
      return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f];
    }
    function erode(level, sc, seed, white) { // xóa mực theo nhiễu (mòn, rỗ)
      if (level <= 0) return;
      var m = noise(sc, seed, white === undefined ? 0.5 : white);
      for (var q = 0; q < n; q++) if (out[q * 4 + 3] && m[q] < level) out[q * 4 + 3] = 0;
    }
    function edgeFade(width, seed) { // viền tan lấm tấm quanh khung hình
      var m = noise(per * 0.2, seed, 0.7);
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var ex = Math.min(x + F.ox, F.fw - x - F.ox) / F.fw, ey = Math.min(y + F.oy, F.fh - y - F.oy) / F.fh;
        var e = Math.min(ex, ey) / width;
        if (e < 1 && m[i] > e) out[i * 4 + 3] = 0;
      }
    }
    function cracks(sz, wid) { // vết nứt mảnh theo ô Voronoi
      var C = Math.max(6, sz), wd = wid || 0.035;
      for (var yy = 0, q = 0; yy < h; yy++) for (var xx = 0; xx < w; xx++, q++) {
        if (!out[q * 4 + 3]) continue;
        var ax = (xx + 0.5 + F.ox) / C, ay = (yy + 0.5 + F.oy) / C, cx0 = Math.floor(ax), cy0 = Math.floor(ay), f1 = 9, f2 = 9;
        for (var jy = -1; jy <= 1; jy++) for (var jx = -1; jx <= 1; jx++) {
          var gx = cx0 + jx, gy = cy0 + jy, qx = gx + hash2(gx, gy, 41), qy = gy + hash2(gx, gy, 43);
          var dq = (ax - qx) * (ax - qx) + (ay - qy) * (ay - qy);
          if (dq < f1) { f2 = f1; f1 = dq; } else if (dq < f2) f2 = dq;
        }
        if (Math.sqrt(f2) - Math.sqrt(f1) < wd * (0.6 + 0.8 * hash2(cx0, cy0, 47))) out[q * 4 + 3] = 0;
      }
    }
    function solid(mask, col) { // tô một màu theo mặt nạ
      for (var q = 0; q < n; q++) if (mask[q]) { out[q * 4] = col[0]; out[q * 4 + 1] = col[1]; out[q * 4 + 2] = col[2]; out[q * 4 + 3] = 255; }
    }
    function densArr() { var d = new Float32Array(n); for (var q = 0; q < n; q++) d[q] = dens(q * 4); return d; }
    function shiftPlate(src, dx, dy) { // dịch một bản in (lệch khuôn)
      var o2 = new Uint8Array(n);
      for (var yy = 0; yy < h; yy++) for (var xx = 0; xx < w; xx++) {
        var sx = xx - dx, sy = yy - dy;
        if (sx >= 0 && sy >= 0 && sx < w && sy < h && src[sy * w + sx]) o2[yy * w + xx] = 1;
      }
      return o2;
    }
    var s = per / 6; // hệ số kích thước theo độ phân giải

    switch (kind) {

    case "v_sepia": // Ảnh sepia
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var l = lum(p) * 255, mx = 0.55 + 0.45 * amt;
        copyPx(p, rgba[p] * (1 - mx) + (l * 1.07 + 20) * mx, rgba[p + 1] * (1 - mx) + (l * 0.86 + 8) * mx, rgba[p + 2] * (1 - mx) + (l * 0.62) * mx);
      }
      erode(0.06 + 0.1 * amt, per * 0.25, 11, 0.6);
      return out;

    case "v_yellowed": // Ảnh ố vàng, đốm ố
      var spots = noise(per * 3, 21, 0, 3);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var r = rgba[p] * 0.92 + 32, g = rgba[p + 1] * 0.88 + 22, b = rgba[p + 2] * 0.66 + 10;
        if (spots[i] > 1 - 0.06 * amt) { r = r * 0.6 + 150 * 0.4; g = g * 0.6 + 100 * 0.4; b = b * 0.6 + 45 * 0.4; }
        copyPx(p, r, g, b);
      }
      erode(0.05 + 0.08 * amt, per * 0.3, 23, 0.6);
      return out;

    case "v_scratch": // Phim xước: vết xước dọc + bụi
      var colW = Math.max(1, Math.round(1.2 * s)), seg = noise(per * 6, 31, 0, 2);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var c3 = sat(rgba[p], rgba[p + 1], rgba[p + 2], 1 - 0.5 * amt); copyPx(p, c3[0], c3[1], c3[2]);
      }
      for (x = 0; x < w; x++) {
        var col = Math.floor((x + F.ox) / colW);
        if (hash2(col, 1, 33) > 0.015 + 0.03 * amt) continue;
        for (y = 0; y < h; y++) { i = y * w + x; if (seg[i] > 0.35) out[i * 4 + 3] = 0; }
      }
      erode(0.02 + 0.03 * amt, per * 0.15, 35, 0.9);
      return out;

    case "v_washed": // Giặt bạc
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var c4 = sat(rgba[p], rgba[p + 1], rgba[p + 2], 1 - 0.6 * amt), lift = 0.32 * amt;
        copyPx(p, c4[0] * (1 - lift) + 225 * lift, c4[1] * (1 - lift) + 220 * lift, c4[2] * (1 - lift) + 210 * lift);
      }
      erode(0.12 + 0.2 * amt, per * 0.2, 41, 0.7);
      return out;

    case "v_screenprint": // In lụa cũ: 5 màu phẳng + nứt + mòn
      var rs = E.indexColor(rgba, w, h, { colors: 5, shirt: null, dither: "none" }), cps = E.indexComposite(rs, w, h);
      for (i = 0; i < n * 4; i++) out[i] = cps[i];
      cracks(per * 5, 0.03);
      erode(0.1 + 0.2 * amt, Math.min(F.fw, F.fh) / 16, 51, 0.15);
      return out;

    case "v_stamp": // Con dấu cao su: 1 màu mực, mực không đều, mép sần
      var dd = densArr(), mott = noise(per * 1.5, 61, 0.2, 3), sm = boxBlur(dd, w, h, Math.max(1, Math.round(s)));
      var edge = noise(per * 0.3, 63, 0.6);
      var msk = new Uint8Array(n);
      for (i = 0; i < n; i++) msk[i] = sm[i] + (edge[i] - 0.5) * 0.25 > 0.42 && mott[i] > 0.2 * amt ? 1 : 0;
      solid(msk, INK);
      return out;

    case "v_band80": // Áo band 80s: 1 màu, chấm to, mòn
      var hb = E.render({ t: "halftone", shape: "round", periodPx: per * 1.6, angleDeg: 45, frame: F }, densArr(), w, h);
      solid(hb, INK);
      erode(0.12 + 0.22 * amt, Math.min(F.fw, F.fh) / 18, 71, 0.2);
      return out;

    case "v_surf70": // Áo surf 70s: dải màu nâu cam vàng kem
      var surf = [[90, 40, 20], [205, 85, 30], [240, 170, 50], [250, 232, 190]];
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var cs = gmap(lum(p), surf); copyPx(p, cs[0], cs[1], cs[2]);
      }
      erode(0.06 + 0.12 * amt, per * 0.3, 81, 0.6);
      return out;

    case "v_propaganda": // Poster cổ động: đen - màu nhấn - kem
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var lp = lum(p), cp = lp < 0.33 ? [28, 22, 20] : lp < 0.66 ? A : [238, 224, 190];
        copyPx(p, cp[0], cp[1], cp[2]); out[p + 3] = 255;
      }
      erode(0.06 + 0.12 * amt, per * 0.35, 91, 0.5);
      return out;

    case "v_woodcut": // Khắc gỗ: đặc ở vùng đậm, nét khắc gỗ ở vùng trung tính
      var dw = densArr(), mw = new Uint8Array(n), rough = noise(per * 0.4, 101, 0.5);
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        var dv = dw[i] + (rough[i] - 0.5) * 0.12;
        if (dv > 0.68) { mw[i] = 1; continue; }
        if (dv > 0.25) {
          var ph = (y + F.oy) / (per * 0.9) + fbm((x + F.ox) / (per * 8), (y + F.oy) / (per * 8), 103, 2) * 3;
          if (Math.abs((ph - Math.floor(ph)) * 2 - 1) < (dv - 0.25) / 0.43) mw[i] = 1;
        }
      }
      solid(mw, INK);
      return out;

    case "v_linocut": // Linocut: mảng đặc, vết đục ngắn
      var dl = densArr(), ml = new Uint8Array(n), gc = per * 1.2;
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        if (dl[i] < 0.5) continue;
        var cx = Math.floor((x + F.ox) / gc), cy = Math.floor((y + F.oy) / gc), hit = false;
        if (hash2(cx, cy, 111) < 0.18 + 0.25 * amt * (1 - dl[i])) {
          var u = ((x + F.ox) / gc - cx) * 2 - 1, v = ((y + F.oy) / gc - cy) * 2 - 1, an = hash2(cx, cy, 113) * 3.14;
          var ru = u * Math.cos(an) + v * Math.sin(an), rv = -u * Math.sin(an) + v * Math.cos(an);
          hit = Math.abs(rv) < 0.16 && Math.abs(ru) < 0.85;
        }
        if (!hit) ml[i] = 1;
      }
      solid(ml, INK);
      return out;

    case "v_newspaper": // Báo cũ: chấm thô 1 màu, mực lúc đậm lúc nhạt
      var hn = E.render({ t: "halftone", shape: "round", periodPx: per * 1.25, angleDeg: 45, frame: F }, densArr(), w, h);
      solid(hn, INK);
      erode(0.1 + 0.2 * amt, Math.min(F.fw, F.fh) / 10, 121, 0);
      return out;

    case "v_comic": // Truyện tranh cổ: chấm CMY to lệch khuôn + nét đen
      var mis = Math.max(1, Math.round(2 * s * (0.5 + amt))), inks = [];
      var cols = { c: [0, 170, 230], m: [230, 30, 120], y: [255, 220, 0] }, offs = { c: [mis, 0], m: [0, mis], y: [-mis, -mis] }, angs = { c: 15, m: 75, y: 0 };
      ["y", "m", "c"].forEach(function (ch) {
        var dch = E.cmykChannel(rgba, w, h, 0.6, ch);
        var inkc = E.render({ t: "halftone", shape: "round", periodPx: per * 1.5, angleDeg: angs[ch], frame: F }, dch, w, h);
        inks.push({ ink: shiftPlate(inkc, offs[ch][0], offs[ch][1]), rgb: cols[ch] });
      });
      var kk = E.cmykChannel(rgba, w, h, 1, "k"), kInk = new Uint8Array(n);
      for (i = 0; i < n; i++) kInk[i] = kk[i] > 0.55 ? 1 : 0;
      inks.push({ ink: kInk, rgb: [25, 20, 25] });
      out = E.compositeInks(inks, w, h);
      return out;

    case "v_polaroid": // Polaroid phai: bóng ngả xanh, sáng ngả ấm, tương phản thấp, viền tan
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var lq = lum(p), c5 = sat(rgba[p], rgba[p + 1], rgba[p + 2], 0.75), t5 = 0.25 + 0.3 * amt;
        var tint = lq < 0.5 ? [20, 60, 70] : [255, 225, 180];
        copyPx(p, 30 + c5[0] * 0.8 * (1 - t5 * 0.5) + tint[0] * t5 * 0.4, 30 + c5[1] * 0.8 * (1 - t5 * 0.5) + tint[1] * t5 * 0.4, 30 + c5[2] * 0.8 * (1 - t5 * 0.5) + tint[2] * t5 * 0.4);
      }
      edgeFade(0.05 + 0.1 * amt, 141);
      return out;

    case "v_kodachrome": // Kodachrome: đỏ rực, ấm, tương phản, hạt phim
      var grain = noise(per * 0.15, 151, 0.9, 1);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var c6 = sat(rgba[p], rgba[p + 1], rgba[p + 2], 1.25 + 0.3 * amt), gr6 = (grain[i] - 0.5) * 30 * amt;
        var sc6 = function (v) { v /= 255; return 255 * (v < 0.5 ? 2 * v * v : 1 - 2 * (1 - v) * (1 - v)) * 0.6 + v * 255 * 0.4; };
        copyPx(p, sc6(c6[0]) * 1.06 + 6 + gr6, sc6(c6[1]) * 0.98 + gr6, sc6(c6[2]) * 0.85 + gr6);
      }
      return out;

    case "v_crossproc": // Cross-process 70s: sáng ngả vàng lục, tối ngả lam
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var rr = rgba[p] / 255, gg = rgba[p + 1] / 255, bb = rgba[p + 2] / 255, m7 = 0.6 + 0.4 * amt;
        var r7 = Math.pow(rr, 0.85), g7 = Math.min(1, gg * 1.12 + 0.03), b7 = bb * 0.55 + 0.22;
        copyPx(p, (rr * (1 - m7) + r7 * m7) * 255, (gg * (1 - m7) + g7 * m7) * 255, (bb * (1 - m7) + b7 * m7) * 255);
      }
      return out;

    case "v_lomo": // Lomo: màu rực, tối 4 góc
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        p = i * 4;
        if (rgba[p + 3] < 8) continue;
        var vx = (x + F.ox) / F.fw - 0.5, vy = (y + F.oy) / F.fh - 0.5, vig = 1 - Math.min(1, (vx * vx + vy * vy) * 2.4) * (0.45 + 0.4 * amt);
        var c8 = sat(rgba[p], rgba[p + 1], rgba[p + 2], 1.45);
        copyPx(p, c8[0] * vig, c8[1] * vig, c8[2] * vig);
      }
      return out;

    case "v_cyanotype": // Cyanotype: dải xanh lam
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var cy9 = gmap(lum(p), [[8, 32, 80], [25, 85, 160], [230, 240, 248]]); copyPx(p, cy9[0], cy9[1], cy9[2]);
      }
      erode(0.04 + 0.08 * amt, per * 0.3, 161, 0.6);
      return out;

    case "v_brownduo": // Duotone nâu
      var gb = noise(per * 0.15, 171, 0.9, 1);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var bd = gmap(Math.min(1, Math.max(0, lum(p) + (gb[i] - 0.5) * 0.12 * amt)), [[45, 25, 15], [150, 95, 55], [242, 222, 182]]);
        copyPx(p, bd[0], bd[1], bd[2]);
      }
      return out;

    case "v_misreg": // In lệch khuôn: tách 4 màu phẳng, mỗi bản lệch một chút
      var res = E.indexColor(rgba, w, h, { colors: 4, shirt: null, dither: "none" }), np = res.palette.length;
      var sh0 = Math.max(1, Math.round(3 * s * (0.5 + amt)));
      for (k = 0; k < np; k++) {
        var pl = new Uint8Array(n);
        for (i = 0; i < n; i++) pl[i] = res.labels[i] === k ? 1 : 0;
        var ang = k * 2.4, sp2 = shiftPlate(pl, Math.round(Math.cos(ang) * sh0 * (k ? 1 : 0)), Math.round(Math.sin(ang) * sh0 * (k ? 1 : 0)));
        solid(sp2, res.palette[k]);
      }
      return out;

    case "v_matchbox": // Nhãn hộp diêm: 3 màu phẳng, giấy mòn
      var rm = E.indexColor(rgba, w, h, { colors: 3, shirt: null, dither: "none" });
      var comp = E.indexComposite(rm, w, h);
      for (i = 0; i < n * 4; i++) out[i] = comp[i];
      erode(0.08 + 0.18 * amt, Math.min(F.fw, F.fh) / 14, 191, 0.25);
      return out;

    case "v_peel": // Sơn tróc: mảng sơn bong ra theo ô
      for (i = 0, p = 0; i < n; i++, p += 4) if (rgba[p + 3] >= 8) copyPx(p, rgba[p], rgba[p + 1], rgba[p + 2]);
      var C = per * 4;
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        if (!out[i * 4 + 3]) continue;
        var ax = (x + F.ox) / C, ay = (y + F.oy) / C, gx = Math.floor(ax), gy = Math.floor(ay), b1 = 9, b2 = 9, bc = 0;
        for (var oy = -1; oy <= 1; oy++) for (var ox = -1; ox <= 1; ox++) {
          var qx = gx + ox + hash2(gx + ox, gy + oy, 201), qy = gy + oy + hash2(gx + ox, gy + oy, 203);
          var d2 = (ax - qx) * (ax - qx) + (ay - qy) * (ay - qy);
          if (d2 < b1) { b2 = b1; b1 = d2; bc = hash2(gx + ox, gy + oy, 205); } else if (d2 < b2) b2 = d2;
        }
        if (bc < 0.06 + 0.22 * amt || Math.sqrt(b2) - Math.sqrt(b1) < 0.03) out[i * 4 + 3] = 0;
      }
      return out;

    case "v_rust": // Gỉ sét: mảng gỉ nâu cam lấn vào hình
      var rn = noise(per * 2.5, 211, 0, 4), rf = noise(per * 0.25, 213, 0.6);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var ru2 = Math.max(0, (0.45 * amt + 0.1 - rn[i]) * 4);
        ru2 = Math.min(1, ru2);
        var rc = [150 + 40 * rf[i], 65 + 30 * rf[i], 25];
        copyPx(p, rgba[p] * (1 - ru2) + rc[0] * ru2, rgba[p + 1] * (1 - ru2) + rc[1] * ru2, rgba[p + 2] * (1 - ru2) + rc[2] * ru2);
        if (ru2 > 0.7 && rf[i] < 0.25) out[p + 3] = 0;
      }
      return out;

    case "v_sunfade": // Vải bạc nắng: phía trên phai màu nhiều hơn
      var fm = noise(per * 0.2, 221, 0.7);
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        p = i * 4;
        if (rgba[p + 3] < 8) continue;
        var f9 = Math.max(0, 1 - (y + F.oy) / F.fh * 1.3) * (0.4 + 0.6 * amt);
        var c9 = sat(rgba[p], rgba[p + 1], rgba[p + 2], 1 - 0.8 * f9);
        copyPx(p, c9[0] * (1 - f9 * 0.5) + 235 * f9 * 0.5, c9[1] * (1 - f9 * 0.5) + 225 * f9 * 0.5, c9[2] * (1 - f9 * 0.5) + 215 * f9 * 0.5);
        if (fm[i] < f9 * 0.3) out[p + 3] = 0;
      }
      return out;

    case "v_bleed": // Mực loang: mực lan ra ngoài mép không đều
      var al = new Float32Array(n), pr = new Float32Array(n), pg = new Float32Array(n), pb = new Float32Array(n);
      for (i = 0, p = 0; i < n; i++, p += 4) { var a9 = rgba[p + 3] / 255; al[i] = a9; pr[i] = rgba[p] * a9; pg[i] = rgba[p + 1] * a9; pb[i] = rgba[p + 2] * a9; }
      var rad = Math.max(1, Math.round(per * (0.5 + 0.8 * amt)));
      var ba = boxBlur(al, w, h, rad), br = boxBlur(pr, w, h, rad), bgc = boxBlur(pg, w, h, rad), bbc = boxBlur(pb, w, h, rad), bn = noise(per * 0.5, 231, 0.4);
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] >= 128) {
          var bk = ba[i] > 0.01 ? 1 / ba[i] : 0, wb = 0.5 + 0.4 * amt * (0.5 + bn[i]);
          var rB = Math.min(rgba[p], br[i] * bk), gB = Math.min(rgba[p + 1], bgc[i] * bk), bB = Math.min(rgba[p + 2], bbc[i] * bk);
          copyPx(p, rgba[p] * (1 - wb) + rB * wb, rgba[p + 1] * (1 - wb) + gB * wb, rgba[p + 2] * (1 - wb) + bB * wb); out[p + 3] = 255; continue;
        }
        if (ba[i] > 0.2 + bn[i] * 0.45) { out[p] = br[i] / ba[i] * 0.85; out[p + 1] = bgc[i] / ba[i] * 0.85; out[p + 2] = bbc[i] / ba[i] * 0.85; out[p + 3] = 255; }
      }
      return out;

    case "v_letterpress": // Letterpress: màu phẳng, mực ép loang lổ chỗ đậm chỗ nhạt, mép đậm hơn
      var rl = E.indexColor(rgba, w, h, { colors: 4, shirt: null, dither: "none" }), cl = E.indexComposite(rl, w, h);
      var lp1 = noise(per * 1.2, 241, 0.3, 3), lab = rl.labels;
      for (y = 0, i = 0; y < h; y++) for (x = 0; x < w; x++, i++) {
        p = i * 4;
        if (!cl[p + 3]) continue;
        var edgeL = (x > 0 && lab[i - 1] !== lab[i]) || (x < w - 1 && lab[i + 1] !== lab[i]) || (y > 0 && lab[i - w] !== lab[i]) || (y < h - 1 && lab[i + w] !== lab[i]);
        var st = edgeL ? -0.15 : Math.max(0, 0.55 * amt + 0.1 - lp1[i]) * 1.6;
        out[p] = clamp(cl[p] + (242 - cl[p]) * st); out[p + 1] = clamp(cl[p + 1] + (236 - cl[p + 1]) * st); out[p + 2] = clamp(cl[p + 2] + (224 - cl[p + 2]) * st); out[p + 3] = 255;
      }
      erode(0.03 + 0.05 * amt, per * 0.15, 243, 0.9);
      return out;

    case "v_varsity": // Varsity: phần đậm tô 1 màu + viền dày màu thứ 2, nứt nhẹ
      var dv2 = boxBlur(densArr(), w, h, Math.max(1, Math.round(s))), fill = new Uint8Array(n), fa = new Float32Array(n);
      for (i = 0; i < n; i++) if (dv2[i] > 0.45) { fill[i] = 1; fa[i] = 1; }
      var grow = boxBlur(fa, w, h, Math.max(1, Math.round(per * 0.7))), outl = new Uint8Array(n);
      for (i = 0; i < n; i++) if (!fill[i] && grow[i] > 0.12) outl[i] = 1;
      solid(outl, B); solid(fill, INK);
      cracks(per * 4, 0.025);
      erode(0.04 + 0.1 * amt, per * 0.4, 251, 0.4);
      return out;

    case "v_engstamp": // Tem khắc: nét khắc 1 màu như tem bưu chính
      var de = densArr(), eg = E.render({ t: "engrave", periodPx: per * 1.0, angleDeg: 0, frame: F }, de, w, h);
      solid(eg, INK);
      return out;

    case "v_vhs": // Băng VHS: lem màu, lệch kênh, vạch quét, dải nhiễu
      var shv = Math.max(1, Math.round(F.fw * 0.006 * (0.5 + amt))), bandH = Math.max(3, F.fh * 0.025);
      for (y = 0; y < h; y++) {
        var Yb = y + F.oy, band = Math.floor(Yb / bandH), track = hash2(band, 3, 261) < 0.1 + 0.12 * amt;
        var tOff = track ? Math.round((hash2(band, 4, 263) - 0.5) * F.fw * 0.04) : 0, scan = (Math.floor(Yb / Math.max(1, Math.round(s))) % 2) ? 0.8 : 1;
        for (x = 0; x < w; x++) {
          p = (y * w + x) * 4;
          var qL = (y * w + Math.max(0, Math.min(w - 1, x - shv + tOff))) * 4, qC = (y * w + Math.max(0, Math.min(w - 1, x + tOff))) * 4, qR = (y * w + Math.max(0, Math.min(w - 1, x + shv + tOff))) * 4;
          var aa = Math.max(rgba[qL + 3], rgba[qC + 3], rgba[qR + 3]);
          if (aa < 8) continue;
          var cv = sat(rgba[qL], rgba[qC + 1], rgba[qR + 2], 0.75);
          out[p] = clamp(cv[0] * scan); out[p + 1] = clamp(cv[1] * scan); out[p + 2] = clamp(cv[2] * scan); out[p + 3] = aa;
          if (track && hash2(x, Yb, 265) < 0.25) { out[p] = out[p + 1] = out[p + 2] = 230; }
        }
      }
      return out;

    case "v_thrift": // Áo thrift: phai nhẹ, nứt mịn, xù lông (lỗ nhỏ rải rác)
      for (i = 0, p = 0; i < n; i++, p += 4) {
        if (rgba[p + 3] < 8) continue;
        var ct = sat(rgba[p], rgba[p + 1], rgba[p + 2], 1 - 0.4 * amt);
        copyPx(p, ct[0] * 0.9 + 22, ct[1] * 0.88 + 18, ct[2] * 0.85 + 12);
      }
      cracks(per * 3, 0.025);
      erode(0.06 + 0.1 * amt, per * 0.12, 271, 0.95);
      return out;
    }
    throw new Error("Hiệu ứng vintage không hỗ trợ: " + kind);
  };

  return E;
});
