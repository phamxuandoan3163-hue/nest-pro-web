/*
 * NOVA Trame Studio 0.6 - giao diện panel (CEP).
 * Viết ES5 để chạy được trên trình duyệt cũ của Photoshop 2015.
 * Kiểu trame "native" dùng bộ lọc gốc của Photoshop; kiểu "canvas" do engine.js kết xuất
 * rồi gửi file PNG đen trắng về Photoshop hoàn thiện.
 */
(function () {
  var E = window.NovaEngine;

  var STYLES = [
    { id: "round", name: "Chấm tròn", engine: "native", nativeKind: "halftone", shape: "round",
      pv: { t: "halftone", shape: "round" }, lpi: true, ang: true,
      desc: "Lưới chấm tròn đều. Kiểu trame phổ biến nhất, chuyển sắc tự nhiên." },
    { id: "ellipse", name: "Ellipse", engine: "native", nativeKind: "halftone", shape: "ellipse",
      pv: { t: "halftone", shape: "ellipse" }, lpi: true, ang: true,
      desc: "Chấm dẹt, nối thành chuỗi ở vùng trung tính. Chuyển sắc mềm hơn chấm tròn." },
    { id: "line", name: "Đường kẻ", engine: "native", nativeKind: "halftone", shape: "line",
      pv: { t: "halftone", shape: "line" }, lpi: true, ang: true,
      desc: "Vạch song song dày mỏng theo độ đậm, xoay được góc. Hợp hiệu ứng khắc, vintage." },
    { id: "square", name: "Chấm vuông", engine: "native", nativeKind: "halftone", shape: "square",
      pv: { t: "halftone", shape: "square" }, lpi: true, ang: true,
      desc: "Chấm vuông, nét gọn và kỹ thuật." },
    { id: "diamond", name: "Chấm thoi", engine: "native", nativeKind: "halftone", shape: "diamond",
      pv: { t: "halftone", shape: "diamond" }, lpi: true, ang: true,
      desc: "Chấm hình kim cương, góc cạnh, nối thành bàn cờ ở vùng 50%." },
    { id: "cross", name: "Chữ thập", engine: "native", nativeKind: "halftone", shape: "cross",
      pv: { t: "halftone", shape: "cross" }, lpi: true, ang: true,
      desc: "Dấu cộng lặp lại, tạo kết cấu lưới đặc biệt." },
    { id: "stripeh", name: "Sọc ngang", engine: "canvas",
      pv: { t: "halftone", shape: "line", fixedAngle: 0 }, lpi: true, ang: false,
      desc: "Vạch ngang đều, dày mỏng theo độ đậm." },
    { id: "stripev", name: "Sọc dọc", engine: "canvas",
      pv: { t: "halftone", shape: "line", fixedAngle: 90 }, lpi: true, ang: false,
      desc: "Vạch dọc đều, dày mỏng theo độ đậm." },
    { id: "striped", name: "Sọc chéo", engine: "canvas",
      pv: { t: "halftone", shape: "line", fixedAngle: 135 }, lpi: true, ang: false,
      desc: "Vạch chéo 135°, tạo cảm giác chuyển động." },
    { id: "diffusion", name: "Hạt lan mực", engine: "native", nativeKind: "bitmap", method: "diffusionDither",
      pv: { t: "diffusion", kernel: "fs" },
      desc: "Khuếch tán sai số của Photoshop. Hạt mịn, giữ chi tiết tốt." },
    { id: "atkinson", name: "Atkinson", engine: "canvas",
      pv: { t: "diffusion", kernel: "atkinson" },
      desc: "Hạt sáng, tương phản nhẹ, kiểu máy Mac cổ. Vùng rất tối vẫn giữ lấm tấm trắng." },
    { id: "stucki", name: "Stucki", engine: "canvas",
      pv: { t: "diffusion", kernel: "stucki" },
      desc: "Lan mực rộng, chi tiết cao, hạt đều hơn Floyd–Steinberg." },
    { id: "jarvis", name: "Jarvis", engine: "canvas",
      pv: { t: "diffusion", kernel: "jarvis" },
      desc: "Lan mực rộng nhất, bóng đổ mượt, hợp nền chuyển sắc lớn." },
    { id: "bayer4", name: "Bayer 4×4", engine: "canvas",
      pv: { t: "ordered", n: 4 },
      desc: "Ma trận lặp 4×4, hạt to kiểu retro game." },
    { id: "pattern", name: "Bayer 8×8", engine: "native", nativeKind: "bitmap", method: "patternDither",
      pv: { t: "ordered", n: 8 },
      desc: "Ma trận lặp 8×8 của Photoshop, mịn hơn 4×4." },
    { id: "random", name: "Hạt ngẫu nhiên", engine: "canvas",
      pv: { t: "random" },
      desc: "Hạt phân bố ngẫu nhiên (FM), vân nhám kiểu grunge." },
    { id: "threshold", name: "Ngưỡng", engine: "native", nativeKind: "threshold",
      pv: { t: "threshold" }, level: true,
      desc: "Chỉ đen và trắng, không có chấm. Dùng cho logo, chữ, nét đơn giản." },

    { id: "euclid", name: "Chấm Euclid", engine: "canvas",
      pv: { t: "halftone", shape: "euclid" }, lpi: true, ang: true,
      desc: "Chấm chuẩn ngành in: tròn ở vùng sáng, bàn cờ ở 50%, lỗ tròn ở vùng tối. Giữ chi tiết vùng tối tốt hơn chấm tròn." },
    { id: "celldot", name: "Chấm theo ô", engine: "canvas",
      pv: { t: "celldot", shape: "round" }, lpi: true, ang: true,
      desc: "Mỗi ô một chấm tròn hoàn hảo theo độ đậm trung bình, như Filter › Color Halftone. Chấm sắc, chất pop-art." },
    { id: "negative", name: "Chấm âm", engine: "canvas",
      pv: { t: "halftone", shape: "round", invert: true }, lpi: true, ang: true,
      desc: "Lỗ trắng tròn trên nền mực. In mực trắng trên áo đen thì lỗ để lộ màu áo." },
    { id: "fade", name: "Mờ dần", engine: "canvas",
      pv: { t: "halftone", shape: "round", fade: 0.55 }, lpi: true, ang: true,
      desc: "Chấm tròn tan dần ra mép dưới, hình biến vào màu áo. Chỉnh độ dài và hướng ở thẻ Hiệu ứng phụ." },

    /* ----- Streetwear / grunge ----- */
    { id: "grain", name: "Hạt sần", group: "street", engine: "canvas",
      pv: { t: "grain" }, lpi: true, lpiLabel: "Cỡ hạt (LPI)", lpiFactor: 1.12,
      desc: "Hạt to nhỏ không đều, vón thành cụm như mực bột. Chất Hellstar. LPI thấp = hạt to." },
    { id: "photocopy", name: "Photocopy", group: "street", engine: "canvas",
      pv: { t: "photocopy" }, lpi: true, level: true, lpiLabel: "Cỡ sạn (LPI)", lpiFactor: 1.12,
      desc: "Trắng đen gắt có rung nhiễu và hạt bắn, như bản photocopy (kiểu Heaven/Hell). Thanh Ngưỡng chỉnh độ đậm." },
    { id: "grunge", name: "Grunge", group: "street", engine: "canvas",
      pv: { t: "threshold", distress: 0.33 }, level: true,
      desc: "Trắng đen bị mòn loang lổ, mép rỗ (kiểu Vicinity). Độ mòn chỉnh ở thẻ Hiệu ứng phụ." },
    { id: "grungedots", name: "Chấm bong tróc", group: "street", engine: "canvas",
      pv: { t: "halftone", shape: "round", distress: 0.3 }, lpi: true, ang: true,
      desc: "Chấm tròn bị bong tróc như in lâu ngày." },
    { id: "mezzo", name: "Mezzotint", group: "street", engine: "canvas",
      pv: { t: "mezzo" }, lpi: true, lpiLabel: "Độ mảnh (LPI)",
      desc: "Sợi ngắn nằm ngang như bản khắc mezzotint." },
    { id: "stipple", name: "Bút kim", group: "street", engine: "canvas",
      pv: { t: "stipple" }, lpi: true, lpiLabel: "Mật độ (LPI)",
      desc: "Chấm cùng cỡ, chỉ thay mật độ, như vẽ bằng bút kim." },

    { id: "sketch", name: "Ký họa", group: "street", engine: "canvas",
      pv: { t: "sketch" }, lpi: true, lpiLabel: "Độ dày gạch (LPI)",
      desc: "Nét viền bút chì cộng gạch chéo ở vùng tối, như bản ký họa tay." },

    /* ----- Hình chấm đặc biệt ----- */
    { id: "roundsq", name: "Vuông bo góc", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "roundsq" }, lpi: true, ang: true,
      desc: "Chấm vuông bo tròn góc, mềm hơn chấm vuông, đậm chất retro." },
    { id: "clover", name: "Cỏ 4 lá", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "clover" }, lpi: true, ang: true, lpiFactor: 0.55,
      desc: "Chấm hình cỏ bốn lá. Dùng LPI thấp để thấy rõ hình." },
    { id: "flower", name: "Hoa 6 cánh", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "flower" }, lpi: true, ang: true, lpiFactor: 0.55,
      desc: "Chấm hình bông hoa 6 cánh, hợp áo nữ, áo trẻ em." },
    { id: "gear", name: "Bánh răng", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "gear" }, lpi: true, ang: true, lpiFactor: 0.55,
      desc: "Chấm hình bánh răng, hợp chủ đề cơ khí, xe cộ." },
    { id: "drop", name: "Giọt nước", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "drop" }, lpi: true, ang: true, lpiFactor: 0.6,
      desc: "Chấm hình giọt nước đáy tròn đỉnh nhọn." },
    { id: "bullseye", name: "Bia bắn", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "bullseye" }, lpi: true, ang: true, lpiFactor: 0.45,
      desc: "Mỗi chấm gồm các vòng tròn lồng nhau như bia bắn." },
    { id: "squarering", name: "Ô vuông lồng", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "squarering" }, lpi: true, ang: true, lpiFactor: 0.6,
      desc: "Mỗi chấm là một khung vuông rỗng, dày dần theo độ đậm." },
    { id: "jitterdash", name: "Mưa ngẫu nhiên", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "dash", jitter: true }, lpi: true,
      desc: "Chấm gạch ngắn xoay ngẫu nhiên mỗi ô, như mưa rơi hay rơm rạ." },
    { id: "jittertri", name: "Tam giác loạn", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "triangle", jitter: true }, lpi: true, lpiFactor: 0.8,
      desc: "Chấm tam giác xoay ngẫu nhiên, kiểu glitch hình học." },
    { id: "voronoidots", name: "Tế bào", group: "shape", engine: "canvas",
      pv: { t: "voronoidots" }, lpi: true,
      desc: "Chấm tròn đặt ngẫu nhiên kiểu tế bào, không có lưới nên không bị vân lặp." },
    { id: "sunflower", name: "Hướng dương", group: "shape", engine: "canvas",
      pv: { t: "sunflower" }, lpi: true,
      desc: "Chấm xếp theo góc vàng 137,5° như hạt hoa hướng dương, tỏa từ giữa hình." },
    { id: "morse", name: "Mã Morse", group: "shape", engine: "canvas",
      pv: { t: "morse" }, lpi: true, lpiFactor: 0.8,
      desc: "Hàng chấm gạch như mã Morse; vùng đậm gạch dài và dày hơn." },

    { id: "hex", name: "Tổ ong", group: "shape", engine: "canvas",
      pv: { t: "hex" }, lpi: true, ang: true,
      desc: "Chấm tròn xếp lưới lục giác như tổ ong. Mịn hơn lưới vuông, ít lộ hướng lưới." },
    { id: "hexagon", name: "Lục giác", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "hexagon" }, lpi: true, ang: true,
      desc: "Chấm hình lục giác, vùng tối nối thành tổ ong." },
    { id: "triangle", name: "Tam giác", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "triangle" }, lpi: true, ang: true,
      desc: "Chấm hình tam giác, hợp thiết kế hình học, streetwear." },
    { id: "star", name: "Ngôi sao", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "star" }, lpi: true, ang: true, lpiFactor: 0.50,
      desc: "Chấm hình ngôi sao 5 cánh. Nên dùng LPI thấp (10–25) để thấy rõ hình sao." },
    { id: "heart", name: "Trái tim", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "heart" }, lpi: true, ang: true, lpiFactor: 0.45,
      desc: "Chấm hình trái tim. Dùng LPI thấp để thấy rõ." },
    { id: "dash", name: "Chấm gạch", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "dash" }, lpi: true, ang: true,
      desc: "Chấm dạng gạch ngắn xoay theo góc, như vệt mưa." },
    { id: "donut", name: "Vòng nhẫn", group: "shape", engine: "canvas",
      pv: { t: "halftone", shape: "donut" }, lpi: true, ang: true, lpiFactor: 0.62,
      desc: "Mỗi chấm là một vòng tròn rỗng, dày dần theo độ đậm." },

    /* ----- Hoa văn đường nét ----- */
    { id: "lattice", name: "Mắt cáo", group: "pattern", engine: "canvas",
      pv: { t: "lattice" }, lpi: true, lpiFactor: 0.7,
      desc: "Lưới chéo hai chiều như hàng rào mắt cáo, nét dày theo độ đậm." },
    { id: "brick", name: "Gạch xây", group: "pattern", engine: "canvas",
      pv: { t: "brick" }, lpi: true, lpiFactor: 0.6,
      desc: "Mạch vữa tường gạch, mạch dày lên ở vùng đậm. Hợp phong cách đường phố." },
    { id: "honeycomb", name: "Lưới tổ ong", group: "pattern", engine: "canvas",
      pv: { t: "honeycomb" }, lpi: true, lpiFactor: 0.8,
      desc: "Đường viền các ô lục giác như tổ ong, nét dày theo độ đậm." },
    { id: "squarerings", name: "Vuông đồng tâm", group: "pattern", engine: "canvas",
      pv: { t: "squarerings" }, lpi: true, multi: true,
      desc: "Các khung vuông đồng tâm. Hỗ trợ bố cục nhiều tâm." },
    { id: "seigaiha", name: "Sóng biển Nhật", group: "pattern", engine: "canvas",
      pv: { t: "seigaiha" }, lpi: true, lpiFactor: 0.45,
      desc: "Họa tiết sóng biển Nhật (seigaiha): các vảy cung tròn lồng nhau." },
    { id: "spiderweb", name: "Mạng nhện", group: "pattern", engine: "canvas",
      pv: { t: "spiderweb" }, lpi: true, multi: true,
      desc: "Vòng tròn và tia đan thành mạng nhện. Hỗ trợ nhiều tâm, hợp áo Halloween, rock." },
    { id: "weave", name: "Đan rổ", group: "pattern", engine: "canvas",
      pv: { t: "weave" }, lpi: true, lpiFactor: 0.35,
      desc: "Sọc ngang dọc xen kẽ như đan rổ, đan vải." },
    { id: "diamondplate", name: "Thép gân", group: "pattern", engine: "canvas",
      pv: { t: "diamondplate" }, lpi: true, lpiFactor: 0.45,
      desc: "Gân chéo như tấm thép chống trượt, hợp chủ đề công nghiệp, xe." },
    { id: "zebra", name: "Vằn ngựa", group: "pattern", engine: "canvas",
      pv: { t: "zebra" }, lpi: true, lpiFactor: 0.7,
      desc: "Sọc vằn uốn lượn như da ngựa vằn, dày mỏng theo độ đậm." },
    { id: "leopard", name: "Da báo", group: "pattern", engine: "canvas",
      pv: { t: "leopard" }, lpi: true, lpiFactor: 0.8,
      desc: "Đốm vòng không đều như da báo." },
    { id: "marble", name: "Vân đá", group: "pattern", engine: "canvas",
      pv: { t: "marble" }, lpi: true,
      desc: "Vân mảnh uốn lượn như đá cẩm thạch." },
    { id: "camo", name: "Rằn ri", group: "pattern", engine: "canvas",
      pv: { t: "camo" }, lpi: true, lpiFactor: 0.7,
      desc: "Mảng loang to kiểu quân đội; độ phủ đúng theo độ đậm." },

    { id: "rings", name: "Vòng tròn", group: "pattern", engine: "canvas", multi: true,
      pv: { t: "rings" }, lpi: true,
      desc: "Vòng tròn đồng tâm. Thẻ Bố cục nhiều tâm: tạo nhiều cụm vòng to nhỏ chen nhau." },
    { id: "spiral", name: "Xoắn ốc", group: "pattern", engine: "canvas", multi: true, swirl: true,
      pv: { t: "spiral" }, lpi: true,
      desc: "Đường xoắn ốc liên tục. Bật nhiều tâm để có nhiều xoắn ốc to nhỏ, xoắn ngược chiều nhau." },
    { id: "radial", name: "Tỏa tia", group: "pattern", engine: "canvas", multi: true,
      pv: { t: "radial" }, lpi: true,
      desc: "Tia tỏa từ tâm như tia nắng. Nhiều tâm cho hiệu ứng pháo hoa, manga." },
    { id: "polardots", name: "Chấm xếp vòng", group: "pattern", engine: "canvas",
      pv: { t: "polardots" }, lpi: true,
      desc: "Chấm tròn xếp thành các vòng đồng tâm quanh giữa hình." },
    { id: "wave", name: "Lượn sóng", group: "pattern", engine: "canvas",
      pv: { t: "wave" }, lpi: true, ang: true,
      desc: "Đường lượn sóng song song, kiểu khắc tiền giấy." },
    { id: "zigzag", name: "Răng cưa", group: "pattern", engine: "canvas",
      pv: { t: "zigzag" }, lpi: true,
      desc: "Đường gãy khúc zigzag, dày mỏng theo độ đậm." },
    { id: "hatch", name: "Đan chéo", group: "pattern", engine: "canvas",
      pv: { t: "hatch" }, lpi: true, ang: true,
      desc: "Nét gạch một chiều ở vùng sáng, thêm lớp vuông góc ở vùng tối, như ký họa bút sắt." },
    { id: "squiggle", name: "Sóng điều biến", group: "pattern", engine: "canvas",
      pv: { t: "squiggle" }, lpi: true,
      desc: "Các hàng sóng ngang, vùng đậm sóng dày và mạnh hơn." },
    { id: "wood", name: "Vân gỗ", group: "pattern", engine: "canvas",
      pv: { t: "wood" }, lpi: true,
      desc: "Vân gỗ cong lượn có nhiễu tự nhiên." },
    { id: "fingerprint", name: "Vân tay", group: "pattern", engine: "canvas",
      pv: { t: "fingerprint" }, lpi: true,
      desc: "Vòng đồng tâm méo như dấu vân tay." },
    { id: "bulge", name: "Lưới phồng", group: "pattern", engine: "canvas",
      pv: { t: "bulge" }, lpi: true,
      desc: "Đường kẻ ngang phồng ở giữa, cảm giác khối cầu 3D." },
    { id: "twirl", name: "Xoáy", group: "pattern", engine: "canvas",
      pv: { t: "twirl" }, lpi: true,
      desc: "Đường kẻ xoắn quanh tâm như nước xoáy." },
    { id: "interference", name: "Giao thoa", group: "pattern", engine: "canvas",
      pv: { t: "interference" }, lpi: true,
      desc: "Hai hệ vòng tròn lệch tâm chồng nhau tạo vân giao thoa." },
    { id: "truchet", name: "Mê cung", group: "pattern", engine: "canvas",
      pv: { t: "truchet" }, lpi: true, lpiFactor: 0.62,
      desc: "Các cung tròn nối nhau ngẫu nhiên thành mê cung." },
    { id: "fishscale", name: "Vảy cá", group: "pattern", engine: "canvas",
      pv: { t: "fishscale" }, lpi: true, lpiFactor: 0.62,
      desc: "Cung tròn xếp so le như vảy cá, vảy rồng." },
    { id: "contour", name: "Đồng mức", group: "pattern", engine: "canvas",
      pv: { t: "contour" }, lpi: true, lpiLabel: "Độ mảnh (LPI)",
      desc: "Chỉ vẽ đường nối các điểm cùng độ đậm, như bản đồ địa hình. Hợp line-art." },

    /* ----- Xu hướng áo thun ----- */
    { id: "sunset", name: "Sọc hoàng hôn", group: "trend", engine: "canvas", keepAll: true,
      pv: { t: "sunset" }, lpi: true, lpiLabel: "Độ dày sọc (LPI)",
      desc: "Sọc ngang retro thập niên 70 cắt nửa dưới hình, khe hở to dần xuống dưới. Giữ nguyên màu thiết kế." },
    { id: "dotfade", name: "Chấm chuyển hướng", group: "trend", engine: "canvas", keepAll: true,
      pv: { t: "dotfade" }, lpi: true, ang: true, angLabel: "Hướng tan",
      desc: "Hình tan dần thành chấm theo một hướng (90° = tan xuống dưới), không phụ thuộc sáng tối của hình." },
    { id: "crack", name: "Mực nứt", group: "trend", engine: "canvas", keepAll: true,
      pv: { t: "crack" }, lpi: true, lpiLabel: "Cỡ mảng nứt (LPI)",
      desc: "Vết nứt như áo in lâu năm, vùng sáng nứt nhiều hơn. Giữ nguyên màu thiết kế." },
    { id: "engrave", name: "Khắc tiền giấy", group: "trend", engine: "canvas",
      pv: { t: "engrave" }, lpi: true, ang: true, lpiFactor: 0.9,
      desc: "Đường khắc uốn theo khối sáng tối như hình trên tiền giấy, tem thư." },
    { id: "stencil", name: "Stencil", group: "trend", engine: "canvas",
      pv: { t: "stencil" }, lpi: true, level: true, lpiLabel: "Độ dày gạch (LPI)",
      desc: "Stencil graffiti 3 tông: tối = đặc, trung tính = gạch chéo, sáng = bỏ trống." },
    { id: "pixel1", name: "Pixel 1-bit", group: "trend", engine: "canvas",
      pv: { t: "pixel1" }, lpi: true, lpiLabel: "Cỡ ô (LPI)", lpiFactor: 0.6,
      desc: "Ô vuông lớn bật/tắt theo độ đậm, kiểu game cổ." },
    { id: "ascii", name: "Chữ ASCII", group: "trend", engine: "canvas",
      pv: { t: "ascii" }, lpi: true, lpiLabel: "Cỡ chữ (LPI)", lpiFactor: 0.75,
      desc: "Hình được dựng bằng ký tự. Đổi bộ ký tự (hoặc gõ chữ thương hiệu) ở thẻ Tùy chọn hiệu ứng." },
    { id: "glitch", name: "Glitch", group: "trend", engine: "fx", fx: "glitch",
      desc: "Lệch kênh RGB, các dải ngang bị xô lệch và vạch quét kiểu Y2K / VHS." },
    { id: "riso", name: "Riso 2 màu", group: "trend", engine: "fx", fx: "riso", lpi: true, lpiLabel: "Cỡ hạt (LPI)", fxColors: 2,
      fxA: "#FF48B0", fxB: "#0078BF",
      desc: "In riso: 2 màu mực hạt sần, in lệch khuôn nhẹ. Đổi 2 màu ở thẻ Tùy chọn hiệu ứng." },
    { id: "popart", name: "Pop-art 2 màu", group: "trend", engine: "fx", fx: "popart", lpi: true, fxColors: 2, lpiFactor: 0.6,
      fxA: "#FF2878", fxB: "#14A0FF",
      desc: "Chấm tròn 2 màu kiểu truyện tranh Mỹ, hai lưới lệch góc và lệch khuôn." },
    { id: "pixel8", name: "Pixel 8-bit", group: "trend", engine: "fx", fx: "pixel8", lpi: true, lpiLabel: "Cỡ ô (LPI)", lpiFactor: 0.5,
      desc: "Khối màu vuông và ít mức màu như đồ họa game 8-bit." },
    { id: "vintage", name: "Vintage bạc màu", group: "trend", engine: "fx", fx: "vintage", lpi: true, lpiLabel: "Cỡ mảng nứt (LPI)",
      desc: "Màu nhạt, ngả ấm, mực mòn và nứt như áo giặt nhiều năm." },
    { id: "trippy", name: "Ảo giác 70s", group: "trend", engine: "fx", fx: "trippy", fxColors: 2, fxA: "#FF7A00", fxB: "#FF0090",
      desc: "Hình uốn sóng kiểu psychedelic, viền lặp 2 màu." },
    { id: "thermal", name: "Ảnh nhiệt", group: "trend", engine: "fx", fx: "thermal",
      desc: "Chuyển hình sang dải màu ảnh nhiệt: tím, đỏ, cam, vàng." },
    { id: "neon", name: "Neon viền", group: "trend", engine: "fx", fx: "neon", lpi: true, lpiLabel: "Độ tỏa (LPI)", fxColors: 1, fxA: "#00E6FF",
      desc: "Chỉ giữ đường viền của hình, phát sáng như đèn neon. Rất hợp áo đen." },

    { id: "duotone", name: "Duotone", group: "trend", engine: "fx", fx: "duotone", fxColors: 2, fxA: "#2A1B6B", fxB: "#FF9E5E",
      desc: "Ánh xạ hình sang dải 2 màu (màu 1 = vùng tối, màu 2 = vùng sáng), kiểu poster thời trang." },
    { id: "rainbowdots", name: "Chấm cầu vồng", group: "trend", engine: "fx", fx: "rainbowdots", lpi: true, lpiFactor: 0.7,
      desc: "Trame chấm tròn, màu chấm chạy dải cầu vồng chéo qua hình. Cường độ xoay dải màu." },
    { id: "rgbdots", name: "Chấm RGB LED", group: "trend", engine: "fx", fx: "rgbdots", lpi: true, lpiFactor: 0.5,
      desc: "Mỗi ô 3 chấm đỏ, lục, lam như màn hình LED. Rất nổi trên áo đen." },
    { id: "spray", name: "Sơn xịt", group: "trend", engine: "fx", fx: "spray", lpi: true, lpiLabel: "Cỡ bụi sơn (LPI)",
      desc: "Mép hình tan thành bụi sơn, có vệt sơn chảy xuống như graffiti." },

    /* ----- Vintage (30) ----- */
    { id: "v_sepia", name: "Ảnh sepia", group: "vintage", engine: "fx", fx: "v_sepia", lpi: true, lpiLabel: "Cỡ mảng mòn (LPI)",
      desc: "Chuyển hình sang tông nâu sepia như ảnh chụp đầu thế kỷ 20, mực mòn nhẹ." },
    { id: "v_yellowed", name: "Ảnh ố vàng", group: "vintage", engine: "fx", fx: "v_yellowed", lpi: true, lpiLabel: "Cỡ mảng mòn (LPI)",
      desc: "Giấy ngả vàng, có đốm ố rải rác như ảnh cất lâu năm." },
    { id: "v_scratch", name: "Phim cũ xước", group: "vintage", engine: "fx", fx: "v_scratch", lpi: true,
      desc: "Màu nhạt bớt, có vết xước dọc và bụi như cuộn phim nhựa cũ." },
    { id: "v_washed", name: "Áo giặt bạc", group: "vintage", engine: "fx", fx: "v_washed", lpi: true, lpiLabel: "Cỡ mảng mòn (LPI)",
      desc: "Màu bạc, nhạt và mòn loang lổ như áo đã giặt rất nhiều lần." },
    { id: "v_screenprint", name: "In lụa cũ", group: "vintage", engine: "fx", fx: "v_screenprint", lpi: true, lpiLabel: "Cỡ mảng nứt (LPI)",
      desc: "Gom còn 5 màu phẳng như in lụa, thêm vết nứt mực và mảng mòn." },
    { id: "v_stamp", name: "Con dấu cao su", group: "vintage", engine: "fx", fx: "v_stamp", lpi: true, fxColors: 1, fxA: "#7A1E1E",
      desc: "Một màu mực, mực ăn không đều và mép sần như đóng dấu tay. Đổi màu mực ở thẻ Tùy chọn hiệu ứng." },
    { id: "v_band80", name: "Áo band 80s", group: "vintage", engine: "fx", fx: "v_band80", lpi: true, fxColors: 1, fxA: "#1E1E1E",
      desc: "Chấm trame to một màu, mòn mảng lớn như áo tour ban nhạc thập niên 80." },
    { id: "v_surf70", name: "Surf 70s", group: "vintage", engine: "fx", fx: "v_surf70", lpi: true,
      desc: "Dải màu nâu, cam, vàng, kem của áo lướt sóng thập niên 70." },
    { id: "v_propaganda", name: "Poster cổ động", group: "vintage", engine: "fx", fx: "v_propaganda", lpi: true, fxColors: 1, fxA: "#C8281E",
      desc: "Ba mảng màu: đen, màu nhấn và nền kem, kiểu tranh cổ động in đá." },
    { id: "v_woodcut", name: "Khắc gỗ", group: "vintage", engine: "fx", fx: "v_woodcut", lpi: true, fxColors: 1, fxA: "#1E1A16",
      desc: "Vùng đậm tô đặc, vùng trung tính thành nét khắc uốn lượn như tranh khắc gỗ." },
    { id: "v_linocut", name: "Khắc linoleum", group: "vintage", engine: "fx", fx: "v_linocut", lpi: true, fxColors: 1, fxA: "#14213D",
      desc: "Mảng đặc lớn, có vết đục ngắn rải rác như bản in khắc linoleum." },
    { id: "v_newspaper", name: "Báo cũ", group: "vintage", engine: "fx", fx: "v_newspaper", lpi: true, fxColors: 1, fxA: "#222222",
      desc: "Chấm trame thô một màu, mực lúc đậm lúc nhạt như trang báo in xưa." },
    { id: "v_comic", name: "Truyện tranh cổ", group: "vintage", engine: "fx", fx: "v_comic", lpi: true,
      desc: "Chấm 3 màu vàng, hồng, xanh to và lệch khuôn, nét đen đậm như truyện tranh thập niên 50." },
    { id: "v_polaroid", name: "Polaroid phai", group: "vintage", engine: "fx", fx: "v_polaroid",
      desc: "Tương phản thấp, bóng ngả xanh, sáng ngả ấm, viền tan như ảnh Polaroid cũ." },
    { id: "v_kodachrome", name: "Kodachrome", group: "vintage", engine: "fx", fx: "v_kodachrome", lpi: true, lpiLabel: "Cỡ hạt (LPI)",
      desc: "Màu rực, ngả ấm, đỏ đậm và hạt phim như ảnh phim màu thập niên 60." },
    { id: "v_crossproc", name: "Cross-process", group: "vintage", engine: "fx", fx: "v_crossproc",
      desc: "Vùng sáng ngả vàng lục, vùng tối ngả lam như tráng phim sai thuốc." },
    { id: "v_lomo", name: "Lomo", group: "vintage", engine: "fx", fx: "v_lomo",
      desc: "Màu bão hòa mạnh, tối bốn góc như máy ảnh Lomo." },
    { id: "v_cyanotype", name: "Cyanotype", group: "vintage", engine: "fx", fx: "v_cyanotype", lpi: true,
      desc: "Dải xanh lam của ảnh in phơi nắng cổ (blueprint)." },
    { id: "v_brownduo", name: "Duotone nâu", group: "vintage", engine: "fx", fx: "v_brownduo", lpi: true, lpiLabel: "Cỡ hạt (LPI)",
      desc: "Dải 3 tông nâu đậm, nâu sữa, kem, có hạt nhẹ." },
    { id: "v_misreg", name: "In lệch khuôn", group: "vintage", engine: "fx", fx: "v_misreg",
      desc: "Tách 4 màu phẳng, mỗi bản in lệch một chút như máy in cũ chạy lệch." },
    { id: "v_matchbox", name: "Nhãn hộp diêm", group: "vintage", engine: "fx", fx: "v_matchbox",
      desc: "Ba màu phẳng, giấy mòn loang lổ như nhãn hộp diêm xưa." },
    { id: "v_peel", name: "Sơn tróc", group: "vintage", engine: "fx", fx: "v_peel", lpi: true, lpiLabel: "Cỡ mảng nứt (LPI)",
      desc: "Lớp in bong tróc từng mảng như sơn cũ trên tường." },
    { id: "v_rust", name: "Gỉ sét", group: "vintage", engine: "fx", fx: "v_rust", lpi: true, lpiLabel: "Cỡ mảng mòn (LPI)",
      desc: "Mảng gỉ nâu cam lan vào hình như biển kim loại cũ." },
    { id: "v_sunfade", name: "Bạc nắng", group: "vintage", engine: "fx", fx: "v_sunfade",
      desc: "Phía trên phai màu nhiều hơn phía dưới như áo phơi nắng lâu ngày." },
    { id: "v_bleed", name: "Mực loang", group: "vintage", engine: "fx", fx: "v_bleed", lpi: true,
      desc: "Mực đậm lan ra, mép hình loang không đều như in trên giấy thấm." },
    { id: "v_letterpress", name: "Letterpress", group: "vintage", engine: "fx", fx: "v_letterpress", lpi: true,
      desc: "Màu phẳng, mực ép loang lổ chỗ đậm chỗ nhạt như in typo." },
    { id: "v_varsity", name: "Varsity 2 màu", group: "vintage", engine: "fx", fx: "v_varsity", lpi: true, lpiLabel: "Cỡ mảng nứt (LPI)", fxColors: 2, fxA: "#1B2F6B", fxB: "#C8102E",
      desc: "Phần đậm tô một màu, viền dày màu thứ hai, nứt nhẹ như chữ áo đội thể thao trường học Mỹ." },
    { id: "v_engstamp", name: "Tem khắc", group: "vintage", engine: "fx", fx: "v_engstamp", lpi: true, fxColors: 1, fxA: "#1F3A5F",
      desc: "Nét khắc ngang một màu như tem bưu chính cổ." },
    { id: "v_vhs", name: "Băng VHS", group: "vintage", engine: "fx", fx: "v_vhs", lpi: true,
      desc: "Lệch kênh màu, vạch quét và dải nhiễu như băng video VHS." },
    { id: "v_thrift", name: "Áo thrift", group: "vintage", engine: "fx", fx: "v_thrift", lpi: true, lpiLabel: "Cỡ mảng nứt (LPI)",
      desc: "Phai nhẹ, nứt mịn, lỗ li ti như áo si-đa mua ở chợ đồ cũ." },

    /* ----- Trame màu (4 kênh) ----- */
    { id: "cmykhex", name: "Màu tổ ong", group: "color", engine: "color", colorKind: "hex", lpi: true, lpiFactor: 0.55,
      desc: "Giống file mẫu face_40x40: 4 màu (vàng, hồng, xanh, đen), chấm tròn lưới tổ ong, mỗi màu xoay lệch 15° để không bị moiré. Chỗ không có mực là màu áo." },
    { id: "cmykround", name: "Màu chấm tròn", group: "color", engine: "color", colorKind: "round", lpi: true, lpiFactor: 0.75,
      desc: "Trame màu kiểu in offset: 4 màu chấm tròn góc chuẩn C15 M75 Y0 K45." },
    { id: "cmykline", name: "Màu đường kẻ", group: "color", engine: "color", colorKind: "line", lpi: true, lpiFactor: 0.62,
      desc: "4 màu dạng vạch kẻ, mỗi màu một góc, đan thành vân lưới màu." },
    { id: "cmykgrain", name: "Màu hạt", group: "color", engine: "color", colorKind: "grain",
      desc: "4 màu hạt ngẫu nhiên, không có lưới nên không bao giờ moiré." },
    { id: "spot", name: "Màu spot", group: "color", engine: "index", idxDither: "none",
      desc: "Tự tìm vài màu chủ đạo, mỗi vùng in một màu phẳng; màu trùng áo được bỏ để lộ áo (kiểu Iron Muscle). In lụa: mỗi màu một phim." },
    { id: "spotgrain", name: "Màu spot hạt", group: "color", engine: "index", idxDither: "grain",
      desc: "Màu spot, chỗ chuyển giữa hai màu và chỗ tan vào nền áo bằng hạt sần (kiểu Hellstar)." }
  ];
  var GROUPS = [
    { id: "basic", short: "Cơ bản", name: "Chấm in truyền thống và hạt" },
    { id: "street", short: "Grunge", name: "Streetwear / grunge" },
    { id: "shape", short: "Hình chấm", name: "Hình chấm đặc biệt" },
    { id: "pattern", short: "Hoa văn", name: "Hoa văn đường nét" },
    { id: "trend", short: "Xu hướng", name: "Hiệu ứng áo thun đang thịnh hành" },
    { id: "vintage", short: "Vintage", name: "Vintage: ảnh cũ, in cũ, áo cũ" },
    { id: "color", short: "Màu", name: "Màu: 4 màu CMYK và màu spot" }
  ];
  var COLOR_CH = ["y", "m", "c", "k"];
  var COLOR_NAME = { y: "Vàng", m: "Hồng", c: "Xanh", k: "Đen" };
  var ANG_STD = { c: 15, m: 75, y: 0, k: 45 };
  // Lưới tổ ong lặp lại mỗi 60°, nên 4 màu xoay cách nhau 15° là đều nhất, ít moiré nhất.
  var ANG_HEX = { y: 0, m: 15, c: 45, k: 30 };
  var SEEDS = { y: 11, m: 2222, c: 33333, k: 444444 };

  var TARGET_HINT = {
    dtfBlack: "Phần sáng của hình in thành chấm, phần tối để lộ màu áo đen. Có lớp trắng lót bên dưới.",
    dtfWhite: "Phần tối của hình in thành chấm, phần sáng để lộ màu áo trắng. Phần trong suốt không in."
  };
  var SHIRT = { dtfBlack: [0, 0, 0], dtfWhite: [255, 255, 255] };
  var PRESETS = { "10x10": [10, 10], "25x30": [25, 30], "30x40": [30, 40], "a4": [21, 29.7], "a3": [29.7, 42] };
  var MAX_APPLY_PX = 40000000;
  var MAX_COLOR_PX = 30000000;

  var state = { style: "round", target: "dtfBlack", busy: false, lpiTouched: false, baseLpi: 35, docCm: null, mcSeed: 1, palette: null, group: "", pvMode: "fit", pvPanel: false, tmpDir: "" };
  var pv = null; // cache xem trước: {rgba,w,h,fullW,fullH,dpi,srcName}

  function $(id) { return document.getElementById(id); }
  /* Dịch: câu tiếng Việt là khóa; {0}, {1}… là chỗ điền giá trị. */
  function T(src, args) { return window.NovaI18n ? window.NovaI18n.t(src, args) : src; }
  function SN(s) { return T(s.name); }

  /*
   * LPI gợi ý cho DTF theo cạnh dài của bản in (cm). Áo in lớn nhìn từ xa hơn nên dùng chấm to hơn;
   * logo nhỏ cần mịn hơn nhưng không quá 45 LPI để chấm vẫn đủ lớn cho bột keo bám.
   */
  var LPI_TABLE = [[15, 45], [32, 40], [45, 35], [999, 30]];
  function recommendLpi(wcm, hcm) {
    var m = Math.max(wcm, hcm);
    for (var i = 0; i < LPI_TABLE.length; i++) if (m <= LPI_TABLE[i][0]) return LPI_TABLE[i][1];
    return 30;
  }
  function styleLpi(s) {
    return Math.max(5, Math.min(150, Math.round(state.baseLpi * (s.lpiFactor || 1))));
  }
  function setDocSize(wcm, hcm) {
    if (!(wcm > 0 && hcm > 0)) return;
    state.docCm = [wcm, hcm];
    state.baseLpi = recommendLpi(wcm, hcm);
    updateLpiRec();
    if (!state.lpiTouched) applyAutoLpi();
  }
  function applyAutoLpi() {
    var v = styleLpi(styleById(state.style));
    $("lpi").value = v; $("lpiVal").textContent = v;
    updateDotInfo();
  }
  function updateLpiRec() {
    var s = styleById(state.style), v = styleLpi(s);
    var size = state.docCm ? state.docCm[0].toFixed(0) + "×" + state.docCm[1].toFixed(0) + " cm" : T("chưa rõ khổ (mặc định 30×40)");
    $("lpiRecText").textContent = T("Gợi ý DTF cho khổ {0}: {1} LPI", [size, v]) + (s.lpiFactor && s.lpiFactor !== 1 ? T(" (đã tính theo kiểu này)") : "");
    show("btnLpiRec", state.lpiTouched && num("lpi", 0) !== v);
  }
  /* Kích thước ô chấm và mức chấm nhỏ nhất tương ứng (hiển thị cho người dùng). */
  function dotLimits(s) {
    var kind = dotKind(s);
    if (!kind) return null;
    var cellMm = 25.4 / num("lpi", 40), d = num("minDotMm", 0.25);
    var c = kind === "dot" ? Math.PI / 4 * (d / cellMm) * (d / cellMm) : d / cellMm;
    return { cellMm: cellMm, min: Math.min(0.5, c), max: num("solidPct", 92) / 100, kind: kind };
  }
  function dotKind(s) {
    if (!s.pv) return null;
    var t = s.pv.t;
    if (t === "halftone") return s.pv.shape === "line" ? "line" : "dot";
    if (t === "hex" || t === "celldot" || t === "dotfade" || t === "polardots" || t === "voronoidots" || t === "sunflower") return "dot";
    if (("rings spiral radial wave zigzag hatch wood fingerprint bulge twirl interference engrave fishscale truchet " +
         "lattice brick honeycomb squarerings seigaiha spiderweb weave diamondplate zebra marble").indexOf(t) >= 0) return "line";
    return null;
  }
  function updateDotInfo() {
    var L = dotLimits(styleById(state.style));
    show("dotInfo", !!L);
    if (L) $("dotInfo").textContent = T(L.kind === "dot" ? "Ô chấm {0} mm · chấm nhỏ hơn {1}% sẽ được nâng/bỏ · từ {2}% tô đặc" :
      "Ô chấm {0} mm · nét nhỏ hơn {1}% sẽ được nâng/bỏ · từ {2}% tô đặc", [L.cellMm.toFixed(2), Math.round(L.min * 100), Math.round(L.max * 100)]);
  }
  function each(list, fn) { Array.prototype.forEach.call(list, fn); }
  function num(id, def) { var v = parseFloat($(id).value); return isNaN(v) ? def : v; }
  function styleById(id) { for (var i = 0; i < STYLES.length; i++) if (STYLES[i].id === id) return STYLES[i]; return STYLES[0]; }

  function show(el, on) {
    if (typeof el === "string") el = $(el);
    if (on) el.classList.remove("hidden"); else el.classList.add("hidden");
  }

  function setStatus(text, kind) {
    $("statusText").textContent = text;
    $("statusDot").className = "dot" + (kind ? " " + kind : "");
  }

  window.NovaLog = function (m) { try { log(m); } catch (e) {} };
  function log(msg) {
    var t = new Date();
    function p(n) { return ("0" + n).slice(-2); }
    var box = $("log");
    box.value += "[" + p(t.getHours()) + ":" + p(t.getMinutes()) + ":" + p(t.getSeconds()) + "] " + msg + "\n";
    box.scrollTop = box.scrollHeight;
    var err = /^✖|\[LỖI\]/.test(msg);
    setStatus(msg.replace(/^\[LỖI\]\s*/, T("Lỗi: ")).replace(/^[▶✔✖⚠]\s*/, ""), err ? "err" : state.busy ? "busy" : "");
  }

  /* ---------- Giao tiếp với Photoshop ---------- */
  function evalJSX(code, cb) {
    if (!window.__adobe_cep__) { cb("ERR\n" + T("Panel không chạy trong Photoshop.")); return; }
    window.__adobe_cep__.evalScript(code, cb);
  }

  function extensionPath() {
    var p = decodeURI(window.__adobe_cep__.getSystemPath("extension"));
    return navigator.platform.indexOf("Win") >= 0 ? p.replace("file:///", "") : p.replace("file://", "");
  }

  function ensureHost(cb) {
    evalJSX("typeof NOVA", function (r) {
      if (r === "object") { cb(true); return; }
      var path = (extensionPath() + "/jsx/host.jsx").replace(/\\/g, "/");
      evalJSX("$.evalFile('" + path.replace(/'/g, "\\'") + "'); typeof NOVA", function (r2) {
        if (r2 !== "object") log("✖ " + T("Không nạp được host.jsx ({0})", [r2]));
        cb(r2 === "object");
      });
    });
  }

  /* Gọi một hàm NOVA.*; cb(ok, lines, data). data = mảng từ dòng DATA| nếu có. */
  function jsx(fn, opts, cb) {
    ensureHost(function (ok) {
      if (!ok) { cb(false, [], null); return; }
      opts = opts || {};
      opts.lang = window.NovaI18n ? window.NovaI18n.lang : "en";
      evalJSX("NOVA." + fn + "(" + JSON.stringify(opts) + ")", function (r) {
        if (!r || r === "EvalScript error.") {
          log("✖ " + T("Photoshop không chạy được lệnh {0} ({1})", [fn, r]));
          cb(false, [], null);
          return;
        }
        var lines = String(r).split("\n");
        var good = lines.shift() === "OK";
        var data = null;
        each(lines, function (l) {
          if (l.indexOf("DATA|") === 0) data = l.substring(5).split("|");
          else if (l) log(l);
        });
        cb(good, lines, data);
      });
    });
  }

  function setButtons(on) {
    each(["btnTrame", "btnNewDoc", "btnEffect", "btnInfo", "btnPreview", "btnPattern", "btnSticker"],
      function (id) { $(id).disabled = !on; });
  }

  /* Quy trình nhiều bước: flow(done) phải gọi done() đúng một lần. */
  function guarded(label, flow, isApply) {
    if (state.busy) return;
    if (window.NovaLicense && !NovaLicense.canUse()) { log(T("Cần kích hoạt license để áp dụng.")); return; }
    state.busy = true;
    setButtons(false);
    isApply = isApply || state.applyPending;
    state.applyPending = false;
    if (isApply) $("btnTrame").textContent = T("Đang xử lý…");
    var t0 = Date.now();
    log("▶ " + label);
    var finished = false;
    function done(failMsg) {
      if (finished) return;
      finished = true;
      state.busy = false;
      setButtons(true);
      $("btnTrame").textContent = T("Áp dụng trame");
      if (failMsg) log("✖ " + label + ": " + failMsg);
      else log("✔ " + T("Xong: {0} ({1} giây)", [label, ((Date.now() - t0) / 1000).toFixed(1)]));
    }
    try { flow(done); }
    catch (e) { done(e.message || String(e)); }
  }

  /* ---------- Đọc file ảnh từ đĩa vào canvas ---------- */
  function loadImageData(path, cb) {
    var fs = window.cep && window.cep.fs;
    if (!fs) { cb(null, T("Không có quyền đọc file (cep.fs).")); return; }
    var r = fs.readFile(path, window.cep.encoding.Base64);
    if (r.err !== 0) { cb(null, T("Không đọc được file tạm (mã {0}): {1}", [r.err, path])); return; }
    var img = new Image();
    img.onload = function () {
      var cv = document.createElement("canvas");
      cv.width = img.width; cv.height = img.height;
      var cx = cv.getContext("2d");
      cx.drawImage(img, 0, 0);
      try { cb(cx.getImageData(0, 0, img.width, img.height), null); }
      catch (e) { cb(null, T("Không đọc được pixel: {0}", [e.message])); }
    };
    img.onerror = function () { cb(null, T("Không giải mã được ảnh PNG tạm.")); };
    img.src = "data:image/png;base64," + r.data;
  }

  function writeCanvasPNG(canvas, path) {
    var fs = window.cep.fs;
    var b64 = canvas.toDataURL("image/png").split(",")[1];
    var r = fs.writeFile(path, b64, window.cep.encoding.Base64);
    if (r.err !== 0) throw new Error(T("Không ghi được file tạm (mã {0}).", [r.err]));
  }

  /* ---------- Kết xuất trame ---------- */
  /* Hiệu ứng phụ đang bật? (mờ dần, bong tróc, chấm âm) */
  function modifiersActive() {
    return num("fadeAmt", 0) > 0 || num("distressAmt", 0) > 0 || $("invertChk").checked;
  }

  /* Tạo thông số cho engine. scale = tỉ lệ ảnh đang xử lý / ảnh gốc; aspect = rộng/cao ảnh gốc. */
  function specFor(s, scale, dpi, aspect) {
    var t = s.pv.t, spec = {}, k;
    for (k in s.pv) if (s.pv.hasOwnProperty(k)) spec[k] = s.pv[k];
    var period = dpi / num("lpi", 55) * scale;
    spec.periodPx = period;
    if (t === "halftone") spec.angleDeg = s.pv.fixedAngle !== undefined ? s.pv.fixedAngle : num("angle", 45);
    else if (t === "hex" || t === "wave" || t === "hatch" || t === "celldot") spec.angleDeg = num("angle", 45);
    else if (t === "diffusion") spec.kernel = s.pv.kernel;
    else if (t === "ordered") spec.n = s.pv.n;
    else if (t === "threshold" || t === "photocopy") spec.level = 1 - num("level", 128) / 255;
    if (t === "contour") spec.levels = 12;
    if (s.multi) {
      var cs = E.makeCenters(num("mcCount", 7), state.mcSeed, num("mcVary", 60) / 100, aspect || 1);
      if (s.swirl && !$("mcSwirl").checked) each(cs, function (c) { c.dir = 1; });
      spec.centers = cs;
    }
    // Hiệu ứng phụ: giá trị trên thẻ ghi đè giá trị mặc định của kiểu
    var fa = num("fadeAmt", 0), da = num("distressAmt", 0);
    if (fa > 0) { spec.fade = fa / 100; spec.fadeDir = $("fadeDir").value; }
    else if (spec.fade) spec.fadeDir = $("fadeDir").value;
    if (da > 0) spec.distress = da / 100;
    if ($("invertChk").checked) spec.invert = !spec.invert;
    var L = dotLimits(s);
    if (L) { spec.minDot = L.min; spec.maxDot = L.max; }
    if (t === "ascii") spec.glyphs = glyphAtlas(Math.max(4, Math.round(period * 1.3)), $("asciiChars").value);
    return spec;
  }

  /* ---------- Trame màu 4 kênh ---------- */
  function hexToRgb(hex) {
    var h = String(hex).replace("#", "").replace(/\s/g, "");
    if (h.length === 3) h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
    var n = parseInt(h, 16);
    if (isNaN(n) || h.length !== 6) throw new Error(T("Màu mực không hợp lệ: {0}", [hex]));
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function colorSpec(s, ch, scale, dpi) {
    var period = dpi / num("lpi", 22) * scale;
    if (s.colorKind === "hex") return { t: "hex", periodPx: period, angleDeg: ANG_HEX[ch] };
    if (s.colorKind === "grain") return { t: "random", seed: SEEDS[ch] };
    return { t: "halftone", shape: s.colorKind, periodPx: period, angleDeg: ANG_STD[ch] };
  }

  /* Trả về { inks: [{ch, ink, rgb}] } cho các kênh được bật. Xử lý từng kênh để tiết kiệm bộ nhớ. */
  function colorRender(s, rgba, w, h, scale, dpi) {
    var gcr = num("gcr", 100) / 100, inks = [];
    each(COLOR_CH, function (ch) {
      var cap = ch.toUpperCase();
      if (!$("use" + cap).checked) return;
      var dark = E.cmykChannel(rgba, w, h, gcr, ch);
      inks.push({ ch: ch, ink: E.render(colorSpec(s, ch, scale, dpi), dark, w, h), rgb: hexToRgb($("ink" + cap).value) });
    });
    if (!inks.length) throw new Error(T("Hãy bật ít nhất một màu mực."));
    return inks;
  }

  /*
   * Mật độ mực cho trame đơn sắc trên DTF: chấm = phần được in (giữ màu thiết kế).
   * Áo trắng: phần tối của hình thành chấm. Áo đen: phần sáng của hình thành chấm.
   * Kiểu "keepAll" (sọc hoàng hôn, chấm chuyển hướng, mực nứt) giữ mọi chỗ có hình.
   */
  function inkDensity(s, rgba, w, h) {
    var n = w * h, d;
    if (state.target === "dtfBlack") {
      d = E.darkness(rgba, w, h, [0, 0, 0]);
      for (var i = 0; i < n; i++) d[i] = 1 - d[i];
    } else d = E.darkness(rgba, w, h, [255, 255, 255]);
    if (s.keepAll) for (var j = 0; j < n; j++) d[j] = rgba[j * 4 + 3] > 8 ? Math.max(0.05, d[j]) : 0;
    return d;
  }

  /* ---------- Bộ ký tự cho kiểu Chữ ASCII (dựng bằng canvas, có bộ nhớ đệm) ---------- */
  var GLYPH_CACHE = {};
  function glyphAtlas(cell, chars) {
    chars = String(chars || "").replace(/\s+/g, "");
    if (!chars) chars = ".:-=+*#%@";
    var key = cell + "|" + chars;
    if (GLYPH_CACHE[key]) return GLYPH_CACHE[key];
    var cv = document.createElement("canvas");
    cv.width = cell; cv.height = cell;
    var cx = cv.getContext("2d"), list = [" "].concat(chars.split("")), raw = [];
    for (var i = 0; i < list.length; i++) {
      cx.clearRect(0, 0, cell, cell);
      cx.fillStyle = "#000";
      cx.font = "bold " + Math.round(cell * 1.05) + "px Consolas, 'Courier New', monospace";
      cx.textAlign = "center"; cx.textBaseline = "middle";
      cx.fillText(list[i], cell / 2, cell / 2 + cell * 0.05);
      var d = cx.getImageData(0, 0, cell, cell).data, bits = new Uint8Array(cell * cell), on = 0;
      for (var k = 0; k < cell * cell; k++) { if (d[k * 4 + 3] > 110) { bits[k] = 1; on++; } }
      raw.push({ bits: bits, cover: on / (cell * cell) });
    }
    raw.sort(function (a, b) { return a.cover - b.cover; });
    var mx = raw[raw.length - 1].cover || 1;
    var G = { cell: cell, levels: [], cover: [] };
    for (var j = 0; j < raw.length; j++) { G.levels.push(raw[j].bits); G.cover.push(raw[j].cover / mx); }
    GLYPH_CACHE[key] = G;
    return G;
  }

  /* ---------- Hiệu ứng màu ---------- */
  function fxOpts(s, scale, dpi, frame, w, h) {
    var A = s.fxColors ? hexToRgb($("fxColorA").value) : null, B = s.fxColors >= 2 ? hexToRgb($("fxColorB").value) : null;
    return { amt: num("fxAmt", 50) / 100, colorA: A, colorB: B, periodPx: dpi / num("lpi", 40) * scale, darkShirt: state.target === "dtfBlack",
      frame: frame || { ox: 0, oy: 0, fw: w, fh: h } };
  }

  function applyFx(s) {
    guarded(T("Áp dụng {0}", [SN(s)]), function (done) {
      log(T("Xuất ảnh đầy đủ từ Photoshop..."));
      jsx("exportImage", { maxDim: 0 }, function (ok, lines, data) {
        if (!ok || !data) { done(T("không xuất được ảnh")); return; }
        var fullW = parseInt(data[1], 10), fullH = parseInt(data[2], 10), dpi = parseInt(data[3], 10);
        if (fullW * fullH > MAX_COLOR_PX) { done(T("ảnh quá lớn (giới hạn 30 triệu pixel). Hãy giảm kích thước hoặc DPI.")); return; }
        loadImageData(data[0], function (imgData, err) {
          if (err) { done(err); return; }
          log(T("Tạo hiệu ứng {0} ({1}×{2} px)...", [SN(s), imgData.width, imgData.height]));
          setTimeout(function () {
            try {
              var w = imgData.width, h = imgData.height;
              var comp = E.fx(s.fx, imgData.data, w, h, fxOpts(s, 1, dpi, null, w, h));
              imgData = null;
              var cv = inkCanvas(w, h, function (dd) { dd.set(comp); });
              var o = commonTrameOpts(s);
              o.dpi = dpi; o.srcName = data[4];
              o.path = data[0].replace("nova-src.png", "nova-color-out.png");
              writeCanvasPNG(cv, o.path);
              log(T("Gửi kết quả về Photoshop..."));
              jsx("applyColorFile", o, function (ok3) { done(ok3 ? null : T("xem nhật ký ở trên")); });
            } catch (e) { done(e.message); }
          }, 30);
        });
      });
    });
  }

  /* ---------- Tách màu spot (index) ---------- */
  function shirtForIndex() {
    var v = $("idxShirt").value;
    return v === "black" ? [0, 0, 0] : v === "white" ? [255, 255, 255] : null;
  }

  function indexRender(s, rgba, w, h, scale, palette) {
    var o = { colors: num("idxColors", 4), shirt: shirtForIndex(), dither: $("idxDither").value,
      grainPx: Math.max(0.7, num("idxGrain", 3) * scale) };
    if (palette) o.palette = palette;
    return E.indexColor(rgba, w, h, o);
  }

  function rgbHex(c) {
    function h2(v) { return ("0" + Math.round(v).toString(16)).slice(-2); }
    return "#" + h2(c[0]) + h2(c[1]) + h2(c[2]);
  }

  function showPalette(pal) {
    var box = $("idxPal");
    box.innerHTML = "";
    each(pal, function (c) {
      var sw = document.createElement("span");
      sw.className = "palsw";
      sw.style.backgroundColor = rgbHex(c);
      sw.title = rgbHex(c);
      box.appendChild(sw);
    });
  }

  function renderPreview() {
    if (!pv) return;
    var s = styleById(state.style);
    // chu kỳ chấm trên ảnh xem trước < 3 px thì toàn hình không hiển thị đúng
    // chỉ cảnh báo với kiểu có lưới chấm/nét đều (hạt ngẫu nhiên không bị vân giả)
    var gridded = !!dotKind(s) || s.engine === "color" || s.fx === "popart";
    var tooFine = !pv.zoom && gridded && pv.dpi / num("lpi", 40) * pv.scale < 3;
    show("pvWarn", !!tooFine && !state.pvPanel);
    state.pvWarnOn = !!tooFine;
    $("pvTag").textContent = T(s.name) + (pv.zoom ? " · 100%" : "");
    var shirt = SHIRT[state.target];
    var w = pv.w, h = pv.h;
    var canvas = $("pvCanvas");
    canvas.width = w; canvas.height = h;
    var cx = canvas.getContext("2d");
    var out = cx.createImageData(w, h);
    var d = out.data, i, p;

    if (s.engine === "fx") {
      var fc = E.fx(s.fx, pv.rgba, w, h, fxOpts(s, pv.scale, pv.dpi, pv.frame, w, h));
      for (i = 0, p = 0; i < w * h; i++, p += 4) {
        if (fc[p + 3]) { d[p] = fc[p]; d[p + 1] = fc[p + 1]; d[p + 2] = fc[p + 2]; }
        else { d[p] = shirt[0]; d[p + 1] = shirt[1]; d[p + 2] = shirt[2]; }
        d[p + 3] = 255;
      }
      cx.putImageData(out, 0, 0);
      previewDone();
      return;
    }

    if (s.engine === "index") {
      var res = indexRender(s, pv.rgba, w, h, pv.scale, null);
      if (!pv.zoom) { state.palette = res.palette; state.paletteSrc = pv.srcName; state.paletteKey = paletteKey(); }
      showPalette(res.palette);
      var ic = E.indexComposite(res, w, h), ibg = shirtForIndex() || [255, 255, 255];
      for (i = 0, p = 0; i < w * h; i++, p += 4) {
        if (ic[p + 3]) { d[p] = ic[p]; d[p + 1] = ic[p + 1]; d[p + 2] = ic[p + 2]; }
        else { d[p] = ibg[0]; d[p + 1] = ibg[1]; d[p + 2] = ibg[2]; }
        d[p + 3] = 255;
      }
      cx.putImageData(out, 0, 0);
      previewDone();
      return;
    }

    if (s.engine === "color") {
      var comp = E.compositeInks(colorRender(s, pv.rgba, w, h, pv.scale, pv.dpi), w, h);
      var bg = shirt;
      for (i = 0, p = 0; i < w * h; i++, p += 4) {
        if (comp[p + 3]) { d[p] = comp[p]; d[p + 1] = comp[p + 1]; d[p + 2] = comp[p + 2]; }
        else { d[p] = bg[0]; d[p + 1] = bg[1]; d[p + 2] = bg[2]; }
        d[p + 3] = 255;
      }
      cx.putImageData(out, 0, 0);
      previewDone();
      return;
    }

    var dark = inkDensity(s, pv.rgba, w, h);
    var pspec = specFor(s, pv.scale, pv.dpi, pv.fullW / pv.fullH);
    if (pv.frame) pspec.frame = pv.frame;
    var ink = E.render(pspec, dark, w, h);
    {
      var rgb = E.composite(pv.rgba, w, h, shirt);
      for (i = 0, p = 0; i < w * h; i++, p += 4) {
        var q = i * 3;
        if (ink[i]) { d[p] = rgb[q]; d[p + 1] = rgb[q + 1]; d[p + 2] = rgb[q + 2]; }
        else { d[p] = shirt[0]; d[p + 1] = shirt[1]; d[p + 2] = shirt[2]; }
        d[p + 3] = 255;
      }
    }
    cx.putImageData(out, 0, 0);
    previewDone();
  }

  function runPreview() {
    guarded(T("Xem trước"), function (done) {
      var zoom = state.pvMode === "zoom";
      jsx("exportImage", zoom ? { crop: { cx: 0.5, cy: 0.45, size: 600 } } : { maxDim: 700 }, function (ok, lines, data) {
        if (!ok || !data) { done(T("không xuất được ảnh xem trước")); return; }
        loadImageData(data[0], function (imgData, err) {
          if (err) { done(err); return; }
          var fullW = parseInt(data[1], 10), fullH = parseInt(data[2], 10);
          pv = { rgba: imgData.data, w: imgData.width, h: imgData.height,
            fullW: fullW, fullH: fullH, dpi: parseInt(data[3], 10), srcName: data[4],
            zoom: zoom, ox: parseInt(data[5] || "0", 10), oy: parseInt(data[6] || "0", 10) };
          // tỉ lệ ảnh xem trước / ảnh thật, và khung ảo để tâm, mờ dần... khớp với bản in
          pv.scale = zoom ? 1 : pv.w / fullW;
          state.tmpDir = data[0].replace("nova-src.png", "");
          setDocSize(fullW / pv.dpi * 2.54, fullH / pv.dpi * 2.54);
          pv.frame = zoom ? { ox: pv.ox, oy: pv.oy, fw: fullW, fh: fullH } : null;
          try { renderPreview(); done(); }
          catch (e) { done(e.message); }
        });
      });
    });
  }

  /* ---------- Giao tiếp giữa panel chính và panel Xem trước (sự kiện CEP) ---------- */
  var EXT_PV = "com.nova.tramestudio.preview";
  function cepEvent(type, data) {
    try {
      var env = JSON.parse(window.__adobe_cep__.getHostEnvironment());
      window.__adobe_cep__.dispatchEvent({ type: type, scope: "APPLICATION", appId: env.appId,
        extensionId: "com.nova.tramestudio.panel", data: JSON.stringify(data || {}) });
    } catch (e) { /* ngoài Photoshop */ }
  }
  function onCep(type, fn) {
    try {
      window.__adobe_cep__.addEventListener(type, function (ev) {
        var d = ev && ev.data;
        if (typeof d === "string") { try { d = JSON.parse(d); } catch (e) { d = {}; } }
        fn(d || {});
      });
    } catch (e) {}
  }
  function setPvPanel(on) {
    if (on) state.pvBeat = Date.now();
    if (state.pvPanel === on) return;
    state.pvPanel = on;
    if (pv) show("pvWarn", !!state.pvWarnOn && !on);
    show("pvBox", !on);
    show("pvDocked", on);
    if (on && pv) sendPreview();
  }
  function sendPreview() {
    if (!state.tmpDir) return;
    var cv = $("pvCanvas"), path = state.tmpDir + "nova-preview.png";
    try { writeCanvasPNG(cv, path); } catch (e) { return; }
    var s = styleById(state.style);
    cepEvent("com.nova.trame.preview.update", {
      path: path, label: SN(s) + (pv && pv.zoom ? " · 100%" : ""), lang: window.NovaI18n ? window.NovaI18n.lang : "en",
      target: state.target === "dtfBlack" ? T("DTF áo đen") : T("DTF áo trắng"),
      lpi: s.lpi ? num("lpi", 40) + " LPI" : "", warn: !!state.pvWarnOn,
      mode: state.pvMode, w: cv.width, h: cv.height, t: Date.now()
    });
  }

  /* Sau khi vẽ xong ảnh xem trước: ẩn chữ hướng dẫn và gửi sang panel Xem trước (nếu đang mở). */
  function previewDone() {
    show("pvEmpty", false);
    if (state.pvPanel) sendPreview();
  }

  function autoPreview() {
    if (pv && $("pvAuto").checked && !state.busy) {
      try { renderPreview(); } catch (e) { log("✖ " + T("Xem trước: {0}", [e.message])); }
    }
  }

  /* ---------- Áp dụng trame ---------- */
  function commonTrameOpts(s) {
    return {
      style: s.id, target: state.target,
      lpi: num("lpi", 55), angle: num("angle", 45), level: num("level", 128),
      underbase: $("underbase").checked, choke: num("choke", 1)
    };
  }

  function applyNative(s) {
    var o = commonTrameOpts(s);
    o.kind = s.nativeKind; o.shape = s.shape || ""; o.method = s.method || "";
    guarded(T("Áp dụng trame {0}", [SN(s)]), function (done) {
      jsx("trame", o, function (ok) { done(ok ? null : T("xem nhật ký ở trên")); });
    });
  }

  function applyCanvas(s) {
    guarded(T("Áp dụng trame {0}", [SN(s)]), function (done) {
      log(T("Xuất ảnh đầy đủ từ Photoshop..."));
      jsx("exportImage", { maxDim: 0 }, function (ok, lines, data) {
        if (!ok || !data) { done(T("không xuất được ảnh")); return; }
        var fullW = parseInt(data[1], 10), fullH = parseInt(data[2], 10), dpi = parseInt(data[3], 10);
        if (fullW * fullH > MAX_APPLY_PX) {
          done(T("ảnh {0}×{1} px quá lớn (giới hạn 40 triệu pixel). Hãy giảm kích thước hoặc DPI.", [fullW, fullH]));
          return;
        }
        loadImageData(data[0], function (imgData, err) {
          if (err) { done(err); return; }
          log(T("Kết xuất trame {0} ({1}×{2} px)...", [SN(s), imgData.width, imgData.height]));
          // setTimeout để dòng log kịp hiện trước khi tính toán nặng
          setTimeout(function () {
            try {
              var w = imgData.width, h = imgData.height;
              var spec = specFor(s, 1, dpi, fullW / fullH);
              var dark = inkDensity(s, imgData.data, w, h);
              var ink = E.render(spec, dark, w, h);
              var cv = document.createElement("canvas");
              cv.width = w; cv.height = h;
              var cx = cv.getContext("2d");
              var out = cx.createImageData(w, h);
              var dd = out.data;
              for (var i = 0, p = 0; i < w * h; i++, p += 4) {
                var v = ink[i] ? 0 : 255;
                dd[p] = v; dd[p + 1] = v; dd[p + 2] = v; dd[p + 3] = 255;
              }
              cx.putImageData(out, 0, 0);
              var outPath = data[0].replace("nova-src.png", "nova-trame-out.png");
              writeCanvasPNG(cv, outPath);
              log(T("Gửi kết quả về Photoshop..."));
              var o = commonTrameOpts(s);
              o.path = outPath; o.dpi = dpi; o.srcName = data[4]; o.keepInk = true;
              jsx("applyTrameFile", o, function (ok2) { done(ok2 ? null : T("xem nhật ký ở trên")); });
            } catch (e) { done(e.message); }
          }, 30);
        });
      });
    });
  }

  function inkCanvas(w, h, fill) {
    var cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    var cx = cv.getContext("2d");
    var out = cx.createImageData(w, h);
    fill(out.data);
    cx.putImageData(out, 0, 0);
    return cv;
  }

  function applyColor(s) {
    guarded(T("Áp dụng trame {0}", [SN(s)]), function (done) {
      log(T("Xuất ảnh đầy đủ từ Photoshop..."));
      jsx("exportImage", { maxDim: 0 }, function (ok, lines, data) {
        if (!ok || !data) { done(T("không xuất được ảnh")); return; }
        var fullW = parseInt(data[1], 10), fullH = parseInt(data[2], 10), dpi = parseInt(data[3], 10);
        if (fullW * fullH > MAX_COLOR_PX) {
          done(T("ảnh {0}×{1} px quá lớn cho trame màu (giới hạn 30 triệu pixel). Hãy giảm kích thước hoặc DPI.", [fullW, fullH]));
          return;
        }
        loadImageData(data[0], function (imgData, err) {
          if (err) { done(err); return; }
          log(T("Tách 4 màu và tạo trame {0} ({1}×{2} px)...", [SN(s), imgData.width, imgData.height]));
          setTimeout(function () {
            try {
              var w = imgData.width, h = imgData.height, n = w * h;
              var inks = colorRender(s, imgData.data, w, h, 1, dpi);
              imgData = null;
              var base = data[0].replace("nova-src.png", "");
              var o = commonTrameOpts(s);
              o.dpi = dpi; o.srcName = data[4];


              var comp = E.compositeInks(inks, w, h);
              inks = null;
              var cv2 = inkCanvas(w, h, function (dd) { dd.set(comp); });
              comp = null;
              o.path = base + "nova-color-out.png";
              writeCanvasPNG(cv2, o.path);
              log(T("Gửi kết quả về Photoshop..."));
              jsx("applyColorFile", o, function (ok3) { done(ok3 ? null : T("xem nhật ký ở trên")); });
            } catch (e) { done(e.message); }
          }, 30);
        });
      });
    });
  }

  function paletteKey() { return num("idxColors", 4) + "|" + $("idxShirt").value; }

  function applyIndex(s) {
    guarded(T("Áp dụng trame {0}", [SN(s)]), function (done) {
      log(T("Xuất ảnh đầy đủ từ Photoshop..."));
      jsx("exportImage", { maxDim: 0 }, function (ok, lines, data) {
        if (!ok || !data) { done(T("không xuất được ảnh")); return; }
        var fullW = parseInt(data[1], 10), fullH = parseInt(data[2], 10), dpi = parseInt(data[3], 10);
        if (fullW * fullH > MAX_COLOR_PX) {
          done(T("ảnh {0}×{1} px quá lớn cho tách màu (giới hạn 30 triệu pixel). Hãy giảm kích thước hoặc DPI.", [fullW, fullH]));
          return;
        }
        loadImageData(data[0], function (imgData, err) {
          if (err) { done(err); return; }
          setTimeout(function () {
            try {
              var w = imgData.width, h = imgData.height, n = w * h;
              // dùng lại bảng màu của bản xem trước để kết quả khớp với cái bạn đã thấy
              var pal = state.palette && state.paletteSrc === data[4] && state.paletteKey === paletteKey() ? state.palette : null;
              log(pal ? T("Tách màu spot (bảng màu từ bản xem trước)...") : T("Tách màu spot (tự tìm {0} màu)...", [num("idxColors", 4)]));
              var res = indexRender(s, imgData.data, w, h, 1, pal);
              imgData = null;
              log(T("Bảng màu: {0}", [res.palette.map(rgbHex).join(", ")]));
              var base = data[0].replace("nova-src.png", "");
              var o = commonTrameOpts(s);
              o.dpi = dpi; o.srcName = data[4];
              var comp = E.indexComposite(res, w, h);
              var cv2 = inkCanvas(w, h, function (dd) { dd.set(comp); });
              o.path = base + "nova-color-out.png";
              writeCanvasPNG(cv2, o.path);
              log(T("Gửi kết quả về Photoshop..."));
              jsx("applyColorFile", o, function (ok3) { done(ok3 ? null : T("xem nhật ký ở trên")); });
            } catch (e) { done(e.message); }
          }, 30);
        });
      });
    });
  }

  /* ---------- Giao diện ---------- */
  function buildStyleGrid() {
    var chips = $("groupChips"), grid = $("styleGrid");
    each(GROUPS, function (g) {
      var n = 0;
      each(STYLES, function (s) { if ((s.group || "basic") === g.id) n++; });
      var c = document.createElement("button");
      c.className = "chip";
      c.setAttribute("data-group", g.id);
      c.innerHTML = '<span class="cl">' + T(g.short) + '</span><span class="n">' + n + "</span>";
      c.title = T(g.name);
      c.addEventListener("click", function () { showGroup(g.id); });
      chips.appendChild(c);
    });
    each(STYLES, function (s) {
      var tile = document.createElement("div");
      tile.className = "tile";
      tile.setAttribute("data-style", s.id);
      tile.setAttribute("data-group", s.group || "basic");
      tile.title = T(s.name) + " — " + T(s.desc);
      tile.innerHTML = '<div class="im"><img src="icons/' + s.id + '.png" alt=""></div><div class="name">' + T(s.name) + "</div>";
      tile.addEventListener("click", function () { selectStyle(s.id); });
      grid.appendChild(tile);
    });
    updateStyleCount();
  }

  /* Nhóm Màu (CMYK, spot) chỉ dùng cho DTF áo trắng. */
  function groupAllowed(gid) {
    if (window.NovaLicense && !NovaLicense.allowed(gid)) return false;
    return gid !== "color" || state.target === "dtfWhite";
  }
  function updateStyleCount() {
    var n = 0;
    each(STYLES, function (s) { if (groupAllowed(s.group || "basic")) n++; });
    $("styleCount").textContent = T("{0} kiểu", [n]);
  }
  function applyTargetGroups() {
    each(document.querySelectorAll(".chip"), function (c) { show(c, groupAllowed(c.getAttribute("data-group"))); });
    updateStyleCount();
    var cur = styleById(state.style);
    if (!groupAllowed(cur.group || "basic")) {
      var back = state.lastNonColor && groupAllowed((styleById(state.lastNonColor).group || "basic")) ? state.lastNonColor : "round";
      selectStyle(back);
    }
  }

  /* Đổi ngôn ngữ: dịch lại phần chữ tĩnh và vẽ lại phần chữ do code tạo. */
  function relabel() {
    each(document.querySelectorAll(".chip"), function (c) {
      var g = null;
      for (var i = 0; i < GROUPS.length; i++) if (GROUPS[i].id === c.getAttribute("data-group")) g = GROUPS[i];
      if (g) { c.querySelector(".cl").textContent = T(g.short); c.title = T(g.name); }
    });
    each(document.querySelectorAll(".tile"), function (t) {
      var s = styleById(t.getAttribute("data-style"));
      t.querySelector(".name").textContent = T(s.name);
      t.title = T(s.name) + " — " + T(s.desc);
    });
    updateStyleCount();
    if (!state.busy) $("btnTrame").textContent = T("Áp dụng trame");
    selectStyle(state.style);
    $("targetHint").textContent = T(TARGET_HINT[state.target]);
    if (state.newLpiHint) state.newLpiHint();
    if (!state.docCm && $("docInfo").getAttribute("data-empty") === "1") $("docInfo").textContent = T("Chưa mở file nào. LPI đang theo khổ mặc định 30×40 cm."); $("docInfo").setAttribute("data-empty", "1");
    if (state.pvPanel && pv) sendPreview();
    cepEvent("com.nova.trame.lang", { lang: window.NovaI18n.lang });
  }

  function showGroup(gid) {
    state.group = gid;
    each(document.querySelectorAll(".chip"), function (c) {
      if (c.getAttribute("data-group") === gid) c.classList.add("active"); else c.classList.remove("active");
    });
    each(document.querySelectorAll(".tile"), function (t) { show(t, t.getAttribute("data-group") === gid); });
  }

  function updateModBadge() {
    show("modBadge", modifiersActive());
  }

  function selectStyle(id) {
    var s = styleById(id);
    id = s.id;
    if (!groupAllowed(s.group || "basic")) { s = styleById(state.lastNonColor || "round"); id = s.id; }
    state.style = id;
    if ((s.group || "basic") !== "color") state.lastNonColor = id;
    if ((s.group || "basic") !== state.group) showGroup(s.group || "basic");
    each(document.querySelectorAll(".tile"), function (t) {
      if (t.getAttribute("data-style") === id) t.classList.add("active"); else t.classList.remove("active");
    });
    $("styleName").textContent = T(s.name);
    $("styleDesc").textContent = T(s.desc);
    show("rowLpi", !!s.lpi);
    show("rowAngle", !!s.ang);
    show("rowLevel", !!s.level);
    show("noParams", !s.lpi && !s.ang && !s.level && s.engine !== "index");
    show("accParams", !!(s.lpi || s.ang || s.level) || s.engine !== "index");
    show("colorOpts", s.engine === "color");
    show("idxOpts", s.engine === "index");
    show("multiOpts", !!s.multi);
    show("rowSwirl", !!s.swirl);
    show("modOpts", s.engine !== "color" && s.engine !== "index" && s.engine !== "fx");
    if (s.fxA) { $("fxColorA").value = s.fxA; $("swFxA").style.backgroundColor = s.fxA; }
    if (s.fxB) { $("fxColorB").value = s.fxB; $("swFxB").style.backgroundColor = s.fxB; }
    $("angLabel").textContent = T(s.angLabel || "Góc");
    $("lpiLabel").textContent = T(s.lpiLabel || "Tần số (LPI)");
    if (s.engine === "index") $("idxDither").value = s.idxDither;
    if (!state.lpiTouched) applyAutoLpi();
    updateLpiRec();
    updateDotInfo();
    show("fxOpts", s.engine === "fx" || s.id === "ascii");
    show("rowFxB", (s.fxColors || 0) >= 2);
    show("rowFxA", (s.fxColors || 0) >= 1);
    show("rowFxAmt", s.engine === "fx");
    show("rowAscii", s.id === "ascii");
    autoPreview();
  }

  function selectTarget(t) {
    state.target = t;
    each(document.querySelectorAll(".segbtn"), function (b) {
      if (b.getAttribute("data-target") === t) b.classList.add("active"); else b.classList.remove("active");
    });
    $("targetHint").textContent = T(TARGET_HINT[t]);
    applyTargetGroups();

    if (t === "dtfBlack") $("idxShirt").value = "black";
    else if (t === "dtfWhite") $("idxShirt").value = "white";
    autoPreview();
  }

  /* Đổi sáng/tối theo giao diện Photoshop. */
  function applyTheme() {
    try {
      var env = JSON.parse(window.__adobe_cep__.getHostEnvironment());
      var c = env.appSkinInfo.panelBackgroundColor.color;
      var light = (c.red + c.green + c.blue) / 3 > 150;
      if (light) document.body.classList.add("light"); else document.body.classList.remove("light");
    } catch (e) { /* giữ giao diện tối */ }
  }

  var pvTimer = null;
  function bindRange(id) {
    var update = function () {
      if (id === "lpi") { state.lpiTouched = true; updateLpiRec(); }
      if (id === "lpi" || id === "minDotMm" || id === "solidPct") updateDotInfo();
      $(id + "Val").textContent = $(id).value;
      updateModBadge();
      if (pvTimer) clearTimeout(pvTimer);
      pvTimer = setTimeout(autoPreview, 120);
    };
    $(id).addEventListener("input", update);
    $(id).addEventListener("change", update);
    $(id + "Val").textContent = $(id).value;
  }

  function showInfo(lines, data) {
    if (lines && lines[0]) $("docInfo").textContent = lines[0];
    if (data) setDocSize(parseFloat(data[0]), parseFloat(data[1]));
  }

  /* ---------- License panel ---------- */
  var PLAN_LABEL = { trial: "Dùng thử", monthly: "Monthly", yearly: "Yearly", yearly_pro: "Yearly Pro" };
  function fmtDate(iso) { var d = new Date(iso); return isNaN(d.getTime()) ? "" : d.toLocaleDateString(); }
  var ERR_TEXT = {
    license_invalid_or_expired: "Key không hợp lệ hoặc đã hết hạn.",
    activation_limit_reached: "Key này đã kích hoạt trên máy khác.",
    trial_already_used: "Máy này đã dùng thử 7 ngày.",
    offline: "Không kết nối được máy chủ license.",
    invalid_request: "Key không đúng định dạng.",
    wrong_device: "Mã này dành cho máy khác.",
    bad_signature: "Mã không hợp lệ.",
    no_verifier: "Không xác thực được mã trên máy này.",
    format: "Mã kích hoạt sai định dạng.",
    expired: "Mã kích hoạt đã hết hạn."
  };
  function renderLicense() {
    if (!window.NovaLicense) return;
    var s = NovaLicense.status();
    var label = "", msg = "", renew = false;
    if (NovaLicense.canUse()) {
      label = T("Đã kích hoạt");
      msg = T("Gói {0} · hết hạn {1}", [T(PLAN_LABEL[s.plan] || s.plan), fmtDate(s.expiresAt)]);
      if (s.status === "offline") msg = T("Ngoại tuyến: đang dùng bản đã lưu tối đa 24 giờ.");
    } else if (s.status === "expired") {
      label = T("Hết hạn"); msg = T("License đã hết hạn {0}.", [fmtDate(s.expiresAt)]); renew = true;
    } else if (s.status === "revoked") {
      label = T("Đã thu hồi"); msg = T("License này đã bị thu hồi."); renew = true;
    } else if (s.status === "offline") {
      label = T("Ngoại tuyến"); msg = T("Không kết nối được máy chủ license.");
    } else if (s.status === "invalid") {
      label = T("Chưa kích hoạt"); msg = T("Key không hợp lệ hoặc không thuộc máy này.");
    } else {
      label = T("Chưa kích hoạt"); msg = T("Nhập key hoặc dùng thử 7 ngày để mở khóa.");
    }
    var st = $("licState");
    var active = NovaLicense.canUse();
    st.className = "lic-state" + (active ? " ok" : "");
    st.textContent = (active ? "\u2714 " : "") + label;
    var extra = s.status === "offline" && NovaLicense.diagnostics ? " [" + NovaLicense.diagnostics() + "]" : "";
    $("licMsg").textContent = (s.message || msg) + extra;
    $("licRenew").style.display = renew ? "inline-block" : "none";
    $("licRenew").href = NovaLicense.renewUrl;
    setBusy(false);
    applyTargetGroups();
  }
  function setButtonsDisabled(off) { $("licActivate").disabled = off; $("licTrial").disabled = off; }
  function setBusy(on) {
    var b = $("licBusy");
    if (b) b.style.display = on ? "flex" : "none";
    setButtonsDisabled(on);
  }
  function licError(code) {
    var base = T(ERR_TEXT[code] || "Không kích hoạt được license.");
    if (code === "offline" && NovaLicense.diagnostics) base += " [" + NovaLicense.diagnostics() + "]";
    return base;
  }
  function openExternal(url) {
    try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) {}
    try { window.open(url, "_blank"); } catch (e2) {}
  }
  function wireExternalLinks() {
    each(document.querySelectorAll('a[target="_blank"]'), function (a) {
      a.addEventListener("click", function (ev) {
        ev.preventDefault();
        openExternal(a.href);
      });
    });
  }

  // Version label and "new version available" notice (see update.js).
  function renderVersion() {
    if (!window.NovaUpdate || !$("verLabel")) return;
    $("verLabel").textContent = T("phiên bản") + " " + NovaUpdate.shortVersion(NovaUpdate.version) + " · DTF";
  }
  function renderUpdate() {
    var u = state.update;
    if (!$("updBar")) return;
    if (!u || !u.newer || u.dismissed) { show("updBar", false); return; }
    $("updText").textContent = T("Đã có phiên bản mới {0}. Tải về, giải nén rồi chạy lại file cài đặt.", [NovaUpdate.shortVersion(u.latest)]);
    show("updBar", true);
  }
  function initUpdate() {
    renderVersion();
    if (!window.NovaUpdate || !$("updBar")) return;
    $("updGet").addEventListener("click", function () { if (state.update) openExternal(state.update.url); });
    $("updClose").addEventListener("click", function () {
      if (state.update) { NovaUpdate.dismiss(state.update.latest); state.update.dismissed = true; }
      renderUpdate();
    });
    NovaUpdate.check(function (u) { state.update = u; renderUpdate(); });
  }

  function initLicense() {
    if (!window.NovaLicense) return;
    $("licActivate").addEventListener("click", function () {
      setBusy(true);
      NovaLicense.activate($("licKey").value, function (r) {
        if (!r.ok) { $("licMsg").textContent = licError(r.error); setBusy(false); return; }
        renderLicense();
      });
    });
    $("licTrial").addEventListener("click", function () {
      setBusy(true);
      NovaLicense.startTrial(function (r) {
        if (!r.ok) { $("licMsg").textContent = licError(r.error); setBusy(false); return; }
        $("licKey").value = r.key;
        renderLicense();
      });
    });
    if ($("licDevice")) $("licDevice").value = NovaLicense.deviceCode();
    if ($("licActPage")) $("licActPage").href = NovaLicense.activateUrl();
    wireExternalLinks();
    if ($("licBuy")) $("licBuy").addEventListener("click", function () { openExternal(NovaLicense.renewUrl); });
    if ($("licOfflineToggle")) $("licOfflineToggle").addEventListener("click", function () {
      var el = $("licOffline"); el.style.display = el.style.display === "none" ? "block" : "none";
    });
    if ($("licCopyDevice")) $("licCopyDevice").addEventListener("click", function () {
      var i = $("licDevice"); i.select();
      try { document.execCommand("copy"); } catch (e) {}
    });
    if ($("licApplyCode")) $("licApplyCode").addEventListener("click", function () {
      var code = $("licCode").value;
      if (!code.trim()) return;
      $("licApplyCode").disabled = true;
      setBusy(true);
      NovaLicense.applyOfflineCode(code, function (r) {
        $("licApplyCode").disabled = false;
        if (!r.ok) { $("licMsg").textContent = licError(r.error); setBusy(false); return; }
        $("licOffline").style.display = "none";
        renderLicense();
      });
    });
    setBusy(true);
    NovaLicense.check(function () { renderLicense(); });
  }

  function init() {
    each(document.querySelectorAll(".tab"), function (tab) {
      tab.addEventListener("click", function () { openTab(tab.getAttribute("data-tab")); });
    });
    function openTab(name) {
      try { localStorage.setItem("nova.tab", name); } catch (e) {}
      var tab = document.querySelector('.tab[data-tab="' + name + '"]');
      (function () {
        each(document.querySelectorAll(".tab"), function (t) { t.className = "tab" + (t === tab ? " active" : ""); });
        each(document.querySelectorAll(".page"), function (p) { p.className = "page" + (p.id === "page-" + name ? " active" : ""); });
        show("btnTrame", name === "trame");
      })();
    }
    state.openTab = openTab;
    each(document.querySelectorAll(".acchead"), function (h) {
      if (h.classList.contains("static")) return;
      h.addEventListener("click", function () { h.parentNode.classList.toggle("open"); });
    });
    each(document.querySelectorAll(".pvm"), function (b) {
      b.addEventListener("click", function () {
        state.pvMode = b.getAttribute("data-mode");
        each(document.querySelectorAll(".pvm"), function (x) {
          if (x === b) x.classList.add("active"); else x.classList.remove("active");
        });
        if (pv || state.pvMode === "zoom") runPreview();
      });
    });
    $("statusLine").addEventListener("click", function () {
      var open = $("logDrawer").classList.contains("hidden");
      show("logDrawer", open);
      if (open) $("statusLine").classList.add("open"); else $("statusLine").classList.remove("open");
    });
    $("btnCopyLog").addEventListener("click", function () {
      var box = $("log");
      box.focus(); box.select();
      try { document.execCommand("copy"); setStatus(T("Đã sao chép nhật ký"), ""); } catch (e) { setStatus(T("Hãy nhấn Ctrl+C để sao chép"), ""); }
    });
    applyTheme();
    if (window.NovaI18n) {
      $("langSel").value = window.NovaI18n.lang;
      $("langSel").addEventListener("change", function () {
        window.NovaI18n.set($("langSel").value);
        window.NovaI18n.apply(document.body);
        relabel();
        if (window.NovaLicense) renderLicense();
        renderVersion();
        renderUpdate();
      });
    }
    try { window.__adobe_cep__.addEventListener("com.adobe.csxs.events.ThemeColorChanged", applyTheme); } catch (e) {}
    each(document.querySelectorAll(".segbtn"), function (b) {
      b.addEventListener("click", function () { selectTarget(b.getAttribute("data-target")); });
    });
    function updateNewLpiHint() {
      var w = num("newW", 30), h = num("newH", 40);
      $("newLpiHint").textContent = T("Trame DTF cho khổ này sẽ dùng {0} LPI", [recommendLpi(w, h)]);
    }
    $("newPreset").addEventListener("change", function () {
      var p = PRESETS[$("newPreset").value];
      if (p) { $("newW").value = p[0]; $("newH").value = p[1]; }
      updateNewLpiHint();
    state.newLpiHint = updateNewLpiHint;
    });
    $("newW").addEventListener("input", updateNewLpiHint);
    $("newH").addEventListener("input", updateNewLpiHint);
    updateNewLpiHint();

    buildStyleGrid();
    selectStyle(state.style);
    selectTarget(state.target);
    each(["fxAmt", "minDotMm", "solidPct"], bindRange);
    each(["fxColorA", "fxColorB"], function (id) {
      var sw = id === "fxColorA" ? "swFxA" : "swFxB";
      $(sw).style.backgroundColor = $(id).value;
      $(id).addEventListener("change", function () { $(sw).style.backgroundColor = $(id).value; autoPreview(); });
    });
    $("asciiChars").addEventListener("change", autoPreview);
    $("btnLpiRec").addEventListener("click", function () { state.lpiTouched = false; applyAutoLpi(); updateLpiRec(); autoPreview(); });
    $("btnPvPanel").addEventListener("click", function () {
      try { window.__adobe_cep__.requestOpenExtension(EXT_PV, ""); }
      catch (e) { log(T("Mở bằng menu Window › Extensions › NOVA Trame Preview")); }
    });
    // panel Xem trước báo mở/đóng và gửi lệnh
    onCep("com.nova.trame.preview.hello", function () {
      setPvPanel(true);
      cepEvent("com.nova.trame.lang", { lang: window.NovaI18n ? window.NovaI18n.lang : "en" });
    });
    onCep("com.nova.trame.preview.bye", function () { setPvPanel(false); });
    onCep("com.nova.trame.preview.alive", function () { setPvPanel(true); });
    // mất nhịp tim quá 1,2 giây = panel Xem trước đã ẩn/đóng -> đưa ô xem trước về chỗ cũ.
    // Khi panel chính vừa bận xử lý (sự kiện bị dồn), cho thêm thời gian để không nhấp nháy.
    var lastTick = Date.now();
    setInterval(function () {
      var now = Date.now(), stalled = now - lastTick > 900;
      lastTick = now;
      if (stalled) { state.pvBeat = Math.max(state.pvBeat || 0, now - 600); return; }
      if (state.pvPanel && !state.busy && now - (state.pvBeat || 0) > 1200) setPvPanel(false);
    }, 250);
    onCep("com.nova.trame.preview.cmd", function (d) {
      if (d.cmd === "refresh") runPreview();
      else if (d.cmd === "mode" && (d.mode === "fit" || d.mode === "zoom")) {
        state.pvMode = d.mode;
        each(document.querySelectorAll(".pvm"), function (x) {
          if (x.getAttribute("data-mode") === d.mode) x.classList.add("active"); else x.classList.remove("active");
        });
        runPreview();
      }
    });
    each(["lpi", "angle", "level", "gcr", "mcCount", "mcVary", "fadeAmt", "distressAmt", "idxColors", "idxGrain"], bindRange);
    each(["mcSwirl", "invertChk", "fadeDir", "idxDither", "idxShirt"], function (id) {
      $(id).addEventListener("change", function () { updateModBadge(); autoPreview(); });
    });
    $("btnShuffle").addEventListener("click", function () {
      state.mcSeed = (state.mcSeed * 7919 + 13) % 100003;
      if (pv) autoPreview(); else log(T("Đã đổi bố cục. Bấm Xem trước để xem."));
    });
    each(COLOR_CH, function (ch) {
      var cap = ch.toUpperCase();
      $("use" + cap).addEventListener("change", autoPreview);
      $("ink" + cap).addEventListener("change", function () {
        $("sw" + cap).style.backgroundColor = $("ink" + cap).value;
        autoPreview();
      });
      $("sw" + cap).style.backgroundColor = $("ink" + cap).value;
    });

    $("btnInfo").addEventListener("click", function () {
      guarded(T("Kiểm tra file"), function (done) {
        jsx("info", {}, function (ok, lines, data) { if (ok) showInfo(lines, data); done(ok ? null : T("xem nhật ký")); });
      });
    });
    $("btnPreview").addEventListener("click", runPreview);
    $("btnTrame").addEventListener("click", function () {
      var s = styleById(state.style);
      // kiểu gốc Photoshop nhưng có bật hiệu ứng phụ -> kết xuất bằng engine của plugin
      state.applyPending = true;
      // DTF: mọi kiểu đơn sắc kết xuất bằng engine của plugin để áp được giới hạn chấm cho bột keo
      // và để kết quả khớp đúng với ô xem trước.
      if (s.engine === "color") applyColor(s);
      else if (s.engine === "index") applyIndex(s);
      else if (s.engine === "fx") applyFx(s);
      else applyCanvas(s);
    });
    $("btnNewDoc").addEventListener("click", function () {
      state.lpiTouched = false;
      setDocSize(num("newW", 30), num("newH", 40));
      guarded(T("Tạo tài liệu"), function (done) {
        jsx("newDoc", { w: num("newW", 30), h: num("newH", 40), dpi: num("newDpi", 300),
          mode: $("newMode").value, bg: $("newBg").value },
          function (ok) { done(ok ? null : T("xem nhật ký")); });
      });
    });
    $("btnPattern").addEventListener("click", function () {
      guarded(T("Họa tiết lặp"), function (done) {
        jsx("makePattern", { gapX: num("patGapX", 50), gapY: num("patGapY", 50), offset: num("patOffset", 50) },
          function (ok) { done(ok ? null : T("xem nhật ký")); });
      });
    });
    $("btnSticker").addEventListener("click", function () {
      guarded(T("Viền sticker"), function (done) {
        jsx("makeSticker", { size: num("stSize", 20), color: $("stColor").value, smooth: num("stSmooth", 5) },
          function (ok) { done(ok ? null : T("xem nhật ký")); });
      });
    });
    $("btnEffect").addEventListener("click", function () {
      guarded(T("Viền & bóng cho layer"), function (done) {
        jsx("effects", {
          stroke: $("fxStroke").checked, strokeSize: num("strokeSize", 10), strokeColor: $("strokeColor").value,
          strokePos: $("strokePos").value, shadow: $("fxShadow").checked, shAngle: num("shAngle", 120),
          shDist: num("shDist", 10), shBlur: num("shBlur", 10), shOpacity: num("shOpacity", 75)
        }, function (ok) { done(ok ? null : T("xem nhật ký")); });
      });
    });
    $("btnClearLog").addEventListener("click", function () { $("log").value = ""; setStatus(T("Sẵn sàng"), ""); });

    ensureHost(function (ok) {
      if (!ok) return;
      evalJSX("NOVA.ping()", function (r) {
        log(T("Plugin đã nạp. {0}", [String(r).split("\n")[1]]));
        // đọc khổ file đang mở để đặt LPI gợi ý (không báo lỗi nếu chưa mở file)
        evalJSX("app.documents.length", function (n) {
          // Chưa kích hoạt: mở tab License trước. Đã kích hoạt: mở tab Trame DTF trước.
          var licensed = !!(window.NovaLicense && NovaLicense.canUse());
          state.openTab(licensed ? "trame" : "license");
          if (parseInt(n, 10) > 0) jsx("info", {}, function (ok2, lines, data) { if (ok2) showInfo(lines, data); });
          else { $("docInfo").textContent = T("Chưa mở file nào. LPI đang theo khổ mặc định 30×40 cm."); updateLpiRec(); }
        });
      });
      cepEvent("com.nova.trame.main.ready", {});
    });
  }

  init();
  initLicense();
  initUpdate();
})();
