/* NOVA Trame Studio: license client.
 * The panel asks the license server on every open. The last server answer is kept
 * (lightly obfuscated) so the panel works offline for up to 24 hours.
 * This is a deterrent, not real security: anything in the panel can be read by the user.
 *
 * Offline hardening:
 * - Clock guard: the latest time the panel has seen is remembered. If the computer clock
 *   is later found to be earlier than that (rolled back), offline use is refused until
 *   the clock is fixed and the panel reaches the server again.
 * - Signed grace token: when the server returns `token` (Ed25519, same key as offline codes,
 *   payload typ "grace" with issued_at), offline use is based on that signed token instead of
 *   the editable local copy. Set REQUIRE_SIGNED_CACHE to true once the server sends it.
 */
(function (root) {
  var API = "https://api.ainovanesting.pro/api/trame";
  var RENEW_URL = "https://ainovanesting.pro/trame-preview#pricing";
  var STORE_KEY = "nvt.lic";
  var DEVICE_KEY = "nvt.dev";
  var CLOCK_KEY = "nvt.ts";
  var OFFLINE_GRACE_MS = 24 * 60 * 60 * 1000;
  // Allowed difference before a clock change counts as a rollback (time sync, time zones).
  var CLOCK_SKEW_MS = 10 * 60 * 1000;
  // Turn on only after the server returns a signed `token` from /license/validate and /trial.
  // While false, the old unsigned local copy still grants the 24-hour offline grace.
  var REQUIRE_SIGNED_CACHE = false;
  var SALT = "nvt-2026-lic";
  // Ed25519 public key (raw 32 bytes, base64) matching TRAME_SIGNING_PRIVATE_KEY on the server.
  var PUBKEY_B64 = "+YkQTptHgYr9q/e55c1xRVi+jSHxmr8Cg+UlmOHuRKM=";

  // Obfuscation: XOR with a key tied to this device, then base64.
  function xorText(text, key) {
    var out = "";
    for (var i = 0; i < text.length; i++) out += String.fromCharCode(text.charCodeAt(i) ^ key.charCodeAt(i % key.length));
    return out;
  }
  function encode(obj, dev) { return btoa(unescape(encodeURIComponent(xorText(JSON.stringify(obj), SALT + dev)))); }
  function decode(text, dev) {
    try { return JSON.parse(xorText(decodeURIComponent(escape(atob(text))), SALT + dev)); }
    catch (e) { return null; }
  }

  // Device id: hash of hostname + first external MAC when Node is available, otherwise a random id kept in storage.
  function deviceId() {
    var saved = localStorage.getItem(DEVICE_KEY);
    if (saved) return saved;
    var id = "";
    try {
      var os = require("os");
      var crypto = require("crypto");
      var mac = "";
      var nets = os.networkInterfaces();
      Object.keys(nets).forEach(function (n) {
        (nets[n] || []).forEach(function (a) { if (!mac && !a.internal && a.mac && a.mac !== "00:00:00:00:00:00") mac = a.mac; });
      });
      id = crypto.createHash("sha256").update(os.hostname() + "|" + mac + "|" + os.platform()).digest("hex").slice(0, 32);
    } catch (e) {
      id = "";
    }
    if (!id) {
      id = "";
      for (var i = 0; i < 32; i++) id += Math.floor(Math.random() * 16).toString(16);
    }
    localStorage.setItem(DEVICE_KEY, id);
    return id;
  }

  function load() {
    var raw = localStorage.getItem(STORE_KEY);
    return raw ? decode(raw, deviceId()) : null;
  }
  function save(state) { localStorage.setItem(STORE_KEY, encode(state, deviceId())); }

  // Clock guard. The latest time seen is kept in its own key and inside the license copy,
  // so deleting one of them is not enough to hide a rollback.
  function readSeen(stored) {
    var a = 0;
    try { a = parseInt(localStorage.getItem(CLOCK_KEY) || "0", 10) || 0; } catch (e) {}
    var b = (stored && +stored.seen) || 0;
    return Math.max(a, b, sessionSeen);
  }
  function markSeen(t, reset) {
    var v = reset ? t : Math.max(t, readSeen(load()));
    sessionSeen = reset ? t : Math.max(sessionSeen, t);
    try { localStorage.setItem(CLOCK_KEY, String(v)); } catch (e) {}
    return v;
  }
  function clockRolledBack(stored, floor) {
    var seen = Math.max(readSeen(stored), floor || 0);
    return seen > 0 && Date.now() + CLOCK_SKEW_MS < seen;
  }
  var sessionSeen = 0;

  function b64ToBytes(b64) {
    var bin = atob(String(b64));
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  // sha256 hex of "trame-device:"+id, matching the server's hashDevice(). Uses CEP's Node
  // crypto, which is present whenever the network is merely firewall-blocked.
  function deviceHashLocal() {
    try { return require("crypto").createHash("sha256").update("trame-device:" + deviceId()).digest("hex"); }
    catch (e) { return null; }
  }

  // Verify a server-signed payload "base64(json).base64(sig)": Ed25519 signature and device binding.
  function verifySigned(code) {
    try {
      var parts = String(code).trim().split(".");
      if (parts.length !== 2) return { ok: false, error: "format" };
      var msg = b64ToBytes(parts[0]);
      var sig = b64ToBytes(parts[1]);
      var pk = b64ToBytes(PUBKEY_B64);
      if (!window.NovaNacl || !window.NovaNacl.sign) return { ok: false, error: "no_verifier" };
      if (!window.NovaNacl.sign.detached.verify(msg, sig, pk)) return { ok: false, error: "bad_signature" };
      var payload = JSON.parse(String.fromCharCode.apply(null, msg));
      var dh = deviceHashLocal();
      if (!dh || payload.device_hash !== dh) return { ok: false, error: "wrong_device" };
      return { ok: true, payload: payload };
    } catch (e) { return { ok: false, error: "format" }; }
  }

  // Offline activation code: signed, bound to this device, not expired.
  // A grace token (typ "grace") is not accepted here, otherwise it would skip the 24-hour limit.
  function verifyOfflineCode(code) {
    var v = verifySigned(code);
    if (!v.ok) return v;
    if (v.payload.typ === "grace") return { ok: false, error: "format" };
    if (Date.now() >= new Date(v.payload.expires_at).getTime()) return { ok: false, error: "expired" };
    return v;
  }

  // Grace token from /license/validate or /trial: signed, bound to this device,
  // issued less than OFFLINE_GRACE_MS ago, and the license itself not expired.
  function verifyGraceToken(token) {
    var v = verifySigned(token);
    if (!v.ok) return v;
    var p = v.payload;
    if (p.typ !== "grace") return { ok: false, error: "format" };
    var issued = new Date(p.issued_at).getTime();
    var now = Date.now();
    if (!issued || now - issued >= OFFLINE_GRACE_MS) return { ok: false, error: "expired" };
    if (now >= new Date(p.expires_at).getTime()) return { ok: false, error: "expired" };
    return { ok: true, payload: p, issued: issued };
  }

    // CEP panels load from file://, so a browser XHR to https is blocked as a cross-origin
  // request before it leaves the panel. When CEP's Node runtime is available we use it
  // directly, which is not subject to that restriction. XHR stays as a fallback.
  function postNode(path, payload, cb) {
    var https = require("https");
    var urlmod = require("url");
    var u = urlmod.parse(API + path);
    var req = https.request({
      host: u.hostname,
      port: 443,
      path: u.path,
      method: "POST",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(payload) }
    }, function (res) {
      var text = "";
      res.setEncoding("utf8");
      res.on("data", function (c) { text += c; });
      res.on("end", function () {
        var data = null;
        try { data = JSON.parse(text); } catch (e) {}
        note("node http " + res.statusCode);
        cb(res.statusCode, data, false);
      });
    });
    req.on("error", function (e) {
      diag.nodeErr = String((e && (e.code || e.message)) || "unknown");
      note("node error " + diag.nodeErr);
      cb(0, null, true);
    });
    req.setTimeout(15000, function () { diag.nodeErr = "timeout"; note("node timeout"); try { req.abort(); } catch (e) {} });
    req.write(payload);
    req.end();
  }

  function postXhr(path, payload, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", API + path, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.timeout = 15000;
    xhr.onload = function () {
      var data = null;
      try { data = JSON.parse(xhr.responseText); } catch (e) {}
      note("xhr http " + xhr.status);
      cb(xhr.status, data, false);
    };
    xhr.onerror = function () { note("xhr blocked (status " + xhr.status + ")"); cb(0, null, true); };
    xhr.ontimeout = function () { note("xhr timeout"); cb(0, null, true); };
    xhr.send(payload);
  }

  function post(path, body, cb) {
    var payload = JSON.stringify(body);
    var done = false;
    function once(code, data, offline) { if (!done) { done = true; cb(code, data, offline); } }
    try {
      if (typeof require === "function") {
        diag.node = "yes";
        try { require("https"); require("url"); } catch (re) { diag.nodeErr = "require:" + (re && re.message); throw re; }
        postNode(path, payload, function (code, data, offline) {
          // If the Node request failed outright, try once more over XHR.
          if (offline && !done) { postXhr(path, payload, once); return; }
          once(code, data, offline);
        });
        return;
      }
    } catch (e) { diag.node = "throw:" + (e && e.message); }
    if (diag.node === "?") diag.node = "no";
    postXhr(path, payload, once);
  }

  var diag = { node: "?", nodeErr: "", last: "" };
  function note(text) {
    diag.last = String(text);
    try { if (window.NovaLog) window.NovaLog("license: " + diag.last); } catch (e) {}
  }

  var state = { status: "none", plan: null, groups: null, expiresAt: null, key: null, lastOk: 0, message: "", renewUrl: RENEW_URL };

  function applyServer(data) {
    var ent = data.entitlement || {};
    state.status = "active";
    state.plan = ent.plan;
    state.groups = ent.groups || [];
    state.expiresAt = ent.expires_at;
    state.lastOk = Date.now();
    state.message = "";
    // The server just confirmed the license, so the current clock becomes the new reference
    // (this also clears a clock that was once set too far ahead).
    var seen = markSeen(state.lastOk, true);
    var prev = load() || {};
    var token = data.token ? String(data.token) : "";
    save({ key: state.key, plan: state.plan, groups: state.groups, expiresAt: state.expiresAt, lastOk: state.lastOk, offlineCode: prev.offlineCode, token: token, seen: seen });
    state.validUntil = new Date(state.expiresAt).getTime() || 0;
  }

  function fail(stateName, message) {
    state.status = stateName;
    state.groups = [];
    state.message = message || "";
    state.validUntil = 0;
    save({ key: state.key, expired: stateName, seen: readSeen(load()) });
  }

  // Clock rolled back: block offline use but keep the saved license, so fixing the clock
  // (or going online) brings it back without a new activation.
  function clockFail() {
    state.status = "clock";
    state.groups = [];
    state.message = "";
    state.validUntil = 0;
  }

  // Decide offline use from what is stored on this computer. Order:
  // clock guard, offline activation code, signed grace token, then (only while
  // REQUIRE_SIGNED_CACHE is false) the old unsigned copy.
  function useOffline(stored) {
    var now = Date.now();
    var t = stored.token ? verifyGraceToken(stored.token) : { ok: false };
    if (clockRolledBack(stored, t.ok ? t.issued : 0)) { clockFail(); return; }
    var v = stored.offlineCode ? verifyOfflineCode(stored.offlineCode) : { ok: false };
    if (v.ok) {
      state.status = "offline"; state.plan = v.payload.plan; state.groups = v.payload.groups; state.expiresAt = v.payload.expires_at;
      state.validUntil = new Date(v.payload.expires_at).getTime();
    } else if (t.ok) {
      state.status = "offline"; state.plan = t.payload.plan; state.groups = t.payload.groups; state.expiresAt = t.payload.expires_at; state.lastOk = t.issued;
      state.validUntil = Math.min(t.issued + OFFLINE_GRACE_MS, new Date(t.payload.expires_at).getTime());
    } else if (!REQUIRE_SIGNED_CACHE && stored.groups && stored.lastOk && now - stored.lastOk < OFFLINE_GRACE_MS && now < new Date(stored.expiresAt).getTime()) {
      state.status = "offline"; state.plan = stored.plan; state.groups = stored.groups; state.expiresAt = stored.expiresAt; state.lastOk = stored.lastOk;
      state.validUntil = Math.min(stored.lastOk + OFFLINE_GRACE_MS, new Date(stored.expiresAt).getTime());
    } else {
      fail("offline", "");
      return;
    }
    var seen = markSeen(now);
    stored.seen = seen;
    save(stored);
  }

  // Ask the server for the current state of the stored key.
  function check(cb) {
    var stored = load();
    // Activated with an offline code only (no key to ask the server about).
    if (stored && !stored.key && stored.offlineCode) { useOffline(stored); return cb && cb(); }
    if (!stored || !stored.key) { state.status = "none"; state.groups = []; return cb && cb(); }
    state.key = stored.key;
    post("/license/validate", { license_key: stored.key, device_id: deviceId() }, function (code, data, offline) {
      if (offline) {
        useOffline(stored);
      } else if (data && data.ok) {
        applyServer(data);
      } else if (data && data.state === "EXPIRED") {
        fail("expired", "");
        state.expiresAt = data.expires_at;
      } else if (data && data.state === "REVOKED") {
        fail("revoked", "");
      } else {
        fail("invalid", "");
      }
      cb && cb();
    });
  }

  function activate(key, cb) {
    key = String(key || "").trim().toUpperCase();
    state.key = key;
    post("/license/activate", { license_key: key, device_id: deviceId(), device_name: "" }, function (code, data, offline) {
      if (offline) return cb({ ok: false, error: "offline" });
      if (!data || !data.activated) return cb({ ok: false, error: (data && data.error) || "unknown" });
      save({ key: key });
      check(function () { cb({ ok: true }); });
    });
  }

  function startTrial(cb) {
    post("/trial", { device_id: deviceId(), device_name: "" }, function (code, data, offline) {
      if (offline) return cb({ ok: false, error: "offline" });
      if (!data || !data.ok) return cb({ ok: false, error: (data && data.error) || "unknown" });
      state.key = data.license_key;
      save({ key: data.license_key });
      applyServer(data);
      cb({ ok: true, key: data.license_key, expiresAt: data.expires_at });
    });
  }

  function clear() {
    localStorage.removeItem(STORE_KEY);
    state = { status: "none", plan: null, groups: [], expiresAt: null, key: null, lastOk: 0, message: "", renewUrl: RENEW_URL };
  }

  function applyOfflineCode(code, cb) {
    if (clockRolledBack(load(), 0)) { cb && cb({ ok: false, error: "clock" }); return; }
    var v = verifyOfflineCode(code);
    if (!v.ok) { cb && cb({ ok: false, error: v.error }); return; }
    state.status = "offline"; state.key = ""; state.plan = v.payload.plan; state.groups = v.payload.groups; state.expiresAt = v.payload.expires_at; state.lastOk = Date.now();
    state.validUntil = new Date(v.payload.expires_at).getTime();
    var seen = markSeen(state.lastOk);
    save({ key: "", plan: state.plan, groups: state.groups, expiresAt: state.expiresAt, lastOk: state.lastOk, offlineCode: String(code).trim(), seen: seen });
    cb && cb({ ok: true });
  }

  // Checked every time the panel applies an effect, so a panel left open does not
  // outlive its offline window or license, and a clock rolled back mid-session is caught.
  function canUse() {
    if (!(state.status === "active" || state.status === "offline") || !state.groups || !state.groups.length) return false;
    var now = Date.now();
    if (state.validUntil && now >= state.validUntil) return false;
    if (sessionSeen && now + CLOCK_SKEW_MS < sessionSeen) return false;
    if (now > sessionSeen) sessionSeen = now;
    return true;
  }

  root.NovaLicense = {
    check: check,
    activate: activate,
    startTrial: startTrial,
    clear: clear,
    status: function () { return state; },
    allowed: function (group) { return state.groups && state.groups.indexOf(group) >= 0; },
    canUse: canUse,
    applyOfflineCode: applyOfflineCode,
    deviceCode: function () { return deviceId(); },
    activateUrl: function () { return API.replace("/api/trame", "/trame-activate"); },
    renewUrl: RENEW_URL,
    diagnostics: function () { return "node=" + diag.node + " nodeErr=" + (diag.nodeErr || "none") + " last=" + (diag.last || "none"); }
  };
})(window);
