this.__NOVA_DICT = {
"Ảnh xem trước đang hiển thị ở panel <b>Xem trước</b>.": {
"en": "Preview is showing in the <b>Preview</b> panel.",
"th": "ภาพตัวอย่างแสดงอยู่ในพาเนล <b>ตัวอย่าง</b>",
"es": "La vista previa se muestra en el panel <b>Vista previa</b>."
},
"Bấm <b>Xem trước</b> để lấy hình từ Photoshop": {
"en": "Click <b>Preview</b> to grab the image from Photoshop",
"th": "กด <b>ดูตัวอย่าง</b> เพื่อดึงภาพจาก Photoshop",
"es": "Pulsa <b>Vista previa</b> para tomar la imagen de Photoshop"
},
"Chấm quá nhỏ để thấy đúng ở chế độ toàn hình (dễ thấy vân giả). Chọn <b>Cận cảnh 100%</b> để xem đúng như bản in.": {
"en": "Dots are too small to show correctly in full view (false moiré may appear). Choose <b>100% close-up</b> to see it exactly as printed.",
"th": "จุดเล็กเกินไปจึงแสดงไม่ถูกต้องในโหมดเต็มภาพ (อาจเห็นลายมัวเร่หลอก) เลือก <b>ซูม 100%</b> เพื่อดูให้ตรงกับงานพิมพ์จริง",
"es": "Los puntos son demasiado pequeños para verse bien en vista completa (puede aparecer muaré falso). Elige <b>Detalle 100%</b> para verlo tal como se imprimirá."
},
"Thêm viền ngoài (kiểu viền sticker trắng) và bóng đổ cho <b>layer đang chọn</b> bằng Layer Style của Photoshop. Dùng khi cần hình nổi khối hoặc có viền cắt trước khi in DTF. Không liên quan tới trame.": {
"en": "Adds an outer stroke (white sticker-style outline) and a drop shadow to the <b>selected layer</b> using Photoshop Layer Styles. Use it when you need a raised look or a cut outline before DTF printing. Not related to halftones.",
"th": "เพิ่มเส้นขอบด้านนอก (ขอบขาวแบบสติกเกอร์) และเงาตกกระทบให้ <b>เลเยอร์ที่เลือก</b> ด้วย Layer Style ของ Photoshop ใช้เมื่อต้องการภาพดูนูนหรือมีขอบตัดก่อนพิมพ์ DTF ไม่เกี่ยวกับฮาล์ฟโทน",
"es": "Añade un trazo exterior (contorno blanco tipo pegatina) y una sombra paralela a la <b>capa seleccionada</b> con los Estilos de capa de Photoshop. Úsalo cuando necesites relieve o un contorno de corte antes de imprimir en DTF. No tiene relación con la trama."
},
"phiên bản 1.0 · DTF": {
"en": "version 1.0 · DTF",
"th": "เวอร์ชัน 1.0 · DTF",
"es": "versión 1.0 · DTF"
},
"Chưa đọc file. Bấm nút làm mới.": {
"en": "No file read yet. Click refresh.",
"th": "ยังไม่ได้อ่านไฟล์ กดปุ่มรีเฟรช",
"es": "Aún no se ha leído el archivo. Pulsa actualizar."
},
"1 · Tạo file": {
"en": "1 · New file",
"th": "1 · สร้างไฟล์",
"es": "1 · Crear archivo"
},
"2 · Trame DTF": {
"en": "2 · DTF halftone",
"th": "2 · ฮาล์ฟโทน DTF",
"es": "2 · Trama DTF"
},
"DTF áo đen": {
"en": "DTF black shirt",
"th": "DTF เสื้อดำ",
"es": "DTF camiseta negra"
},
"DTF áo trắng": {
"en": "DTF white shirt",
"th": "DTF เสื้อขาว",
"es": "DTF camiseta blanca"
},
"Toàn hình": {
"en": "Full view",
"th": "เต็มภาพ",
"es": "Vista completa"
},
"Cận cảnh 100%": {
"en": "100% close-up",
"th": "ซูม 100%",
"es": "Detalle 100%"
},
"Xem trước": {
"en": "Preview",
"th": "ดูตัวอย่าง",
"es": "Vista previa"
},
"Tự cập nhật": {
"en": "Auto update",
"th": "อัปเดตอัตโนมัติ",
"es": "Actualizar solo"
},
"Kiểu trame": {
"en": "Halftone style",
"th": "รูปแบบฮาล์ฟโทน",
"es": "Estilo de trama"
},
"Thông số": {
"en": "Settings",
"th": "ค่าตั้ง",
"es": "Parámetros"
},
"Tần số (LPI)": {
"en": "Frequency (LPI)",
"th": "ความถี่ (LPI)",
"es": "Frecuencia (LPI)"
},
"Dùng gợi ý": {
"en": "Use suggestion",
"th": "ใช้ค่าแนะนำ",
"es": "Usar sugerencia"
},
"Góc": {
"en": "Angle",
"th": "มุม",
"es": "Ángulo"
},
"Kiểu này không có thông số lưới.": {
"en": "This style has no grid settings.",
"th": "รูปแบบนี้ไม่มีค่าตั้งของกริด",
"es": "Este estilo no tiene ajustes de retícula."
},
"Tùy chọn hiệu ứng": {
"en": "Effect options",
"th": "ตัวเลือกเอฟเฟกต์",
"es": "Opciones del efecto"
},
"Cường độ": {
"en": "Strength",
"th": "ความแรง",
"es": "Intensidad"
},
"Màu 1": {
"en": "Color 1",
"th": "สี 1",
"es": "Color 1"
},
"Màu 2": {
"en": "Color 2",
"th": "สี 2",
"es": "Color 2"
},
"Bộ ký tự (từ nhạt đến đậm, hoặc gõ chữ thương hiệu)": {
"en": "Characters (light to dark, or type your brand name)",
"th": "ชุดตัวอักษร (จากจางไปเข้ม หรือพิมพ์ชื่อแบรนด์)",
"es": "Caracteres (de claro a oscuro, o escribe tu marca)"
},
"Bố cục nhiều tâm": {
"en": "Multi-center layout",
"th": "เลย์เอาต์หลายจุดศูนย์กลาง",
"es": "Diseño multicentro"
},
"Số tâm": {
"en": "Centers",
"th": "จำนวนจุดศูนย์กลาง",
"es": "Centros"
},
"Chênh lệch to / nhỏ": {
"en": "Size variation",
"th": "ความต่างของขนาด",
"es": "Variación de tamaño"
},
"Chiều xoắn ngẫu nhiên": {
"en": "Random twist direction",
"th": "สุ่มทิศทางการหมุน",
"es": "Giro aleatorio"
},
"Đổi bố cục": {
"en": "Shuffle layout",
"th": "สุ่มเลย์เอาต์ใหม่",
"es": "Cambiar diseño"
},
"Màu mực": {
"en": "Ink colors",
"th": "สีหมึก",
"es": "Colores de tinta"
},
"Vàng": {
"en": "Yellow",
"th": "เหลือง",
"es": "Amarillo"
},
"Hồng": {
"en": "Pink",
"th": "ชมพู",
"es": "Rosa"
},
"Xanh": {
"en": "Cyan",
"th": "ฟ้า",
"es": "Cian"
},
"Đen": {
"en": "Black",
"th": "ดำ",
"es": "Negro"
},
"Lượng đen (GCR)": {
"en": "Black amount (GCR)",
"th": "ปริมาณสีดำ (GCR)",
"es": "Cantidad de negro (GCR)"
},
"Tách màu spot": {
"en": "Spot color separation",
"th": "แยกสีสปอต",
"es": "Separación de tintas planas"
},
"Bảng màu hiện sau khi xem trước.": {
"en": "The palette appears after preview.",
"th": "จานสีจะแสดงหลังดูตัวอย่าง",
"es": "La paleta aparece tras la vista previa."
},
"Số màu in": {
"en": "Print colors",
"th": "จำนวนสีที่พิมพ์",
"es": "Colores de impresión"
},
"Màu áo (không in)": {
"en": "Shirt color (not printed)",
"th": "สีเสื้อ (ไม่พิมพ์)",
"es": "Color de camiseta (no se imprime)"
},
"Trắng": {
"en": "White",
"th": "ขาว",
"es": "Blanco"
},
"Không bỏ": {
"en": "Keep all",
"th": "ไม่ตัดออก",
"es": "No quitar"
},
"Chuyển tiếp": {
"en": "Transition",
"th": "การไล่สี",
"es": "Transición"
},
"Phẳng": {
"en": "Flat",
"th": "เรียบ",
"es": "Plana"
},
"Hạt mịn": {
"en": "Fine grain",
"th": "เม็ดละเอียด",
"es": "Grano fino"
},
"Cỡ hạt": {
"en": "Grain size",
"th": "ขนาดเม็ด",
"es": "Tamaño de grano"
},
"Hiệu ứng phụ": {
"en": "Extra effects",
"th": "เอฟเฟกต์เสริม",
"es": "Efectos extra"
},
"Đang bật": {
"en": "On",
"th": "เปิดอยู่",
"es": "Activo"
},
"Hướng mờ": {
"en": "Fade direction",
"th": "ทิศทางการจาง",
"es": "Dirección del desvanecido"
},
"Tan ra mép dưới": {
"en": "Fade to bottom edge",
"th": "จางลงขอบล่าง",
"es": "Desvanecer hacia abajo"
},
"Tan ra mép trên": {
"en": "Fade to top edge",
"th": "จางขึ้นขอบบน",
"es": "Desvanecer hacia arriba"
},
"Tan ra xung quanh": {
"en": "Fade to all edges",
"th": "จางรอบด้าน",
"es": "Desvanecer hacia los bordes"
},
"Bong tróc": {
"en": "Distress",
"th": "ลายลอก",
"es": "Desgaste"
},
"Chấm âm (đảo chấm thành lỗ)": {
"en": "Negative dots (turn dots into holes)",
"th": "จุดกลับ (เปลี่ยนจุดเป็นรู)",
"es": "Puntos negativos (convertir puntos en huecos)"
},
"Đầu ra DTF": {
"en": "DTF output",
"th": "เอาต์พุต DTF",
"es": "Salida DTF"
},
"Chấm nhỏ nhất": {
"en": "Minimum dot",
"th": "จุดเล็กสุด",
"es": "Punto mínimo"
},
"Tô đặc từ": {
"en": "Solid from",
"th": "ทึบตั้งแต่",
"es": "Sólido desde"
},
"Tạo lớp trắng (underbase)": {
"en": "Create white underbase",
"th": "สร้างชั้นขาวรองพื้น (underbase)",
"es": "Crear base blanca (underbase)"
},
"Co lớp trắng (px)": {
"en": "Underbase choke (px)",
"th": "หดชั้นขาว (px)",
"es": "Contracción de la base (px)"
},
"Lớp trắng chỉ tạo khi in trên áo đen. File gốc giữ nguyên, kết quả nằm trong tài liệu mới.": {
"en": "The underbase is only made for black shirts. The original file is untouched; the result opens as a new document.",
"th": "ชั้นขาวสร้างเฉพาะเมื่อพิมพ์บนเสื้อดำ ไฟล์ต้นฉบับไม่ถูกแก้ไข ผลลัพธ์อยู่ในเอกสารใหม่",
"es": "La base blanca solo se crea para camisetas negras. El archivo original no se modifica; el resultado se abre en un documento nuevo."
},
"Tài liệu mới": {
"en": "New document",
"th": "เอกสารใหม่",
"es": "Documento nuevo"
},
"Khổ": {
"en": "Size",
"th": "ขนาด",
"es": "Tamaño"
},
"Tùy chỉnh": {
"en": "Custom",
"th": "กำหนดเอง",
"es": "Personalizado"
},
"10 × 10 cm · logo ngực": {
"en": "10 × 10 cm · chest logo",
"th": "10 × 10 ซม. · โลโก้หน้าอก",
"es": "10 × 10 cm · logo pecho"
},
"25 × 30 cm · lưng áo": {
"en": "25 × 30 cm · back print",
"th": "25 × 30 ซม. · ด้านหลัง",
"es": "25 × 30 cm · espalda"
},
"30 × 40 cm · khổ lớn": {
"en": "30 × 40 cm · large",
"th": "30 × 40 ซม. · ขนาดใหญ่",
"es": "30 × 40 cm · grande"
},
"A4 · 21 × 29,7 cm": {
"en": "A4 · 21 × 29.7 cm",
"th": "A4 · 21 × 29.7 ซม.",
"es": "A4 · 21 × 29,7 cm"
},
"A3 · 29,7 × 42 cm": {
"en": "A3 · 29.7 × 42 cm",
"th": "A3 · 29.7 × 42 ซม.",
"es": "A3 · 29,7 × 42 cm"
},
"Rộng (cm)": {
"en": "Width (cm)",
"th": "กว้าง (ซม.)",
"es": "Ancho (cm)"
},
"Cao (cm)": {
"en": "Height (cm)",
"th": "สูง (ซม.)",
"es": "Alto (cm)"
},
"Hệ màu": {
"en": "Color mode",
"th": "โหมดสี",
"es": "Modo de color"
},
"Nền": {
"en": "Background",
"th": "พื้นหลัง",
"es": "Fondo"
},
"Trong suốt": {
"en": "Transparent",
"th": "โปร่งใส",
"es": "Transparente"
},
"Tạo tài liệu": {
"en": "Create document",
"th": "สร้างเอกสาร",
"es": "Crear documento"
},
"Họa tiết lặp": {
"en": "Repeat pattern",
"th": "ลายซ้ำ",
"es": "Patrón repetido"
},
"Nhân bản layer đang chọn thành lưới phủ kín tài liệu.": {
"en": "Duplicates the selected layer into a grid that fills the document.",
"th": "ทำสำเนาเลเยอร์ที่เลือกเป็นกริดเต็มเอกสาร",
"es": "Duplica la capa seleccionada en una cuadrícula que llena el documento."
},
"Cách ngang (px)": {
"en": "Horizontal gap (px)",
"th": "ระยะห่างแนวนอน (px)",
"es": "Separación horizontal (px)"
},
"Cách dọc (px)": {
"en": "Vertical gap (px)",
"th": "ระยะห่างแนวตั้ง (px)",
"es": "Separación vertical (px)"
},
"Lệch hàng (%)": {
"en": "Row offset (%)",
"th": "เลื่อนแถว (%)",
"es": "Desfase de fila (%)"
},
"Tạo họa tiết lặp": {
"en": "Create pattern",
"th": "สร้างลายซ้ำ",
"es": "Crear patrón"
},
"Viền sticker": {
"en": "Sticker outline",
"th": "ขอบสติกเกอร์",
"es": "Contorno de pegatina"
},
"Viền quanh layer đang chọn, nằm ở layer riêng bên dưới.": {
"en": "An outline around the selected layer, on its own layer underneath.",
"th": "ขอบรอบเลเยอร์ที่เลือก อยู่ในเลเยอร์แยกด้านล่าง",
"es": "Contorno alrededor de la capa seleccionada, en su propia capa debajo."
},
"Độ dày (px)": {
"en": "Thickness (px)",
"th": "ความหนา (px)",
"es": "Grosor (px)"
},
"Làm mịn (px)": {
"en": "Smoothing (px)",
"th": "ความเรียบ (px)",
"es": "Suavizado (px)"
},
"Màu": {
"en": "Color",
"th": "สี",
"es": "Color"
},
"Tạo viền sticker": {
"en": "Create sticker outline",
"th": "สร้างขอบสติกเกอร์",
"es": "Crear contorno"
},
"Viền & bóng cho layer": {
"en": "Layer stroke & shadow",
"th": "เส้นขอบและเงาเลเยอร์",
"es": "Trazo y sombra de capa"
},
"Viền ngoài": {
"en": "Outer stroke",
"th": "เส้นขอบด้านนอก",
"es": "Trazo exterior"
},
"Vị trí": {
"en": "Position",
"th": "ตำแหน่ง",
"es": "Posición"
},
"Bên ngoài": {
"en": "Outside",
"th": "ด้านนอก",
"es": "Exterior"
},
"Giữa": {
"en": "Center",
"th": "กึ่งกลาง",
"es": "Centro"
},
"Bên trong": {
"en": "Inside",
"th": "ด้านใน",
"es": "Interior"
},
"Bóng đổ": {
"en": "Drop shadow",
"th": "เงาตกกระทบ",
"es": "Sombra paralela"
},
"Góc (°)": {
"en": "Angle (°)",
"th": "มุม (°)",
"es": "Ángulo (°)"
},
"Khoảng cách": {
"en": "Distance",
"th": "ระยะ",
"es": "Distancia"
},
"Độ nhòe": {
"en": "Blur",
"th": "ความเบลอ",
"es": "Desenfoque"
},
"Độ mờ (%)": {
"en": "Opacity (%)",
"th": "ความทึบ (%)",
"es": "Opacidad (%)"
},
"Thêm viền & bóng": {
"en": "Add stroke & shadow",
"th": "เพิ่มเส้นขอบและเงา",
"es": "Añadir trazo y sombra"
},
"Nhật ký": {
"en": "Log",
"th": "บันทึก",
"es": "Registro"
},
"Sao chép": {
"en": "Copy",
"th": "คัดลอก",
"es": "Copiar"
},
"Xóa": {
"en": "Clear",
"th": "ล้าง",
"es": "Borrar"
},
"Áp dụng trame": {
"en": "Apply halftone",
"th": "ใช้ฮาล์ฟโทน",
"es": "Aplicar trama"
},
"Sẵn sàng": {
"en": "Ready",
"th": "พร้อม",
"es": "Listo"
},
"Đọc lại thông tin file đang mở": {
"en": "Re-read the open file",
"th": "อ่านข้อมูลไฟล์ที่เปิดอยู่อีกครั้ง",
"es": "Volver a leer el archivo abierto"
},
"Mở ô xem trước thành panel riêng": {
"en": "Open the preview as a separate panel",
"th": "เปิดตัวอย่างเป็นพาเนลแยก",
"es": "Abrir la vista previa en un panel aparte"
},
"Cao: vùng tối in bằng mực đen, màu sạch và tiết kiệm. Thấp: vùng tối tạo bằng chồng 3 màu, rực hơn.": {
"en": "High: dark areas use black ink, cleaner colors and less ink. Low: dark areas are built from 3 overlapping colors, more vivid.",
"th": "สูง: บริเวณมืดใช้หมึกดำ สีสะอาดและประหยัดหมึก ต่ำ: บริเวณมืดเกิดจากการซ้อน 3 สี สีสดกว่า",
"es": "Alto: las zonas oscuras usan tinta negra, colores más limpios y menos tinta. Bajo: las zonas oscuras se forman con 3 colores superpuestos, más vivos."
},
"Chấm nhỏ hơn mức này bột keo khó bám, chấm sẽ bị rơi khi ép.": {
"en": "Dots smaller than this won't hold the adhesive powder and fall off when pressed.",
"th": "จุดที่เล็กกว่านี้ผงกาวเกาะได้ยาก จะหลุดตอนรีด",
"es": "Los puntos más pequeños no retienen el polvo adhesivo y se caen al prensar."
},
"Vùng đậm hơn mức này được tô đặc, tránh lỗ li ti.": {
"en": "Areas darker than this are printed solid, avoiding tiny pinholes.",
"th": "บริเวณที่เข้มกว่านี้จะพิมพ์ทึบ เพื่อไม่ให้มีรูเล็ก ๆ",
"es": "Las zonas más oscuras que esto se imprimen sólidas, sin microagujeros."
},
"Mở nhật ký": {
"en": "Open log",
"th": "เปิดบันทึก",
"es": "Abrir registro"
},
"Chấm quá nhỏ để thấy đúng ở chế độ toàn hình. Chọn <b>Cận cảnh 100%</b> để xem đúng như bản in.": {
"en": "Dots are too small to show correctly in full view. Choose <b>100% close-up</b> to see it exactly as printed.",
"th": "จุดเล็กเกินไปจึงแสดงไม่ถูกต้องในโหมดเต็มภาพ เลือก <b>ซูม 100%</b> เพื่อดูให้ตรงกับงานพิมพ์จริง",
"es": "Los puntos son demasiado pequeños para la vista completa. Elige <b>Detalle 100%</b> para verlo tal como se imprimirá."
},
"Mở panel <b>NOVA Trame</b> và bấm <b>Xem trước</b>.<br>Ảnh sẽ hiện ở đây và cập nhật khi bạn chỉnh thông số.": {
"en": "Open the <b>NOVA Trame</b> panel and click <b>Preview</b>.<br>The image will appear here and update as you adjust settings.",
"th": "เปิดพาเนล <b>NOVA Trame</b> แล้วกด <b>ดูตัวอย่าง</b><br>ภาพจะแสดงที่นี่และอัปเดตเมื่อคุณปรับค่า",
"es": "Abre el panel <b>NOVA Trame</b> y pulsa <b>Vista previa</b>.<br>La imagen aparecerá aquí y se actualizará al cambiar los ajustes."
},
"Đang chờ panel NOVA Trame…": {
"en": "Waiting for the NOVA Trame panel…",
"th": "กำลังรอพาเนล NOVA Trame…",
"es": "Esperando el panel NOVA Trame…"
},
"Vừa": {
"en": "Fit",
"th": "พอดี",
"es": "Ajustar"
},
"Lấy lại hình từ Photoshop": {
"en": "Grab the image again from Photoshop",
"th": "ดึงภาพจาก Photoshop อีกครั้ง",
"es": "Volver a tomar la imagen de Photoshop"
},
"Phóng ảnh trong panel": {
"en": "Zoom the image in the panel",
"th": "ซูมภาพในพาเนล",
"es": "Ampliar la imagen en el panel"
},
"Xem trước trame": {
"en": "Halftone preview",
"th": "ตัวอย่างฮาล์ฟโทน",
"es": "Vista previa de la trama"
},
"chưa rõ khổ (mặc định 30×40)": {
"en": "unknown size (default 30×40)",
"th": "ไม่ทราบขนาด (ค่าเริ่มต้น 30×40)",
"es": "tamaño desconocido (por defecto 30×40)"
},
"Gợi ý DTF cho khổ {0}: {1} LPI": {
"en": "DTF suggestion for {0}: {1} LPI",
"th": "ค่าแนะนำ DTF สำหรับขนาด {0}: {1} LPI",
"es": "Sugerencia DTF para {0}: {1} LPI"
},
" (đã tính theo kiểu này)": {
"en": " (adjusted for this style)",
"th": " (ปรับตามรูปแบบนี้แล้ว)",
"es": " (ajustado a este estilo)"
},
"Lỗi: ": {
"en": "Error: ",
"th": "ข้อผิดพลาด: ",
"es": "Error: "
},
"Panel không chạy trong Photoshop.": {
"en": "The panel is not running inside Photoshop.",
"th": "พาเนลไม่ได้ทำงานใน Photoshop",
"es": "El panel no se está ejecutando en Photoshop."
},
"Không nạp được host.jsx ({0})": {
"en": "Could not load host.jsx ({0})",
"th": "โหลด host.jsx ไม่ได้ ({0})",
"es": "No se pudo cargar host.jsx ({0})"
},
"Photoshop không chạy được lệnh {0} ({1})": {
"en": "Photoshop could not run command {0} ({1})",
"th": "Photoshop ไม่สามารถรันคำสั่ง {0} ({1})",
"es": "Photoshop no pudo ejecutar el comando {0} ({1})"
},
"Đang xử lý…": {
"en": "Processing…",
"th": "กำลังประมวลผล…",
"es": "Procesando…"
},
"Xong: {0} ({1} giây)": {
"en": "Done: {0} ({1} s)",
"th": "เสร็จ: {0} ({1} วินาที)",
"es": "Listo: {0} ({1} s)"
},
"Không có quyền đọc file (cep.fs).": {
"en": "No permission to read files (cep.fs).",
"th": "ไม่มีสิทธิ์อ่านไฟล์ (cep.fs)",
"es": "Sin permiso para leer archivos (cep.fs)."
},
"Không đọc được file tạm (mã {0}): {1}": {
"en": "Could not read temp file (code {0}): {1}",
"th": "อ่านไฟล์ชั่วคราวไม่ได้ (รหัส {0}): {1}",
"es": "No se pudo leer el archivo temporal (código {0}): {1}"
},
"Không đọc được pixel: {0}": {
"en": "Could not read pixels: {0}",
"th": "อ่านพิกเซลไม่ได้: {0}",
"es": "No se pudieron leer los píxeles: {0}"
},
"Không giải mã được ảnh PNG tạm.": {
"en": "Could not decode the temporary PNG.",
"th": "ถอดรหัสไฟล์ PNG ชั่วคราวไม่ได้",
"es": "No se pudo decodificar el PNG temporal."
},
"Không ghi được file tạm (mã {0}).": {
"en": "Could not write temp file (code {0}).",
"th": "เขียนไฟล์ชั่วคราวไม่ได้ (รหัส {0})",
"es": "No se pudo escribir el archivo temporal (código {0})."
},
"Màu mực không hợp lệ: {0}": {
"en": "Invalid ink color: {0}",
"th": "สีหมึกไม่ถูกต้อง: {0}",
"es": "Color de tinta no válido: {0}"
},
"Hãy bật ít nhất một màu mực.": {
"en": "Turn on at least one ink color.",
"th": "เปิดสีหมึกอย่างน้อยหนึ่งสี",
"es": "Activa al menos un color de tinta."
},
"Áp dụng {0}": {
"en": "Apply {0}",
"th": "ใช้ {0}",
"es": "Aplicar {0}"
},
"Xuất ảnh đầy đủ từ Photoshop...": {
"en": "Exporting the full image from Photoshop...",
"th": "กำลังส่งออกภาพเต็มจาก Photoshop...",
"es": "Exportando la imagen completa desde Photoshop..."
},
"không xuất được ảnh": {
"en": "could not export the image",
"th": "ส่งออกภาพไม่ได้",
"es": "no se pudo exportar la imagen"
},
"ảnh quá lớn (giới hạn 30 triệu pixel). Hãy giảm kích thước hoặc DPI.": {
"en": "image too large (30 megapixel limit). Reduce the size or DPI.",
"th": "ภาพใหญ่เกินไป (จำกัด 30 ล้านพิกเซล) ลดขนาดหรือ DPI",
"es": "imagen demasiado grande (límite de 30 megapíxeles). Reduce el tamaño o los DPI."
},
"Tạo hiệu ứng {0} ({1}×{2} px)...": {
"en": "Creating effect {0} ({1}×{2} px)...",
"th": "กำลังสร้างเอฟเฟกต์ {0} ({1}×{2} px)...",
"es": "Creando efecto {0} ({1}×{2} px)..."
},
"Gửi kết quả về Photoshop...": {
"en": "Sending the result to Photoshop...",
"th": "กำลังส่งผลลัพธ์ไปยัง Photoshop...",
"es": "Enviando el resultado a Photoshop..."
},
"xem nhật ký ở trên": {
"en": "see the log above",
"th": "ดูบันทึกด้านบน",
"es": "consulta el registro de arriba"
},
"không xuất được ảnh xem trước": {
"en": "could not export the preview image",
"th": "ส่งออกภาพตัวอย่างไม่ได้",
"es": "no se pudo exportar la vista previa"
},
"Xem trước: {0}": {
"en": "Preview: {0}",
"th": "ตัวอย่าง: {0}",
"es": "Vista previa: {0}"
},
"Áp dụng trame {0}": {
"en": "Apply halftone {0}",
"th": "ใช้ฮาล์ฟโทน {0}",
"es": "Aplicar trama {0}"
},
"ảnh {0}×{1} px quá lớn (giới hạn 40 triệu pixel). Hãy giảm kích thước hoặc DPI.": {
"en": "image {0}×{1} px is too large (40 megapixel limit). Reduce the size or DPI.",
"th": "ภาพ {0}×{1} px ใหญ่เกินไป (จำกัด 40 ล้านพิกเซล) ลดขนาดหรือ DPI",
"es": "la imagen de {0}×{1} px es demasiado grande (límite de 40 megapíxeles). Reduce el tamaño o los DPI."
},
"Kết xuất trame {0} ({1}×{2} px)...": {
"en": "Rendering halftone {0} ({1}×{2} px)...",
"th": "กำลังเรนเดอร์ฮาล์ฟโทน {0} ({1}×{2} px)...",
"es": "Generando trama {0} ({1}×{2} px)..."
},
"ảnh {0}×{1} px quá lớn cho trame màu (giới hạn 30 triệu pixel). Hãy giảm kích thước hoặc DPI.": {
"en": "image {0}×{1} px is too large for color halftone (30 megapixel limit). Reduce the size or DPI.",
"th": "ภาพ {0}×{1} px ใหญ่เกินไปสำหรับฮาล์ฟโทนสี (จำกัด 30 ล้านพิกเซล) ลดขนาดหรือ DPI",
"es": "la imagen de {0}×{1} px es demasiado grande para la trama a color (límite de 30 megapíxeles). Reduce el tamaño o los DPI."
},
"Tách 4 màu và tạo trame {0} ({1}×{2} px)...": {
"en": "Splitting into 4 colors and creating halftone {0} ({1}×{2} px)...",
"th": "กำลังแยก 4 สีและสร้างฮาล์ฟโทน {0} ({1}×{2} px)...",
"es": "Separando en 4 colores y creando la trama {0} ({1}×{2} px)..."
},
"ảnh {0}×{1} px quá lớn cho tách màu (giới hạn 30 triệu pixel). Hãy giảm kích thước hoặc DPI.": {
"en": "image {0}×{1} px is too large for color separation (30 megapixel limit). Reduce the size or DPI.",
"th": "ภาพ {0}×{1} px ใหญ่เกินไปสำหรับการแยกสี (จำกัด 30 ล้านพิกเซล) ลดขนาดหรือ DPI",
"es": "la imagen de {0}×{1} px es demasiado grande para la separación de color (límite de 30 megapíxeles). Reduce el tamaño o los DPI."
},
"Tách màu spot (bảng màu từ bản xem trước)...": {
"en": "Spot color separation (palette from the preview)...",
"th": "กำลังแยกสีสปอต (จานสีจากตัวอย่าง)...",
"es": "Separación de tintas planas (paleta de la vista previa)..."
},
"Tách màu spot (tự tìm {0} màu)...": {
"en": "Spot color separation (finding {0} colors)...",
"th": "กำลังแยกสีสปอต (หา {0} สีอัตโนมัติ)...",
"es": "Separación de tintas planas (buscando {0} colores)..."
},
"Bảng màu: {0}": {
"en": "Palette: {0}",
"th": "จานสี: {0}",
"es": "Paleta: {0}"
},
"{0} kiểu": {
"en": "{0} styles",
"th": "{0} รูปแบบ",
"es": "{0} estilos"
},
"Chưa mở file nào. LPI đang theo khổ mặc định 30×40 cm.": {
"en": "No file open. LPI follows the default 30×40 cm size.",
"th": "ยังไม่มีไฟล์เปิดอยู่ LPI ใช้ขนาดเริ่มต้น 30×40 ซม.",
"es": "No hay archivo abierto. El LPI sigue el tamaño por defecto de 30×40 cm."
},
"Đã sao chép nhật ký": {
"en": "Log copied",
"th": "คัดลอกบันทึกแล้ว",
"es": "Registro copiado"
},
"Hãy nhấn Ctrl+C để sao chép": {
"en": "Press Ctrl+C to copy",
"th": "กด Ctrl+C เพื่อคัดลอก",
"es": "Pulsa Ctrl+C para copiar"
},
"Trame DTF cho khổ này sẽ dùng {0} LPI": {
"en": "DTF halftone for this size will use {0} LPI",
"th": "ฮาล์ฟโทน DTF สำหรับขนาดนี้จะใช้ {0} LPI",
"es": "La trama DTF para este tamaño usará {0} LPI"
},
"Mở bằng menu Window › Extensions › NOVA Trame Preview": {
"en": "Open it from Window › Extensions › NOVA Trame Preview",
"th": "เปิดจากเมนู Window › Extensions › NOVA Trame Preview",
"es": "Ábrelo desde Ventana › Extensiones › NOVA Trame Preview"
},
"Đã đổi bố cục. Bấm Xem trước để xem.": {
"en": "Layout shuffled. Click Preview to see it.",
"th": "สุ่มเลย์เอาต์ใหม่แล้ว กดดูตัวอย่างเพื่อดู",
"es": "Diseño cambiado. Pulsa Vista previa para verlo."
},
"Kiểm tra file": {
"en": "Check file",
"th": "ตรวจไฟล์",
"es": "Comprobar archivo"
},
"xem nhật ký": {
"en": "see the log",
"th": "ดูบันทึก",
"es": "consulta el registro"
},
"Plugin đã nạp. {0}": {
"en": "Plugin loaded. {0}",
"th": "โหลดปลั๊กอินแล้ว {0}",
"es": "Plugin cargado. {0}"
},
"Không đọc được ảnh xem trước.": {
"en": "Could not read the preview image.",
"th": "อ่านภาพตัวอย่างไม่ได้",
"es": "No se pudo leer la imagen de vista previa."
},
"Đang lấy hình…": {
"en": "Grabbing image…",
"th": "กำลังดึงภาพ…",
"es": "Tomando la imagen…"
},
"Ô chấm {0} mm · chấm nhỏ hơn {1}% sẽ được nâng/bỏ · từ {2}% tô đặc": {
"en": "Dot cell {0} mm · dots under {1}% are raised/removed · solid from {2}%",
"th": "ช่องจุด {0} มม. · จุดที่เล็กกว่า {1}% จะถูกขยาย/ตัดออก · ทึบตั้งแต่ {2}%",
"es": "Celda {0} mm · los puntos bajo {1}% se suben/eliminan · sólido desde {2}%"
},
"Ô chấm {0} mm · nét nhỏ hơn {1}% sẽ được nâng/bỏ · từ {2}% tô đặc": {
"en": "Dot cell {0} mm · lines under {1}% are raised/removed · solid from {2}%",
"th": "ช่องจุด {0} มม. · เส้นที่บางกว่า {1}% จะถูกขยาย/ตัดออก · ทึบตั้งแต่ {2}%",
"es": "Celda {0} mm · las líneas bajo {1}% se suben/eliminan · sólido desde {2}%"
},
"Phần sáng của hình in thành chấm, phần tối để lộ màu áo đen. Có lớp trắng lót bên dưới.": {
"en": "Light parts of the image become dots, dark parts show the black shirt. A white underbase is added underneath.",
"th": "ส่วนสว่างของภาพกลายเป็นจุด ส่วนมืดเผยสีเสื้อดำ มีชั้นขาวรองด้านล่าง",
"es": "Las partes claras se convierten en puntos y las oscuras dejan ver la camiseta negra. Se añade una base blanca debajo."
},
"Phần tối của hình in thành chấm, phần sáng để lộ màu áo trắng. Phần trong suốt không in.": {
"en": "Dark parts of the image become dots, light parts show the white shirt. Transparent areas are not printed.",
"th": "ส่วนมืดของภาพกลายเป็นจุด ส่วนสว่างเผยสีเสื้อขาว ส่วนโปร่งใสไม่พิมพ์",
"es": "Las partes oscuras se convierten en puntos y las claras dejan ver la camiseta blanca. Las zonas transparentes no se imprimen."
},
"Cơ bản": {
"en": "Basic",
"th": "พื้นฐาน",
"es": "Básico"
},
"Chấm in truyền thống và hạt": {
"en": "Classic print dots and grains",
"th": "จุดพิมพ์แบบดั้งเดิมและเม็ด",
"es": "Puntos clásicos y granos"
},
"Streetwear / grunge": {
"en": "Streetwear / grunge",
"th": "สตรีทแวร์ / กรันจ์",
"es": "Streetwear / grunge"
},
"Hình chấm": {
"en": "Shapes",
"th": "รูปจุด",
"es": "Formas"
},
"Hình chấm đặc biệt": {
"en": "Special dot shapes",
"th": "รูปทรงจุดพิเศษ",
"es": "Formas de punto especiales"
},
"Hoa văn": {
"en": "Patterns",
"th": "ลวดลาย",
"es": "Patrones"
},
"Hoa văn đường nét": {
"en": "Line patterns",
"th": "ลวดลายเส้น",
"es": "Patrones de líneas"
},
"Xu hướng": {
"en": "Trends",
"th": "เทรนด์",
"es": "Tendencias"
},
"Hiệu ứng áo thun đang thịnh hành": {
"en": "Trending T-shirt effects",
"th": "เอฟเฟกต์เสื้อยืดที่กำลังนิยม",
"es": "Efectos de camiseta en tendencia"
},
"Màu: 4 màu CMYK và màu spot": {
"en": "Color: 4-color CMYK and spot colors",
"th": "สี: CMYK 4 สีและสีสปอต",
"es": "Color: CMYK de 4 colores y tintas planas"
},
"Cỡ hạt (LPI)": {
"en": "Grain size (LPI)",
"th": "ขนาดเม็ด (LPI)",
"es": "Tamaño de grano (LPI)"
},
"Cỡ sạn (LPI)": {
"en": "Grit size (LPI)",
"th": "ขนาดเม็ดหยาบ (LPI)",
"es": "Tamaño del grumo (LPI)"
},
"Độ mảnh (LPI)": {
"en": "Fineness (LPI)",
"th": "ความละเอียด (LPI)",
"es": "Finura (LPI)"
},
"Mật độ (LPI)": {
"en": "Density (LPI)",
"th": "ความหนาแน่น (LPI)",
"es": "Densidad (LPI)"
},
"Độ dày gạch (LPI)": {
"en": "Hatch thickness (LPI)",
"th": "ความหนาเส้นแรเงา (LPI)",
"es": "Grosor del rayado (LPI)"
},
"Độ dày sọc (LPI)": {
"en": "Stripe thickness (LPI)",
"th": "ความหนาแถบ (LPI)",
"es": "Grosor de franja (LPI)"
},
"Hướng tan": {
"en": "Fade direction",
"th": "ทิศทางการจาง",
"es": "Dirección"
},
"Cỡ mảng nứt (LPI)": {
"en": "Crack size (LPI)",
"th": "ขนาดรอยแตก (LPI)",
"es": "Tamaño de grieta (LPI)"
},
"Cỡ ô (LPI)": {
"en": "Cell size (LPI)",
"th": "ขนาดช่อง (LPI)",
"es": "Tamaño de celda (LPI)"
},
"Cỡ chữ (LPI)": {
"en": "Character size (LPI)",
"th": "ขนาดตัวอักษร (LPI)",
"es": "Tamaño de carácter (LPI)"
},
"Độ tỏa (LPI)": {
"en": "Glow (LPI)",
"th": "การเรืองแสง (LPI)",
"es": "Resplandor (LPI)"
},
"Cỡ bụi sơn (LPI)": {
"en": "Spray size (LPI)",
"th": "ขนาดละอองสี (LPI)",
"es": "Tamaño del spray (LPI)"
},
"Vintage: ảnh cũ, in cũ, áo cũ": {
"en": "Vintage: old photos, old prints, old tees",
"th": "วินเทจ: ภาพเก่า งานพิมพ์เก่า เสื้อเก่า",
"es": "Vintage: fotos antiguas, impresiones antiguas, camisetas gastadas"
},
"Cỡ mảng mòn (LPI)": {
"en": "Wear patch size (LPI)",
"th": "ขนาดรอยสึก (LPI)",
"es": "Tamaño del desgaste (LPI)"
},
"Vintage": {
"en": "Vintage",
"th": "วินเทจ",
"es": "Vintage"
},
"Giấy phép": {
"en": "License",
"th": "ใบอนุญาต",
"es": "Licencia"
},
"Nhập key hoặc dùng thử 7 ngày để mở khóa.": {
"en": "Enter a key or start a 7-day trial to unlock.",
"th": "กรอกคีย์หรือทดลองใช้ 7 วันเพื่อปลดล็อก",
"es": "Introduce la clave o prueba 7 días para desbloquear."
},
"Đã kích hoạt": {
"en": "Activated",
"th": "เปิดใช้งานแล้ว",
"es": "Activada"
},
"Gói {0} · hết hạn {1}": {
"en": "{0} plan · expires {1}",
"th": "แพ็กเกจ {0} · หมดอายุ {1}",
"es": "Plan {0} · vence {1}"
},
"Ngoại tuyến: đang dùng bản đã lưu tối đa 24 giờ.": {
"en": "Offline: using the saved copy for up to 24 hours.",
"th": "ออฟไลน์: ใช้ข้อมูลที่บันทึกไว้ได้สูงสุด 24 ชั่วโมง",
"es": "Sin conexión: se usa la copia guardada durante un máximo de 24 horas."
},
"Hết hạn": {
"en": "Expired",
"th": "หมดอายุ",
"es": "Vencida"
},
"License đã hết hạn {0}.": {
"en": "The license expired on {0}.",
"th": "license หมดอายุเมื่อ {0}",
"es": "La licencia venció el {0}."
},
"Đã thu hồi": {
"en": "Revoked",
"th": "ถูกเพิกถอนแล้ว",
"es": "Revocada"
},
"License này đã bị thu hồi.": {
"en": "This license has been revoked.",
"th": "license นี้ถูกเพิกถอนแล้ว",
"es": "Esta licencia ha sido revocada."
},
"Ngoại tuyến": {
"en": "Offline",
"th": "ออฟไลน์",
"es": "Sin conexión"
},
"Không kết nối được máy chủ license.": {
"en": "Could not reach the license server.",
"th": "เชื่อมต่อเซิร์ฟเวอร์ license ไม่ได้",
"es": "No se pudo conectar con el servidor de licencias."
},
"Chưa kích hoạt": {
"en": "Not activated",
"th": "ยังไม่เปิดใช้งาน",
"es": "Sin activar"
},
"Key không hợp lệ hoặc không thuộc máy này.": {
"en": "The key is invalid or not tied to this computer.",
"th": "คีย์ไม่ถูกต้องหรือไม่ได้ผูกกับเครื่องนี้",
"es": "La clave no es válida o no pertenece a este equipo."
},
"Kích hoạt": {
"en": "Activate",
"th": "เปิดใช้งาน",
"es": "Activar"
},
"Dùng thử 7 ngày": {
"en": "7-day trial",
"th": "ทดลองใช้ 7 วัน",
"es": "Prueba 7 días"
},
"Gia hạn license": {
"en": "Renew license",
"th": "ต่ออายุ license",
"es": "Renovar licencia"
},
"Dùng thử": {
"en": "Trial",
"th": "ทดลองใช้",
"es": "Prueba"
},
"Cần kích hoạt license để áp dụng.": {
"en": "Activate the license to apply.",
"th": "ต้องเปิดใช้งาน license ก่อนจึงจะใช้งานได้",
"es": "Activa la licencia para aplicar."
},
"Key này đã kích hoạt trên máy khác.": {
"en": "This key is already activated on another computer.",
"th": "คีย์นี้ถูกเปิดใช้งานบนเครื่องอื่นแล้ว",
"es": "Esta clave ya está activada en otro equipo."
},
"Máy này đã dùng thử 7 ngày.": {
"en": "This computer already used the 7-day trial.",
"th": "เครื่องนี้เคยทดลองใช้ 7 วันแล้ว",
"es": "Este equipo ya usó la prueba de 7 días."
},
"Key không đúng định dạng.": {
"en": "The key format is not valid.",
"th": "รูปแบบคีย์ไม่ถูกต้อง",
"es": "El formato de la clave no es correcto."
},
"Không kích hoạt được license.": {
"en": "The license could not be activated.",
"th": "เปิดใช้งาน license ไม่สำเร็จ",
"es": "No se pudo activar la licencia."
},
"Key hết hạn hoặc không hợp lệ.": {
"en": "The key expired or is not valid.",
"th": "คีย์หมดอายุหรือไม่ถูกต้อง",
"es": "La clave venció o no es válida."
},
"Key không hợp lệ hoặc đã hết hạn.": {
"en": "The key is invalid or has expired.",
"th": "คีย์ไม่ถูกต้องหรือหมดอายุแล้ว",
"es": "La clave no es válida o ha vencido."
},
"Kích hoạt ngoại tuyến (khi bị chặn mạng)": {
"en": "Offline activation (when the network is blocked)",
"th": "เปิดใช้งานออฟไลน์ (เมื่อเครือข่ายถูกบล็อก)",
"es": "Activación sin conexión (cuando la red está bloqueada)"
},
"Dùng khi panel không kết nối được máy chủ. Mở trang kích hoạt trên trình duyệt, nhập key và mã máy bên dưới, rồi dán mã nhận được vào ô cuối.": {
"en": "Use this when the panel can't reach the server. Open the activation page in a browser, enter your key and the device code below, then paste the returned code into the last box.",
"th": "ใช้เมื่อพาเนลเชื่อมต่อเซิร์ฟเวอร์ไม่ได้ เปิดหน้าเปิดใช้งานในเบราว์เซอร์ กรอกคีย์และรหัสเครื่องด้านล่าง แล้ววางรหัสที่ได้ลงในช่องสุดท้าย",
"es": "Úsalo cuando el panel no pueda conectar con el servidor. Abre la página de activación en el navegador, introduce tu clave y el código del equipo, y pega el código recibido en el último campo."
},
"Mã máy (gửi cho trang kích hoạt)": {
"en": "Device code (send it to the activation page)",
"th": "รหัสเครื่อง (ส่งให้หน้าเปิดใช้งาน)",
"es": "Código del equipo (para la página de activación)"
},
"Chép": {
"en": "Copy",
"th": "คัดลอก",
"es": "Copiar"
},
"Mở trang kích hoạt": {
"en": "Open the activation page",
"th": "เปิดหน้าเปิดใช้งาน",
"es": "Abrir la página de activación"
},
"Dán mã kích hoạt vào đây": {
"en": "Paste the activation code here",
"th": "วางรหัสเปิดใช้งานที่นี่",
"es": "Pega aquí el código de activación"
},
"Áp dụng mã": {
"en": "Apply code",
"th": "ใช้รหัส",
"es": "Aplicar código"
},
"Mã này dành cho máy khác.": {
"en": "This code is for a different computer.",
"th": "รหัสนี้สำหรับเครื่องอื่น",
"es": "Este código es para otro equipo."
},
"Mã không hợp lệ.": {
"en": "The code is not valid.",
"th": "รหัสไม่ถูกต้อง",
"es": "El código no es válido."
},
"Không xác thực được mã trên máy này.": {
"en": "The code could not be verified on this computer.",
"th": "ตรวจสอบรหัสบนเครื่องนี้ไม่ได้",
"es": "No se pudo verificar el código en este equipo."
},
"Mã kích hoạt sai định dạng.": {
"en": "The activation code format is wrong.",
"th": "รูปแบบรหัสเปิดใช้งานไม่ถูกต้อง",
"es": "El formato del código de activación es incorrecto."
},
"Mã kích hoạt đã hết hạn.": {
"en": "The activation code has expired.",
"th": "รหัสเปิดใช้งานหมดอายุแล้ว",
"es": "El código de activación ha caducado."
},
"Mua & kích hoạt": {
"en": "Buy & activate",
"th": "ซื้อและเปิดใช้งาน",
"es": "Comprar y activar"
},
"3 · Giấy phép": {
"en": "3 · License",
"th": "3 · ใบอนุญาต",
"es": "3 · Licencia"
},
"Đang kết nối máy chủ license...": {
"en": "Connecting to the license server...",
"th": "กำลังเชื่อมต่อเซิร์ฟเวอร์ license...",
"es": "Conectando con el servidor de licencias..."
},
"Chấm tròn": {
"en": "Round dot",
"th": "จุดกลม",
"es": "Punto redondo"
},
"Lưới chấm tròn đều. Kiểu trame phổ biến nhất, chuyển sắc tự nhiên.": {
"en": "Even grid of round dots. The most popular halftone, with natural tonal transitions.",
"th": "จุดกลมเรียงเป็นกริดสม่ำเสมอ ฮาล์ฟโทนที่นิยมที่สุด ไล่โทนเป็นธรรมชาติ",
"es": "Retícula uniforme de puntos redondos. La trama más popular, con transiciones naturales."
},
"Ellipse": {
"en": "Ellipse",
"th": "วงรี",
"es": "Elipse"
},
"Chấm dẹt, nối thành chuỗi ở vùng trung tính. Chuyển sắc mềm hơn chấm tròn.": {
"en": "Elongated dots that chain together in midtones. Softer transitions than round dots.",
"th": "จุดรีที่ต่อกันเป็นสายในโทนกลาง ไล่โทนนุ่มกว่าจุดกลม",
"es": "Puntos alargados que se encadenan en los medios tonos. Transiciones más suaves que el punto redondo."
},
"Đường kẻ": {
"en": "Line",
"th": "เส้นขนาน",
"es": "Línea"
},
"Vạch song song dày mỏng theo độ đậm, xoay được góc. Hợp hiệu ứng khắc, vintage.": {
"en": "Parallel lines that thicken with darkness, with adjustable angle. Great for engraved or vintage looks.",
"th": "เส้นขนานหนาบางตามความเข้ม ปรับมุมได้ เหมาะกับลุคแกะสลักหรือวินเทจ",
"es": "Líneas paralelas que engrosan con la oscuridad, con ángulo ajustable. Ideal para aspecto grabado o vintage."
},
"Chấm vuông": {
"en": "Square dot",
"th": "จุดสี่เหลี่ยม",
"es": "Punto cuadrado"
},
"Chấm vuông, nét gọn và kỹ thuật.": {
"en": "Square dots, clean and technical.",
"th": "จุดสี่เหลี่ยม คมและดูเป็นเทคนิค",
"es": "Puntos cuadrados, limpios y técnicos."
},
"Chấm thoi": {
"en": "Diamond dot",
"th": "จุดข้าวหลามตัด",
"es": "Punto rombo"
},
"Chấm hình kim cương, góc cạnh, nối thành bàn cờ ở vùng 50%.": {
"en": "Diamond-shaped dots that form a checkerboard at 50%.",
"th": "จุดทรงข้าวหลามตัด เชื่อมเป็นตารางหมากรุกที่ 50%",
"es": "Puntos en forma de rombo que forman un tablero a 50%."
},
"Chữ thập": {
"en": "Cross",
"th": "กากบาท",
"es": "Cruz"
},
"Dấu cộng lặp lại, tạo kết cấu lưới đặc biệt.": {
"en": "Repeating plus signs that create a distinctive grid texture.",
"th": "เครื่องหมายบวกซ้ำ ๆ สร้างพื้นผิวกริดที่โดดเด่น",
"es": "Signos más repetidos que crean una textura de retícula especial."
},
"Sọc ngang": {
"en": "Horizontal stripes",
"th": "แถบแนวนอน",
"es": "Franjas horizontales"
},
"Vạch ngang đều, dày mỏng theo độ đậm.": {
"en": "Even horizontal lines that thicken with darkness.",
"th": "เส้นแนวนอนสม่ำเสมอ หนาบางตามความเข้ม",
"es": "Líneas horizontales uniformes que engrosan con la oscuridad."
},
"Sọc dọc": {
"en": "Vertical stripes",
"th": "แถบแนวตั้ง",
"es": "Franjas verticales"
},
"Vạch dọc đều, dày mỏng theo độ đậm.": {
"en": "Even vertical lines that thicken with darkness.",
"th": "เส้นแนวตั้งสม่ำเสมอ หนาบางตามความเข้ม",
"es": "Líneas verticales uniformes que engrosan con la oscuridad."
},
"Sọc chéo": {
"en": "Diagonal stripes",
"th": "แถบเฉียง",
"es": "Franjas diagonales"
},
"Vạch chéo 135°, tạo cảm giác chuyển động.": {
"en": "135° diagonal lines that suggest motion.",
"th": "เส้นเฉียง 135° ให้ความรู้สึกเคลื่อนไหว",
"es": "Líneas diagonales a 135° que sugieren movimiento."
},
"Hạt lan mực": {
"en": "Error diffusion",
"th": "กระจายความคลาดเคลื่อน",
"es": "Difusión de error"
},
"Khuếch tán sai số của Photoshop. Hạt mịn, giữ chi tiết tốt.": {
"en": "Floyd–Steinberg error diffusion. Fine grain that keeps detail well.",
"th": "การกระจายความคลาดเคลื่อนแบบ Floyd–Steinberg เม็ดละเอียด เก็บรายละเอียดได้ดี",
"es": "Difusión de error Floyd–Steinberg. Grano fino que conserva bien el detalle."
},
"Atkinson": {
"en": "Atkinson",
"th": "Atkinson",
"es": "Atkinson"
},
"Hạt sáng, tương phản nhẹ, kiểu máy Mac cổ. Vùng rất tối vẫn giữ lấm tấm trắng.": {
"en": "Bright, slightly contrasty grain like early Macs. Very dark areas keep white specks.",
"th": "เม็ดสว่าง คอนทราสต์เล็กน้อยแบบเครื่อง Mac ยุคแรก บริเวณที่มืดมากยังมีจุดขาวประปราย",
"es": "Grano claro y algo contrastado como los primeros Mac. Las zonas muy oscuras conservan motas blancas."
},
"Stucki": {
"en": "Stucki",
"th": "Stucki",
"es": "Stucki"
},
"Lan mực rộng, chi tiết cao, hạt đều hơn Floyd–Steinberg.": {
"en": "Wide error spread with high detail; more even grain than Floyd–Steinberg.",
"th": "กระจายกว้าง รายละเอียดสูง เม็ดสม่ำเสมอกว่า Floyd–Steinberg",
"es": "Difusión amplia con mucho detalle; grano más uniforme que Floyd–Steinberg."
},
"Jarvis": {
"en": "Jarvis",
"th": "Jarvis",
"es": "Jarvis"
},
"Lan mực rộng nhất, bóng đổ mượt, hợp nền chuyển sắc lớn.": {
"en": "The widest error spread, smooth shading, good for large gradients.",
"th": "กระจายกว้างที่สุด เงานุ่ม เหมาะกับพื้นไล่โทนขนาดใหญ่",
"es": "La difusión más amplia, sombreado suave, ideal para degradados grandes."
},
"Bayer 4×4": {
"en": "Bayer 4×4",
"th": "Bayer 4×4",
"es": "Bayer 4×4"
},
"Ma trận lặp 4×4, hạt to kiểu retro game.": {
"en": "4×4 repeating matrix with chunky retro-game grain.",
"th": "เมทริกซ์ซ้ำ 4×4 เม็ดใหญ่แบบเกมย้อนยุค",
"es": "Matriz repetida 4×4 con grano grueso de videojuego retro."
},
"Bayer 8×8": {
"en": "Bayer 8×8",
"th": "Bayer 8×8",
"es": "Bayer 8×8"
},
"Ma trận lặp 8×8 của Photoshop, mịn hơn 4×4.": {
"en": "8×8 repeating matrix, finer than 4×4.",
"th": "เมทริกซ์ซ้ำ 8×8 ละเอียดกว่า 4×4",
"es": "Matriz repetida 8×8, más fina que la 4×4."
},
"Hạt ngẫu nhiên": {
"en": "Random grain",
"th": "เม็ดสุ่ม",
"es": "Grano aleatorio"
},
"Hạt phân bố ngẫu nhiên (FM), vân nhám kiểu grunge.": {
"en": "Randomly scattered grain (FM), with a rough grunge texture.",
"th": "เม็ดกระจายแบบสุ่ม (FM) ผิวหยาบแบบกรันจ์",
"es": "Grano disperso al azar (FM), con textura áspera tipo grunge."
},
"Ngưỡng": {
"en": "Threshold",
"th": "ขาวดำ",
"es": "Umbral"
},
"Chỉ đen và trắng, không có chấm. Dùng cho logo, chữ, nét đơn giản.": {
"en": "Pure black and white, no dots. For logos, text and simple line art.",
"th": "ขาวดำล้วน ไม่มีจุด ใช้กับโลโก้ ตัวอักษร และลายเส้นเรียบง่าย",
"es": "Blanco y negro puro, sin puntos. Para logos, texto y dibujo lineal simple."
},
"Chấm Euclid": {
"en": "Euclidean dot",
"th": "จุดยุคลิด",
"es": "Punto euclidiano"
},
"Chấm chuẩn ngành in: tròn ở vùng sáng, bàn cờ ở 50%, lỗ tròn ở vùng tối. Giữ chi tiết vùng tối tốt hơn chấm tròn.": {
"en": "The print-industry standard: round in highlights, checkerboard at 50%, round holes in shadows. Holds shadow detail better than round dots.",
"th": "จุดมาตรฐานงานพิมพ์: กลมในส่วนสว่าง เป็นตารางหมากรุกที่ 50% และเป็นรูกลมในส่วนมืด เก็บรายละเอียดส่วนมืดได้ดีกว่าจุดกลม",
"es": "El estándar de la industria: redondo en luces, tablero a 50% y huecos redondos en sombras. Conserva mejor el detalle oscuro."
},
"Chấm theo ô": {
"en": "Cell dot",
"th": "จุดตามช่อง",
"es": "Punto por celda"
},
"Mỗi ô một chấm tròn hoàn hảo theo độ đậm trung bình, như Filter › Color Halftone. Chấm sắc, chất pop-art.": {
"en": "One perfect round dot per cell sized by its average tone, like Filter › Color Halftone. Crisp pop-art dots.",
"th": "หนึ่งช่องหนึ่งจุดกลมสมบูรณ์ ขนาดตามความเข้มเฉลี่ย เหมือน Filter › Color Halftone จุดคมสไตล์ป๊อปอาร์ต",
"es": "Un punto redondo perfecto por celda según su tono medio, como Filtro › Semitono de color. Puntos nítidos pop-art."
},
"Chấm âm": {
"en": "Negative dot",
"th": "จุดกลับ",
"es": "Punto negativo"
},
"Lỗ trắng tròn trên nền mực. In mực trắng trên áo đen thì lỗ để lộ màu áo.": {
"en": "Round white holes in solid ink. With white ink on a black shirt, the holes show the shirt color.",
"th": "รูกลมสีขาวบนพื้นหมึก เมื่อพิมพ์หมึกขาวบนเสื้อดำ รูจะเผยสีเสื้อ",
"es": "Huecos blancos redondos en tinta sólida. Con tinta blanca sobre camiseta negra, los huecos muestran la prenda."
},
"Mờ dần": {
"en": "Fade out",
"th": "จางหาย",
"es": "Desvanecido"
},
"Chấm tròn tan dần ra mép dưới, hình biến vào màu áo. Chỉnh độ dài và hướng ở thẻ Hiệu ứng phụ.": {
"en": "Round dots that fade toward the bottom edge so the image melts into the shirt. Adjust length and direction in Extra effects.",
"th": "จุดกลมค่อย ๆ จางลงขอบล่าง ภาพกลืนไปกับสีเสื้อ ปรับความยาวและทิศทางได้ในเอฟเฟกต์เสริม",
"es": "Puntos que se desvanecen hacia el borde inferior y la imagen se funde con la camiseta. Ajusta largo y dirección en Efectos extra."
},
"Hạt sần": {
"en": "Gritty grain",
"th": "เม็ดหยาบ",
"es": "Grano rugoso"
},
"Hạt to nhỏ không đều, vón thành cụm như mực bột. Chất Hellstar. LPI thấp = hạt to.": {
"en": "Uneven grains that clump like powdered ink. The Hellstar look. Lower LPI = bigger grain.",
"th": "เม็ดเล็กใหญ่ไม่เท่ากัน จับกันเป็นกลุ่มเหมือนหมึกผง ลุคแบบ Hellstar LPI ต่ำ = เม็ดใหญ่",
"es": "Granos irregulares que se agrupan como tinta en polvo. El estilo Hellstar. Menos LPI = grano más grande."
},
"Photocopy": {
"en": "Photocopy",
"th": "ถ่ายเอกสาร",
"es": "Fotocopia"
},
"Trắng đen gắt có rung nhiễu và hạt bắn, như bản photocopy (kiểu Heaven/Hell). Thanh Ngưỡng chỉnh độ đậm.": {
"en": "Harsh black and white with noise and speckles, like a photocopy (Heaven/Hell style). The Threshold slider sets darkness.",
"th": "ขาวดำจัด มีสัญญาณรบกวนและจุดกระเด็นเหมือนสำเนาถ่ายเอกสาร (สไตล์ Heaven/Hell) แถบเกณฑ์ใช้ปรับความเข้ม",
"es": "Blanco y negro duro con ruido y salpicaduras, como una fotocopia (estilo Heaven/Hell). El control Umbral ajusta la oscuridad."
},
"Grunge": {
"en": "Grunge",
"th": "กรันจ์",
"es": "Grunge"
},
"Trắng đen bị mòn loang lổ, mép rỗ (kiểu Vicinity). Độ mòn chỉnh ở thẻ Hiệu ứng phụ.": {
"en": "Worn, patchy black and white with pitted edges (Vicinity style). Set the wear in Extra effects.",
"th": "ขาวดำสึกเป็นด่าง ขอบขรุขระ (สไตล์ Vicinity) ปรับความสึกในเอฟเฟกต์เสริม",
"es": "Blanco y negro gastado y con manchas, bordes picados (estilo Vicinity). Ajusta el desgaste en Efectos extra."
},
"Chấm bong tróc": {
"en": "Distressed dots",
"th": "จุดลอก",
"es": "Puntos gastados"
},
"Chấm tròn bị bong tróc như in lâu ngày.": {
"en": "Round dots that look worn, like an old print.",
"th": "จุดกลมที่ลอกเหมือนงานพิมพ์เก่า",
"es": "Puntos redondos desgastados, como una impresión antigua."
},
"Mezzotint": {
"en": "Mezzotint",
"th": "เมซโซทินต์",
"es": "Mezzotinta"
},
"Sợi ngắn nằm ngang như bản khắc mezzotint.": {
"en": "Short horizontal fibers like a mezzotint engraving.",
"th": "เส้นใยสั้นแนวนอนเหมือนภาพพิมพ์เมซโซทินต์",
"es": "Fibras cortas horizontales como un grabado a la mezzotinta."
},
"Bút kim": {
"en": "Stipple",
"th": "ปากกาจุด",
"es": "Punteado"
},
"Chấm cùng cỡ, chỉ thay mật độ, như vẽ bằng bút kim.": {
"en": "Same-size dots that only vary in density, like drawing with a fine pen.",
"th": "จุดขนาดเท่ากัน เปลี่ยนแค่ความหนาแน่น เหมือนวาดด้วยปากกาหัวเข็ม",
"es": "Puntos del mismo tamaño que solo cambian de densidad, como dibujar con estilógrafo."
},
"Ký họa": {
"en": "Sketch",
"th": "สเก็ตช์",
"es": "Boceto"
},
"Nét viền bút chì cộng gạch chéo ở vùng tối, như bản ký họa tay.": {
"en": "Pencil outlines plus cross-hatching in dark areas, like a hand sketch.",
"th": "เส้นขอบดินสอพร้อมแรเงาไขว้ในส่วนมืด เหมือนภาพสเก็ตช์มือ",
"es": "Contornos a lápiz y rayado cruzado en las zonas oscuras, como un boceto a mano."
},
"Vuông bo góc": {
"en": "Rounded square",
"th": "สี่เหลี่ยมมุมมน",
"es": "Cuadrado redondeado"
},
"Chấm vuông bo tròn góc, mềm hơn chấm vuông, đậm chất retro.": {
"en": "Square dots with rounded corners, softer and more retro.",
"th": "จุดสี่เหลี่ยมมุมมน นุ่มกว่าและดูเรโทร",
"es": "Puntos cuadrados con esquinas redondeadas, más suaves y retro."
},
"Cỏ 4 lá": {
"en": "Four-leaf clover",
"th": "ใบโคลเวอร์",
"es": "Trébol"
},
"Chấm hình cỏ bốn lá. Dùng LPI thấp để thấy rõ hình.": {
"en": "Four-leaf clover dots. Use a low LPI to see the shape.",
"th": "จุดรูปใบโคลเวอร์สี่แฉก ใช้ LPI ต่ำเพื่อให้เห็นรูปชัด",
"es": "Puntos con forma de trébol de cuatro hojas. Usa LPI bajo para ver la forma."
},
"Hoa 6 cánh": {
"en": "Six-petal flower",
"th": "ดอกไม้ 6 กลีบ",
"es": "Flor de seis pétalos"
},
"Chấm hình bông hoa 6 cánh, hợp áo nữ, áo trẻ em.": {
"en": "Flower-shaped dots, nice for women's and kids' tees.",
"th": "จุดรูปดอกไม้ 6 กลีบ เหมาะกับเสื้อผู้หญิงและเด็ก",
"es": "Puntos con forma de flor, ideales para camisetas de mujer e infantiles."
},
"Bánh răng": {
"en": "Gear",
"th": "เฟือง",
"es": "Engranaje"
},
"Chấm hình bánh răng, hợp chủ đề cơ khí, xe cộ.": {
"en": "Gear-shaped dots for mechanical and car themes.",
"th": "จุดรูปเฟือง เหมาะกับธีมเครื่องกลและรถ",
"es": "Puntos con forma de engranaje para temas mecánicos y de motor."
},
"Giọt nước": {
"en": "Water drop",
"th": "หยดน้ำ",
"es": "Gota"
},
"Chấm hình giọt nước đáy tròn đỉnh nhọn.": {
"en": "Drop-shaped dots with a round base and pointed tip.",
"th": "จุดรูปหยดน้ำ ฐานกลม ปลายแหลม",
"es": "Puntos en forma de gota, base redonda y punta afilada."
},
"Bia bắn": {
"en": "Bullseye",
"th": "เป้ายิง",
"es": "Diana"
},
"Mỗi chấm gồm các vòng tròn lồng nhau như bia bắn.": {
"en": "Each dot is a set of nested rings like a target.",
"th": "แต่ละจุดเป็นวงกลมซ้อนกันเหมือนเป้ายิง",
"es": "Cada punto es un conjunto de anillos concéntricos como una diana."
},
"Ô vuông lồng": {
"en": "Square frame",
"th": "กรอบสี่เหลี่ยม",
"es": "Marco cuadrado"
},
"Mỗi chấm là một khung vuông rỗng, dày dần theo độ đậm.": {
"en": "Each dot is a hollow square that thickens with darkness.",
"th": "แต่ละจุดเป็นกรอบสี่เหลี่ยมกลวง หนาขึ้นตามความเข้ม",
"es": "Cada punto es un cuadrado hueco que engrosa con la oscuridad."
},
"Mưa ngẫu nhiên": {
"en": "Random rain",
"th": "ฝนสุ่ม",
"es": "Lluvia aleatoria"
},
"Chấm gạch ngắn xoay ngẫu nhiên mỗi ô, như mưa rơi hay rơm rạ.": {
"en": "Short dashes rotated randomly in each cell, like rain or straw.",
"th": "ขีดสั้นหมุนแบบสุ่มในแต่ละช่อง เหมือนฝนตกหรือฟาง",
"es": "Guiones cortos girados al azar en cada celda, como lluvia o paja."
},
"Tam giác loạn": {
"en": "Scattered triangles",
"th": "สามเหลี่ยมกระจาย",
"es": "Triángulos dispersos"
},
"Chấm tam giác xoay ngẫu nhiên, kiểu glitch hình học.": {
"en": "Randomly rotated triangles for a geometric glitch look.",
"th": "สามเหลี่ยมหมุนแบบสุ่ม สไตล์กลิตช์เรขาคณิต",
"es": "Triángulos girados al azar con aspecto de glitch geométrico."
},
"Tế bào": {
"en": "Cells",
"th": "เซลล์",
"es": "Células"
},
"Chấm tròn đặt ngẫu nhiên kiểu tế bào, không có lưới nên không bị vân lặp.": {
"en": "Round dots placed randomly like cells; no grid, so no repeating pattern.",
"th": "จุดกลมวางแบบสุ่มเหมือนเซลล์ ไม่มีกริดจึงไม่เกิดลายซ้ำ",
"es": "Puntos redondos colocados al azar como células; sin retícula, sin patrón repetido."
},
"Hướng dương": {
"en": "Sunflower",
"th": "ทานตะวัน",
"es": "Girasol"
},
"Chấm xếp theo góc vàng 137,5° như hạt hoa hướng dương, tỏa từ giữa hình.": {
"en": "Dots arranged at the 137.5° golden angle like sunflower seeds, radiating from the center.",
"th": "จุดเรียงตามมุมทอง 137.5° เหมือนเมล็ดทานตะวัน แผ่ออกจากกลางภาพ",
"es": "Puntos dispuestos en el ángulo áureo de 137,5° como semillas de girasol, desde el centro."
},
"Mã Morse": {
"en": "Morse code",
"th": "รหัสมอร์ส",
"es": "Código Morse"
},
"Hàng chấm gạch như mã Morse; vùng đậm gạch dài và dày hơn.": {
"en": "Rows of dots and dashes like Morse code; dark areas get longer, thicker dashes.",
"th": "แถวจุดและขีดเหมือนรหัสมอร์ส ส่วนมืดขีดยาวและหนากว่า",
"es": "Filas de puntos y rayas como el código Morse; las zonas oscuras tienen rayas más largas y gruesas."
},
"Tổ ong": {
"en": "Honeycomb dots",
"th": "จุดรังผึ้ง",
"es": "Puntos panal"
},
"Chấm tròn xếp lưới lục giác như tổ ong. Mịn hơn lưới vuông, ít lộ hướng lưới.": {
"en": "Round dots on a hexagonal grid. Smoother than a square grid, less visible direction.",
"th": "จุดกลมบนกริดหกเหลี่ยมแบบรังผึ้ง เนียนกว่ากริดสี่เหลี่ยม เห็นทิศทางกริดน้อยกว่า",
"es": "Puntos redondos en retícula hexagonal. Más suave que la cuadrada y con menos dirección visible."
},
"Lục giác": {
"en": "Hexagon",
"th": "หกเหลี่ยม",
"es": "Hexágono"
},
"Chấm hình lục giác, vùng tối nối thành tổ ong.": {
"en": "Hexagon-shaped dots that join into a honeycomb in dark areas.",
"th": "จุดรูปหกเหลี่ยม ส่วนมืดต่อกันเป็นรังผึ้ง",
"es": "Puntos hexagonales que se unen en panal en las zonas oscuras."
},
"Tam giác": {
"en": "Triangle",
"th": "สามเหลี่ยม",
"es": "Triángulo"
},
"Chấm hình tam giác, hợp thiết kế hình học, streetwear.": {
"en": "Triangle-shaped dots for geometric and streetwear designs.",
"th": "จุดรูปสามเหลี่ยม เหมาะกับงานเรขาคณิตและสตรีทแวร์",
"es": "Puntos triangulares para diseños geométricos y streetwear."
},
"Ngôi sao": {
"en": "Star",
"th": "ดาว",
"es": "Estrella"
},
"Chấm hình ngôi sao 5 cánh. Nên dùng LPI thấp (10–25) để thấy rõ hình sao.": {
"en": "Five-point star dots. Use a low LPI (10–25) to see the stars.",
"th": "จุดรูปดาว 5 แฉก ควรใช้ LPI ต่ำ (10–25) เพื่อให้เห็นรูปดาว",
"es": "Puntos en forma de estrella de cinco puntas. Usa LPI bajo (10–25) para verlas."
},
"Trái tim": {
"en": "Heart",
"th": "หัวใจ",
"es": "Corazón"
},
"Chấm hình trái tim. Dùng LPI thấp để thấy rõ.": {
"en": "Heart-shaped dots. Use a low LPI to see them clearly.",
"th": "จุดรูปหัวใจ ใช้ LPI ต่ำเพื่อให้เห็นชัด",
"es": "Puntos en forma de corazón. Usa LPI bajo para verlos bien."
},
"Chấm gạch": {
"en": "Dash",
"th": "ขีด",
"es": "Guion"
},
"Chấm dạng gạch ngắn xoay theo góc, như vệt mưa.": {
"en": "Short dash dots rotated to the angle, like rain streaks.",
"th": "จุดเป็นขีดสั้นหมุนตามมุม เหมือนสายฝน",
"es": "Puntos en forma de guion girados según el ángulo, como trazos de lluvia."
},
"Vòng nhẫn": {
"en": "Ring",
"th": "วงแหวน",
"es": "Anillo"
},
"Mỗi chấm là một vòng tròn rỗng, dày dần theo độ đậm.": {
"en": "Each dot is a hollow ring that thickens with darkness.",
"th": "แต่ละจุดเป็นวงแหวนกลวง หนาขึ้นตามความเข้ม",
"es": "Cada punto es un anillo hueco que engrosa con la oscuridad."
},
"Mắt cáo": {
"en": "Lattice",
"th": "ตาข่ายไขว้",
"es": "Celosía"
},
"Lưới chéo hai chiều như hàng rào mắt cáo, nét dày theo độ đậm.": {
"en": "Diagonal two-way grid like a lattice fence; lines thicken with darkness.",
"th": "กริดเฉียงสองทางเหมือนรั้วระแนง เส้นหนาตามความเข้ม",
"es": "Retícula diagonal en dos sentidos como una celosía; las líneas engrosan con la oscuridad."
},
"Gạch xây": {
"en": "Brick wall",
"th": "กำแพงอิฐ",
"es": "Muro de ladrillo"
},
"Mạch vữa tường gạch, mạch dày lên ở vùng đậm. Hợp phong cách đường phố.": {
"en": "Mortar lines of a brick wall that thicken in dark areas. Street style.",
"th": "ร่องปูนของกำแพงอิฐ หนาขึ้นในส่วนมืด สไตล์สตรีท",
"es": "Juntas de un muro de ladrillo que engrosan en las zonas oscuras. Estilo urbano."
},
"Lưới tổ ong": {
"en": "Honeycomb lines",
"th": "เส้นรังผึ้ง",
"es": "Líneas de panal"
},
"Đường viền các ô lục giác như tổ ong, nét dày theo độ đậm.": {
"en": "Hexagon cell outlines like a honeycomb; lines thicken with darkness.",
"th": "เส้นขอบช่องหกเหลี่ยมเหมือนรังผึ้ง หนาตามความเข้ม",
"es": "Contornos hexagonales como un panal; las líneas engrosan con la oscuridad."
},
"Vuông đồng tâm": {
"en": "Concentric squares",
"th": "สี่เหลี่ยมซ้อน",
"es": "Cuadrados concéntricos"
},
"Các khung vuông đồng tâm. Hỗ trợ bố cục nhiều tâm.": {
"en": "Concentric square frames. Supports the multi-center layout.",
"th": "กรอบสี่เหลี่ยมซ้อนกันจากจุดศูนย์กลาง รองรับเลย์เอาต์หลายจุดศูนย์กลาง",
"es": "Marcos cuadrados concéntricos. Admite el diseño multicentro."
},
"Sóng biển Nhật": {
"en": "Japanese waves",
"th": "คลื่นญี่ปุ่น",
"es": "Olas japonesas"
},
"Họa tiết sóng biển Nhật (seigaiha): các vảy cung tròn lồng nhau.": {
"en": "Seigaiha pattern: nested arcs like stylized Japanese waves.",
"th": "ลายเซไกฮะ: ส่วนโค้งซ้อนกันเหมือนคลื่นทะเลญี่ปุ่น",
"es": "Patrón seigaiha: arcos anidados como olas japonesas estilizadas."
},
"Mạng nhện": {
"en": "Spider web",
"th": "ใยแมงมุม",
"es": "Telaraña"
},
"Vòng tròn và tia đan thành mạng nhện. Hỗ trợ nhiều tâm, hợp áo Halloween, rock.": {
"en": "Rings and spokes woven into a web. Multi-center ready; great for Halloween and rock tees.",
"th": "วงกลมและเส้นรัศมีถักเป็นใยแมงมุม รองรับหลายจุดศูนย์กลาง เหมาะกับเสื้อฮาโลวีนและร็อก",
"es": "Anillos y radios tejidos como una telaraña. Admite multicentro; ideal para Halloween y rock."
},
"Đan rổ": {
"en": "Basket weave",
"th": "ลายสาน",
"es": "Cestería"
},
"Sọc ngang dọc xen kẽ như đan rổ, đan vải.": {
"en": "Alternating horizontal and vertical stripes like woven fabric.",
"th": "แถบแนวนอนและแนวตั้งสลับกันเหมือนลายสานหรือผ้าทอ",
"es": "Franjas horizontales y verticales alternas como un tejido."
},
"Thép gân": {
"en": "Diamond plate",
"th": "แผ่นเหล็กลาย",
"es": "Chapa estriada"
},
"Gân chéo như tấm thép chống trượt, hợp chủ đề công nghiệp, xe.": {
"en": "Diagonal ribs like anti-slip steel plate, for industrial and car themes.",
"th": "สันเฉียงเหมือนแผ่นเหล็กกันลื่น เหมาะกับธีมอุตสาหกรรมและรถ",
"es": "Relieves diagonales como chapa antideslizante, para temas industriales y de motor."
},
"Vằn ngựa": {
"en": "Zebra",
"th": "ลายม้าลาย",
"es": "Cebra"
},
"Sọc vằn uốn lượn như da ngựa vằn, dày mỏng theo độ đậm.": {
"en": "Wavy zebra stripes that thicken with darkness.",
"th": "ลายทางคดเคี้ยวเหมือนม้าลาย หนาบางตามความเข้ม",
"es": "Rayas onduladas de cebra que engrosan con la oscuridad."
},
"Da báo": {
"en": "Leopard",
"th": "ลายเสือดาว",
"es": "Leopardo"
},
"Đốm vòng không đều như da báo.": {
"en": "Irregular ring spots like leopard skin.",
"th": "จุดวงแหวนไม่สม่ำเสมอเหมือนหนังเสือดาว",
"es": "Manchas anulares irregulares como piel de leopardo."
},
"Vân đá": {
"en": "Marble",
"th": "ลายหินอ่อน",
"es": "Mármol"
},
"Vân mảnh uốn lượn như đá cẩm thạch.": {
"en": "Thin flowing veins like marble.",
"th": "ลายเส้นบางคดเคี้ยวเหมือนหินอ่อน",
"es": "Vetas finas y onduladas como el mármol."
},
"Rằn ri": {
"en": "Camo",
"th": "ลายพราง",
"es": "Camuflaje"
},
"Mảng loang to kiểu quân đội; độ phủ đúng theo độ đậm.": {
"en": "Large military blotches; coverage matches the tone exactly.",
"th": "ลายพรางทหารขนาดใหญ่ ความครอบคลุมตรงตามความเข้ม",
"es": "Manchas militares grandes; la cobertura coincide con el tono."
},
"Vòng tròn": {
"en": "Rings",
"th": "วงกลมซ้อน",
"es": "Anillos"
},
"Vòng tròn đồng tâm. Thẻ Bố cục nhiều tâm: tạo nhiều cụm vòng to nhỏ chen nhau.": {
"en": "Concentric circles. Use Multi-center layout for clusters of big and small rings.",
"th": "วงกลมซ้อนกัน ใช้เลย์เอาต์หลายจุดศูนย์กลางเพื่อสร้างกลุ่มวงเล็กใหญ่เบียดกัน",
"es": "Círculos concéntricos. Usa el diseño multicentro para grupos de anillos grandes y pequeños."
},
"Xoắn ốc": {
"en": "Spiral",
"th": "เกลียว",
"es": "Espiral"
},
"Đường xoắn ốc liên tục. Bật nhiều tâm để có nhiều xoắn ốc to nhỏ, xoắn ngược chiều nhau.": {
"en": "One continuous spiral. Turn on multiple centers for many spirals of different sizes twisting both ways.",
"th": "เส้นเกลียวต่อเนื่อง เปิดหลายจุดศูนย์กลางเพื่อได้เกลียวหลายขนาดที่หมุนสวนกัน",
"es": "Una espiral continua. Activa varios centros para muchas espirales de distintos tamaños y giros."
},
"Tỏa tia": {
"en": "Sunburst",
"th": "รัศมี",
"es": "Rayos"
},
"Tia tỏa từ tâm như tia nắng. Nhiều tâm cho hiệu ứng pháo hoa, manga.": {
"en": "Rays from the center like sunbeams. Multiple centers give a fireworks or manga look.",
"th": "เส้นรัศมีจากจุดกลางเหมือนแสงอาทิตย์ หลายจุดศูนย์กลางให้ลุคพลุหรือมังงะ",
"es": "Rayos desde el centro como un sol. Varios centros dan aspecto de fuegos artificiales o manga."
},
"Chấm xếp vòng": {
"en": "Circular dots",
"th": "จุดเรียงวง",
"es": "Puntos circulares"
},
"Chấm tròn xếp thành các vòng đồng tâm quanh giữa hình.": {
"en": "Round dots arranged in concentric rings around the center.",
"th": "จุดกลมเรียงเป็นวงซ้อนรอบกลางภาพ",
"es": "Puntos redondos dispuestos en anillos concéntricos alrededor del centro."
},
"Lượn sóng": {
"en": "Waves",
"th": "คลื่น",
"es": "Ondas"
},
"Đường lượn sóng song song, kiểu khắc tiền giấy.": {
"en": "Parallel wavy lines, banknote-engraving style.",
"th": "เส้นคลื่นขนาน สไตล์ลายแกะบนธนบัตร",
"es": "Líneas onduladas paralelas, estilo grabado de billete."
},
"Răng cưa": {
"en": "Zigzag",
"th": "ซิกแซก",
"es": "Zigzag"
},
"Đường gãy khúc zigzag, dày mỏng theo độ đậm.": {
"en": "Zigzag lines that thicken with darkness.",
"th": "เส้นซิกแซกหนาบางตามความเข้ม",
"es": "Líneas en zigzag que engrosan con la oscuridad."
},
"Đan chéo": {
"en": "Cross-hatch",
"th": "แรเงาไขว้",
"es": "Rayado cruzado"
},
"Nét gạch một chiều ở vùng sáng, thêm lớp vuông góc ở vùng tối, như ký họa bút sắt.": {
"en": "One-way hatching in light areas with a second perpendicular layer in dark areas, like pen drawing.",
"th": "เส้นแรเงาทางเดียวในส่วนสว่าง เพิ่มชั้นตั้งฉากในส่วนมืด เหมือนวาดด้วยปากกา",
"es": "Rayado en un sentido en luces y una segunda capa perpendicular en sombras, como dibujo a plumilla."
},
"Sóng điều biến": {
"en": "Squiggle",
"th": "คลื่นปรับ",
"es": "Garabato"
},
"Các hàng sóng ngang, vùng đậm sóng dày và mạnh hơn.": {
"en": "Rows of horizontal waves; darker areas have denser, stronger waves.",
"th": "แถวคลื่นแนวนอน ส่วนมืดคลื่นถี่และแรงกว่า",
"es": "Filas de ondas horizontales; las zonas oscuras tienen ondas más densas y fuertes."
},
"Vân gỗ": {
"en": "Wood grain",
"th": "ลายไม้",
"es": "Veta de madera"
},
"Vân gỗ cong lượn có nhiễu tự nhiên.": {
"en": "Curving wood grain with natural noise.",
"th": "ลายไม้โค้งพร้อมความไม่สม่ำเสมอตามธรรมชาติ",
"es": "Veta de madera curvada con ruido natural."
},
"Vân tay": {
"en": "Fingerprint",
"th": "ลายนิ้วมือ",
"es": "Huella dactilar"
},
"Vòng đồng tâm méo như dấu vân tay.": {
"en": "Warped concentric rings like a fingerprint.",
"th": "วงซ้อนบิดเบี้ยวเหมือนลายนิ้วมือ",
"es": "Anillos concéntricos deformados como una huella dactilar."
},
"Lưới phồng": {
"en": "Bulge",
"th": "นูน",
"es": "Abombado"
},
"Đường kẻ ngang phồng ở giữa, cảm giác khối cầu 3D.": {
"en": "Horizontal lines that bulge in the middle for a 3D sphere feel.",
"th": "เส้นแนวนอนโป่งตรงกลาง ให้ความรู้สึกเป็นทรงกลม 3D",
"es": "Líneas horizontales que se abomban en el centro, con sensación de esfera 3D."
},
"Xoáy": {
"en": "Twirl",
"th": "หมุนวน",
"es": "Remolino"
},
"Đường kẻ xoắn quanh tâm như nước xoáy.": {
"en": "Lines twisting around the center like a whirlpool.",
"th": "เส้นบิดหมุนรอบจุดกลางเหมือนน้ำวน",
"es": "Líneas que giran alrededor del centro como un remolino."
},
"Giao thoa": {
"en": "Interference",
"th": "การแทรกสอด",
"es": "Interferencia"
},
"Hai hệ vòng tròn lệch tâm chồng nhau tạo vân giao thoa.": {
"en": "Two offset ring systems overlap into interference patterns.",
"th": "วงกลมสองชุดเหลื่อมกันสร้างลายแทรกสอด",
"es": "Dos sistemas de anillos desplazados se superponen en patrones de interferencia."
},
"Mê cung": {
"en": "Maze",
"th": "เขาวงกต",
"es": "Laberinto"
},
"Các cung tròn nối nhau ngẫu nhiên thành mê cung.": {
"en": "Arcs joining at random into a maze (Truchet tiles).",
"th": "ส่วนโค้งต่อกันแบบสุ่มเป็นเขาวงกต",
"es": "Arcos que se unen al azar formando un laberinto (teselas de Truchet)."
},
"Vảy cá": {
"en": "Fish scales",
"th": "เกล็ดปลา",
"es": "Escamas"
},
"Cung tròn xếp so le như vảy cá, vảy rồng.": {
"en": "Staggered arcs like fish or dragon scales.",
"th": "ส่วนโค้งเรียงสลับเหมือนเกล็ดปลาหรือเกล็ดมังกร",
"es": "Arcos escalonados como escamas de pez o de dragón."
},
"Đồng mức": {
"en": "Contour lines",
"th": "เส้นชั้นความสูง",
"es": "Curvas de nivel"
},
"Chỉ vẽ đường nối các điểm cùng độ đậm, như bản đồ địa hình. Hợp line-art.": {
"en": "Only draws lines of equal tone, like a topographic map. Great for line art.",
"th": "วาดเฉพาะเส้นที่ความเข้มเท่ากัน เหมือนแผนที่ภูมิประเทศ เหมาะกับลายเส้น",
"es": "Solo dibuja líneas de igual tono, como un mapa topográfico. Ideal para line art."
},
"Sọc hoàng hôn": {
"en": "Sunset stripes",
"th": "แถบซันเซ็ต",
"es": "Franjas atardecer"
},
"Sọc ngang retro thập niên 70 cắt nửa dưới hình, khe hở to dần xuống dưới. Giữ nguyên màu thiết kế.": {
"en": "70s retro stripes cutting the lower half, with gaps widening downward. Keeps the design colors.",
"th": "แถบเรโทรยุค 70 ตัดครึ่งล่างของภาพ ช่องว่างกว้างขึ้นด้านล่าง คงสีของดีไซน์",
"es": "Franjas retro de los 70 que cortan la mitad inferior, con huecos que se ensanchan hacia abajo. Mantiene los colores."
},
"Chấm chuyển hướng": {
"en": "Directional dot fade",
"th": "จุดจางตามทิศ",
"es": "Degradado de puntos"
},
"Hình tan dần thành chấm theo một hướng (90° = tan xuống dưới), không phụ thuộc sáng tối của hình.": {
"en": "The image dissolves into dots along a direction (90° = downward), regardless of light and dark.",
"th": "ภาพค่อย ๆ สลายเป็นจุดตามทิศทาง (90° = ลงล่าง) ไม่ขึ้นกับความสว่างมืด",
"es": "La imagen se disuelve en puntos en una dirección (90° = hacia abajo), sin depender de luces y sombras."
},
"Mực nứt": {
"en": "Cracked ink",
"th": "หมึกแตก",
"es": "Tinta agrietada"
},
"Vết nứt như áo in lâu năm, vùng sáng nứt nhiều hơn. Giữ nguyên màu thiết kế.": {
"en": "Cracks like a well-worn print; lighter areas crack more. Keeps the design colors.",
"th": "รอยแตกเหมือนเสื้อที่พิมพ์มานาน ส่วนสว่างแตกมากกว่า คงสีของดีไซน์",
"es": "Grietas como una estampa muy usada; las zonas claras se agrietan más. Mantiene los colores."
},
"Khắc tiền giấy": {
"en": "Banknote engraving",
"th": "ลายแกะธนบัตร",
"es": "Grabado de billete"
},
"Đường khắc uốn theo khối sáng tối như hình trên tiền giấy, tem thư.": {
"en": "Engraved lines that bend with light and shadow, like banknotes and stamps.",
"th": "เส้นแกะสลักโค้งตามแสงเงา เหมือนภาพบนธนบัตรและแสตมป์",
"es": "Líneas grabadas que se curvan con luces y sombras, como en billetes y sellos."
},
"Stencil": {
"en": "Stencil",
"th": "สเตนซิล",
"es": "Plantilla"
},
"Stencil graffiti 3 tông: tối = đặc, trung tính = gạch chéo, sáng = bỏ trống.": {
"en": "Three-tone graffiti stencil: dark = solid, midtones = hatched, light = empty.",
"th": "สเตนซิลกราฟฟิตี 3 โทน: มืด = ทึบ กลาง = แรเงา สว่าง = เว้นว่าง",
"es": "Plantilla de graffiti en 3 tonos: oscuro = sólido, medios = rayado, claro = vacío."
},
"Pixel 1-bit": {
"en": "1-bit pixel",
"th": "พิกเซล 1 บิต",
"es": "Píxel 1 bit"
},
"Ô vuông lớn bật/tắt theo độ đậm, kiểu game cổ.": {
"en": "Large square pixels on or off by tone, old-school game style.",
"th": "พิกเซลสี่เหลี่ยมใหญ่ เปิด/ปิดตามความเข้ม สไตล์เกมยุคเก่า",
"es": "Píxeles cuadrados grandes encendidos o apagados según el tono, estilo videojuego clásico."
},
"Chữ ASCII": {
"en": "ASCII text",
"th": "ตัวอักษร ASCII",
"es": "Texto ASCII"
},
"Hình được dựng bằng ký tự. Đổi bộ ký tự (hoặc gõ chữ thương hiệu) ở thẻ Tùy chọn hiệu ứng.": {
"en": "The image is built from characters. Change the character set (or type your brand name) in Effect options.",
"th": "ภาพสร้างจากตัวอักษร เปลี่ยนชุดตัวอักษร (หรือพิมพ์ชื่อแบรนด์) ในตัวเลือกเอฟเฟกต์",
"es": "La imagen se forma con caracteres. Cambia el juego de caracteres (o escribe tu marca) en Opciones del efecto."
},
"Glitch": {
"en": "Glitch",
"th": "กลิตช์",
"es": "Glitch"
},
"Lệch kênh RGB, các dải ngang bị xô lệch và vạch quét kiểu Y2K / VHS.": {
"en": "RGB channel shift, displaced horizontal bands and scanlines, Y2K / VHS style.",
"th": "แยกช่องสี RGB แถบแนวนอนเหลื่อม และเส้นสแกน สไตล์ Y2K / VHS",
"es": "Desplazamiento de canales RGB, bandas horizontales corridas y líneas de escaneo, estilo Y2K / VHS."
},
"Riso 2 màu": {
"en": "2-color riso",
"th": "ริโซ 2 สี",
"es": "Riso a 2 colores"
},
"In riso: 2 màu mực hạt sần, in lệch khuôn nhẹ. Đổi 2 màu ở thẻ Tùy chọn hiệu ứng.": {
"en": "Riso print: two grainy ink colors with slight misregistration. Change the two colors in Effect options.",
"th": "งานพิมพ์ริโซ: หมึก 2 สีเม็ดหยาบ พิมพ์เหลื่อมเล็กน้อย เปลี่ยน 2 สีได้ในตัวเลือกเอฟเฟกต์",
"es": "Impresión riso: dos tintas granuladas con ligero desregistro. Cambia los dos colores en Opciones del efecto."
},
"Pop-art 2 màu": {
"en": "2-color pop art",
"th": "ป๊อปอาร์ต 2 สี",
"es": "Pop art a 2 colores"
},
"Chấm tròn 2 màu kiểu truyện tranh Mỹ, hai lưới lệch góc và lệch khuôn.": {
"en": "Two-color round dots like American comics, with offset angles and misregistration.",
"th": "จุดกลม 2 สีแบบการ์ตูนอเมริกัน กริดเหลื่อมมุมและเหลื่อมตำแหน่ง",
"es": "Puntos redondos a dos colores como el cómic americano, con ángulos y registro desplazados."
},
"Pixel 8-bit": {
"en": "8-bit pixel",
"th": "พิกเซล 8 บิต",
"es": "Píxel 8 bits"
},
"Khối màu vuông và ít mức màu như đồ họa game 8-bit.": {
"en": "Square color blocks with few color levels, like 8-bit game graphics.",
"th": "บล็อกสีสี่เหลี่ยม ระดับสีน้อย เหมือนกราฟิกเกม 8 บิต",
"es": "Bloques de color cuadrados con pocos niveles, como gráficos de 8 bits."
},
"Vintage bạc màu": {
"en": "Faded vintage",
"th": "วินเทจซีด",
"es": "Vintage desgastado"
},
"Màu nhạt, ngả ấm, mực mòn và nứt như áo giặt nhiều năm.": {
"en": "Faded, warm colors with worn, cracked ink like a tee washed for years.",
"th": "สีซีดอมอุ่น หมึกสึกและแตกเหมือนเสื้อที่ซักมาหลายปี",
"es": "Colores apagados y cálidos, tinta gastada y agrietada como una camiseta lavada durante años."
},
"Ảo giác 70s": {
"en": "Trippy 70s",
"th": "ไซเคเดลิก 70s",
"es": "Psicodélico 70s"
},
"Hình uốn sóng kiểu psychedelic, viền lặp 2 màu.": {
"en": "Psychedelic wavy distortion with a two-color echo outline.",
"th": "ภาพบิดเป็นคลื่นสไตล์ไซเคเดลิก ขอบสะท้อน 2 สี",
"es": "Distorsión ondulada psicodélica con contorno eco a dos colores."
},
"Ảnh nhiệt": {
"en": "Thermal",
"th": "ภาพความร้อน",
"es": "Térmico"
},
"Chuyển hình sang dải màu ảnh nhiệt: tím, đỏ, cam, vàng.": {
"en": "Maps the image to a thermal-camera palette: purple, red, orange, yellow.",
"th": "เปลี่ยนภาพเป็นโทนกล้องถ่ายภาพความร้อน: ม่วง แดง ส้ม เหลือง",
"es": "Convierte la imagen a la paleta de una cámara térmica: morado, rojo, naranja, amarillo."
},
"Neon viền": {
"en": "Neon outline",
"th": "นีออน",
"es": "Contorno neón"
},
"Chỉ giữ đường viền của hình, phát sáng như đèn neon. Rất hợp áo đen.": {
"en": "Keeps only the outlines and makes them glow like neon. Great on black shirts.",
"th": "เก็บเฉพาะเส้นขอบและทำให้เรืองแสงเหมือนไฟนีออน เหมาะกับเสื้อดำ",
"es": "Conserva solo los contornos y los hace brillar como neón. Ideal en camisetas negras."
},
"Duotone": {
"en": "Duotone",
"th": "ดูโอโทน",
"es": "Duotono"
},
"Ánh xạ hình sang dải 2 màu (màu 1 = vùng tối, màu 2 = vùng sáng), kiểu poster thời trang.": {
"en": "Maps the image to two colors (color 1 = shadows, color 2 = highlights), fashion-poster style.",
"th": "เปลี่ยนภาพเป็นโทน 2 สี (สี 1 = ส่วนมืด สี 2 = ส่วนสว่าง) สไตล์โปสเตอร์แฟชั่น",
"es": "Convierte la imagen a dos colores (color 1 = sombras, color 2 = luces), estilo cartel de moda."
},
"Chấm cầu vồng": {
"en": "Rainbow dots",
"th": "จุดสายรุ้ง",
"es": "Puntos arcoíris"
},
"Trame chấm tròn, màu chấm chạy dải cầu vồng chéo qua hình. Cường độ xoay dải màu.": {
"en": "Round-dot halftone colored by a diagonal rainbow. Strength rotates the colors.",
"th": "ฮาล์ฟโทนจุดกลม สีจุดไล่เป็นสายรุ้งเฉียงทั่วภาพ ความแรงใช้หมุนสี",
"es": "Trama de puntos redondos coloreada con un arcoíris diagonal. La intensidad gira los colores."
},
"Chấm RGB LED": {
"en": "RGB LED dots",
"th": "จุด RGB LED",
"es": "Puntos LED RGB"
},
"Mỗi ô 3 chấm đỏ, lục, lam như màn hình LED. Rất nổi trên áo đen.": {
"en": "Three red, green and blue dots per cell like an LED screen. Pops on black shirts.",
"th": "แต่ละช่องมี 3 จุด แดง เขียว น้ำเงิน เหมือนจอ LED เด่นมากบนเสื้อดำ",
"es": "Tres puntos rojo, verde y azul por celda como una pantalla LED. Destaca en camisetas negras."
},
"Sơn xịt": {
"en": "Spray paint",
"th": "สเปรย์",
"es": "Spray"
},
"Mép hình tan thành bụi sơn, có vệt sơn chảy xuống như graffiti.": {
"en": "Edges dissolve into paint mist with drips running down, graffiti style.",
"th": "ขอบภาพสลายเป็นละอองสี มีหยดสีไหลลง สไตล์กราฟฟิตี",
"es": "Los bordes se deshacen en niebla de pintura con chorreones, estilo graffiti."
},
"Ảnh sepia": {
"en": "Sepia photo",
"th": "ภาพซีเปีย",
"es": "Foto sepia"
},
"Chuyển hình sang tông nâu sepia như ảnh chụp đầu thế kỷ 20, mực mòn nhẹ.": {
"en": "Turns the image into brown sepia tones like an early 20th-century photo, with light ink wear.",
"th": "เปลี่ยนภาพเป็นโทนน้ำตาลซีเปียเหมือนภาพถ่ายต้นศตวรรษที่ 20 มีรอยหมึกสึกเล็กน้อย",
"es": "Convierte la imagen a tonos sepia como una foto de principios del siglo XX, con ligero desgaste de tinta."
},
"Ảnh ố vàng": {
"en": "Yellowed photo",
"th": "ภาพเหลืองซีด",
"es": "Foto amarillenta"
},
"Giấy ngả vàng, có đốm ố rải rác như ảnh cất lâu năm.": {
"en": "Paper turned yellow with scattered age spots, like a photo stored for years.",
"th": "กระดาษเปลี่ยนเป็นสีเหลือง มีจุดคราบกระจายเหมือนภาพที่เก็บไว้หลายปี",
"es": "Papel amarillento con manchas de humedad dispersas, como una foto guardada durante años."
},
"Phim cũ xước": {
"en": "Scratched film",
"th": "ฟิล์มเก่ามีรอยขีด",
"es": "Película rayada"
},
"Màu nhạt bớt, có vết xước dọc và bụi như cuộn phim nhựa cũ.": {
"en": "Faded colors with vertical scratches and dust, like an old film reel.",
"th": "สีจางลง มีรอยขีดแนวตั้งและฝุ่นเหมือนม้วนฟิล์มเก่า",
"es": "Colores apagados con rayas verticales y polvo, como un rollo de película antiguo."
},
"Áo giặt bạc": {
"en": "Washed-out tee",
"th": "เสื้อซักจนซีด",
"es": "Camiseta deslavada"
},
"Màu bạc, nhạt và mòn loang lổ như áo đã giặt rất nhiều lần.": {
"en": "Faded, pale colors with patchy wear, like a shirt washed many times.",
"th": "สีซีดจางและสึกเป็นหย่อมเหมือนเสื้อที่ซักมาหลายครั้ง",
"es": "Colores pálidos y desvaídos con desgaste irregular, como una camiseta lavada muchas veces."
},
"In lụa cũ": {
"en": "Old screen print",
"th": "สกรีนเก่า",
"es": "Serigrafía antigua"
},
"Gom còn 5 màu phẳng như in lụa, thêm vết nứt mực và mảng mòn.": {
"en": "Reduces to 5 flat colors like a screen print, then adds ink cracks and worn patches.",
"th": "ลดเหลือ 5 สีเรียบแบบงานสกรีน แล้วเพิ่มรอยแตกของหมึกและรอยสึก",
"es": "Reduce a 5 colores planos como una serigrafía y añade grietas de tinta y zonas gastadas."
},
"Con dấu cao su": {
"en": "Rubber stamp",
"th": "ตรายาง",
"es": "Sello de goma"
},
"Một màu mực, mực ăn không đều và mép sần như đóng dấu tay. Đổi màu mực ở thẻ Tùy chọn hiệu ứng.": {
"en": "One ink color with uneven coverage and rough edges, like a hand stamp. Change the ink color in the Effect options card.",
"th": "หมึกสีเดียว ติดไม่สม่ำเสมอ ขอบหยาบเหมือนการประทับตราด้วยมือ เปลี่ยนสีหมึกได้ในการ์ดตัวเลือกเอฟเฟกต์",
"es": "Una tinta con cobertura irregular y bordes ásperos, como un sello a mano. Cambia el color en la tarjeta Opciones del efecto."
},
"Áo band 80s": {
"en": "80s band tee",
"th": "เสื้อวงยุค 80",
"es": "Camiseta de banda 80s"
},
"Chấm trame to một màu, mòn mảng lớn như áo tour ban nhạc thập niên 80.": {
"en": "Big one-color halftone dots with large worn patches, like an 80s tour shirt.",
"th": "จุดฮาล์ฟโทนใหญ่สีเดียว สึกเป็นหย่อมใหญ่เหมือนเสื้อทัวร์วงดนตรียุค 80",
"es": "Puntos de trama grandes de una tinta con grandes zonas gastadas, como una camiseta de gira de los 80."
},
"Surf 70s": {
"en": "70s surf",
"th": "เซิร์ฟยุค 70",
"es": "Surf años 70"
},
"Dải màu nâu, cam, vàng, kem của áo lướt sóng thập niên 70.": {
"en": "Brown, orange, yellow and cream gradient of a 70s surf tee.",
"th": "ไล่สีน้ำตาล ส้ม เหลือง ครีม แบบเสื้อเซิร์ฟยุค 70",
"es": "Degradado marrón, naranja, amarillo y crema de una camiseta surf de los 70."
},
"Poster cổ động": {
"en": "Propaganda poster",
"th": "โปสเตอร์โฆษณาชวนเชื่อ",
"es": "Cartel de propaganda"
},
"Ba mảng màu: đen, màu nhấn và nền kem, kiểu tranh cổ động in đá.": {
"en": "Three flat areas: black, an accent color and a cream base, like a lithographed propaganda poster.",
"th": "สามพื้นสี: ดำ สีเน้น และพื้นครีม แบบโปสเตอร์ปลุกใจพิมพ์หิน",
"es": "Tres zonas planas: negro, un color de acento y fondo crema, como un cartel litográfico."
},
"Khắc gỗ": {
"en": "Woodcut",
"th": "ภาพพิมพ์แกะไม้",
"es": "Xilografía"
},
"Vùng đậm tô đặc, vùng trung tính thành nét khắc uốn lượn như tranh khắc gỗ.": {
"en": "Dark areas go solid and midtones become flowing carved lines, like a woodcut print.",
"th": "ส่วนเข้มเป็นสีทึบ ส่วนโทนกลางกลายเป็นเส้นแกะสลักโค้งไหลเหมือนภาพพิมพ์แกะไม้",
"es": "Las zonas oscuras quedan sólidas y los medios tonos se vuelven líneas talladas, como una xilografía."
},
"Khắc linoleum": {
"en": "Linocut",
"th": "ภาพพิมพ์ลิโนเลียม",
"es": "Linograbado"
},
"Mảng đặc lớn, có vết đục ngắn rải rác như bản in khắc linoleum.": {
"en": "Large solid areas with short gouge marks scattered through, like a linocut print.",
"th": "พื้นทึบขนาดใหญ่ มีรอยเซาะสั้นๆ กระจายเหมือนภาพพิมพ์แกะลิโนเลียม",
"es": "Grandes zonas sólidas con marcas cortas de gubia, como un linograbado."
},
"Báo cũ": {
"en": "Old newspaper",
"th": "หนังสือพิมพ์เก่า",
"es": "Periódico antiguo"
},
"Chấm trame thô một màu, mực lúc đậm lúc nhạt như trang báo in xưa.": {
"en": "Coarse one-color halftone with ink that goes heavy and light, like an old printed newspaper.",
"th": "ฮาล์ฟโทนหยาบสีเดียว หมึกเข้มบ้างจางบ้างเหมือนหนังสือพิมพ์สมัยก่อน",
"es": "Trama gruesa de una tinta, con tinta a veces cargada y a veces débil, como un periódico antiguo."
},
"Truyện tranh cổ": {
"en": "Vintage comic",
"th": "การ์ตูนยุคเก่า",
"es": "Cómic vintage"
},
"Chấm 3 màu vàng, hồng, xanh to và lệch khuôn, nét đen đậm như truyện tranh thập niên 50.": {
"en": "Big yellow, magenta and cyan dots printed off-register with bold black lines, like a 1950s comic.",
"th": "จุดใหญ่สีเหลือง ชมพู ฟ้า พิมพ์เหลื่อม พร้อมเส้นดำหนาเหมือนการ์ตูนยุค 50",
"es": "Puntos grandes amarillo, magenta y cian desregistrados con trazos negros gruesos, como un cómic de los 50."
},
"Polaroid phai": {
"en": "Faded Polaroid",
"th": "โพลารอยด์ซีด",
"es": "Polaroid desvaída"
},
"Tương phản thấp, bóng ngả xanh, sáng ngả ấm, viền tan như ảnh Polaroid cũ.": {
"en": "Low contrast, shadows tinted teal, highlights warm and a dissolving border, like an old Polaroid.",
"th": "คอนทราสต์ต่ำ เงาอมเขียวฟ้า ส่วนสว่างอมอุ่น ขอบจางหายเหมือนโพลารอยด์เก่า",
"es": "Bajo contraste, sombras verdeazuladas, luces cálidas y borde que se deshace, como una Polaroid antigua."
},
"Kodachrome": {
"en": "Kodachrome",
"th": "โกดาโครม",
"es": "Kodachrome"
},
"Màu rực, ngả ấm, đỏ đậm và hạt phim như ảnh phim màu thập niên 60.": {
"en": "Rich, warm colors with deep reds and film grain, like 1960s color film.",
"th": "สีสดอบอุ่น แดงเข้ม และมีเกรนฟิล์มเหมือนฟิล์มสียุค 60",
"es": "Colores intensos y cálidos, rojos profundos y grano de película, como el film en color de los 60."
},
"Cross-process": {
"en": "Cross-process",
"th": "ครอสโปรเซส",
"es": "Proceso cruzado"
},
"Vùng sáng ngả vàng lục, vùng tối ngả lam như tráng phim sai thuốc.": {
"en": "Highlights shift yellow-green and shadows shift blue, like film developed in the wrong chemistry.",
"th": "ส่วนสว่างอมเหลืองเขียว ส่วนมืดอมน้ำเงิน เหมือนล้างฟิล์มผิดน้ำยา",
"es": "Las luces viran a amarillo verdoso y las sombras a azul, como una película revelada con la química equivocada."
},
"Lomo": {
"en": "Lomo",
"th": "โลโม่",
"es": "Lomo"
},
"Màu bão hòa mạnh, tối bốn góc như máy ảnh Lomo.": {
"en": "Strongly saturated colors with dark corners, like a Lomo camera.",
"th": "สีอิ่มจัด มุมภาพมืดเหมือนกล้องโลโม่",
"es": "Colores muy saturados con esquinas oscuras, como una cámara Lomo."
},
"Cyanotype": {
"en": "Cyanotype",
"th": "ไซยาโนไทป์",
"es": "Cianotipia"
},
"Dải xanh lam của ảnh in phơi nắng cổ (blueprint).": {
"en": "Prussian-blue range of an old sun-printed blueprint.",
"th": "โทนน้ำเงินปรัสเซียนแบบภาพพิมพ์แดดโบราณ (บลูพรินต์)",
"es": "Gama azul de Prusia de una antigua impresión al sol (blueprint)."
},
"Duotone nâu": {
"en": "Brown duotone",
"th": "ดูโอโทนน้ำตาล",
"es": "Duotono marrón"
},
"Dải 3 tông nâu đậm, nâu sữa, kem, có hạt nhẹ.": {
"en": "Three-tone range of dark brown, café au lait and cream with light grain.",
"th": "ไล่สามโทน น้ำตาลเข้ม น้ำตาลนม ครีม มีเกรนเล็กน้อย",
"es": "Gama de tres tonos: marrón oscuro, café con leche y crema, con grano ligero."
},
"In lệch khuôn": {
"en": "Misregistered print",
"th": "พิมพ์เหลื่อม",
"es": "Impresión desregistrada"
},
"Tách 4 màu phẳng, mỗi bản in lệch một chút như máy in cũ chạy lệch.": {
"en": "Separates 4 flat colors and offsets each plate a little, like an old press running out of register.",
"th": "แยก 4 สีเรียบ แต่ละเพลตเลื่อนเล็กน้อยเหมือนแท่นพิมพ์เก่าที่พิมพ์ไม่ตรง",
"es": "Separa 4 colores planos y desplaza un poco cada plancha, como una prensa vieja fuera de registro."
},
"Nhãn hộp diêm": {
"en": "Matchbox label",
"th": "ฉลากกล่องไม้ขีด",
"es": "Etiqueta de cerillas"
},
"Ba màu phẳng, giấy mòn loang lổ như nhãn hộp diêm xưa.": {
"en": "Three flat colors on worn, patchy paper, like an old matchbox label.",
"th": "สามสีเรียบบนกระดาษที่สึกเป็นหย่อม เหมือนฉลากกล่องไม้ขีดสมัยก่อน",
"es": "Tres colores planos sobre papel gastado, como una antigua etiqueta de caja de cerillas."
},
"Sơn tróc": {
"en": "Peeling paint",
"th": "สีลอก",
"es": "Pintura descascarada"
},
"Lớp in bong tróc từng mảng như sơn cũ trên tường.": {
"en": "The print flakes off in patches, like old paint on a wall.",
"th": "งานพิมพ์ลอกออกเป็นแผ่นๆ เหมือนสีเก่าบนผนัง",
"es": "La impresión se desprende a trozos, como pintura vieja en una pared."
},
"Gỉ sét": {
"en": "Rust",
"th": "สนิม",
"es": "Óxido"
},
"Mảng gỉ nâu cam lan vào hình như biển kim loại cũ.": {
"en": "Orange-brown rust patches creep into the image, like an old metal sign.",
"th": "คราบสนิมสีน้ำตาลส้มลามเข้ามาในภาพ เหมือนป้ายโลหะเก่า",
"es": "Manchas de óxido marrón anaranjado invaden la imagen, como un viejo cartel metálico."
},
"Bạc nắng": {
"en": "Sun-faded",
"th": "ซีดแดด",
"es": "Desteñido por el sol"
},
"Phía trên phai màu nhiều hơn phía dưới như áo phơi nắng lâu ngày.": {
"en": "The top fades more than the bottom, like a shirt left in the sun for a long time.",
"th": "ด้านบนซีดมากกว่าด้านล่าง เหมือนเสื้อที่ตากแดดนาน",
"es": "La parte superior se decolora más que la inferior, como una prenda expuesta al sol mucho tiempo."
},
"Mực loang": {
"en": "Ink bleed",
"th": "หมึกซึม",
"es": "Tinta corrida"
},
"Mực đậm lan ra, mép hình loang không đều như in trên giấy thấm.": {
"en": "Dark ink spreads and edges bleed unevenly, like printing on absorbent paper.",
"th": "หมึกเข้มแผ่ออก ขอบภาพซึมไม่สม่ำเสมอเหมือนพิมพ์บนกระดาษซับหมึก",
"es": "La tinta oscura se expande y los bordes se corren de forma irregular, como en papel absorbente."
},
"Letterpress": {
"en": "Letterpress",
"th": "เลตเตอร์เพรส",
"es": "Tipografía (letterpress)"
},
"Màu phẳng, mực ép loang lổ chỗ đậm chỗ nhạt như in typo.": {
"en": "Flat colors with mottled pressed ink, heavier in some spots and lighter in others, like letterpress printing.",
"th": "สีเรียบ หมึกกดเป็นด่าง เข้มบ้างจางบ้างเหมือนงานพิมพ์ตัวเรียง",
"es": "Colores planos con tinta prensada moteada, más cargada en unos puntos y más débil en otros, como la impresión tipográfica."
},
"Varsity 2 màu": {
"en": "2-color varsity",
"th": "วาร์ซิตี้ 2 สี",
"es": "Varsity 2 colores"
},
"Phần đậm tô một màu, viền dày màu thứ hai, nứt nhẹ như chữ áo đội thể thao trường học Mỹ.": {
"en": "Dark parts filled with one color plus a thick outline in a second color, lightly cracked, like American college team lettering.",
"th": "ส่วนเข้มเติมสีหนึ่ง มีขอบหนาสีที่สอง แตกเล็กน้อย เหมือนตัวอักษรเสื้อทีมมหาวิทยาลัยอเมริกัน",
"es": "Partes oscuras rellenas de un color con un contorno grueso de un segundo color, ligeramente agrietado, como las letras de equipos universitarios."
},
"Tem khắc": {
"en": "Engraved stamp",
"th": "แสตมป์แกะลาย",
"es": "Sello grabado"
},
"Nét khắc ngang một màu như tem bưu chính cổ.": {
"en": "One-color horizontal engraved lines, like an old postage stamp.",
"th": "เส้นแกะแนวนอนสีเดียวเหมือนแสตมป์ไปรษณีย์โบราณ",
"es": "Líneas grabadas horizontales de una tinta, como un sello postal antiguo."
},
"Băng VHS": {
"en": "VHS tape",
"th": "เทป VHS",
"es": "Cinta VHS"
},
"Lệch kênh màu, vạch quét và dải nhiễu như băng video VHS.": {
"en": "Color channels shift, with scan lines and noise bands like a VHS videotape.",
"th": "ช่องสีเหลื่อม มีเส้นสแกนและแถบสัญญาณรบกวนเหมือนเทปวิดีโอ VHS",
"es": "Canales de color desplazados, líneas de barrido y bandas de ruido, como una cinta de vídeo VHS."
},
"Áo thrift": {
"en": "Thrift tee",
"th": "เสื้อมือสอง",
"es": "Camiseta de segunda mano"
},
"Phai nhẹ, nứt mịn, lỗ li ti như áo si-đa mua ở chợ đồ cũ.": {
"en": "Lightly faded with fine cracks and tiny holes, like a shirt from a second-hand market.",
"th": "ซีดเล็กน้อย แตกลายละเอียด มีรูเล็กๆ เหมือนเสื้อจากตลาดมือสอง",
"es": "Ligeramente desteñida, con grietas finas y pequeños agujeros, como una prenda de mercadillo."
},
"Màu tổ ong": {
"en": "Color honeycomb",
"th": "สีรังผึ้ง",
"es": "Panal de color"
},
"Giống file mẫu face_40x40: 4 màu (vàng, hồng, xanh, đen), chấm tròn lưới tổ ong, mỗi màu xoay lệch 15° để không bị moiré. Chỗ không có mực là màu áo.": {
"en": "Like the face_40x40 sample: 4 colors (yellow, pink, cyan, black), round dots on a honeycomb grid, each color rotated 15° to avoid moiré. Unprinted areas show the shirt.",
"th": "เหมือนไฟล์ตัวอย่าง face_40x40: 4 สี (เหลือง ชมพู ฟ้า ดำ) จุดกลมบนกริดรังผึ้ง แต่ละสีหมุนต่างกัน 15° เพื่อไม่ให้เกิดมัวเร่ ส่วนที่ไม่พิมพ์เผยสีเสื้อ",
"es": "Como la muestra face_40x40: 4 colores (amarillo, rosa, cian, negro), puntos en retícula de panal, cada color girado 15° para evitar muaré. Lo no impreso muestra la camiseta."
},
"Màu chấm tròn": {
"en": "Color round dots",
"th": "สีจุดกลม",
"es": "Puntos de color"
},
"Trame màu kiểu in offset: 4 màu chấm tròn góc chuẩn C15 M75 Y0 K45.": {
"en": "Offset-style color halftone: 4 colors of round dots at the standard angles C15 M75 Y0 K45.",
"th": "ฮาล์ฟโทนสีแบบออฟเซ็ต: จุดกลม 4 สีที่มุมมาตรฐาน C15 M75 Y0 K45",
"es": "Trama a color estilo offset: 4 colores de puntos redondos en los ángulos estándar C15 M75 Y0 K45."
},
"Màu đường kẻ": {
"en": "Color lines",
"th": "สีเส้น",
"es": "Líneas de color"
},
"4 màu dạng vạch kẻ, mỗi màu một góc, đan thành vân lưới màu.": {
"en": "Four colors of lines, each at its own angle, weaving a colored mesh.",
"th": "เส้น 4 สี แต่ละสีมีมุมของตัวเอง ถักเป็นตาข่ายสี",
"es": "Cuatro colores de líneas, cada uno con su ángulo, tejiendo una malla de color."
},
"Màu hạt": {
"en": "Color grain",
"th": "สีเม็ด",
"es": "Grano de color"
},
"4 màu hạt ngẫu nhiên, không có lưới nên không bao giờ moiré.": {
"en": "Four colors of random grain; no grid, so never any moiré.",
"th": "เม็ดสุ่ม 4 สี ไม่มีกริดจึงไม่เกิดมัวเร่เลย",
"es": "Cuatro colores de grano aleatorio; sin retícula, nunca hay muaré."
},
"Màu spot": {
"en": "Spot colors",
"th": "สีสปอต",
"es": "Tintas planas"
},
"Tự tìm vài màu chủ đạo, mỗi vùng in một màu phẳng; màu trùng áo được bỏ để lộ áo (kiểu Iron Muscle). In lụa: mỗi màu một phim.": {
"en": "Finds the main colors and prints each area as a flat color; the shirt color is dropped so the shirt shows through (Iron Muscle style).",
"th": "หาสีหลักของภาพ พิมพ์แต่ละบริเวณเป็นสีเรียบ สีที่ตรงกับเสื้อถูกตัดออกเพื่อเผยเสื้อ (สไตล์ Iron Muscle)",
"es": "Encuentra los colores principales e imprime cada zona en color plano; el color de la camiseta se elimina para que se vea la prenda (estilo Iron Muscle)."
},
"Màu spot hạt": {
"en": "Grainy spot colors",
"th": "สีสปอตเม็ดหยาบ",
"es": "Tintas planas granuladas"
},
"Màu spot, chỗ chuyển giữa hai màu và chỗ tan vào nền áo bằng hạt sần (kiểu Hellstar).": {
"en": "Spot colors where transitions between colors and into the shirt use gritty grain (Hellstar style).",
"th": "สีสปอตที่การเปลี่ยนสีและการจางเข้าสู่เสื้อใช้เม็ดหยาบ (สไตล์ Hellstar)",
"es": "Tintas planas cuyas transiciones entre colores y hacia la camiseta usan grano rugoso (estilo Hellstar)."
}
};
/*
 * NOVA Trame Studio 0.9 - đa ngôn ngữ (EN mặc định, VI, TH, ES).
 * Câu gốc tiếng Việt là khóa tra từ điển; {0}, {1}… là chỗ điền giá trị.
 * Từ điển DICT được ghép vào cuối file này khi đóng gói (xem tools/build_i18n.py).
 * ES5 để chạy được trên CEP cũ.
 */
(function (root) {
  var LANGS = ["en", "vi", "th", "es"];
  var DICT = root.__NOVA_DICT || {}; // DICT[câu gốc] = { en: "...", th: "...", es: "..." }

  function norm(s) { return String(s).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }

  var I = {
    lang: "en",
    langs: LANGS,
    t: function (src, args) {
      var out = src;
      if (I.lang !== "vi") {
        var e = DICT[src] || DICT[norm(src)];
        if (e && e[I.lang]) out = e[I.lang];
      }
      if (args) out = out.replace(/\{(\d+)\}/g, function (m, k) { return args[+k] !== undefined ? args[+k] : m; });
      return out;
    },
    set: function (l) {
      if (LANGS.indexOf(l) < 0) l = "en";
      I.lang = l;
      try { localStorage.setItem("nova.lang", l); } catch (e) {}
      try { document.documentElement.setAttribute("lang", l); } catch (e2) {}
    },
    /*
     * Dịch chữ tĩnh trong trang. Mỗi nút giữ câu gốc (__src) và câu đã xuất (__out);
     * nếu code đã tự đổi chữ của nút (khác __out) thì coi là chữ động và bỏ qua.
     */
    apply: function (rootEl) {
      rootEl = rootEl || document.body;
      // 1) phần tử dịch nguyên khối HTML (câu có chữ đậm xen giữa)
      var blocks = rootEl.querySelectorAll("[data-i18n-html]");
      for (var b = 0; b < blocks.length; b++) {
        var el = blocks[b];
        if (el.__srcHtml === undefined) el.__srcHtml = norm(el.innerHTML);
        el.innerHTML = I.t(el.__srcHtml);
        el.__done = true;
      }
      // 2) nút chữ thường
      walk(rootEl);
      // 3) thuộc tính title / alt / placeholder
      var all = rootEl.querySelectorAll("[title],[alt],[placeholder]");
      for (var a = 0; a < all.length; a++) {
        var x = all[a];
        ["title", "alt", "placeholder"].forEach(function (attr) {
          if (!x.hasAttribute(attr)) return;
          var key = "__src_" + attr, cur = x.getAttribute(attr);
          if (x[key] === undefined) { if (!hasKey(cur)) return; x[key] = cur; }
          else if (x["__out_" + attr] !== cur) { return; }
          var v = I.t(x[key]);
          x.setAttribute(attr, v);
          x["__out_" + attr] = v;
        });
      }
    }
  };

  function hasKey(s) { return !!(DICT[s] || DICT[norm(s)]); }

  function walk(node) {
    for (var c = node.firstChild; c; c = c.nextSibling) {
      if (c.nodeType === 1) {
        var tag = c.tagName;
        if (tag === "SCRIPT" || tag === "STYLE" || tag === "TEXTAREA" || tag === "SELECT" && c.id === "langSel") continue;
        if (c.__done) continue;
        walk(c);
      } else if (c.nodeType === 3) {
        var raw = c.nodeValue;
        if (!/\S/.test(raw)) continue;
        if (c.__src === undefined) {
          if (!hasKey(raw)) continue;
          c.__src = norm(raw);
          c.__lead = raw.match(/^\s*/)[0]; c.__trail = raw.match(/\s*$/)[0];
        } else if (c.__out !== raw) {
          continue; // code đã đổi chữ này -> chữ động
        }
        var v = c.__lead + I.t(c.__src) + c.__trail;
        c.nodeValue = v;
        c.__out = v;
      }
    }
  }

  var saved = null;
  try {
    // Default to English. One-time reset so installs that saved another language
    // still open in English for this version; the user can switch back anytime.
    if (!localStorage.getItem("nova.lang.default.en")) {
      localStorage.setItem("nova.lang.default.en", "1");
      localStorage.setItem("nova.lang", "en");
    }
    saved = localStorage.getItem("nova.lang");
  } catch (e) {}
  I.set(saved || "en");
  root.NovaI18n = I;
  if (document.body) I.apply(document.body);
})(this);
