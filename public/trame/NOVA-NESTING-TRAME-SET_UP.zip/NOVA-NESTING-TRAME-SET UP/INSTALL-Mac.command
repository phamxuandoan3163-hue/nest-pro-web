#!/bin/bash
cd "$(dirname "$0")"
SRC="$PWD/com.nova.tramestudio"
DST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.nova.tramestudio"
if [ ! -f "$SRC/CSXS/manifest.xml" ]; then echo "Could not find the com.nova.tramestudio folder."; read -p "Press Enter to close."; exit 1; fi
for v in 6 7 8 9 10 11 12; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
mkdir -p "$(dirname "$DST")"; rm -rf "$DST"; cp -R "$SRC" "$DST"
echo "Installation complete. Reopen Photoshop, then Window > Extensions (legacy) > NOVA Trame Studio."
read -p "Press Enter to close."
