@echo off
setlocal
title Uninstall NOVA Trame Studio
set "DST=%APPDATA%\Adobe\CEP\extensions\com.nova.tramestudio"
if exist "%DST%" rmdir /s /q "%DST%"
echo NOVA Trame Studio has been removed. Please reopen Photoshop.
echo.
pause
