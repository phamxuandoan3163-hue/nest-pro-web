NOVA NESTING AI - MARKER MAKING & NESTING
Adobe Illustrator panel (CEP). Version 2.6.7.

INSTALL
  Windows: run install_win.bat (double-click).
  macOS:   run  bash install_mac.sh
  Then restart Illustrator and open: Window > Extensions > Nova Nesting AI.
  (The installer enables PlayerDebugMode because the panel is unsigned. To install by
   hand, copy the NovaNest folder into
     %APPDATA%\Adobe\CEP\extensions\            (Windows)
     ~/Library/Application Support/Adobe/CEP/extensions/   (macOS) )

WHAT IT DOES
  Scan -> Pair sizes -> Nest -> Check -> Export. The panel reads the pattern pieces of each
  size, pairs sizes efficiently with the Nest-Pro Sparrow engine, builds one marker file per
  layout (one layer per size), checks them, then exports the .ai files plus a CSV report.

LANGUAGE
  English (default), Vietnamese, Thai, Spanish. Switch with the EN/VI/TH/ES selector at the
  top right. The whole UI, the log, result tables, progress window and CSV header follow it.
  (Text printed onto the marker file uses English in Thai mode, because Illustrator's default
   font has no Thai glyphs.)

LICENSE
  The License tab appears until the panel is activated; after that the panel opens straight on
  the work screen, and the "License" button at the top reopens the tab to view the plan or renew.
  Enter a purchased key, or start a free 7-day trial (once per computer), or use offline
  activation when the network is blocked. A license is required to Scan, Pair, Nest and Export.
  Plans: Monthly / Yearly (1 computer), Yearly Pro (2 computers).
  Offline use works for up to 24 hours after the last online check. Setting the computer clock
  back blocks offline use until the clock is corrected.

SUPPORT
  If something fails, open the Log (top right), copy its contents and send them over.

REVISION NOTES (2.6.7)
  - Release package no longer includes the .debug file (debug ports are not published).

REVISION NOTES (2.6.6)
  - Progress is shown inside the panel only; the separate progress window is no longer opened,
    so the bar appears immediately when Pair or Nest starts.

REVISION NOTES (2.6.5)
  - Each time the panel opens it starts on the Scan step with no results from the previous order
    (the size list is kept).
  - Result tables (Nest, Pair, Export) no longer wrap file names letter by letter; they scroll sideways.

REVISION NOTES (2.6.4)
  - Pair and Nest buttons stay disabled until the Sparrow engine has loaded; then the panel logs
    "Engine ready" and the run starts with the progress window already in step.

REVISION NOTES (2.6.3)
  - The panel can install a newer version itself: "Update now" downloads the package from the
    website, checks its SHA-256, and copies it in (the old files are restored if anything fails).
    Restart Illustrator afterwards to use the new version.

REVISION NOTES (2.6.2)
  - Added "Back to scan and clear this order" (bottom of the Nest and Export steps): clears the
    size list, results and the work folder, then returns to Scan. The pattern library is kept.
  - Faster start for Nest and Pair: worker threads start in parallel, and the progress bar moves
    slightly while the engine starts instead of sitting still.
  - Progress window: fixed a malformed document type.

REVISION NOTES (2.6.1)
  - Fixed: "Run simulation & pairing" did nothing after the simulation step (a helper function
    was declared in the wrong scope, so the marker names could not be built).
  - The panel now checks the website for a newer version and shows a notice with a download link.

REVISION NOTES (2.6.0, round 2)
  - Fixed: a marker made of 2 garments of the same size (e.g. M+M) now builds 2 layers,
    named <size> and <size>1 (e.g. "M" and "M1"), each holding the full piece set of one
    garment. Previously both garments landed in a single layer of the same name.
  - Removed the "length and efficiency were re-checked... / single-size markers with an
    even number of plies..." explanation text from the pairing result screen.
  - Export is no longer its own tab; its button and table are now at the bottom of the
    Check tab, so the panel has 4 tabs (Scan, Pair sizes, Nest, Check) instead of 5.
  - Exported file names now use the selected language's word for "ply" and "scale"
    (e.g. "M_25ply" in English, "M_25lop" in Vietnamese) instead of always Vietnamese.
  - Logo (full lockup, unchanged) is now shown smaller, capped at 220px wide instead of
    stretched to the panel's full width.
  - The Nest step now explains, before it starts, that Illustrator can briefly stop
    responding while it prepares a pattern design for a size not already used this session
    (expanding a pattern fill is a single Illustrator action and cannot be done in smaller
    steps) — this was previously silent and could look like a freeze.
