@echo off
chcp 65001 >nul
echo Installing Nova Nesting AI...
for %%v in (9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
set "DEST=%APPDATA%\Adobe\CEP\extensions\NovaNest"
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy /E /I /Y /Q "%~dp0." "%DEST%" >nul
echo Done. Restart Illustrator, then open Window ^> Extensions ^> Nova Nesting AI.
pause
