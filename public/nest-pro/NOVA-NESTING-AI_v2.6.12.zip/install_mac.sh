#!/bin/bash
for v in 9 10 11 12; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/NovaNest"
rm -rf "$DEST"; mkdir -p "$DEST"
cp -R "$(cd "$(dirname "$0")" && pwd)/." "$DEST/"
echo "Done. Restart Illustrator, then open Window > Extensions > Nova Nesting AI."
