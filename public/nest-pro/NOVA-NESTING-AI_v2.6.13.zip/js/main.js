﻿(function () {
    'use strict';
    var NN = window.NN;
    var PT = 28.346456692913385;           // pt / cm
    var $ = function (id) { return document.getElementById(id); };
    // i18n (js/i18n.js): T('English source {0}', [value]) -> text in the current language.
    function T(src, args) {
        if (window.NovaI18n) return window.NovaI18n.t(src, args);
        return args ? String(src).replace(/\{(\d+)\}/g, function (m, k) { return args[+k] !== undefined ? args[+k] : m; }) : src;
    }
    // Text written into the marker file itself: Illustrator's default font has no Thai glyphs, so Thai uses English there.
    function TF(src, args) {
        var I = window.NovaI18n;
        return I && I.lang === 'th' && I.tIn ? I.tIn('en', src, args) : T(src, args);
    }
    function curLang() { return window.NovaI18n ? window.NovaI18n.lang : 'en'; }

    // Settings shown in the panel (defaults = the reference values in the 2.6.0 requirements).
    var DEFAULTS = { cWidth: 150, cGap: 0.2, cML: 0.1, cMR: 0.1, cMT: 0.1, cMB: 0.1, cRotMode: 1, cStroke: false, cAskSave: true, cClip: true, cSkipNest: true, cPdfCompat: true };
    // 2.6.0: the advanced settings are no longer in the panel; these fixed values are used instead.
    var FIXED = { effTol: 2, fileSlackPct: 2, penaltyM: 0, simTimeMs: 1500, pruneTol: 3, testTimeMs: 5000, nestTimeMs: 12000, pdf: false };
    var SIZE_LIST = ['5XS', '4XS', '3XS', '2XS', 'XS', 'S', 'M', 'L', 'XL', '2XL', '3XL', '4XL', '5XL', '6XL', '7XL', '8XL'];
    var state = { sizes: [], plan: null, approved: false, busy: false, cancel: false, selected: '', simDb: {}, dirty: false, step: 1, layouts: null, checks: [], checked: false, checkBlock: false };
    // Pair and Nest wait until the Sparrow engine (worker threads) is loaded, so a run never starts while the panel is still loading.
    var engineReady = false;

    // ---------- thanh tiáº¿n trÃ¬nh: cá»­a sá»• riÃªng (extension Modeless "progress.html") ----------
    // Truyá»n tráº¡ng thÃ¡i qua 2 Ä‘Æ°á»ng cÃ¹ng lÃºc Ä‘á»ƒ cháº¯c cháº¯n tá»›i nÆ¡i:
    //   (1) file nhá» NovaNest_progress.json trong thÆ° má»¥c userData (cá»­a sá»• tiáº¿n trÃ¬nh Ä‘á»c 8 láº§n/giÃ¢y),
    //   (2) sá»± kiá»‡n CEP com.novanest.progress.
    // Cá»­a sá»• tá»± Ä‘Ã³ng NGAY khi nháº­n lá»‡nh close. NÃºt Dá»«ng á»Ÿ cá»­a sá»• ghi file NovaNest_cancel.json, panel Ä‘á»c Ä‘á»ƒ dá»«ng.
    var PROG_EXT = 'com.novanest.panel.progress';
    var PROG_EVT = 'com.novanest.progress';
    var cep = window.__adobe_cep__;
    var prog = { max: 0, last: null, sentAt: 0, seq: 0, run: '', poll: null, pending: null };

    function sysPath(t) {
        try {
            var p = decodeURIComponent(cep.getSystemPath(t)).replace(/^file:\/\//, '');
            if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
            return p;
        } catch (e) { return ''; }
    }
    var PDIR = cep ? sysPath('userData') : '';
    var LIBDIR = PDIR ? PDIR + '/NovaNest_kho' : '';      // kho: Báº¢N CHÃ‰P cÃ¡c file ráº­p Ä‘Ã£ quÃ©t (file gá»‘c khÃ´ng bá»‹ sá»­a)
    var WORKDIR = (PDIR || '') + '/NovaNest_work';         // thÆ° má»¥c lÃ m viá»‡c: file sÆ¡ Ä‘á»“ táº¡m, ngÆ°á»i dÃ¹ng khÃ´ng pháº£i tháº¥y
    var PFILE = PDIR ? PDIR + '/NovaNest_progress.json' : '';
    var CFILE = PDIR ? PDIR + '/NovaNest_cancel.json' : '';
    function fsWrite(path, text) { try { if (path && window.cep && cep && window.cep.fs) window.cep.fs.writeFile(path, text); } catch (e) { /* bá» qua */ } }
    function fsRead(path) {
        try { if (path && window.cep && window.cep.fs) { var r = window.cep.fs.readFile(path); if (r && !r.err) return r.data; } } catch (e) { /* bá» qua */ }
        return '';
    }
    function hostAppId() { try { return JSON.parse(cep.getHostEnvironment()).appId; } catch (e) { return 'ILST'; } }

    function sendProg(msg) {
        prog.seq++;
        msg.seq = prog.seq;
        msg.lang = curLang();
        msg.run = prog.run;
        prog.last = msg;
        prog.sentAt = Date.now();
        // Progress is shown in the panel only (no separate progress window).
        renderInlineProg(msg);
        if (!cep) return;
        var text = JSON.stringify(msg);
        fsWrite(PFILE, text);
        try { cep.dispatchEvent({ type: PROG_EVT, scope: 'APPLICATION', appId: hostAppId(), extensionId: '', data: text }); } catch (e) { /* bá» qua */ }
    }
    function renderInlineProg(m) {   // chá»‰ dÃ¹ng khi thá»­ giao diá»‡n ngoÃ i Illustrator
        $('progressBox').hidden = !!m.close;
        if (m.close) return;
        $('barFill').style.width = ((m.frac || 0) * 100).toFixed(1) + '%';
        $('pLabel').textContent = m.label;
        $('pCap').textContent = m.cap || '';
    }
    function progReset() {
        prog.max = 0;
        prog.run = String(Date.now());
        if (prog.pending) { clearTimeout(prog.pending); prog.pending = null; }
        fsWrite(CFILE, '');
        sendProg({ frac: 0, label: 'LOADING  0%', cap: T('Starting...') });   // ghi trÆ°á»›c khi má»Ÿ Ä‘á»ƒ cá»­a sá»• Ä‘á»c Ä‘Æ°á»£c ngay
        if (cep) {
            /* no separate progress window: see sendProg */
            if (prog.poll) clearInterval(prog.poll);
            prog.poll = setInterval(function () {   // nÃºt Dá»«ng á»Ÿ cá»­a sá»• tiáº¿n trÃ¬nh
                var t = fsRead(CFILE);
                if (t && t.indexOf(prog.run) >= 0) { fsWrite(CFILE, ''); if (state.busy) stopAll(); }
            }, 250);
        }
    }
    function progEnd() {
        if (prog.pending) { clearTimeout(prog.pending); prog.pending = null; }
        if (prog.poll) { clearInterval(prog.poll); prog.poll = null; }
        sendProg({ close: true });   // Ä‘Ã³ng cá»­a sá»• ngay
    }
    function setProg(frac, cap, label, upto, etaMs) {
        var msg = prog.last && !prog.last.close ? { frac: prog.last.frac, label: prog.last.label, cap: prog.last.cap } : { frac: 0, label: '', cap: '' };
        if (frac !== null && frac !== undefined) {
            frac = Math.max(prog.max, Math.max(0, Math.min(1, frac)));
            prog.max = frac;
            msg.frac = frac;
            msg.label = label || ('LOADING  ' + Math.floor(frac * 100) + '%');
        } else if (label) msg.label = label;
        if (cap !== undefined && cap !== null) msg.cap = cap;
        // má»‘c káº¿ tiáº¿p + thá»i gian dá»± kiáº¿n Ä‘á»ƒ cá»­a sá»• tiáº¿n trÃ¬nh tá»± trÆ°á»£t mÆ°á»£t trong lÃºc chá»
        msg.upto = upto !== undefined ? Math.max(msg.frac, Math.min(1, upto)) : msg.frac;
        msg.eta = etaMs || 0;
        // giá»›i háº¡n ~10 láº§n/giÃ¢y, nhÆ°ng luÃ´n gá»­i báº£n cuá»‘i cÃ¹ng
        var wait = 100 - (Date.now() - prog.sentAt);
        if (prog.pending) clearTimeout(prog.pending);
        if (wait <= 0) { prog.pending = null; sendProg(msg); }
        else prog.pending = setTimeout(function () { prog.pending = null; sendProg(msg); }, wait);
    }
    if (cep) {
        try {
            cep.addEventListener(PROG_EVT + '.ready', function () { if (prog.last) sendProg(Object.assign({}, prog.last)); });
            cep.addEventListener(PROG_EVT + '.cancel', function () { if (state.busy) stopAll(); });
        } catch (e) { /* bá» qua */ }
    }

    // ---------- tiá»‡n Ã­ch ----------
    function log(msg) {
        var el = $('log');
        el.textContent += msg + '\n';
        el.scrollTop = el.scrollHeight;
        if ($('logModal').hidden && /lá»—i|cáº£nh bÃ¡o|chÆ°a|khÃ´ng|error|warning|not |could not|à¸‚à¹‰à¸­à¸œà¸´à¸”à¸žà¸¥à¸²à¸”|à¸„à¸³à¹€à¸•à¸·à¸­à¸™|à¹„à¸¡à¹ˆ|advertencia|no se|todavÃ­a no/i.test(msg)) $('logDot').hidden = false;
    }
    function tick() { return new Promise(function (r) { setTimeout(r, 20); }); }
    function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
    function f1(x) { return (Math.round(x * 10) / 10).toFixed(1); }
    function f2(x) { return (Math.round(x * 100) / 100).toFixed(2); }
    function f3(x) { return (Math.round(x * 1000) / 1000).toFixed(3); }
    function polyArea(pts) {
        var a = 0;
        for (var i = 0; i < pts.length; i++) { var j = (i + 1) % pts.length; a += pts[i][0] * pts[j][1] - pts[j][0] * pts[i][1]; }
        return Math.abs(a) / 2;
    }
    // diá»‡n tÃ­ch thá»±c (cmÂ²): Ä‘Æ°á»ng bao lá»›n nháº¥t trá»« cÃ¡c lá»—
    // 2.2.2: 1 chi tiáº¿t cÃ³ thá»ƒ gá»“m nhiá»u Ä‘Æ°á»ng cáº¯t (group). Engine tÃ´ kÃ­n tá»«ng Ä‘Æ°á»ng rá»“i há»£p láº¡i,
    // nÃªn bá» cÃ¡c Ä‘Æ°á»ng náº±m trá»n trong Ä‘Æ°á»ng khÃ¡c (lá»—, chi tiáº¿t con) vÃ  cá»™ng diá»‡n tÃ­ch cÃ¡c pháº§n cÃ²n láº¡i.
    function ptIn(x, y, poly) {
        var inside = false;
        for (var i = 0, j = poly.length - 1; i < poly.length; j = i++) {
            var a = poly[i], b = poly[j];
            if (((a[1] > y) !== (b[1] > y)) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside;
        }
        return inside;
    }
    function cleanOutline(outline) {
        if (!outline || outline.length < 2) return outline;
        var ar = outline.map(polyArea);
        return outline.filter(function (p, i) {
            for (var k = 0; k < outline.length; k++) {
                if (k === i || ar[k] < ar[i]) continue;
                if (ar[k] === ar[i] && k > i) continue;
                var allIn = true;
                for (var q = 0; q < p.length && allIn; q += Math.max(1, Math.floor(p.length / 24))) if (!ptIn(p[q][0], p[q][1], outline[k])) allIn = false;
                if (allIn) return false;
            }
            return true;
        });
    }
    function netAreaCm2(outline) {
        var a = 0;
        cleanOutline(outline).forEach(function (p) { a += polyArea(p); });
        return a / (PT * PT);
    }

    // ---------- báº£ng chá»n size ----------
    function sizeRank(n) { var i = SIZE_LIST.indexOf(n); return i < 0 ? 999 : i; }
    function sortSizes() { state.sizes.sort(function (a, b) { return sizeRank(a.name) - sizeRank(b.name); }); }
    function renderChips() {
        var done = {};
        state.sizes.forEach(function (s) { done[s.name] = true; });
        $('sizeChips').innerHTML = SIZE_LIST.map(function (n) {
            return '<button type="button" class="chip' + (state.selected === n ? ' sel' : '') + (done[n] ? ' done' : '') + '" data-size="' + n + '">' + n + '</button>';
        }).join('');
    }
    function selectSize(n) {
        state.selected = n;
        renderChips();
    }
    function selectNext(n) {
        var done = {};
        state.sizes.forEach(function (s) { done[s.name] = true; });
        for (var i = SIZE_LIST.indexOf(n) + 1; i < SIZE_LIST.length; i++) {
            if (!done[SIZE_LIST[i]]) { state.selected = SIZE_LIST[i]; return; }
        }
        state.selected = '';
    }

    // ---------- cÃ i Ä‘áº·t ----------
    function loadCfg() {
        var saved = {};
        try {
            saved = JSON.parse(localStorage.getItem('novanest.cfg6') || 'null');
            if (!saved) { saved = JSON.parse(localStorage.getItem('novanest.cfg5') || '{}'); ['cML', 'cMR', 'cMT', 'cMB'].forEach(function (k) { delete saved[k]; }); }
        } catch (e) { saved = {}; }
        if (saved.cRotMode === undefined && saved.cRot !== undefined) saved.cRotMode = saved.cRot ? 1 : 0;   // chuyá»ƒn tá»« báº£n cÅ©
        if (saved.cMargin !== undefined) ['cML', 'cMR', 'cMT', 'cMB'].forEach(function (k) { if (saved[k] === undefined) saved[k] = saved.cMargin; });
        Object.keys(DEFAULTS).forEach(function (k) {
            var v = saved[k] !== undefined ? saved[k] : DEFAULTS[k];
            var el = $(k);
            if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
            el.addEventListener('change', function () {
                saveCfg();
                if (k === 'cStroke' || k === 'cAskSave' || k === 'cClip' || k === 'cSkipNest' || k === 'cPdfCompat') return;   // khÃ´ng áº£nh hÆ°á»Ÿng káº¿t quáº£ Ä‘Ã£ xáº¿p
                invalidate(); validate();
            });
        });
        var k2 = '3';
        try { k2 = localStorage.getItem('novanest.maxSizes') || '3'; } catch (e) { /* bá» qua */ }
        $(k2 === '2' ? 'rK2' : 'rK3').checked = true;
    }
    function resetCfg() {
        Object.keys(DEFAULTS).forEach(function (k) { var el = $(k); if (el.type === 'checkbox') el.checked = !!DEFAULTS[k]; else el.value = DEFAULTS[k]; });
        saveCfg(); invalidate(); validate();
        log(T('Settings restored to defaults.'));
    }
    function saveCfg() {
        var o = {};
        Object.keys(DEFAULTS).forEach(function (k) { var el = $(k); o[k] = el.type === 'checkbox' ? el.checked : el.value; });
        try { localStorage.setItem('novanest.cfg6', JSON.stringify(o)); } catch (e) { /* bá» qua */ }
    }
    function cfg() {
        var n = function (id) { return parseFloat(String($(id).value).replace(',', '.')); };
        return {
            widthCm: n('cWidth'), gapCm: n('cGap') || 0,
            mL: Math.max(0, n('cML') || 0), mR: Math.max(0, n('cMR') || 0), mT: Math.max(0, n('cMT') || 0), mB: Math.max(0, n('cMB') || 0),
            penaltyM: FIXED.penaltyM, maxSizes: $('rK2').checked ? 2 : 3,
            simTimeMs: FIXED.simTimeMs,
            nestTimeMs: FIXED.nestTimeMs,
            pruneTol: FIXED.pruneTol,
            testTimeMs: FIXED.testTimeMs,
            effTol: FIXED.effTol,
            fileSlackPct: FIXED.fileSlackPct,
            rotMode: parseInt($('cRotMode').value, 10) || 0, pdf: FIXED.pdf, stroke: $('cStroke').checked, clip: $('cClip').checked, skipNest: $('cSkipNest').checked, pdfCompat: $('cPdfCompat').checked
        };
    }
    function usableCm(c) { return c.widthCm - c.mL - c.mR; }

    // ---------- lÆ°u danh sÃ¡ch size ----------
    function saveSizes() { try { localStorage.setItem('novanest.sizes2', JSON.stringify(state.sizes)); } catch (e) { log(T('Could not store the size list in the panel memory (too large); the data still works in this session.')); } }
    function loadSizes() {
        try { state.sizes = JSON.parse(localStorage.getItem('novanest.sizes2') || '[]'); } catch (e) { state.sizes = []; }
        sortSizes();
    }

    function invalidate() {
        state.plan = null;
        state.approved = false;
        state.layouts = null; state.checks = []; state.checked = false; state.checkBlock = false;
        $('secPlan').hidden = true;
        $('tblNest').innerHTML = ''; $('tblCheck').innerHTML = ''; $('checkSum').innerHTML = ''; $('tblRun').innerHTML = '';
        while (state.step > 1 && !stepAvail(state.step)) state.step--;
        refreshSteps();
    }

    // ---------- cÃ¡c bÆ°á»›c (stepper) ----------
    function stepAvail(n) {
        if (n === 1) return true;
        if (n === 2) return state.sizes.some(function (s) { return s.qty > 0; });
        if (n === 3) return !!state.approved;
        if (n === 4) return !!state.layouts;
        if (n === 5) return !!state.layouts && state.checked && !state.checkBlock;
        return false;
    }
    function stepDone(n) {
        if (n === 1) return state.sizes.some(function (s) { return s.qty > 0; });
        if (n === 2) return !!state.approved;
        if (n === 3) return !!state.layouts;
        if (n === 4) return state.checked && !state.checkBlock;
        return false;
    }
    function refreshSteps() {
        var i, btns = $('stepper').querySelectorAll('button');
        // step4 now holds both Check and Export (merged tabs); there is no step5 div.
        for (i = 1; i <= 4; i++) $('step' + i).hidden = state.step !== i;
        for (i = 0; i < btns.length; i++) {
            var n = +btns[i].getAttribute('data-step');
            btns[i].classList.toggle('on', n === state.step);
            btns[i].classList.toggle('done', stepDone(n));
            btns[i].disabled = !stepAvail(n) || state.busy;
        }
        $('btnExport').disabled = !stepAvail(5) || state.busy;
    }
    function goStep(n) {
        if (!stepAvail(n)) return false;
        state.step = n;
        refreshSteps();
        return true;
    }

    // ---------- bÆ°á»›c 1-3: quÃ©t ----------
    async function addSize() {
        if (state.busy) return;
        var name = state.selected;
        if (!name) { log(T('Choose a size in the table.')); return; }
        var btn = $('btnScan'), oldTxt = btn.textContent;
        btn.disabled = true; btn.textContent = T('Scanning and saving design for size {0}...', [name]);
        var t0 = Date.now();
        var r = await NN.host('nn_scan', { size: name, lib: LIBDIR });
        btn.disabled = false; btn.textContent = oldTxt;
        if (r.error) { log(T('Scan error: {0}', [r.error])); return; }
        var sec = (Date.now() - t0) / 1000;
        var pieces = r.pieces.map(function (p) {
            var ol = cleanOutline(p.outline);
            return { uid: p.uid, tag: p.tag || '', loc: p.loc || null, tn: p.tn || '', gb: p.gb || null, name: p.name, outline: ol, parts: p.parts || 1, curved: p.curved, npts: p.npts, off: p.off,
                     w: p.w / PT, h: p.h / PT, area: netAreaCm2(ol) };
        });
        var prev = state.sizes.filter(function (s) { return s.name === name; })[0];
        var size = {
            name: name, qty: prev ? prev.qty : 0, docName: r.doc, docPath: r.docPath || '', srcPath: r.srcPath || '', cs: /RGB/i.test(r.cs || '') ? 'RGB' : (/CMYK/i.test(r.cs || '') ? 'CMYK' : ''), design: !!r.design, srcName: r.src || '', pieces: pieces,
            areaCm2: pieces.reduce(function (s, p) { return s + p.area; }, 0),
            maxH: Math.max.apply(null, pieces.map(function (p) { return p.h; })),
            maxW: Math.max.apply(null, pieces.map(function (p) { return p.w; })),
            scanSec: sec
        };
        var i = state.sizes.findIndex(function (s) { return s.name === name; });
        if (i >= 0) { state.sizes[i] = size; log(T(prev ? 'Rescanned size {0}: {1} pieces, {2} dmÂ², {3} s.' : 'Added size {0}: {1} pieces, {2} dmÂ², {3} s.', [name, pieces.length, f1(size.areaCm2 / 100), f1(sec)])); }
        else { state.sizes.push(size); log(T('Added size {0}: {1} pieces, {2} dmÂ², {3} s.', [name, pieces.length, f1(size.areaCm2 / 100), f1(sec)])); }
        var fnm = String(r.docPath || '').replace(/\\/g, '/').split('/').pop();
        if (r.savedAs === 'saveas-dirty') log('  ' + T(r.where === 'library' ? 'File "{0}" has unsaved changes: Nova Nest did NOT overwrite it, but saved what you see as a new file "{1}" in the Nova Nest library. The open window is now this new file; the original file on disk is unchanged.' : 'File "{0}" has unsaved changes: Nova Nest did NOT overwrite it, but saved what you see as a new file "{1}" in the NovaNest_rap folder. The open window is now this new file; the original file on disk is unchanged.', [String(r.orig || '').replace(/\\/g, '/').split('/').pop(), fnm]));
        else if (r.savedAs === 'saveas') log('  ' + T('The file had never been saved, so it was saved as "{0}" in the Nova Nest library.', [fnm]));
        else if (r.where === 'self') log('  ' + T('This file is already in the NovaNest_rap folder; using it directly.'));
        else log('  ' + T(r.copied ? 'Saved a new file "{0}"' : 'Using the existing file "{0}"', [fnm]) + ' ' + T(r.where === 'library' ? 'in the Nova Nest library (the pattern file\'s folder is not writable)' : 'in the NovaNest_rap folder next to the pattern file') + '. ' + T('The original file "{0}" is unchanged.', [size.docName]));
        var nMulti = pieces.filter(function (p) { return p.parts > 1; }).length;
        if (nMulti) log('  ' + T('{0} groups with several cut lines were kept as one piece each (not split).', [nMulti]));
        if (r.skipped) log('  ' + T('(skipped {0} objects without a closed path, such as text)', [r.skipped]));
        sortSizes();
        selectNext(name);
        saveSizes();
        state.dirty = true;
        invalidate();
        renderSizes();
        var idx = state.sizes.findIndex(function (s) { return s.name === name; });
        var inp = idx >= 0 ? document.querySelector('#tblSizes input[data-q="' + idx + '"]') : null;
        if (inp && !(size.qty > 0)) { try { inp.focus(); } catch (eF) { /* bá» qua */ } }
    }

    // ---------- lÆ°u / má»Ÿ bá»™ ráº­p (toÃ n bá»™ size Ä‘Ã£ quÃ©t, há»i khi sang bÆ°á»›c ghÃ©p cáº·p) ----------
    var saveCtx = null;
    function safeFile(t) { return String(t).replace(/[^A-Za-z0-9_\-]/g, '_'); }
    function sizeToObj(s, libs) {
        var o = { name: s.name, qty: s.qty, docName: s.docName, docPath: s.docPath || '', srcPath: s.srcPath || '', cs: s.cs || '', design: !!s.design, areaCm2: s.areaCm2, maxH: s.maxH, maxW: s.maxW, pieces: s.pieces };
        if (libs && libs[s.name]) { o.libFile = libs[s.name]; o.docName = libs[s.name]; o.docPath = ''; }   // kho design chÃ©p cáº¡nh file bá»™ ráº­p
        return o;
    }
    function setToJson(sizes, libs) {
        return JSON.stringify({ app: 'NovaNest', version: 3, savedAt: new Date().toISOString(), sizes: sizes.map(function (s) { return sizeToObj(s, libs); }) });
    }
    function defaultSetName(sizes) {
        var pre = ($('namePrefix').value || '').trim();
        var rng = sizes.length > 1 ? sizes[0].name + '-' + sizes[sizes.length - 1].name : sizes[0].name;
        return (pre ? pre + '_' : '') + rng;
    }
    function askSave() {
        return new Promise(function (resolve) {
            var sizes = state.sizes.slice();
            saveCtx = { sizes: sizes, dir: '', done: resolve, ok: false };
            var pc = sizes.reduce(function (n, s) { return n + s.pieces.length; }, 0);
            $('saveTitle').textContent = T('Save pattern set ({0} sizes)?', [sizes.length]);
            $('saveInfo').textContent = sizes.map(function (s) { return s.name + 'Ã—' + s.qty; }).join('  ') + ' Â· ' + T('{0} pieces in total', [pc]);
            $('saveStep1').hidden = false; $('saveStep2').hidden = true; $('saveWarn').hidden = true;
            $('saveModal').hidden = false;
        });
    }
    function closeSave(msg, markDone) {
        $('saveModal').hidden = true;
        var c = saveCtx; saveCtx = null;
        if (markDone) state.dirty = false;
        if (msg) log(msg);
        if (c) c.done();
    }
    async function pickSaveFolder() {
        var nm0 = ($('saveName').value || defaultSetName(saveCtx.sizes)).replace(/\.nnset\.json$/i, '') + '.nnset.json';
        var d = await NN.host('nn_pick_folder', { save: true, start: lastDir(), name: nm0, filter: T('Nova Nest pattern set') + ':*.nnset.json', title: T('Save pattern set (you can paste a folder path)') });
        if (d.error) { log(T('Error: {0}', [d.error])); return false; }
        if (!d.path) return false;
        rememberDir(d.path);
        if (d.name) { $('saveName').value = d.name.replace(/\.nnset\.json$/i, '').replace(/\.json$/i, ''); saveCtx.picked = true; }       // ngÆ°á»i dÃ¹ng Ä‘Ã³ng há»™p thoáº¡i
        saveCtx.dir = d.path;
        $('saveDir').textContent = T('Folder: {0}', [d.path]);
        return true;
    }
    async function saveYes() {
        if (!saveCtx) return;
        $('saveName').value = defaultSetName(saveCtx.sizes);
        saveCtx.picked = false;
        if (!(await pickSaveFolder())) { closeSave(T('Pattern set not saved.'), true); return; }
        if (saveCtx.picked) { saveCtx.overwrite = true; await saveGo(); return; }   // Ä‘Ã£ chá»n chá»— + tÃªn trong há»™p Save: lÆ°u luÃ´n
        $('saveWarn').hidden = true; saveCtx.overwrite = false;
        $('saveStep1').hidden = true; $('saveStep2').hidden = false;
        $('saveName').focus(); $('saveName').select();
    }
    async function saveGo() {
        if (!saveCtx) return;
        var name = $('saveName').value.trim();
        if (!name) { $('saveName').focus(); return; }
        var base = name.replace(/\.nnset\.json$/i, '').replace(/[\\/:*?"<>|]/g, '_');
        if (!saveCtx.overwrite) {
            var ck = await NN.host('nn_check_files', { paths: [saveCtx.dir + '/' + base + '.nnset.json'] });
            if (!ck.error && ck.exists && ck.exists[0]) { saveCtx.overwrite = true; $('saveWarn').hidden = false; return; }
        }
        var libs = {};
        var r = await NN.host('nn_write_set', { dir: saveCtx.dir, name: base, text: setToJson(saveCtx.sizes, libs), overwrite: true });
        if (r.error) { log(T('Error saving pattern set: {0}', [r.error])); return; }
        closeSave(T('Saved pattern set with {0} sizes: {1}', [saveCtx.sizes.length, r.path]), true);
    }
    async function saveNow() {          // nÃºt "Save pattern set..." á»Ÿ bÆ°á»›c 4
        if (state.busy) return;
        if (!state.sizes.length) { log(T('There are no sizes to save.')); return; }
        await askSave();
    }
    function setSizesFromFile(o, dir) {      // há»— trá»£ file cÅ© (1 size), file nhiá»u size vÃ  file cÃ³ kho design Ä‘i kÃ¨m
        var arr = o && o.app === 'NovaNest' ? (o.sizes ? o.sizes : (o.name && o.pieces ? [o] : [])) : [];
        return arr.filter(function (x) { return x && x.name && x.pieces && x.pieces.length; }).map(function (x) {
            var pcs = x.pieces.map(function (p) {
                return { uid: p.uid, tag: p.tag || '', loc: p.loc || null, tn: p.tn || '', gb: p.gb || null, name: p.name, outline: p.outline, curved: p.curved, npts: p.npts, off: p.off, w: p.w, h: p.h, area: p.area };
            });
            var sz = { name: x.name, qty: x.qty || 0, docName: x.docName, docPath: x.docPath || '', srcPath: x.srcPath || '', cs: x.cs || '', design: !!x.design, pieces: pcs,
                     areaCm2: x.areaCm2 || pcs.reduce(function (s, p) { return s + p.area; }, 0),
                     maxH: x.maxH || Math.max.apply(null, pcs.map(function (p) { return p.h; })),
                     maxW: x.maxW || Math.max.apply(null, pcs.map(function (p) { return p.w; })) };
            if (x.libFile) { sz.docName = x.libFile; sz.docPath = dir + '/' + x.libFile; sz.design = true; }
            return sz;
        });
    }
    async function openSets() {
        if (state.busy) return;
        var d = await NN.host('nn_pick_sets', {});
        if (d.error) { log(T('Error: {0}', [d.error])); return; }
        if (!d.paths || !d.paths.length) return;
        var added = 0;
        for (var i = 0; i < d.paths.length; i++) {
            var f = await NN.host('nn_read_set', { path: d.paths[i] });
            if (f.error) { log(T('Error opening pattern set: {0}', [f.error])); continue; }
            var o;
            try { o = JSON.parse(f.text); } catch (e) { log(T('Error: cannot read file {0}', [d.paths[i]])); continue; }
            var dir = d.paths[i].replace(/[\\/][^\\/]*$/, '');
            var list = setSizesFromFile(o, dir);
            if (!list.length) { log(T('Error: not a Nova Nest pattern set {0}', [d.paths[i]])); continue; }
            for (var j = 0; j < list.length; j++) {
                var size = list[j];
                var k = state.sizes.findIndex(function (s) { return s.name === size.name; });
                if (k >= 0) state.sizes[k] = size; else state.sizes.push(size);
                added++;
                log(T(size.qty > 0 ? 'Opened pattern set size {0}: {1} pieces, quantity {2}.' : 'Opened pattern set size {0}: {1} pieces.', [size.name, size.pieces.length, size.qty]));
                if (size.design) {
                    var ck = await NN.host('nn_check_files', { paths: [size.docPath] });
                    if (!ck.error && ck.exists && ck.exists[0] === false) log(T('Warning: design file "{0}" for size {1} was not found (moved or deleted?). Scan this size again.', [size.docPath, size.name]));
                } else {
                    var b = await NN.host('nn_bind', { doc: size.docName, uids: size.pieces.map(function (p) { return p.uid; }) });
                    if (b && !b.error) {
                        if (!b.open) log(T('Warning: size {0} has no saved design; reopen the original Illustrator file "{1}" when exporting.', [size.name, size.docName]));
                        else if (b.found < b.total) log(T('Warning: file "{0}" matches only {1}/{2} pieces of size {3}; scan again if the file was edited.', [size.docName, b.found, b.total, size.name]));
                    }
                }
            }
        }
        if (added) { sortSizes(); selectNext(''); saveSizes(); invalidate(); renderSizes(); }
    }

    // ---------- bÆ°á»›c 4: danh sÃ¡ch ----------
    function renderSizes() {
        renderChips();
        var t = $('tblSizes');
        if (!state.sizes.length) { t.innerHTML = '<tr><td class="muted">' + esc(T('No sizes yet.')) + '</td></tr>'; $('warn').innerHTML = ''; refreshSteps(); return; }
        var h = '<thead><tr><th>Size</th><th class="c">' + T('Qty') + '</th><th class="num">' + T('Pieces') + '</th><th class="num">dmÂ²</th><th class="c">Design</th><th></th></tr></thead><tbody>';
        state.sizes.forEach(function (s, i) {
            var tip = T('Largest piece {0} Ã— {1} cm', [f1(s.maxW), f1(s.maxH)]) + (s.scanSec ? ', ' + T('scanned in {0} s', [f1(s.scanSec)]) : '');
            h += '<tr><td><b>' + esc(s.name) + '</b></td>' +
                '<td class="c' + (s.qty > 0 ? '' : ' need') + '"><input type="number" min="0" value="' + (s.qty > 0 ? s.qty : '') + '" placeholder="Qty" data-q="' + i + '"></td>' +
                '<td class="num">' + s.pieces.length + '</td>' +
                '<td class="num" title="' + esc(tip) + '">' + f1(s.areaCm2 / 100) + '</td>' +
                '<td class="c">' + (s.design ? '<span class="tag-ok" title="' + esc(T('Design saved in the library')) + '">âœ“ ' + esc(T('library')) + '</span>' : '<span class="tag-warn" title="' + esc(T('Design not saved; the original file is needed when exporting')) + '">' + esc(T('outline only')) + '</span>') + '</td>' +
                '<td><button class="mini" data-rm="' + i + '">âœ•</button></td></tr>';
        });
        t.innerHTML = h + '</tbody>';
        validate();
        refreshSteps();
    }

    function validate() {
        var c = cfg(), w = [], u = usableCm(c);
        state.sizes.forEach(function (s) {
            s.pieces.forEach(function (p) {
                if (p.w > u) w.push(T('Size {0}: piece {1} is {2} cm wide, wider than the usable width of {3} cm.', [s.name, p.name, f1(p.w), f1(u)]));
            });
        });
        $('warn').innerHTML = w.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('');
        $('warn').className = w.length ? 'warn bad' : 'warn';
        return w.length === 0;
    }

    function onSizesClick(e) {
        var rm = e.target.getAttribute && e.target.getAttribute('data-rm');
        if (rm === null || rm === undefined) return;
        state.sizes.splice(+rm, 1); state.dirty = true;
        saveSizes(); invalidate(); renderSizes();
    }
    function onSizesChange(e) {
        var q = e.target.getAttribute('data-q');
        if (q === null) return;
        var v = parseInt(e.target.value, 10);
        if (!(v >= 0)) v = 0;
        state.sizes[+q].qty = v; state.dirty = true;
        var td = e.target.parentNode; if (td && td.classList) td.classList.toggle('need', !(v > 0));
        saveSizes(); invalidate();
    }

    // ---------- engine Sparrow ----------
    function sizeByName(n) { return state.sizes.filter(function (x) { return x.name === n; })[0]; }

    // dá»±ng input cho Nest-Pro tá»« danh sÃ¡ch size (cÃ³ thá»ƒ láº·p size, vd [L, L])
    function npInput(names, searchMs) {
        var c = cfg(), pieces = [], map = [], copyNo = {};
        names.forEach(function (n) {
            var s = sizeByName(n);
            copyNo[n] = (copyNo[n] || 0) + 1;
            s.pieces.forEach(function (p) {
                var idx = pieces.length;
                pieces.push({ index: idx, name: n + '|' + p.name + '#' + copyNo[n], outline: p.outline, curved: p.curved, npts: p.npts });
                map.push({ uid: p.uid, tag: p.tag || '', doc: s.docName, off: p.off, size: n, copy: copyNo[n], name: p.name, w: p.w * PT, h: p.h * PT });
            });
        });
        return {
            input: {
                cfg: { rollW: c.widthCm * PT, gap: c.gapCm * PT, marginL: c.mL * PT, marginR: c.mR * PT, marginT: c.mT * PT, marginB: c.mB * PT,
                       displayMode: 0, strokeWidth: 0, rotationMode: c.rotMode, searchMs: searchMs },
                pieces: pieces
            },
            map: map
        };
    }

    // ---------- bÆ°á»›c 5-6: mÃ´ phá»ng & ghÃ©p cáº·p ----------
    function pairInput() {
        return state.sizes.map(function (s) { return { name: s.name, qty: s.qty, areaCm2: s.areaCm2, maxH: s.maxH, ref: s }; });
    }
    function simEnvKey() {
        var c = cfg();
        return ['sparrow', c.widthCm, c.gapCm, c.mL, c.mR, c.mT, c.mB, c.rotMode, c.simTimeMs].join('|');
    }
    // chá»¯ kÃ½ hÃ¬nh dáº¡ng cá»§a size: khÃ´ng Ä‘á»•i khi quÃ©t láº¡i cÃ¹ng bá»™ ráº­p (khÃ¡c vá»›i uid)
    function fnv(str) {
        var h = 0x811c9dc5;
        for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; }
        return ('0000000' + h.toString(16)).slice(-8);
    }
    function geomSig(s) {
        if (s.geom) return s.geom;
        var parts = s.pieces.map(function (p) {
            var t = '';
            p.outline.forEach(function (poly) {
                // toáº¡ Ä‘á»™ tÆ°Æ¡ng Ä‘á»‘i theo Ä‘iá»ƒm Ä‘áº§u, lÃ m trÃ²n 0,1 pt -> khÃ´ng phá»¥ thuá»™c vá»‹ trÃ­ trÃªn canvas
                var x0 = poly[0][0], y0 = poly[0][1];
                poly.forEach(function (q) { t += Math.round((q[0] - x0) * 10) + ',' + Math.round((q[1] - y0) * 10) + ';'; });
                t += '|';
            });
            return fnv(t);
        }).sort();
        s.geom = fnv(parts.join('')) + parts.length;
        return s.geom;
    }
    function simKey(names) { return names.map(function (n) { var s = sizeByName(n); return s ? geomSig(s) : n; }).join(','); }
    function fullSimKey(names) { return simEnvKey() + '#' + simKey(names); }
    function simByNames(names) { return state.simDb[fullSimKey(names)] || null; }

    // lÆ°u / náº¡p file NovaNest_simcache.json trong thÆ° má»¥c userData cá»§a Adobe
    var SIMFILE = PDIR ? PDIR + '/NovaNest_simcache.json' : '';
    var simSaveTimer = null;
    function loadSimDb() {
        state.simDb = {};
        var t = fsRead(SIMFILE);
        if (!t) { try { t = localStorage.getItem('novanest.simcache') || ''; } catch (e) { t = ''; } }
        try { var o = JSON.parse(t); if (o && o.v === 1 && o.e) state.simDb = o.e; } catch (e) { state.simDb = {}; }
    }
    function saveSimDb() {
        if (simSaveTimer) clearTimeout(simSaveTimer);
        simSaveTimer = setTimeout(function () {
            simSaveTimer = null;
            var keys = Object.keys(state.simDb);
            if (keys.length > 30000) {   // giá»¯ 30.000 káº¿t quáº£ má»›i nháº¥t
                keys.sort(function (a, b) { return (state.simDb[a].t || 0) - (state.simDb[b].t || 0); });
                keys.slice(0, keys.length - 30000).forEach(function (k) { delete state.simDb[k]; });
            }
            var text = JSON.stringify({ v: 1, e: state.simDb });
            if (SIMFILE) fsWrite(SIMFILE, text);
            else { try { localStorage.setItem('novanest.simcache', text); } catch (e) { /* bá» qua */ } }
        }, 500);
    }

    async function simulate(sets, pa, pb, what) {
        if (pa === undefined) { pa = 0.02; pb = 0.95; }
        var c = cfg();
        var seen = {}, cached = 0;
        var todo = sets.filter(function (names) {
            var k = fullSimKey(names);
            if (state.simDb[k]) { cached++; return false; }
            if (seen[k]) return false;
            seen[k] = true;
            return true;
        });
        if (cached) log(T('Reused {0} saved simulation results.', [cached]));
        if (!todo.length) return true;
        var threads = await NN.npInit();
        var t0 = Date.now(), done = 0, failed = null;
        var estSec = Math.ceil(todo.length * c.simTimeMs / 1000 / threads);
        var lbl = what || T('Simulation');
        log(T('{0}: {1} combinations with Sparrow, {2} parallel threads (about {3} s)...', [lbl, todo.length, threads, estSec]));
        setProg(pa, lbl + ' 0/' + todo.length + ' Â· ' + T('{0} threads', [threads]), null, pa + (pb - pa) * Math.min(1, threads / todo.length), c.simTimeMs + 400);
        var jobs = todo.map(function (names) {
            var x = npInput(names, c.simTimeMs);
            return NN.npRun(x.input).then(function (r) {
                state.simDb[fullSimKey(names)] = { lengthCm: r.sheetH / PT, effPct: r.effPct, t: Date.now() };
                done++;
                setProg(pa + (pb - pa) * done / todo.length, lbl + ' ' + done + '/' + todo.length + ' Â· ' + names.join('_') + ' ' + f2(r.sheetH / PT / 100) + ' m, ' + f1(r.effPct) + '%', null,
                    pa + (pb - pa) * Math.min(1, (done + threads) / todo.length), c.simTimeMs + 400);
            }, function (err) {
                done++;
                if (String(err) !== 'CANCELLED' && !failed) failed = names.join('_') + ': ' + err;
            });
        });
        await Promise.all(jobs);
        saveSimDb();
        if (state.cancel) return false;
        if (failed) { log(T('Simulation errors: {0}', [failed])); return false; }
        log(T('Simulated {0} combinations in {1} s.', [todo.length, f1((Date.now() - t0) / 1000)]));
        return true;
    }

    // (2) lá»c tá»• há»£p 3 size: chá»‰ mÃ´ phá»ng bá»™ 3 mÃ  cáº£ 3 cáº·p con cá»§a nÃ³ Ä‘á»u cÃ³ hiá»‡u suáº¥t gáº§n má»©c tá»‘t nháº¥t
    function pruneTriples(active, triples, tol) {
        if (tol < 0) return triples;
        var eff = {}, bestOf = {};
        active.forEach(function (s) { bestOf[s.name] = 0; });
        for (var i = 0; i < active.length; i++) for (var j = i + 1; j < active.length; j++) {
            var r = simByNames([active[i].name, active[j].name]);
            var e = r ? r.effPct : 0;
            eff[active[i].name + ',' + active[j].name] = e;
            if (e > bestOf[active[i].name]) bestOf[active[i].name] = e;
            if (e > bestOf[active[j].name]) bestOf[active[j].name] = e;
        }
        function pe(a, b) { return eff[a + ',' + b] || eff[b + ',' + a] || 0; }
        var scored = triples.map(function (t) {
            var e1 = pe(t[0], t[1]), e2 = pe(t[0], t[2]), e3 = pe(t[1], t[2]);
            var mn = Math.min(e1, e2, e3);
            var need = Math.max(bestOf[t[0]], bestOf[t[1]], bestOf[t[2]]) - tol;
            return { t: t, keep: mn >= need, score: (e1 + e2 + e3) / 3 };
        });
        var kept = scored.filter(function (x) { return x.keep; });
        // luÃ´n giá»¯ thÃªm cÃ¡c bá»™ 3 cÃ³ Ä‘iá»ƒm trung bÃ¬nh cao nháº¥t Ä‘á»ƒ khÃ´ng bá» sÃ³t (Ã­t nháº¥t 2 bá»™ / size)
        var minKeep = Math.min(scored.length, active.length * 2);
        if (kept.length < minKeep) {
            scored.sort(function (a, b) { return b.score - a.score; });
            scored.forEach(function (x) { if (kept.length < minKeep && !x.keep) { x.keep = true; kept.push(x); } });
        }
        return kept.map(function (x) { return x.t; });
    }

    function setBusy(b, stopId) {
        state.busy = b;
        $('btnPair').disabled = b || !engineReady; $('btnScan').disabled = b; $('btnOpenSets').disabled = b; $('btnSaveSet').disabled = b; $('btnNest').disabled = b || !engineReady;
        $('btnManual').disabled = b; $('btnToPair').disabled = b;
        $('btnBackScan').disabled = b; $('btnBackScan2').disabled = b;
        if (stopId) $(stopId).hidden = !b;
        refreshSteps();
    }

    function stopAll() {
        state.cancel = true;
        NN.npCancelAll();
    }

    // ---------- kiá»ƒm tra (test) sau khi ghÃ©p cáº·p ----------
    // Cháº¡y láº¡i Sparrow lÃ¢u hÆ¡n cho tá»«ng sÆ¡ Ä‘á»“ Ä‘Ã£ chá»n, kiá»ƒm khoáº£ng há»Ÿ, Ä‘á»‘i chiáº¿u sá»‘ lÆ°á»£ng, cáº­p nháº­t Ä‘á»‹nh má»©c.
    function testKey(names) {
        var sig = names.map(function (n) { var s = sizeByName(n); return s ? geomSig(s) + ':' + (s.pieces[0] ? s.pieces[0].uid : '') : n; }).join(',');
        return simEnvKey() + '#' + cfg().testTimeMs + '#' + sig;
    }
    async function verifyPlan(input, res, c, pa, pb) {
        state.test = state.test || {};
        var N = res.markers.length, done = 0, errs = [];
        var t0 = Date.now();
        var thr = NN.npThreads();
        setProg(pa, T('Re-checking {0} paired markers ({1} s per marker)...', [N, Math.round(c.testTimeMs / 1000)]), null, pa + (pb - pa) * Math.min(1, thr / N), c.testTimeMs + 800);
        await Promise.all(res.markers.map(function (m) {
            var k = testKey(m.sizes);
            if (state.test[k]) { done++; return Promise.resolve(); }
            var x = npInput(m.sizes, c.testTimeMs);
            return NN.npRun(x.input).then(function (r) {
                state.test[k] = { lengthCm: r.sheetH / PT, effPct: r.effPct, gapOk: r.minGap >= r.reqGap - 1e-6,
                    layout: { rows: r.rows, sheetW: r.sheetW, sheetH: r.sheetH, edgePad: r.edgePad, cfg: { marginB: r.cfg.marginB }, effPct: r.effPct, minGap: r.minGap, reqGap: r.reqGap, map: x.map } };
                done++;
                setProg(pa + (pb - pa) * done / N, T('Check') + ' ' + done + '/' + N + ' Â· ' + m.name + ' ' + f2(r.sheetH / PT / 100) + ' m, ' + f1(r.effPct) + '%', null,
                    pa + (pb - pa) * Math.min(1, (done + thr) / N), c.testTimeMs + 800);
            }, function (err) {
                done++;
                if (String(err) !== 'CANCELLED') errs.push(m.name + ': ' + err);
            });
        }));
        if (state.cancel) return null;
        var specs = res.markers.map(function (m) { return { sizes: m.sizes.slice(), plies: m.plies }; });
        var c2 = Object.assign({}, c, { simByNames: function (names) { return state.test[testKey(names)] || simByNames(names); } });
        var ev = NN.pairing.evaluate(input, specs, c2);
        ev.markers.forEach(function (m, i) {
            var t = state.test[testKey(m.sizes)];
            m.customName = res.markers[i].customName;
            m.simLengthM = res.markers[i].lengthM;
            m.tested = !!t;
            m.gapOk = t ? t.gapOk : false;
        });
        ev.tested = true;
        ev.testErrors = errs;
        ev.errors = (res.errors || []).concat(ev.errors || []);
        var bad = ev.markers.filter(function (m) { return !m.tested || !m.gapOk; });
        log(T('Checked {0} markers in {1} s:', [N, f1((Date.now() - t0) / 1000)]) + ' ' +
            T(ev.totals.ok ? 'quantities match' : 'quantities do NOT match') + ', ' + (bad.length ? T('{0} markers need review', [bad.length]) : T('gaps OK')) +
            ', ' + T('order consumption {0} m/garment.', [f3(ev.totals.normM)]));
        errs.forEach(function (e) { log('  ' + T('Check error {0}', [e])); });
        return ev;
    }

    async function pair() {
        if (state.busy) return;
        if (!state.sizes.length) { log(T('No sizes yet.')); return; }
        if (!validate()) { log(T('Some pieces are wider than the fabric; check the size list.')); return; }
        var c = cfg();
        if (!(c.widthCm > 0) || usableCm(c) <= 0) { log(T('The fabric width or margins are not valid.')); return; }
        var input = pairInput();
        var active = input.filter(function (s) { return s.qty > 0; });
        if (!active.length) { log(T('No size has a quantity above 0.')); return; }
        if ($('cAskSave').checked && state.dirty) { await askSave(); if (state.busy) return; }
        state.cancel = false;
        progReset();
        setProg(0.01, T('Preparing simulation...'), null, 0.03, 4000);   // trÆ°á»£t nháº¹ trong lÃºc khá»Ÿi Ä‘á»™ng engine
        setBusy(true, 'btnStop');
        try {
            var sets = NN.pairing.candidateSets(active, c.maxSizes).map(function (idx) {
                return idx.map(function (i) { return active[i].name; });
            });
            var small = sets.filter(function (x) { return x.length < 3 || x[0] === x[1]; });
            var triples = sets.filter(function (x) { return x.length === 3 && x[0] !== x[1]; });
            // giai Ä‘oáº¡n 1: 1 size, 2 Ã¡o cÃ¹ng size, tá»«ng cáº·p 2 size
            var ok = await simulate(small, 0.02, triples.length ? 0.4 : 0.75, T('Simulation (1â€“2 sizes)'));
            if (ok && triples.length) {
                // giai Ä‘oáº¡n 2: chá»‰ cÃ¡c bá»™ 3 size triá»ƒn vá»ng
                var keep = pruneTriples(active, triples, c.pruneTol);
                if (keep.length < triples.length) log(T('3-size filter: kept {0}/{1} promising combinations.', [keep.length, triples.length]));
                ok = await simulate(keep, 0.4, 0.75, T('Simulation (3 sizes)'));
            }
            if (!ok) { log(T(state.cancel ? 'Simulation stopped.' : 'The simulation did not finish.')); progEnd(T(state.cancel ? 'STOPPED' : 'ERROR'), T(state.cancel ? 'Cancelled.' : 'There was an error, see the Log.')); return; }
            setProg(0.76, T('Finding the pairing with the fewest markers and highest efficiency...'), null, 0.78, 1500);
            await tick();
            c.simByNames = simByNames;
            c.requireSim = true;   // chá»‰ ghÃ©p tá»« cÃ¡c tá»• há»£p Ä‘Ã£ mÃ´ phá»ng tháº­t
            var res = NN.pairing.solve(input, c);
            if (!res.markers.length) { log(T('No pairing was found.')); progEnd(T('ERROR'), T('No pairing was found.')); return; }
            log(T('Pairing done: {0} files, order consumption {1} m/garment (simulated).', [res.markers.length, f3(res.totals.normM)]));
            var tested = await verifyPlan(input, res, c, 0.78, 1);
            if (!tested) { log(T('Check stopped.')); progEnd(T('STOPPED'), T('Cancelled.')); return; }
            showPlan(tested);
            progEnd(T('DONE  100%'), T('{0} markers checked.', [tested.markers.length]));
        } finally {
            setBusy(false, 'btnStop');
            if (prog.last && !prog.last.close) progEnd();
        }
    }

    function testCell(m) {
        if (!m.tested) return '<span class="bad">' + esc(T('not tested')) + '</span>';
        var d = m.simLengthM ? (m.lengthM - m.simLengthM) / m.simLengthM * 100 : 0;
        return (m.gapOk ? '<span class="ok">âœ“</span>' : '<span class="bad">âš  ' + esc(T('gap')) + '</span>') + ' <span class="muted">' + (d >= 0 ? '+' : '') + f1(d) + '%</span>';
    }

    function showPlan(res) {
        state.plan = res;
        state.approved = false;
        state.layouts = null; state.checked = false; state.checkBlock = false;
        $('secPlan').hidden = false;
        var h = '<thead><tr><th>' + T('File name (editable)') + '</th><th class="num" title="' + T('Plies') + '">' + T('Plies') + '</th><th class="num" title="' + T('Length (m)') + '">' + T('Length') + '</th><th class="num" title="' + T('Consumption (m/garment)') + '">' + T('Cons.') + '</th><th class="num" title="' + T('Efficiency') + '">' + T('Eff.') + '</th><th>Test</th></tr></thead><tbody>';
        res.markers.forEach(function (m, i) {
            if (m.customName === undefined) m.customName = m.base;
            h += '<tr><td class="fname"><input type="text" data-fn="' + i + '" value="' + esc(m.customName) + '"><span class="muted">_' + m.plies + esc(plySuffix()) + '</span></td><td class="num">' + m.plies + '</td><td class="num">' + f2(m.lengthM) +
                '</td><td class="num">' + f3(m.normM) + '</td><td class="num">' + (m.effPct ? f1(m.effPct) + '%' : '') + '</td><td>' + testCell(m) + '</td></tr>';
        });
        var t = res.totals;
        h += '</tbody><tfoot><tr><td>' + T('Whole order ({0} files, {1} m fabric)', [t.files, f1(t.fabricM)]) + '</td><td class="num">' + T('{0} garments', [t.garments]) + '</td><td></td><td class="num">' + f3(t.normM) + '</td><td></td><td>' + (res.tested ? (t.ok ? '<span class="ok">âœ“ ' + T('qty OK') + '</span>' : '<span class="bad">âœ— ' + T('Qty') + '</span>') : '') + '</td></tr></tfoot>';
        $('tblPlan').innerHTML = h;

        var p = '<thead><tr><th>Size</th><th class="num">' + T('Qty') + '</th><th class="num">' + T('Fabric (m)') + '</th><th class="num">' + T('Cons. (m/garment)') + '</th></tr></thead><tbody>';
        t.perSize.forEach(function (d) {
            p += '<tr><td><b>' + esc(d.name) + '</b></td><td class="num">' + d.qty + '</td><td class="num">' + f1(d.fabricM) + '</td><td class="num">' + f3(d.normM) + '</td></tr>';
        });
        p += '</tbody><tfoot><tr><td>' + T('Whole order') + '</td><td class="num">' + t.garments + '</td><td class="num">' + f1(t.fabricM) + '</td><td class="num">' + f3(t.normM) + '</td></tr></tfoot>';
        $('tblPerSize').innerHTML = p;

        var sum = T('Order consumption <b>{0} m/garment</b>, total fabric <b>{1} m</b>.', [f3(t.normM), f1(t.fabricM)]);
        if (t.baselineM > 0) sum += ' ' + T('Compared with one marker per size: {0} m ({1} m/garment), saving {2} m.', [f1(t.baselineM), f3(t.baselineNormM), f1(t.savedM)]);
        if (!t.ok) {
            sum += ' <span style="color:var(--bad)">' + T('Quantities do not match:') + ' ' + t.perSize.filter(function (d) { return d.diff !== 0; })
                .map(function (d) { return esc(d.name) + ' (' + T(d.diff > 0 ? '{0} short' : '{0} extra', [Math.abs(d.diff)]) + ')'; }).join(', ') + '.</span>';
        }
        $('planSum').innerHTML = sum;
        $('manual').value = res.markers.map(function (m) { return m.base + ' ' + m.plies; }).join('\n');
        $('manualErr').innerHTML = '';
        $('btnApprove').disabled = !t.ok || !res.tested || (res.errors && res.errors.length > 0);
    }

    async function applyManual() {
        if (state.busy) return;
        var c = cfg();
        var input = pairInput();
        var specs = NN.pairing.parseSpec($('manual').value, state.sizes);
        var sets = specs.map(function (sp) { return sp.sizes.slice().sort(function (a, b) { return sizeRank(a) - sizeRank(b); }); })
            .filter(function (names) { return names.length <= 3 && names.every(function (n) { return !!sizeByName(n); }); });
        state.cancel = false;
        setBusy(true, 'btnStop');
        var ok;
        progReset();
        setProg(0.01, T('Simulating the hand-edited size pairs...'));
        var res = null, errs = [];
        try {
            ok = await simulate(sets, 0.02, 0.5);
            if (ok) {
                c.simByNames = simByNames;
                res = NN.pairing.evaluate(input, specs, c);
                errs = res.errors.slice();
                if (res.markers.length) {
                    var prev = state.plan ? state.plan.markers : [];
                    res.markers.forEach(function (m) {
                        var old = prev.filter(function (o) { return o.base === m.base; })[0];
                        if (old) m.customName = old.customName;
                    });
                    res = await verifyPlan(input, res, c, 0.52, 1);
                }
            }
        } finally { setBusy(false, 'btnStop'); if ((!ok || !res) && prog.last && !prog.last.close) progEnd(); }
        if (!ok || !res) { progEnd(T(state.cancel ? 'STOPPED' : 'ERROR'), T(state.cancel ? 'Cancelled.' : 'There was an error, see the Log.')); return; }
        progEnd(T('DONE  100%'), T('Hand-edited size pairs checked.'));
        if (!res.markers.length) {
            errs.push(T('No valid files yet.'));
            $('manualErr').innerHTML = errs.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('');
            $('manualErr').className = 'warn bad';
            return;
        }
        showPlan(res);
        $('manualErr').innerHTML = errs.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('');
        $('manualErr').className = errs.length ? 'warn bad' : 'warn';
        if (errs.length) $('btnApprove').disabled = true;
        log(T('Hand-edited size pairs applied.'));
    }

    function approve() {
        if (!state.plan || !state.plan.totals.ok) return;
        state.approved = true;
        log(T('Approved: {0}', [state.plan.markers.map(function (m) { return m.name + 'Ã—' + m.plies; }).join(', ')]));
        goStep(3);
    }

    // ---------- bÆ°á»›c 7: nesting & xuáº¥t ----------
    function safeName(s) { return s.replace(/[\\/:*?"<>|]/g, '-').trim(); }
    // "ply" word for file names, in the language on screen right now (e.g. "_25ply", "_25lop", "_25capas").
    function plySuffix() { return T('ply'); }
    // All 4 languages' "ply" words, so a name carrying a suffix from a previously selected language is
    // still recognised and replaced (instead of piling up, e.g. "M_25lop_30ply") when re-approving or
    // switching language mid-session.
    function plySuffixPattern() {
        var I = window.NovaI18n, words = ['ply'];
        if (I && I.langs) I.langs.forEach(function (l) { var w = I.tIn(l, 'ply'); if (words.indexOf(w) < 0) words.push(w); });
        return new RegExp('_\\d+\\s*(?:' + words.map(function (w) { return w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('|') + ')$', 'i');
    }
    function finalName(m) {
        var pre = safeName($('namePrefix').value || '').replace(/[_\s]+$/, '');
        var base = safeName(m.customName || m.base).replace(plySuffixPattern(), '') || m.base;
        return (pre ? pre + '_' : '') + base + '_' + m.plies + plySuffix();
    }
    function pickScale(maxPt) {
        var list = [1, 0.5, 0.25, 0.2, 0.1, 0.05];
        for (var i = 0; i < list.length; i++) if (maxPt * list[i] <= 16000) return list[i];
        return 0;
    }
    function stageName(s) { return T(s === 'lbf' ? 'initial placement' : s === 'cmpr' ? 'compressing' : 'exploring'); }

    function uniqNames(arr) { var o = {}, out = []; arr.forEach(function (n) { if (!o[n]) { o[n] = 1; out.push(n); } }); return out; }
    // Layers to build for a marker. Each distinct size gets one layer named after the size; when a size
    // repeats (a one-size marker turned into 2 garments of that size), the 2nd copy gets its own layer
    // named "<size>1" (key "<size>#2") so each layer holds the full piece set of one garment.
    function layerPlan(sizes) {
        var seen = {}, plan = [];
        sizes.forEach(function (n) {
            seen[n] = (seen[n] || 0) + 1;
            var copy = seen[n], key = copy > 1 ? n + '#' + copy : n;
            if (!plan.some(function (x) { return x.key === key; })) plan.push({ key: key, name: copy > 1 ? n + (copy - 1) : n });
        });
        return plan;
    }

    // ---------- bÆ°á»›c 5: xáº¿p sÆ¡ Ä‘á»“ (Sparrow) ----------
    async function nestAll() {
        if (!state.approved || state.busy || !engineReady) return;
        var c = cfg();
        state.cancel = false;
        setBusy(true, 'btnStopRun');
        var finished = false;
        try {
            try { await closeResultFiles(); } catch (eCl) { /* bá» qua */ }
            await savePending();
            state.layouts = null; state.checked = false; state.checkBlock = false;
            $('tblNest').innerHTML = ''; $('tblCheck').innerHTML = ''; $('checkSum').innerHTML = ''; $('tblRun').innerHTML = '';
            progReset();
            setProg(0.005, T('Starting nesting...'), null, 0.03, 4000);   // trÆ°á»£t nháº¹ trong lÃºc khá»Ÿi Ä‘á»™ng engine
            var plan = state.plan, N = plan.markers.length;
            var threads = await NN.npInit();
            var jobs = plan.markers.map(function (m) {
                var x = npInput(m.sizes, c.nestTimeMs);
                var nP = x.input.pieces.length;
                var cached = state.test ? state.test[testKey(m.sizes)] : null;
                cached = cached && cached.layout && cached.layout.map.length === x.map.length ? cached.layout : null;
                return { m: m, x: x, cached: cached, fr: 0, done: false, res: null, err: null,
                         estMs: (c.skipNest && cached) ? 0 : c.nestTimeMs > 0 ? c.nestTimeMs : Math.min(45, Math.max(10, 5 + nP)) * 1000 };
            });
            var totalMs = jobs.reduce(function (t, j) { return t + j.estMs; }, 0);
            var wallMs = Math.ceil(totalMs / Math.max(1, threads));
            log(T('Nesting {0} markers in parallel on {1} threads (about {2} s)...', [N, threads, Math.round(wallMs / 1000)]));
            var tA = Date.now();
            var aggProg = function () {
                var sum = 0, nd = 0;
                jobs.forEach(function (j) { sum += j.done ? 1 : j.fr; if (j.done) nd++; });
                var f = 0.01 + 0.97 * sum / N;
                var leftMs = Math.max(0, wallMs - (Date.now() - tA));
                setProg(f, T('Sparrow nesting Â· {0}/{1} done Â· about {2} s left', [nd, N, Math.round(leftMs / 1000)]), null,
                    Math.min(0.98, f + 0.97 * Math.min(threads, N - nd) / N * 0.5), Math.max(400, leftMs));
            };
            setProg(0.01, T('Sparrow nesting Â· 0/{0} Â· {1} threads', [N, threads]), null, 0.97 * Math.min(1, threads / N), wallMs / Math.max(1, Math.ceil(N / threads)));
            var nSkip = 0;
            await Promise.all(jobs.map(function (j) {
                // v2.5: Ä‘Ã£ cÃ³ bá»‘ cá»¥c test (Ä‘Ã£ kiá»ƒm khoáº£ng há»Ÿ) -> dÃ¹ng luÃ´n, bá» bÆ°á»›c Sparrow xáº¿p thÃªm
                if (c.skipNest && j.cached) { j.res = null; j.done = true; j.fr = 1; nSkip++; aggProg(); return Promise.resolve(); }
                return NN.npRun(j.x.input, function (p) {
                    if (p.phase === 'prepare') return;
                    j.fr = 0.05 + 0.95 * Math.min(1, p.ev / Math.max(1, p.budget));
                    aggProg();
                }).then(function (r) { j.res = r; j.done = true; aggProg(); },
                        function (e) { j.err = String(e); j.done = true; aggProg(); });
            }));
            if (state.cancel) { log(T('Nesting stopped.')); progEnd(T('STOPPED'), T('Cancelled.')); finished = true; return; }
            if (nSkip) log(T('Used the tested layout for {0}/{1} markers (extra nesting skipped).', [nSkip, N]));
            if (nSkip < N) log(T('Sparrow nested {0} markers in {1} s.', [N - nSkip, f1((Date.now() - tA) / 1000)]));

            var layouts = [];
            for (var mi = 0; mi < N; mi++) {
                var J = jobs[mi], m = J.m, res = J.res, map = J.x.map, cached = J.cached;
                log(T('Marker {0}:', [m.name]));
                if (J.err) {
                    if (!cached) { log('  ' + T('Engine error: {0}', [J.err])); layouts.push({ i: mi, m: m, err: T('Engine error: {0}', [J.err]) }); continue; }
                    log('  ' + T('Engine error ({0}); using the tested layout.', [J.err]));
                    res = null;
                }
                // so vá»›i bá»‘ cá»¥c Ä‘Ã£ test vÃ  láº¥y báº£n ngáº¯n hÆ¡n
                var fromTest = false;
                if (cached && (!res || cached.sheetH < res.sheetH - 1e-6 || (cached.minGap >= cached.reqGap - 1e-6 && res.minGap < res.reqGap - 1e-6))) {
                    if (res) log('  ' + T('The tested layout is {0} cm shorter; using it.', [f1((res.sheetH - cached.sheetH) / PT)]));
                    res = cached; map = cached.map; fromTest = true;
                } else if (cached) {
                    log('  ' + T('Extra nesting is {0} cm shorter than the tested layout.', [f1((cached.sheetH - res.sheetH) / PT)]));
                }
                var scale = pickScale(Math.max(res.sheetW, res.sheetH));
                if (!scale) { log('  ' + T('The marker is too large for Illustrator.')); layouts.push({ i: mi, m: m, err: T('The marker is too large for Illustrator.') }); continue; }
                var lenM = res.sheetH / PT / 100;
                var fname = finalName(m) + (scale < 1 ? '_' + T('scale') + '-1-' + Math.round(1 / scale) : '');
                var label = [finalName(m), m.sizes.join(', '), TF('{0} plies', [m.plies]), TF('width {0} cm', [c.widthCm]), TF('length {0} m', [f2(lenM)]), TF('efficiency {0}%', [f1(res.effPct)])].join(' | ') +
                    (scale < 1 ? ' | ' + TF('scale 1:{0}', [Math.round(1 / scale)]) : '');
                layouts.push({ i: mi, m: m, res: res, map: map, scale: scale, lenM: lenM, fname: fname, label: label, fromTest: fromTest });
                log('  ' + T('Length {0} m (simulated {1} m), efficiency {2}%.', [f2(lenM), f2(m.lengthM), f1(res.effPct)]));
            }
            state.layouts = layouts;
            if (layouts.some(function (x) { return x.res; })) {
                progReset();
                setProg(0.02, T('Building marker files in the background...'));
                await buildMarkers(layouts, c);
            }
            renderNest();
            var okN = layouts.filter(function (x) { return x.res; }).length;
            progEnd(T('DONE  100%'), T('Nested {0}/{1} markers.', [okN, N]));
            finished = true;
        } finally {
            setBusy(false, 'btnStopRun');
            if (prog.last && !prog.last.close) progEnd();
        }
        if (finished && state.layouts) {
            await runChecks();
            goStep(4);
            if (!state.checkBlock) await openResults();
        }
    }

    function renderNest() {
        var L = state.layouts || [];
        var h = '<thead><tr><th>' + T('Marker') + '</th><th class="num">' + T('Plies') + '</th><th class="num">' + T('Length (m)') + '</th><th class="num">' + T('Cons. (m/garment)') + '</th><th class="num">' + T('Efficiency') + '</th><th class="num">' + T('vs. simulation') + '</th></tr></thead><tbody>';
        L.forEach(function (x) {
            if (!x.res) { h += '<tr><td><b>' + esc(finalName(x.m)) + '</b></td><td colspan="5" class="bad">' + esc(x.err || T('Not nested')) + '</td></tr>'; return; }
            var d = x.m.lengthM ? (x.lenM - x.m.lengthM) / x.m.lengthM * 100 : 0;
            h += '<tr><td><b>' + esc(finalName(x.m)) + '</b></td><td class="num">' + x.m.plies + '</td><td class="num">' + f2(x.lenM) + '</td><td class="num">' + f3(x.lenM / x.m.sizes.length) +
                '</td><td class="num">' + f1(x.res.effPct) + '%</td><td class="num">' + (d >= 0 ? '+' : '') + f1(d) + '%</td></tr>';
        });
        $('tblNest').innerHTML = h + '</tbody>';
    }

    // ---------- dá»±ng file sÆ¡ Ä‘á»“ cháº¡y ngáº§m (thÆ° má»¥c lÃ m viá»‡c) ----------
    function lastDir() { try { return localStorage.getItem('novanest.lastdir') || ''; } catch (e) { return ''; } }
    function rememberDir(d) { try { if (d) localStorage.setItem('novanest.lastdir', d); } catch (e) { /* bá» qua */ } }
    function markerCs(L) {
        var cs = '';
        uniqNames(L.m.sizes).forEach(function (n) { var s = sizeByName(n); if (s && s.cs && !cs) cs = s.cs; });
        return cs;
    }
    function beginArgs(L, out, c) {
        var res = L.res, ol = {};
        uniqNames(L.m.sizes).forEach(function (n) { var s = sizeByName(n); if (s) s.pieces.forEach(function (p) { ol[p.uid] = p.outline; }); });
        return {
            out: out, sizes: uniqNames(L.m.sizes), layers: layerPlan(L.m.sizes), sheetW: res.sheetW, sheetH: res.sheetH, marginB: res.cfg.marginB, edgePad: res.edgePad,
            scale: L.scale, label: L.label, design: !c.stroke, clip: !!c.clip, cs: markerCs(L),
            placements: res.rows.map(function (r) {
                var mp = L.map[r.index], sz = sizeByName(mp.size);
                var pl = { uid: mp.uid, tag: mp.tag || '', doc: mp.doc, path: sz ? sz.docPath || '' : '', off: mp.off, size: mp.size, copy: mp.copy || 1, name: mp.name, w: mp.w, h: mp.h, angle: r.angle, x: r.x, y: r.y };
                if ((c.stroke || c.clip) && ol[mp.uid]) pl.ol = ol[mp.uid];
                return pl;
            })
        };
    }
    async function closeResultFiles() {
        var paths = (state.layouts || []).map(function (x) { return x.file; }).filter(Boolean);
        if (paths.length) await NN.host('nn_close_files', { paths: paths });
    }
    // dá»±ng tá»«ng sÆ¡ Ä‘á»“ trong 1 file má»›i (khung nhÃ¬n thu nhá», khÃ´ng má»Ÿ file ráº­p), lÆ°u vÃ o thÆ° má»¥c lÃ m viá»‡c rá»“i Ä‘Ã³ng
    async function buildMarkers(layouts, c) {
        try { return await buildMarkers0(layouts, c); }
        finally { var se = await NN.host('nn_stock_end', {}); if (se && se.closed) log(T('Closed {0} pattern files that had to be opened temporarily.', [se.closed])); }
    }
    async function buildMarkers0(layouts, c) {
        var dir = WORKDIR + '/run_' + Date.now().toString(36);
        var md = await NN.host('nn_make_dir', { path: dir });
        if (md.error) { log(T('Error: could not create the work folder: {0}', [md.error])); return false; }
        state.workDir = md.path || dir;
        await NN.host('nn_reset', {});
        var todo = layouts.filter(function (x) { return x.res; }), N = todo.length, used = {}, nBuilt = 0, tB = Date.now();
        // náº¡p design: má»—i file ráº­p 1 láº§n (file gá»‘c Ä‘ang má»Ÿ thÃ¬ láº¥y tháº³ng, khÃ´ng thÃ¬ má»Ÿ táº¡m Báº¢N CHÃ‰P trong kho rá»“i Ä‘Ã³ng ngay)
        var srcs = {}, order = [], badPatU = {};
        todo.forEach(function (x) { uniqNames(x.m.sizes).forEach(function (n) {
            var s = sizeByName(n); if (!s) return;
            var key = s.docPath || s.docName;
            if (!srcs[key]) { srcs[key] = { src: s.srcPath || '', kho: s.docPath || '', cs: s.cs || '', names: [], pieces: [] }; order.push(key); }
            if (srcs[key].names.indexOf(n) < 0) { srcs[key].names.push(n); s.pieces.forEach(function (p) { srcs[key].pieces.push({ uid: p.uid, loc: p.loc, tn: p.tn, gb: p.gb, tag: p.tag || '' }); }); }
        }); });
        var csSet = uniqNames(order.map(function (k) { return srcs[k].cs; }).filter(Boolean));
        if (csSet.length > 1) log('  ' + T('Warning: the pattern files use different color modes ({0}). The marker uses the first size\'s color mode; colors of other sizes may change in conversion.', [csSet.join(', ')]));
        // Expanding a pattern fill is a single Illustrator action and cannot be split into smaller
        // steps, so Illustrator itself can stop responding for a few seconds while it runs â€” this is
        // expected, not a freeze. It only happens once per size per session (see the "using the copy
        // expanded last time" log line below); say so up front instead of leaving the wait unexplained.
        if (order.length) log(T('Preparing pattern designs for {0} size group(s). Illustrator may briefly stop responding while it does this for a size not already prepared this session.', [order.length]));
        for (var si = 0; si < order.length && !state.cancel; si++) {
            var sc = srcs[order[si]];
            setProg(0.01 + 0.2 * si / order.length, T('Loading design for size {0} ({1}/{2})...', [sc.names.join(', '), si + 1, order.length]), null, 0.01 + 0.2 * (si + 1) / order.length, 8000);
            await tick();
            var la = await NN.host('nn_stock_add', { src: sc.src, kho: sc.kho, pieces: sc.pieces, cs: sc.cs });
            if (la.error) { log('  ' + T('Error loading design for size {0}: {1}', [sc.names.join(', '), la.error])); continue; }
            if (la.cachedExp && !la.expanded) log('  ' + T('Size {0}: using the copy expanded last time (no need to expand again).', [sc.names.join(', ')]));
            if (la.savedExp) log('  ' + T('Saved the expanded copy in NovaNest_rap so the next nesting is faster.'));
            if (la.pruned) log('  ' + T('Size {0}: removed {1} parts of the artwork lying fully outside the pattern outline (not visible; keeps the file light and correctly placed).', [sc.names.join(', '), la.pruned]));
            if (la.expanded) log('  ' + T('Size {0}: expanded the pattern fill of {1} pieces in the copy (keeps the print in the right place).', [sc.names.join(', '), la.expanded]));
            (la.badPat || []).forEach(function (u) { badPatU[u] = true; });
            if (la.badPat && la.badPat.length) log('  ' + T('ERROR: the pattern fill of {0} pieces of size {1} could not be expanded (the print will shift). Markers with these pieces will be blocked at the Check step.', [la.badPat.length, sc.names.join(', ')]));
            if (la.expErr) log('  ' + T('Warning: the pattern fill could not be expanded ({0}); the print may shift.', [la.expErr]));
            if (la.missing && la.missing.length) log('  ' + T('{0} pieces of size {1} were not found (library file deleted or old pattern set). Scan this size again.', [la.missing.length, sc.names.join(', ')]));
        }
        for (var i = 0; i < N; i++) {
            if (state.cancel) break;
            var X = todo[i], base = X.fname, k = 1;
            while (used[base.toLowerCase()]) { k++; base = X.fname + '_' + k; }
            used[base.toLowerCase()] = true; X.base = base;
            var label0 = T('Building file {0}/{1}: {2}', [i + 1, N, base]);
            var fp = (function (q) { return function (x) { return 0.22 + 0.76 * (q + x) / N; }; })(i);
            setProg(fp(0.02), label0 + ' Â· ' + T('creating...'), null, fp(0.08), 800);
            var out = await NN.host('nn_file_begin', beginArgs(X, state.workDir + '/' + base + '.ai', c));
            while (!out.error && !out.done && !state.cancel) {
                out = await NN.host('nn_file_step', {});
                if (!out.error) setProg(fp(0.1 + 0.75 * out.i / Math.max(1, out.n)), label0 + ' Â· ' + (out.wait ? T('finding pieces in a heavy pattern file...') : T('placing piece {0}/{1}', [out.i, out.n])), null,
                    fp(0.1 + 0.75 * Math.min(out.n, out.i + 4) / Math.max(1, out.n)), out.wait ? 3000 : 400);
                await tick();
            }
            if (state.cancel && !out.error) { await NN.host('nn_file_cancel', {}); break; }
            if (!out.error) {
                setProg(fp(0.88), label0 + ' Â· ' + T('saving...'), null, fp(0.99), 2500);
                await new Promise(function (r) { setTimeout(r, 150); });
                out = await NN.host('nn_file_finish', {});
            }
            if (out.error) { X.buildErr = out.error; log('  ' + T('Error building file {0}: {1}', [base, out.error])); continue; }
            X.patBad = X.res.rows.filter(function (r) { return badPatU[X.map[r.index].uid]; }).length;
            X.file = out.path; X.missing = out.missing || 0; X.rebuilt = out.rebuilt || 0; X.how = out.how || {};
            X.posErr = (out.pos || []).length; X.outSheet = out.out || [];
            if (out.fix) log('  ' + T('{0} pieces needed a correction move after placing (Illustrator did not move them far enough).', [out.fix]));
            if (X.posErr) { log('  ' + T('{0} pieces are OUT OF POSITION compared with the layout:', [X.posErr])); out.pos.slice(0, 8).forEach(function (t) { log('    ' + t); }); }
            if (X.outSheet.length) log('  ' + T('Pieces outside the fabric width: {0}', [X.outSheet.join(', ')]));
            nBuilt++;
            var hw = X.how || {};
            log('  ' + base + ': ' + T('built, {0} pieces', [out.placed]) + (out.patN ? ', ' + T('pattern fill re-aligned on {0} paths (offset before {1}, now {2})', [out.patN, out.patBefore, out.patRes]) : '') + (out.patRev ? ', ' + T('{0} pieces could NOT have the pattern fill adjusted (left as is, measured offset {1})', [out.patRev, out.patBefore]) : '') + (out.patBad ? ', ' + T('{0} pieces could not be compared for the pattern fill', [out.patBad]) : '') + '.');
            if (out.patDbg) log('  [' + T('pattern diagnostics') + '] ' + JSON.stringify(out.patDbg, function (k, v) { return typeof v === 'number' ? Math.round(v * 1000) / 1000 : v; }));
        }
        log(T('Built {0}/{1} marker files in {2} s.', [nBuilt, N, f1((Date.now() - tB) / 1000)]));
        return nBuilt;
    }
    async function openResults() {
        var paths = (state.layouts || []).map(function (x) { return x.file; }).filter(Boolean);
        if (!paths.length) return;
        progReset();
        for (var i = 0; i < paths.length; i++) {      // má»Ÿ tá»«ng file Ä‘á»ƒ thanh tiáº¿n trÃ¬nh cháº¡y giá»¯a cÃ¡c file náº·ng
            setProg(0.02 + 0.96 * i / paths.length, T('Opening marker {0}/{1} for checking...', [i + 1, paths.length]), null, 0.02 + 0.96 * (i + 1) / paths.length, 5000);
            await tick();
            var r = await NN.host('nn_open_files', { paths: [paths[i]] });
            if (r.error) log(T('Error opening result file: {0}', [r.error]));
            else if (r.errors && r.errors.length) r.errors.forEach(function (e) { log(T('Could not open {0}', [e])); });
        }
        progEnd();
        log(T('Opened {0} markers in Illustrator for checking.', [paths.length]));
    }

    // ---------- bÆ°á»›c 6: kiá»ƒm tra ----------
    async function runChecks() {
        var L = state.layouts || [], checks = [], block = false;
        L.forEach(function (x) {
            var e = [], w = [];
            if (!x.res) { e.push(x.err || T('Not nested.')); }
            else {
                var expected = 0;
                x.m.sizes.forEach(function (n) { var s = sizeByName(n); expected += s ? s.pieces.length : 0; });
                if (x.res.rows.length !== expected) e.push(T('The marker has {0} pieces but needs {1}.', [x.res.rows.length, expected]));
                if (!x.file) e.push(x.buildErr ? T('The file could not be built: {0}', [x.buildErr]) : T('The marker file could not be built.'));
                if (x.missing) e.push(T('{0} pieces are missing from the file (design not found in the pattern file). Scan the related sizes again, then nest again.', [x.missing]));
                if (x.patBad) e.push(T('{0} pieces could not have their pattern fill expanded, so the print may shift. Close the pattern file / copy in NovaNest_rap, then nest again.', [x.patBad]));
                if (x.posErr) e.push(T('{0} pieces in the file are out of position compared with the nested layout (they may overlap). Nest again; if it still fails, send the Log to support.', [x.posErr]));
                if (x.outSheet && x.outSheet.length) e.push(T('Pieces outside the fabric width: {0}.', [x.outSheet.join(', ')]));
                if (x.rebuilt) w.push(T('{0} pieces were rebuilt from the outline (inner lines, text and notches are lost).', [x.rebuilt]));
                if (x.res.minGap < x.res.reqGap - 1e-6) w.push(T('Smallest gap {0} cm < required {1} cm.', [f3(x.res.minGap / PT), f2(x.res.reqGap / PT)]));
                if (x.scale < 1) w.push(T('The marker is very long and will be exported at scale 1:{0}.', [Math.round(1 / x.scale)]));
                if (x.m.lengthM && x.lenM > x.m.lengthM * 1.03) w.push(T('{0}% longer than simulated.', [f1((x.lenM / x.m.lengthM - 1) * 100)]));
                uniqNames(x.m.sizes).forEach(function (n) { if (!sizeByName(n)) e.push(T('Size {0} is no longer in the list.', [n])); });
            }
            checks.push({ errors: e, warns: w });
            if (e.length) block = true;
        });
        state.checks = checks; state.checked = true; state.checkBlock = block;
        renderCheck();
        refreshSteps();
    }

    function renderCheck() {
        var L = state.layouts || [], C = state.checks || [];
        var h = '<thead><tr><th>' + T('Marker') + '</th><th class="num" title="' + T('Pieces') + '">' + T('Pcs') + '</th><th class="num" title="' + T('Smallest gap (cm)') + '">' + T('Gap') + '</th><th class="num" title="' + T('Efficiency') + '">' + T('Eff.') + '</th><th>' + T('Result') + '</th><th></th></tr></thead><tbody>';
        var nOk = 0, nWarn = 0, nErr = 0;
        L.forEach(function (x, i) {
            var ck = C[i] || { errors: [], warns: [] };
            var st = ck.errors.length ? '<span class="tag-bad">âœ— ' + T('error') + '</span>' : (ck.warns.length ? '<span class="tag-warn">âš  ' + ck.warns.length + '</span>' : '<span class="tag-ok">âœ“ ' + T('OK') + '</span>');
            if (ck.errors.length) nErr++; else if (ck.warns.length) nWarn++; else nOk++;
            var exp = 0; if (x.m) x.m.sizes.forEach(function (n) { var s = sizeByName(n); exp += s ? s.pieces.length : 0; });
            h += '<tr><td><b>' + esc(x.m ? finalName(x.m) : '') + '</b></td><td class="num">' + (x.res ? (x.res.rows.length - (x.missing || 0)) + '/' + exp : '') + '</td>' +
                '<td class="num">' + (x.res ? f3(x.res.minGap / PT) : '') + '</td><td class="num">' + (x.res ? f1(x.res.effPct) + '%' : '') + '</td><td>' + st + '</td>' +
                '<td class="act"><button class="mini" data-view="' + i + '"' + (x.file ? '' : ' disabled') + '>' + T('Open') + '</button></td></tr>';
            var msgs = ck.errors.map(function (t) { return '<li class="bad">' + esc(t) + '</li>'; }).concat(ck.warns.map(function (t) { return '<li>' + esc(t) + '</li>'; }));
            if (msgs.length) h += '<tr><td colspan="6" class="msg"><ul class="warn">' + msgs.join('') + '</ul></td></tr>';
        });
        $('tblCheck').innerHTML = h + '</tbody>';
        var sum = T('{0} markers:', [L.length]) + ' <b class="tag-ok">' + T('{0} OK', [nOk]) + '</b>' + (nWarn ? ', <b class="tag-warn">' + T('{0} with warnings', [nWarn]) + '</b>' : '') + (nErr ? ', <b class="tag-bad">' + T('{0} with errors', [nErr]) + '</b>' : '') + '. ';
        sum += T(nErr ? 'There are errors, so the files cannot be exported yet. Fix them, then nest again.' : 'Review and edit in Illustrator (one layer per size), then go to the Export step.');
        $('checkSum').innerHTML = sum;
        $('btnOpenAll').disabled = !L.some(function (x) { return x.file; });
        log(T('Check: {0} OK, {1} warnings, {2} errors.', [nOk, nWarn, nErr]));
    }

    async function openOne(i) {
        var x = state.layouts && state.layouts[i];
        if (!x || !x.file) return;
        var r = await NN.host('nn_open_files', { paths: [x.file] });
        if (r.error) log(T('Error: {0}', [r.error]));
    }

    // ---------- bÆ°á»›c 7: xuáº¥t file (chá»‰ chÃ©p file sÆ¡ Ä‘á»“ + CSV vÃ o thÆ° má»¥c káº¿t quáº£) ----------
    async function exportAll() {
        if (state.busy || !state.layouts || !stepAvail(5)) return;
        var c = cfg(), L = state.layouts.filter(function (x) { return x.res && x.file; }), N = L.length;
        if (!N) { log(T('There are no marker files to export yet.')); return; }
        state.cancel = false;
        setBusy(true, 'btnStopExp');
        try {
            var d = await NN.host('nn_pick_folder', { save: true, start: lastDir(), name: '_bao_cao_dinh_muc.csv', filter: T('CSV report') + ':*.csv', title: T('Choose the output folder (paste a folder path, then click Save)') });
            if (d.error) { log(T('Error: {0}', [d.error])); return; }
            if (!d.path) { log(T('Folder selection cancelled.')); return; }
            rememberDir(d.path);
            progReset();
            setProg(0.05, T('Saving and copying {0} marker files...', [N]), null, 0.9, 4000 * N);
            log(T('Output folder: {0}', [d.path]));
            var files = L.map(function (x) { return { path: x.file, name: x.base || x.fname }; });
            var r = await NN.host('nn_publish', { dir: d.path, files: files, close: true, pdf: !!c.pdf, pdfCompat: c.pdfCompat });
            if (r.error) { log(T('Export error: {0}', [r.error])); progEnd(T('ERROR'), r.error); return; }
            (r.errors || []).forEach(function (e) { log('  ' + T('Error: {0}', [e])); });
            var okNames = {};
            (r.done || []).forEach(function (p) { okNames[p.replace(/\\/g, '/').split('/').pop().replace(/\.ai$/i, '')] = true; });
            var rows = L.filter(function (x) { return okNames[x.base || x.fname]; }).map(function (x) {
                return { name: x.base || x.fname, plies: x.m.plies, k: x.m.sizes.length, estM: x.m.lengthM, lenM: x.lenM, eff: x.res.effPct, scale: x.scale, rebuilt: x.rebuilt || 0, missing: x.missing || 0 };
            });
            renderRun(rows);
            if (rows.length) {
                var fabric = rows.reduce(function (s, q) { return s + q.plies * q.lenM; }, 0);
                var gar = rows.reduce(function (s, q) { return s + q.plies * q.k; }, 0);
                log(T('Exported {0}/{1} files. Actual total fabric {2} m, order consumption {3} m/garment.', [rows.length, N, f1(fabric), f3(fabric / gar)]));
                var csv = '\ufeff' + ['File', T('Plies'), T('Simulated length (m)'), T('Actual length (m)'), T('Cons. (m/garment)'), T('Fabric (m)'), T('Efficiency (%)'), T('Scale'), T('Rebuilt pieces'), T('Missing pieces')].map(function (x) { return '"' + x + '"'; }).join(',') + '\n';
                rows.forEach(function (q) {
                    csv += '"' + q.name + '",' + q.plies + ',' + f2(q.estM) + ',' + f2(q.lenM) + ',' + f3(q.lenM / q.k) + ',' + f1(q.plies * q.lenM) + ',' + f1(q.eff) + ',' + (q.scale < 1 ? '1:' + Math.round(1 / q.scale) : '1:1') + ',' + (q.rebuilt || 0) + ',' + (q.missing || 0) + '\n';
                });
                csv += '"' + T('Whole order') + '",' + gar + ',,,' + f3(fabric / gar) + ',' + f1(fabric) + ',,,,\n';
                var w = await NN.host('nn_write_text', { path: d.path + '/_bao_cao_dinh_muc.csv', text: csv });
                if (w.error) log(T('Could not write the report: {0}', [w.error])); else log(T('Report written: {0}', ['_bao_cao_dinh_muc.csv']));
            }
            if (rows.length === N) progEnd(T('DONE  100%'), T('Exported {0} marker files + report.', [N]));
            else progEnd(T('DONE WITH ERRORS'), T('Exported {0}/{1} files, see the Log.', [rows.length, N]));
        } finally {
            setBusy(false, 'btnStopExp');
            if (prog.last && !prog.last.close) progEnd();
        }
    }

    function renderRun(rows) {
        var h = '<thead><tr><th>File</th><th class="num">' + T('Plies') + '</th><th class="num">' + T('Actual length (m)') + '</th><th class="num">' + T('Cons. (m/garment)') + '</th><th class="num">' + T('Fabric (m)') + '</th><th class="num">' + T('Efficiency') + '</th></tr></thead><tbody>';
        var fabric = 0, gar = 0;
        rows.forEach(function (r) {
            fabric += r.plies * r.lenM; gar += r.plies * r.k;
            h += '<tr><td><b>' + esc(r.name) + '</b>' + (r.missing ? ' <span class="bad" title="' + T('Missing pieces') + '">âš  ' + T('{0} short', [r.missing]) + '</span>' : (r.rebuilt ? ' <span class="muted" title="' + T('Rebuilt from outline') + '">Â·' + T('{0} rebuilt', [r.rebuilt]) + '</span>' : '')) + '</td><td class="num">' + r.plies + '</td><td class="num">' + f2(r.lenM) + '</td><td class="num">' + f3(r.lenM / r.k) +
                '</td><td class="num">' + f1(r.plies * r.lenM) + '</td><td class="num">' + f1(r.eff) + '%</td></tr>';
        });
        h += '</tbody><tfoot><tr><td>' + T('Whole order') + '</td><td class="num">' + T('{0} garments', [gar]) + '</td><td></td><td class="num">' + f3(fabric / gar) + '</td><td class="num">' + f1(fabric) + '</td><td></td></tr></tfoot>';
        $('tblRun').innerHTML = h;
    }

    // file ráº­p náº·ng: chÆ°a lÆ°u lÃºc quÃ©t, lÆ°u 1 láº§n á»Ÿ Ä‘Ã¢y (má»—i file 1 láº§n dÃ¹ quÃ©t nhiá»u size trong cÃ¹ng file)
    async function savePending() { /* 2.3: khÃ´ng cÃ²n lÆ°u file ráº­p cá»§a ngÆ°á»i dÃ¹ng */ }

    async function toPair() {
        if (state.busy) return;
        if (!stepAvail(2)) { log(T('No size has a quantity above 0. Enter quantities in the Qty column.')); return; }
        await savePending();
        if ($('cAskSave').checked && state.dirty) await askSave();
        goStep(2);
    }

    // ---------- khá»Ÿi Ä‘á»™ng ----------
    // ---------- license (js/license.js, API /api/nest, separate from NOVA Trame) ----------
    var VERSION = '2.6.13';
    var PLAN_LABEL = { trial: 'Trial', monthly: 'Monthly', yearly: 'Yearly', yearly_pro: 'Yearly Pro' };
    var LIC_ERR = {
        license_invalid_or_expired: 'The key is invalid or has expired.',
        activation_limit_reached: 'This key is already active on the maximum number of computers.',
        trial_already_used: 'This computer has already used the 7-day trial.',
        offline: 'Could not reach the license server.',
        invalid_request: 'The key format is not valid.',
        wrong_device: 'This code is for another computer.',
        bad_signature: 'The code is not valid.',
        no_verifier: 'The code could not be verified on this computer.',
        format: 'The activation code format is not valid.',
        expired: 'The activation code has expired.',
        clock: 'The computer\'s date/time was set back. Set the correct date and time, then try again.'
    };
    function fmtDate(iso) {
        var d = new Date(iso);
        if (isNaN(d.getTime())) return '';
        var loc = { vi: 'vi-VN', en: 'en-GB', th: 'th-TH', es: 'es-ES' }[curLang()] || 'en-GB';
        try { return d.toLocaleDateString(loc); } catch (e) { return d.toISOString().slice(0, 10); }
    }
    function licOk() { return !window.NovaLicense || window.NovaLicense.canUse(); }
    function licBusy(on) {
        $('licBusy').hidden = !on;
        ['licActivate', 'licTrial', 'licApplyCode'].forEach(function (id) { $(id).disabled = on; });
    }
    function renderLicense() {
        if (!window.NovaLicense) return;
        var L = window.NovaLicense, s = L.status(), ok = L.canUse(), label, msg;
        if (ok) {
            label = T('Activated');
            msg = s.status === 'offline' ? T('Offline: using the saved license for up to 24 hours.')
                : T('{0} plan Â· expires {1}', [T(PLAN_LABEL[s.plan] || s.plan || ''), fmtDate(s.expiresAt)]);
        } else if (s.status === 'expired') { label = T('Expired'); msg = T('The license expired on {0}.', [fmtDate(s.expiresAt)]); }
        else if (s.status === 'revoked') { label = T('Revoked'); msg = T('This license has been revoked.'); }
        else if (s.status === 'clock') { label = T('Wrong date/time'); msg = T('The computer\'s date/time was set back. Set the correct date and time, then connect to the internet to check the license.'); }
        else if (s.status === 'offline') { label = T('Offline'); msg = T('Could not reach the license server.'); }
        else if (s.status === 'invalid') { label = T('Not activated'); msg = T('The key is invalid or not tied to this computer.'); }
        else { label = T('Not activated'); msg = T('Enter a key or start the 7-day trial to begin.'); }
        $('licState').textContent = (ok ? 'âœ“ ' : '') + label;
        $('licState').className = 'lic-state' + (ok ? ' ok' : '');
        $('licMsg').textContent = msg;
        $('btnLic').textContent = ok ? 'License âœ“' : 'License';
        $('licBuy').textContent = T(s.status === 'expired' || ok ? 'Renew license' : 'Buy & renew');
        licBusy(false);
    }
    function licError(code) {
        var t = T(LIC_ERR[code] || 'The license could not be activated.');
        if (code === 'offline' && window.NovaLicense && window.NovaLicense.diagnostics) t += ' [' + window.NovaLicense.diagnostics() + ']';
        return t;
    }
    function openUrl(url) {
        try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) { /* bá» qua */ }
        try { if (cep && cep.openURLInDefaultBrowser) { cep.openURLInDefaultBrowser(url); return; } } catch (e2) { /* bá» qua */ }
        try { window.open(url, '_blank'); } catch (e3) { /* bá» qua */ }
    }
    // Scan, pair, nest and export need a valid license; the rest of the panel stays usable for viewing.
    // Ask the license server again (revoked or refunded keys stop working). Offline keeps the 24 h grace.
    var lastLicCheck = Date.now();
    function recheckLicense(done) {
        if (!window.NovaLicense || !(window.NovaLicense.hasStored && window.NovaLicense.hasStored())) { if (done) done(); return; }
        window.NovaLicense.check(function () {
            lastLicCheck = Date.now();
            renderLicense();
            if (!licOk()) showLicense(true);
            if (done) done();
        });
    }
    function needLicense(fn) {
        return function () {
            var self = this, args = arguments;
            if (!licOk()) { log(T('Activate a license to use this feature.')); showLicense(true); return; }
            if (Date.now() - lastLicCheck < 5 * 60 * 1000) return fn.apply(self, args);
            recheckLicense(function () {
                if (licOk()) fn.apply(self, args);
                else log(T('Activate a license to use this feature.'));
            });
        };
    }
    setInterval(function () { if (!state.busy) recheckLicense(); }, 15 * 60 * 1000);
    // License screen (own tab) vs work screen. The license screen shows only while the panel is not
    // activated; once activated the panel opens on the work screen, and the header "License" button
    // can still open the license screen (with a Back button) to see the plan or renew.
    function showLicense(on) {
        var ok = licOk();
        $('licCard').hidden = !on;
        $('licTabs').hidden = !on;
        $('appMain').hidden = on;
        $('licClose').hidden = !(on && ok);
        if (on) { try { window.scrollTo(0, 0); } catch (e) { /* bá» qua */ } }
    }
    function afterActivated(msg) {
        renderLicense();
        log(msg);
        if (licOk()) showLicense(false);
    }
    function initLicense() {
        $('btnLic').addEventListener('click', function () { showLicense($('licCard').hidden); });
        $('licClose').addEventListener('click', function () { if (licOk()) showLicense(false); });
        if (!window.NovaLicense) { $('licMsg').textContent = T('The license module could not be loaded.'); return; }
        var L = window.NovaLicense;
        $('licActivate').addEventListener('click', function () {
            if (!$('licKey').value.trim()) { $('licKey').focus(); return; }
            licBusy(true);
            L.activate($('licKey').value, function (r) {
                if (!r.ok) { $('licMsg').textContent = licError(r.error); licBusy(false); return; }
                afterActivated(T('License activated.'));
            });
        });
        $('licKey').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('licActivate').click(); });
        $('licTrial').addEventListener('click', function () {
            licBusy(true);
            L.startTrial(function (r) {
                if (!r.ok) { $('licMsg').textContent = licError(r.error); licBusy(false); return; }
                $('licKey').value = r.key || '';
                afterActivated(T('7-day trial started.'));
            });
        });
        $('licBuy').addEventListener('click', function () { openUrl(L.currentRenewUrl ? L.currentRenewUrl() : L.renewUrl); });
        $('licOfflineToggle').addEventListener('click', function () { $('licOffline').hidden = !$('licOffline').hidden; });
        $('licDevice').value = L.deviceCode();
        $('licCopyDevice').addEventListener('click', function () {
            var i = $('licDevice'); i.select();
            try { document.execCommand('copy'); } catch (e) { /* bá» qua */ }
        });
        $('licActPage').addEventListener('click', function () { openUrl(L.activateUrl()); });
        $('licApplyCode').addEventListener('click', function () {
            var code = $('licCode').value;
            if (!code.trim()) return;
            licBusy(true);
            L.applyOfflineCode(code, function (r) {
                if (!r.ok) { $('licMsg').textContent = licError(r.error); licBusy(false); return; }
                $('licOffline').hidden = true; $('licCode').value = '';
                afterActivated(T('Activated offline.'));
            });
        });
        showLicense(!(L.hasStored && L.hasStored()));
        licBusy(true);
        L.check(function () {
            try { var st = L.status(); if (st && st.key) $('licKey').value = st.key; } catch (e) { /* bá» qua */ }
            renderLicense();
            showLicense(!licOk());
        });
    }

    // ---------- language ----------
    function initLang() {
        var I = window.NovaI18n;
        $('verLabel').textContent = 'v' + VERSION;
        if (!I) { $('langSel').hidden = true; return; }
        $('langSel').value = I.lang;
        I.apply(document.body);
        $('langSel').addEventListener('change', function () {
            I.set($('langSel').value);
            I.apply(document.body);
            // redraw the parts built in code, in the new language
            try { renderSizes(); refreshSteps(); } catch (e) { /* bá» qua */ }
            try { if (state.plan) showPlan(state.plan); } catch (e1) { /* bá» qua */ }
            try { if (state.layouts) { renderNest(); renderCheck(); } } catch (e2) { /* bá» qua */ }
            renderLicense();
        });
    }

    // Update notice (js/update.js): read latest.json once per open; show a bar only when a newer version exists.
    function initUpdate() {
        if (!window.NovaUpdate) return;
        window.NovaUpdate.check(function (info) {
            if (!info || !info.newer || info.dismissed) return;
            $('updText').textContent = T('A new version {0} is available.', [info.latest]);
            $('updGet').textContent = T('Download {0}', [info.latest]);
            $('updGet').onclick = function () { openUrl(info.url); };
            var auto = $('updAuto');
            if (info.canAuto && auto) {
                auto.hidden = false;
                auto.onclick = function () { installUpdate(info); };
            }
            $('updClose').onclick = function () { window.NovaUpdate.dismiss(info.latest); $('updBar').hidden = true; };
            $('updBar').hidden = false;
        });
    }

    // One-click install (js/update.js). The new version runs after Illustrator is restarted.
    function installUpdate(info) {
        var auto = $('updAuto'), stat = $('updStatus');
        auto.disabled = true; $('updGet').disabled = true;
        $('updText').textContent = T('Updating...');
        window.NovaUpdate.install(info, function (err) {
            if (!err) {
                $('updText').textContent = T('Updated to {0}. Restart Illustrator to use the new version.', [info.latest]);
                stat.textContent = ''; auto.hidden = true; $('updGet').hidden = true;
                return;
            }
            // Could not install here: keep the download link and say why.
            auto.disabled = false; $('updGet').disabled = false;
            $('updText').textContent = T('Automatic update failed. Use the download button instead.'); stat.textContent = '';
            log(T('Automatic update failed ({0}).', [err.code || 'error']));
        }, { onStep: function () {} });
    }

    function init() {
        NN.onSlow = function (fn, ms) {
            if (/^nn_pick/.test(fn)) return;   // há»™p thoáº¡i chá»n thÆ° má»¥c/file: thá»i gian lÃ  lÃºc ngÆ°á»i dÃ¹ng chá»n
            log('  ' + T('(Illustrator took {1} s for {0})', [fn, f1(ms / 1000)])); };
        initLang();
        initLicense();
        initUpdate();
        loadCfg();
        loadSimDb();
        loadSizes();
        renderSizes();
        // Each time the panel opens, start from the Scan step with no old results (the size list is kept).
        state.step = 1; invalidate();
        NN.host('nn_work_clean', { dir: WORKDIR, days: 2 });   // dá»n thÆ° má»¥c lÃ m viá»‡c cÅ©
        NN.host('nn_tmp_clean', {});                            // file táº¡m cÃ²n sÃ³t khi Illustrator bá»‹ táº¯t giá»¯a chá»«ng
        var rstTimer = null;
        $('btnResetCfg').addEventListener('click', function () {
            var b = $('btnResetCfg');
            if (state.busy) return;
            if (!b.classList.contains('armed')) {   // báº¥m 2 láº§n Ä‘á»ƒ trÃ¡nh báº¥m nháº§m
                b.classList.add('armed'); b.textContent = T('Click again to restore');
                rstTimer = setTimeout(function () { b.classList.remove('armed'); b.textContent = T('Restore defaults'); }, 3000);
                return;
            }
            clearTimeout(rstTimer); b.classList.remove('armed'); b.textContent = T('Restore defaults');
            resetCfg();
        });
        if (LIBDIR) NN.host('nn_lib_clean', { dir: LIBDIR, days: 60, keep: state.sizes.map(function (s) { return s.docPath; }).filter(Boolean) });   // báº£n chÃ©p cÅ© khÃ´ng dÃ¹ng > 60 ngÃ y
        $('btnScan').addEventListener('click', needLicense(addSize));
        $('btnOpenSets').addEventListener('click', openSets);
        $('btnSaveYes').addEventListener('click', saveYes);
        $('btnSaveNo').addEventListener('click', function () { closeSave('', true); });
        $('btnSaveSet').addEventListener('click', saveNow);
        $('btnSaveGo').addEventListener('click', saveGo);
        $('btnSaveCancel').addEventListener('click', function () { closeSave(T('Pattern set not saved.'), true); });
        $('btnSaveFolder').addEventListener('click', async function () { if (await pickSaveFolder()) { saveCtx.overwrite = false; $('saveWarn').hidden = true; } });
        $('saveName').addEventListener('input', function () { if (saveCtx) { saveCtx.overwrite = false; $('saveWarn').hidden = true; } });
        $('saveName').addEventListener('keydown', function (e) { if (e.key === 'Enter') saveGo(); });
        var clearTimer = null;
        $('btnClearAll').addEventListener('click', function () {
            var b = $('btnClearAll');
            if (state.busy || !state.sizes.length) return;
            if (!b.classList.contains('armed')) {   // báº¥m 2 láº§n Ä‘á»ƒ trÃ¡nh xoÃ¡ nháº§m
                b.classList.add('armed'); b.textContent = T('Click again to clear');
                clearTimer = setTimeout(function () { b.classList.remove('armed'); b.textContent = T('Clear all'); }, 3000);
                return;
            }
            clearTimeout(clearTimer);
            b.classList.remove('armed'); b.textContent = T('Clear all');
            state.sizes = []; state.selected = ''; state.test = {}; state.dirty = false;
            saveSizes(); invalidate(); renderSizes();
            log(T('Cleared the whole size list.'));
        });
        // Quay láº¡i bÆ°á»›c quÃ©t vÃ  xÃ³a Ä‘Æ¡n vá»«a cháº¡y: danh sÃ¡ch size, káº¿t quáº£ ghÃ©p/xáº¿p/kiá»ƒm tra, vÃ  thÆ° má»¥c lÃ m viá»‡c.
        // ThÆ° má»¥c kho (báº£n chÃ©p file ráº­p Ä‘Ã£ quÃ©t) giá»¯ nguyÃªn Ä‘á»ƒ láº§n sau dÃ¹ng láº¡i. Báº¥m 2 láº§n Ä‘á»ƒ trÃ¡nh nháº§m.
        var backTimer = null;
        function onBackToScan() {
            if (state.busy) return;
            var btns = [$('btnBackScan'), $('btnBackScan2')];
            if (!btns[0].classList.contains('armed')) {
                btns.forEach(function (b) { b.classList.add('armed'); b.textContent = T('Click again to clear this order'); });
                backTimer = setTimeout(function () { btns.forEach(function (b) { b.classList.remove('armed'); b.textContent = T('Back to scan and clear this order'); }); }, 3000);
                return;
            }
            clearTimeout(backTimer);
            btns.forEach(function (b) { b.classList.remove('armed'); b.textContent = T('Back to scan and clear this order'); });
            state.sizes = []; state.selected = ''; state.test = {}; state.dirty = false;
            saveSizes(); invalidate(); renderSizes();
            $('tblNest').innerHTML = ''; $('tblRun').innerHTML = '';
            state.step = 1; refreshSteps();
            if (WORKDIR) NN.host('nn_work_clean', { dir: WORKDIR, all: true });
            log(T('Order cleared. Scan the next order.'));
        }
        $('btnBackScan').addEventListener('click', onBackToScan);
        $('btnBackScan2').addEventListener('click', onBackToScan);

        $('btnPair').addEventListener('click', needLicense(pair));
        $('btnStop').addEventListener('click', stopAll);
        $('btnStopRun').addEventListener('click', stopAll);
        $('btnStopExp').addEventListener('click', stopAll);
        $('btnManual').addEventListener('click', applyManual);
        $('btnApprove').addEventListener('click', approve);
        $('btnNest').addEventListener('click', needLicense(nestAll));
        $('btnExport').addEventListener('click', needLicense(exportAll));
        $('btnToPair').addEventListener('click', toPair);
        $('btnOpenAll').addEventListener('click', openResults);
        $('tblCheck').addEventListener('click', function (e) {
            var v = e.target.getAttribute && e.target.getAttribute('data-view');
            if (v !== null && v !== undefined) openOne(+v);
        });
        $('stepper').addEventListener('click', function (e) {
            var b = e.target.closest ? e.target.closest('button') : null;
            if (b && !b.disabled) goStep(+b.getAttribute('data-step'));
        });
        $('tblSizes').addEventListener('click', onSizesClick);
        $('btnLog').addEventListener('click', function () { $('logModal').hidden = false; $('logDot').hidden = true; var el = $('log'); el.scrollTop = el.scrollHeight; });
        $('btnLogClose').addEventListener('click', function () { $('logModal').hidden = true; });
        $('btnLogClear').addEventListener('click', function () { $('log').textContent = ''; });
        $('logModal').addEventListener('click', function (e) { if (e.target === $('logModal')) $('logModal').hidden = true; });
        $('tblSizes').addEventListener('change', onSizesChange);
        $('tblPlan').addEventListener('input', function (e) {
            var i = e.target.getAttribute && e.target.getAttribute('data-fn');
            if (i !== null && i !== undefined && state.plan) state.plan.markers[+i].customName = e.target.value;
        });
        try { $('namePrefix').value = localStorage.getItem('novanest.prefix') || ''; } catch (e) { /* bá» qua */ }
        $('namePrefix').addEventListener('change', function () { try { localStorage.setItem('novanest.prefix', $('namePrefix').value); } catch (e) { /* bá» qua */ } });
        $('sizeChips').addEventListener('click', function (e) {
            var n = e.target.getAttribute && e.target.getAttribute('data-size');
            if (n) selectSize(n);
        });
        ['rK2', 'rK3'].forEach(function (id) {
            $(id).addEventListener('change', function () {
                try { localStorage.setItem('novanest.maxSizes', $('rK2').checked ? '2' : '3'); } catch (e) { /* bá» qua */ }
                invalidate();
            });
        });
        $('btnNest').disabled = true; $('btnPair').disabled = true;
        NN.npInit().then(function (threads) {
            engineReady = true;
            log(T('Engine ready: {0} threads.', [threads]));
            $('btnNest').disabled = state.busy; $('btnPair').disabled = state.busy;
        }, function () { engineReady = true; $('btnNest').disabled = state.busy; $('btnPair').disabled = state.busy; });
        NN.host('nn_ping', {}).then(function (r) {
            if (r && r.ok) log(T('Connected to Illustrator {0}. Engine: Nest-Pro Sparrow.', [r.version]));
            else log(T('Could not connect to Illustrator yet: {0}', [r && r.error ? r.error : '']));
        });
    }
    init();
})();
