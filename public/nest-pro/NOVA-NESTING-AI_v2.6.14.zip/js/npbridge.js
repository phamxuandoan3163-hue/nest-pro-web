/* Nova Nest - cầu nối tới engine Nest-Pro Sparrow.
 * Chạy engine trong nhóm Web Worker (song song khi mô phỏng nhiều tổ hợp), dự phòng chạy trong trang panel.
 * NN.npRun(input, onProgress) -> Promise(kết quả NP_runPipeline)
 * input = { cfg: {rollW, gap, marginL, marginR, marginT, marginB, displayMode, strokeWidth, rotationMode, searchMs}, pieces: [...] }
 */
(function (root) {
    'use strict';
    var NN = root.NN = root.NN || {};
    var workers = [], idle = [], queue = [], pending = {}, nextId = 1;
    var initPromise = null, useWorkers = false;
    var pageChain = Promise.resolve(), pageCtls = [];

    function poolSize() {
        var hc = (root.navigator && navigator.hardwareConcurrency) || 2;
        return Math.max(1, Math.min(4, hc - 1));
    }

    function spawn() {
        return new Promise(function (resolve) {
            var w, done = false;
            try { w = new Worker('js/np/worker.js'); } catch (e) { resolve(null); return; }
            var timer = setTimeout(function () {
                if (!done) { done = true; try { w.terminate(); } catch (e) { /* bỏ qua */ } resolve(null); }
            }, 4000);
            w.onmessage = function (e) {
                if (e.data && e.data.type === 'ready' && !done) {
                    done = true; clearTimeout(timer);
                    w.onmessage = onMsg;
                    resolve(w);
                }
            };
            w.onerror = function () { if (!done) { done = true; clearTimeout(timer); resolve(null); } };
        });
    }

    function onMsg(e) {
        var m = e.data, job = pending[m.id];
        if (!job) return;
        if (m.type === 'progress') { if (job.onProgress) job.onProgress(m.p); return; }
        delete pending[m.id];
        idle.push(job.worker);
        if (m.type === 'done') job.resolve(m.r); else job.reject(m.msg);
        pump();
    }

    function pump() {
        while (idle.length && queue.length) {
            var job = queue.shift(), w = idle.pop();
            job.worker = w;
            pending[job.id] = job;
            w.postMessage({ cmd: 'run', id: job.id, input: job.input });
        }
    }

    function loadScript(src) {
        return new Promise(function (resolve, reject) {
            var el = document.createElement('script');
            el.src = src; el.onload = resolve; el.onerror = function () { reject('Không nạp được ' + src); };
            document.head.appendChild(el);
        });
    }
    function loadPageEngine() {
        if (root.NP_runPipeline) return Promise.resolve();
        return loadScript('js/np/engine.js').then(function () { return loadScript('js/np/pipeline.js'); });
    }

    NN.npInit = function () {
        if (initPromise) return initPromise;
        initPromise = (async function () {
            // Start all workers at once: each one loads the engine, so starting them one by one
            // made the progress bar sit still for several seconds before anything moved.
            var n = poolSize();
            var started = await Promise.all(Array.from({ length: n }, function () { return spawn(); }));
            started.forEach(function (w) { if (w) { workers.push(w); idle.push(w); } });
            useWorkers = workers.length > 0;
            return workers.length || 1;
        })();
        return initPromise;
    };

    NN.npThreads = function () { return useWorkers ? workers.length : 1; };

    NN.npRun = function (input, onProgress) {
        return NN.npInit().then(function () {
            if (useWorkers) {
                return new Promise(function (resolve, reject) {
                    queue.push({ id: nextId++, input: input, onProgress: onProgress, resolve: resolve, reject: reject });
                    pump();
                });
            }
            // dự phòng: chạy tuần tự ngay trong trang panel (chỉ nạp engine khi cần)
            var ctl = { cancel: false, skip: false };
            pageCtls.push(ctl);
            var p = pageChain.then(loadPageEngine).then(function () {
                if (ctl.cancel) throw 'CANCELLED';
                return root.NP_runPipeline(input, onProgress || function () {}, ctl);
            });
            pageChain = p.catch(function () {});
            return p;
        });
    };

    // Dừng mọi việc đang chạy / đang chờ
    NN.npCancelAll = function () {
        queue.splice(0).forEach(function (j) { j.reject('CANCELLED'); });
        Object.keys(pending).forEach(function (id) {
            var j = pending[id];
            delete pending[id];
            j.reject('CANCELLED');
        });
        workers.forEach(function (w) { try { w.terminate(); } catch (e) { /* bỏ qua */ } });
        workers = []; idle = []; initPromise = null; useWorkers = false;
        pageCtls.forEach(function (c) { c.cancel = true; });
        pageCtls = [];
    };
})(window);
