/* Nova Nesting AI - Marker Making & Nesting: 4 languages. English is the base/default language;
 * the source text in index.html and in T('...') calls is English, and DICT gives VI / TH / ES.
 * Static text in the page is translated by NovaI18n.apply(); code uses NovaI18n.t(src, args).
 * Error text from Illustrator (host.jsx) is translated by known fragments (FRAG).
 */
(function (root) {
  var LANGS = ["en", "vi", "th", "es"];
  var STORE = "nns.lang";

  // DICT["english source"] = { vi, th, es }. Placeholders {0} {1} ... are filled by t(src, args).
  var DICT = {
    "STOPPED": { vi: "ĐÃ DỪNG", th: "หยุดแล้ว", es: "DETENIDO" },
    "ERROR": { vi: "LỖI", th: "ข้อผิดพลาด", es: "ERROR" },
    "DONE  100%": { vi: "HOÀN TẤT  100%", th: "เสร็จ  100%", es: "LISTO  100%" },
    "DONE WITH ERRORS": { vi: "XONG NHƯNG CÓ LỖI", th: "เสร็จแต่มีข้อผิดพลาด", es: "LISTO CON ERRORES" },
    "Cancelled.": { vi: "Đã huỷ.", th: "ยกเลิกแล้ว", es: "Cancelado." },
    "There was an error, see the Log.": { vi: "Có lỗi, xem nhật ký.", th: "มีข้อผิดพลาด ดูบันทึก", es: "Hubo un error, consulte el registro." },
    "{0} markers checked.": { vi: "{0} sơ đồ đã kiểm tra.", th: "ตรวจ {0} มาร์กเกอร์แล้ว", es: "{0} marcadas revisadas." },
    "Hand-edited size pairs checked.": { vi: "Đã kiểm tra cặp size chỉnh tay.", th: "ตรวจคู่ไซซ์ที่แก้เองแล้ว", es: "Combinaciones manuales revisadas." },
    "Nested {0}/{1} markers.": { vi: "Đã xếp {0}/{1} sơ đồ.", th: "จัดวาง {0}/{1} มาร์กเกอร์แล้ว", es: "Encajadas {0}/{1} marcadas." },
    "Exported {0} marker files + report.": { vi: "Đã xuất {0} file sơ đồ + báo cáo.", th: "ส่งออกไฟล์มาร์กเกอร์ {0} ไฟล์ + รายงาน", es: "Exportados {0} archivos de marcada + informe." },
    "Exported {0}/{1} files, see the Log.": { vi: "Đã xuất {0}/{1} file, xem Nhật ký.", th: "ส่งออก {0}/{1} ไฟล์ ดูบันทึก", es: "Exportados {0}/{1} archivos, consulte el registro." },
    "Log": { vi: "Nhật ký", th: "บันทึก", es: "Registro" },
    "READY": { vi: "SẴN SÀNG", th: "พร้อม", es: "LISTO" },
    "Select the pieces of one size on the canvas to start.": { vi: "Chọn chi tiết của một size trên canvas để bắt đầu.", th: "เลือกชิ้นงานของหนึ่งไซซ์บนแคนวาสเพื่อเริ่ม", es: "Seleccione las piezas de una talla en la mesa de trabajo para empezar." },
    "Scan": { vi: "Quét", th: "สแกน", es: "Escanear" },
    "Pair sizes": { vi: "Ghép cặp", th: "จับคู่ไซซ์", es: "Combinar" },
    "Nest": { vi: "Xếp sơ đồ", th: "จัดมาร์กเกอร์", es: "Encajar" },
    "Check": { vi: "Kiểm tra", th: "ตรวจสอบ", es: "Revisar" },
    "Export": { vi: "Xuất file", th: "ส่งออกไฟล์", es: "Exportar" },
    "Settings": { vi: "Cài đặt", th: "ตั้งค่า", es: "Ajustes" },
    "Fabric width (cm)": { vi: "Khổ vải (cm)", th: "หน้าผ้า (ซม.)", es: "Ancho de tela (cm)" },
    "Gap between pieces (cm)": { vi: "Khoảng hở giữa chi tiết (cm)", th: "ระยะห่างระหว่างชิ้น (ซม.)", es: "Separación entre piezas (cm)" },
    "Left margin (cm)": { vi: "Lề trái (cm)", th: "ขอบซ้าย (ซม.)", es: "Margen izquierdo (cm)" },
    "Right margin (cm)": { vi: "Lề phải (cm)", th: "ขอบขวา (ซม.)", es: "Margen derecho (cm)" },
    "Top margin (cm)": { vi: "Lề trên (cm)", th: "ขอบบน (ซม.)", es: "Margen superior (cm)" },
    "Bottom margin (cm)": { vi: "Lề dưới (cm)", th: "ขอบล่าง (ซม.)", es: "Margen inferior (cm)" },
    "Rotation when nesting": { vi: "Hướng xoay khi xếp", th: "การหมุนขณะจัดวาง", es: "Rotación al encajar" },
    "No rotation": { vi: "Không xoay", th: "ไม่หมุน", es: "Sin rotación" },
    "Rotate 180° (default)": { vi: "Xoay 180° (mặc định)", th: "หมุน 180° (ค่าเริ่มต้น)", es: "Girar 180° (predeterminado)" },
    "Rotate 90° (0, 90, 180, 270)": { vi: "Xoay 90° (0, 90, 180, 270)", th: "หมุน 90° (0, 90, 180, 270)", es: "Girar 90° (0, 90, 180, 270)" },
    "Every 45°": { vi: "Mỗi 45°", th: "ทุก 45°", es: "Cada 45°" },
    "Every 30°": { vi: "Mỗi 30°", th: "ทุก 30°", es: "Cada 30°" },
    "PDF-compatible .ai file (preview, readable by print software)": { vi: "File .ai tương thích PDF (xem trước, phần mềm in đọc được)", th: "ไฟล์ .ai ที่รองรับ PDF (ดูตัวอย่างได้ โปรแกรมพิมพ์อ่านได้)", es: "Archivo .ai compatible con PDF (vista previa, legible por el software de impresión)" },
    "Use the tested layout, skip extra nesting (faster)": { vi: "Dùng luôn bố cục đã test, bỏ bước xếp thêm (nhanh hơn)", th: "ใช้เลย์เอาต์ที่ทดสอบแล้ว ข้ามการจัดวางเพิ่ม (เร็วกว่า)", es: "Usar la distribución probada, omitir el encaje adicional (más rápido)" },
    "Clip the design to the pattern outline in the marker (recommended)": { vi: "Cắt design theo đường rập trong sơ đồ (khuyên dùng)", th: "ตัดดีไซน์ตามเส้นแพทเทิร์นในมาร์กเกอร์ (แนะนำ)", es: "Recortar el diseño al contorno del patrón en la marcada (recomendado)" },
    "Export as outlines (with size labels and frame) instead of the design": { vi: "Xuất dạng nét (có nhãn size, khung) thay vì design", th: "ส่งออกเป็นเส้น (มีป้ายไซซ์และกรอบ) แทนดีไซน์", es: "Exportar como contornos (con etiquetas de talla y marco) en lugar del diseño" },
    "Ask to save the pattern set when pairing sizes": { vi: "Hỏi lưu bộ rập khi bấm ghép cặp", th: "ถามเพื่อบันทึกชุดแพทเทิร์นเมื่อกดจับคู่ไซซ์", es: "Preguntar si guardar el juego de patrones al combinar tallas" },
    "Restore defaults": { vi: "Khôi phục mặc định", th: "คืนค่าเริ่มต้น", es: "Restaurar valores predeterminados" },
    "Click again to restore": { vi: "Bấm lần nữa để khôi phục", th: "กดอีกครั้งเพื่อคืนค่า", es: "Haga clic de nuevo para restaurar" },
    "Scan design": { vi: "Quét design", th: "สแกนดีไซน์", es: "Escanear diseño" },
    "Select all pieces (with design) of one size in Illustrator, choose the size below, then click Scan. The design is saved in the Nova Nest library, so you can close the pattern file after scanning.": { vi: "Chọn tất cả chi tiết (có design) của một size trong Illustrator, chọn size bên dưới rồi bấm quét. Design được lưu vào kho của Nova Nest, nên quét xong có thể đóng file rập.", th: "เลือกชิ้นงานทั้งหมด (พร้อมดีไซน์) ของหนึ่งไซซ์ใน Illustrator เลือกไซซ์ด้านล่าง แล้วกดสแกน ดีไซน์จะถูกบันทึกในคลังของ Nova Nest จึงปิดไฟล์แพทเทิร์นได้หลังสแกน", es: "Seleccione todas las piezas (con diseño) de una talla en Illustrator, elija la talla abajo y haga clic en Escanear. El diseño se guarda en la biblioteca de Nova Nest, así que puede cerrar el archivo de patrones después." },
    "Scan selection & save design": { vi: "Quét vùng chọn & lưu design", th: "สแกนส่วนที่เลือกและบันทึกดีไซน์", es: "Escanear selección y guardar diseño" },
    "Open saved pattern set...": { vi: "Mở bộ rập đã lưu...", th: "เปิดชุดแพทเทิร์นที่บันทึกไว้...", es: "Abrir juego de patrones guardado..." },
    "Quantity per size": { vi: "Số lượng từng size", th: "จำนวนแต่ละไซซ์", es: "Cantidad por talla" },
    "Save pattern set...": { vi: "Lưu bộ rập...", th: "บันทึกชุดแพทเทิร์น...", es: "Guardar juego de patrones..." },
    "Clear all": { vi: "Xoá tất cả", th: "ลบทั้งหมด", es: "Borrar todo" },
    "Click again to clear": { vi: "Bấm lần nữa để xoá", th: "กดอีกครั้งเพื่อลบ", es: "Haga clic de nuevo para borrar" },
    "Enter quantities in the Qty column. Sizes left empty or 0 are not nested.": { vi: "Điền số lượng ở cột SL. Size để trống hoặc 0 sẽ không được xếp.", th: "กรอกจำนวนในคอลัมน์จำนวน ไซซ์ที่เว้นว่างหรือเป็น 0 จะไม่ถูกจัดวาง", es: "Introduzca las cantidades en la columna Cant. Las tallas vacías o en 0 no se encajan." },
    "Next: pair sizes": { vi: "Tiếp: ghép cặp", th: "ถัดไป: จับคู่ไซซ์", es: "Siguiente: combinar tallas" },
    "Simulate & pair sizes": { vi: "Mô phỏng & ghép cặp", th: "จำลองและจับคู่ไซซ์", es: "Simular y combinar tallas" },
    "Number of sizes per marker:": { vi: "Chọn số size đi chung một sơ đồ:", th: "จำนวนไซซ์ต่อหนึ่งมาร์กเกอร์:", es: "Número de tallas por marcada:" },
    "2 sizes / marker": { vi: "2 size / sơ đồ", th: "2 ไซซ์ / มาร์กเกอร์", es: "2 tallas / marcada" },
    "Up to 3 sizes / marker": { vi: "Tối đa 3 size / sơ đồ", th: "สูงสุด 3 ไซซ์ / มาร์กเกอร์", es: "Hasta 3 tallas / marcada" },
    "Run simulation & pairing": { vi: "Chạy mô phỏng & ghép cặp", th: "เริ่มจำลองและจับคู่", es: "Ejecutar simulación y combinación" },
    "Stop": { vi: "Dừng", th: "หยุด", es: "Detener" },
    "Pairing result": { vi: "Kết quả ghép cặp", th: "ผลการจับคู่", es: "Resultado de la combinación" },
    "Order code / file name prefix (optional)": { vi: "Mã đơn / tiền tố tên file (tuỳ chọn)", th: "รหัสออเดอร์ / คำนำหน้าชื่อไฟล์ (ไม่บังคับ)", es: "Código de pedido / prefijo del archivo (opcional)" },
    "Edit each file name in the first column; the number of plies is always added to the end of the name.": { vi: "Sửa tên từng file ở cột đầu; số lớp in luôn được thêm vào cuối tên.", th: "แก้ชื่อไฟล์ในคอลัมน์แรกได้ จำนวนชั้นจะถูกเติมท้ายชื่อเสมอ", es: "Edite el nombre de cada archivo en la primera columna; el número de capas se añade siempre al final." },
    "Consumption per size": { vi: "Định mức từng size", th: "อัตราสิ้นเปลืองแต่ละไซซ์", es: "Consumo por talla" },
    "Edit size pairs by hand": { vi: "Chỉnh tay cặp size", th: "แก้คู่ไซซ์ด้วยตนเอง", es: "Editar combinaciones a mano" },
    "One file per line: <code>file_name plies</code>, for example <code>S_M 100</code>.": { vi: "Mỗi dòng một file: <code>tên_file số_lớp</code>, ví dụ <code>S_M 100</code>.", th: "หนึ่งไฟล์ต่อบรรทัด: <code>ชื่อไฟล์ จำนวนชั้น</code> เช่น <code>S_M 100</code>", es: "Un archivo por línea: <code>nombre_archivo capas</code>, por ejemplo <code>S_M 100</code>." },
    "Apply manual pairs": { vi: "Áp dụng chỉnh tay", th: "ใช้คู่ที่แก้เอง", es: "Aplicar combinaciones manuales" },
    "Approve pairing": { vi: "Duyệt cách ghép", th: "อนุมัติการจับคู่", es: "Aprobar combinación" },
    "Sparrow nests each marker for real (in parallel), then builds the marker files in the background (one layer per size, layer name = size). Scanned pattern files are not opened. Temporary files stay in the work folder, not in the output folder yet.": { vi: "Sparrow xếp chính thức từng sơ đồ (song song), rồi dựng file sơ đồ chạy ngầm (mỗi size một layer, tên layer = tên size). Không mở file rập đã quét. File tạm nằm trong thư mục làm việc, chưa vào thư mục kết quả.", th: "Sparrow จัดวางมาร์กเกอร์จริงทีละไฟล์ (แบบขนาน) แล้วสร้างไฟล์มาร์กเกอร์เบื้องหลัง (หนึ่งเลเยอร์ต่อไซซ์ ชื่อเลเยอร์ = ไซซ์) โดยไม่เปิดไฟล์แพทเทิร์นที่สแกนแล้ว ไฟล์ชั่วคราวอยู่ในโฟลเดอร์งาน ยังไม่อยู่ในโฟลเดอร์ผลลัพธ์", es: "Sparrow encaja cada marcada de forma definitiva (en paralelo) y luego crea los archivos en segundo plano (una capa por talla, nombre de capa = talla). No abre los archivos de patrones escaneados. Los archivos temporales quedan en la carpeta de trabajo, aún no en la de resultados." },
    "The panel checks piece count, gaps and marker scale. The new markers open in Illustrator for you to review and edit (one layer per size). Leave them open when done; the Export step saves them.": { vi: "Panel tự kiểm: đủ chi tiết, khoảng hở, tỉ lệ sơ đồ. Các sơ đồ vừa dựng được mở trong Illustrator để bạn xem và chỉnh (mỗi size một layer). Chỉnh xong cứ để mở, bước Xuất file sẽ tự lưu lại.", th: "แผงจะตรวจจำนวนชิ้น ระยะห่าง และสเกลของมาร์กเกอร์ มาร์กเกอร์ที่สร้างใหม่จะเปิดใน Illustrator ให้ตรวจและแก้ (หนึ่งเลเยอร์ต่อไซซ์) แก้เสร็จให้เปิดไว้ ขั้นส่งออกจะบันทึกให้เอง", es: "El panel revisa el número de piezas, la separación y la escala. Las marcadas nuevas se abren en Illustrator para revisarlas y editarlas (una capa por talla). Al terminar déjelas abiertas; el paso Exportar las guarda." },
    "Reopen all markers in Illustrator": { vi: "Mở lại tất cả sơ đồ trong Illustrator", th: "เปิดมาร์กเกอร์ทั้งหมดใน Illustrator อีกครั้ง", es: "Volver a abrir todas las marcadas en Illustrator" },
    "Copies the marker .ai files (including your edits) to the folder you choose, with a CSV consumption report. The output folder holds only these files.": { vi: "Chép các file sơ đồ .ai (đã lưu cả phần bạn chỉnh) vào thư mục bạn chọn, kèm báo cáo định mức CSV. Thư mục kết quả chỉ có các file này.", th: "คัดลอกไฟล์มาร์กเกอร์ .ai (รวมส่วนที่คุณแก้) ไปยังโฟลเดอร์ที่เลือก พร้อมรายงานอัตราสิ้นเปลือง CSV โฟลเดอร์ผลลัพธ์จะมีเฉพาะไฟล์เหล่านี้", es: "Copia los archivos .ai de las marcadas (con sus cambios) a la carpeta elegida, junto con un informe de consumo CSV. La carpeta de resultados solo contiene estos archivos." },
    "Choose folder & export": { vi: "Chọn thư mục & xuất file", th: "เลือกโฟลเดอร์และส่งออก", es: "Elegir carpeta y exportar" },
    "Save pattern set?": { vi: "Lưu bộ rập?", th: "บันทึกชุดแพทเทิร์น?", es: "¿Guardar juego de patrones?" },
    "Save this pattern set (with design) so you can reuse it without scanning again?": { vi: "Bạn có muốn lưu bộ rập này (kèm design) để dùng lại mà không cần quét lại không?", th: "ต้องการบันทึกชุดแพทเทิร์นนี้ (พร้อมดีไซน์) เพื่อใช้ซ้ำโดยไม่ต้องสแกนใหม่หรือไม่?", es: "¿Guardar este juego de patrones (con diseño) para reutilizarlo sin volver a escanear?" },
    "Save...": { vi: "Lưu...", th: "บันทึก...", es: "Guardar..." },
    "Skip": { vi: "Bỏ qua", th: "ข้าม", es: "Omitir" },
    "File name": { vi: "Tên file", th: "ชื่อไฟล์", es: "Nombre del archivo" },
    "The file already exists. Click Save again to overwrite, or change the name.": { vi: "File đã tồn tại. Bấm Lưu lần nữa để ghi đè, hoặc đổi tên.", th: "มีไฟล์นี้อยู่แล้ว กดบันทึกอีกครั้งเพื่อเขียนทับ หรือเปลี่ยนชื่อ", es: "El archivo ya existe. Haga clic en Guardar de nuevo para sobrescribirlo o cambie el nombre." },
    "Save": { vi: "Lưu", th: "บันทึก", es: "Guardar" },
    "Change folder": { vi: "Đổi thư mục", th: "เปลี่ยนโฟลเดอร์", es: "Cambiar carpeta" },
    "Cancel": { vi: "Hủy", th: "ยกเลิก", es: "Cancelar" },
    "Clear": { vi: "Xoá", th: "ล้าง", es: "Borrar" },
    "Close": { vi: "Đóng", th: "ปิด", es: "Cerrar" },
    "Back": { vi: "Quay lại", th: "กลับ", es: "Volver" },
    "Activate Nova Nesting AI to start. Enter the key you bought or start a free 7-day trial.": { vi: "Kích hoạt Nova Nesting AI để bắt đầu sử dụng. Nhập key đã mua hoặc dùng thử miễn phí 7 ngày.", th: "เปิดใช้งาน Nova Nesting AI เพื่อเริ่มใช้งาน กรอกคีย์ที่ซื้อไว้หรือทดลองใช้ฟรี 7 วัน", es: "Active Nova Nesting AI para empezar. Introduzca la clave que compró o inicie una prueba gratuita de 7 días." },
    "Connecting to the license server...": { vi: "Đang kết nối máy chủ license...", th: "กำลังเชื่อมต่อเซิร์ฟเวอร์ license...", es: "Conectando con el servidor de licencias..." },
    "Activate": { vi: "Kích hoạt", th: "เปิดใช้งาน", es: "Activar" },
    "7-day trial": { vi: "Dùng thử 7 ngày", th: "ทดลองใช้ 7 วัน", es: "Prueba de 7 días" },
    "Buy & renew": { vi: "Mua & gia hạn", th: "ซื้อและต่ออายุ", es: "Comprar y renovar" },
    "Renew license": { vi: "Gia hạn license", th: "ต่ออายุ license", es: "Renovar licencia" },
    "Offline activation (when the network is blocked)": { vi: "Kích hoạt ngoại tuyến (khi bị chặn mạng)", th: "เปิดใช้งานแบบออฟไลน์ (เมื่อเครือข่ายถูกบล็อก)", es: "Activación sin conexión (si la red está bloqueada)" },
    "Use this when the panel cannot reach the server. Open the activation page in a browser, enter your key and the device code below, then paste the code you receive into the last box.": { vi: "Dùng khi panel không kết nối được máy chủ. Mở trang kích hoạt trên trình duyệt, nhập key và mã máy bên dưới, rồi dán mã nhận được vào ô cuối.", th: "ใช้เมื่อแผงเชื่อมต่อเซิร์ฟเวอร์ไม่ได้ เปิดหน้าเปิดใช้งานในเบราว์เซอร์ กรอกคีย์และรหัสเครื่องด้านล่าง แล้ววางรหัสที่ได้รับในช่องสุดท้าย", es: "Úselo cuando el panel no pueda conectar con el servidor. Abra la página de activación en un navegador, introduzca su clave y el código del equipo de abajo y pegue el código recibido en el último campo." },
    "Device code (for the activation page)": { vi: "Mã máy (gửi cho trang kích hoạt)", th: "รหัสเครื่อง (สำหรับหน้าเปิดใช้งาน)", es: "Código del equipo (para la página de activación)" },
    "Copy": { vi: "Chép", th: "คัดลอก", es: "Copiar" },
    "Open activation page": { vi: "Mở trang kích hoạt", th: "เปิดหน้าเปิดใช้งาน", es: "Abrir página de activación" },
    "Paste the activation code here": { vi: "Dán mã kích hoạt vào đây", th: "วางรหัสเปิดใช้งานที่นี่", es: "Pegue aquí el código de activación" },
    "Apply code": { vi: "Áp dụng mã", th: "ใช้รหัส", es: "Aplicar código" },
    "Trial": { vi: "Dùng thử", th: "ทดลองใช้", es: "Prueba" },
    "The key is invalid or has expired.": { vi: "Key không hợp lệ hoặc đã hết hạn.", th: "คีย์ไม่ถูกต้องหรือหมดอายุแล้ว", es: "La clave no es válida o ha caducado." },
    "This key is already active on the maximum number of computers.": { vi: "Key này đã kích hoạt trên đủ số máy cho phép.", th: "คีย์นี้เปิดใช้งานครบจำนวนเครื่องที่อนุญาตแล้ว", es: "Esta clave ya está activa en el número máximo de equipos." },
    "This computer has already used the 7-day trial.": { vi: "Máy này đã dùng thử 7 ngày.", th: "เครื่องนี้ใช้สิทธิ์ทดลอง 7 วันไปแล้ว", es: "Este equipo ya usó la prueba de 7 días." },
    "Could not reach the license server.": { vi: "Không kết nối được máy chủ license.", th: "เชื่อมต่อเซิร์ฟเวอร์ license ไม่ได้", es: "No se pudo conectar con el servidor de licencias." },
    "The key format is not valid.": { vi: "Key không đúng định dạng.", th: "รูปแบบคีย์ไม่ถูกต้อง", es: "El formato de la clave no es válido." },
    "This code is for another computer.": { vi: "Mã này dành cho máy khác.", th: "รหัสนี้เป็นของเครื่องอื่น", es: "Este código es de otro equipo." },
    "The code is not valid.": { vi: "Mã không hợp lệ.", th: "รหัสไม่ถูกต้อง", es: "El código no es válido." },
    "The code could not be verified on this computer.": { vi: "Không xác thực được mã trên máy này.", th: "ไม่สามารถตรวจสอบรหัสบนเครื่องนี้ได้", es: "No se pudo verificar el código en este equipo." },
    "The activation code format is not valid.": { vi: "Mã kích hoạt sai định dạng.", th: "รูปแบบรหัสเปิดใช้งานไม่ถูกต้อง", es: "El formato del código de activación no es válido." },
    "The activation code has expired.": { vi: "Mã kích hoạt đã hết hạn.", th: "รหัสเปิดใช้งานหมดอายุแล้ว", es: "El código de activación ha caducado." },
    "The computer's date/time was set back. Set the correct date and time, then try again.": { vi: "Ngày giờ trên máy tính bị lùi. Hãy chỉnh lại đúng ngày giờ rồi thử lại.", th: "วันเวลาของคอมพิวเตอร์ถูกตั้งย้อนหลัง โปรดตั้งวันเวลาให้ถูกต้องแล้วลองอีกครั้ง", es: "La fecha/hora del equipo se atrasó. Ajuste la fecha y hora correctas e inténtelo de nuevo." },
    "Activated": { vi: "Đã kích hoạt", th: "เปิดใช้งานแล้ว", es: "Activada" },
    "Offline: using the saved license for up to 24 hours.": { vi: "Ngoại tuyến: đang dùng bản đã lưu tối đa 24 giờ.", th: "ออฟไลน์: ใช้ license ที่บันทึกไว้ได้สูงสุด 24 ชั่วโมง", es: "Sin conexión: se usa la licencia guardada durante 24 horas como máximo." },
    "{0} plan · expires {1}": { vi: "Gói {0} · hết hạn {1}", th: "แพ็กเกจ {0} · หมดอายุ {1}", es: "Plan {0} · caduca el {1}" },
    "Expired": { vi: "Hết hạn", th: "หมดอายุ", es: "Caducada" },
    "The license expired on {0}.": { vi: "License đã hết hạn {0}.", th: "license หมดอายุเมื่อ {0}", es: "La licencia caducó el {0}." },
    "Revoked": { vi: "Đã thu hồi", th: "ถูกเพิกถอน", es: "Revocada" },
    "This license has been revoked.": { vi: "License này đã bị thu hồi.", th: "license นี้ถูกเพิกถอนแล้ว", es: "Esta licencia ha sido revocada." },
    "Wrong date/time": { vi: "Sai ngày giờ", th: "วันเวลาไม่ถูกต้อง", es: "Fecha/hora incorrecta" },
    "The computer's date/time was set back. Set the correct date and time, then connect to the internet to check the license.": { vi: "Ngày giờ trên máy tính bị lùi. Hãy chỉnh lại đúng ngày giờ và kết nối mạng để kiểm tra license.", th: "วันเวลาของคอมพิวเตอร์ถูกตั้งย้อนหลัง โปรดตั้งวันเวลาให้ถูกต้องแล้วเชื่อมต่ออินเทอร์เน็ตเพื่อตรวจสอบ license", es: "La fecha/hora del equipo se atrasó. Ajuste la fecha y hora correctas y conéctese a internet para comprobar la licencia." },
    "Offline": { vi: "Ngoại tuyến", th: "ออฟไลน์", es: "Sin conexión" },
    "Not activated": { vi: "Chưa kích hoạt", th: "ยังไม่เปิดใช้งาน", es: "Sin activar" },
    "The key is invalid or not tied to this computer.": { vi: "Key không hợp lệ hoặc không thuộc máy này.", th: "คีย์ไม่ถูกต้องหรือไม่ได้ผูกกับเครื่องนี้", es: "La clave no es válida o no pertenece a este equipo." },
    "Enter a key or start the 7-day trial to begin.": { vi: "Nhập key hoặc dùng thử 7 ngày để bắt đầu.", th: "กรอกคีย์หรือเริ่มทดลองใช้ 7 วันเพื่อเริ่มต้น", es: "Introduzca una clave o inicie la prueba de 7 días para empezar." },
    "The license could not be activated.": { vi: "Không kích hoạt được license.", th: "เปิดใช้งาน license ไม่สำเร็จ", es: "No se pudo activar la licencia." },
    "Activate a license to use this feature.": { vi: "Cần kích hoạt license để dùng chức năng này.", th: "ต้องเปิดใช้งาน license ก่อนจึงจะใช้ฟังก์ชันนี้ได้", es: "Active una licencia para usar esta función." },
    "The license module could not be loaded.": { vi: "Không tải được mô-đun license.", th: "โหลดโมดูล license ไม่ได้", es: "No se pudo cargar el módulo de licencias." },
    "License activated.": { vi: "Đã kích hoạt license.", th: "เปิดใช้งาน license แล้ว", es: "Licencia activada." },
    "7-day trial started.": { vi: "Đã bắt đầu dùng thử 7 ngày.", th: "เริ่มทดลองใช้ 7 วันแล้ว", es: "Prueba de 7 días iniciada." },
    "Activated offline.": { vi: "Đã kích hoạt ngoại tuyến.", th: "เปิดใช้งานแบบออฟไลน์แล้ว", es: "Activada sin conexión." },
    "Starting...": { vi: "Đang khởi động...", th: "กำลังเริ่ม...", es: "Iniciando..." },
    "Settings restored to defaults.": { vi: "Đã đưa Cài đặt về mặc định.", th: "คืนค่าการตั้งค่าเป็นค่าเริ่มต้นแล้ว", es: "Ajustes restaurados a los valores predeterminados." },
    "Could not store the size list in the panel memory (too large); the data still works in this session.": { vi: "Không lưu được danh sách size vào bộ nhớ panel (quá lớn), dữ liệu vẫn dùng được trong phiên này.", th: "บันทึกรายการไซซ์ลงหน่วยความจำของแผงไม่ได้ (ใหญ่เกินไป) ข้อมูลยังใช้ได้ในเซสชันนี้", es: "No se pudo guardar la lista de tallas en la memoria del panel (demasiado grande); los datos siguen disponibles en esta sesión." },
    "Choose a size in the table.": { vi: "Hãy chọn size trong bảng.", th: "โปรดเลือกไซซ์ในตาราง", es: "Elija una talla en la tabla." },
    "Scanning and saving design for size {0}...": { vi: "Đang quét và lưu design size {0}...", th: "กำลังสแกนและบันทึกดีไซน์ไซซ์ {0}...", es: "Escaneando y guardando el diseño de la talla {0}..." },
    "Scan error: {0}": { vi: "Lỗi quét: {0}", th: "สแกนผิดพลาด: {0}", es: "Error de escaneo: {0}" },
    "Rescanned size {0}: {1} pieces, {2} dm², {3} s.": { vi: "Quét lại size {0}: {1} chi tiết, {2} dm², mất {3} giây.", th: "สแกนไซซ์ {0} ใหม่: {1} ชิ้น, {2} ตร.ดม., ใช้เวลา {3} วินาที", es: "Talla {0} escaneada de nuevo: {1} piezas, {2} dm², {3} s." },
    "Added size {0}: {1} pieces, {2} dm², {3} s.": { vi: "Thêm size {0}: {1} chi tiết, {2} dm², mất {3} giây.", th: "เพิ่มไซซ์ {0}: {1} ชิ้น, {2} ตร.ดม., ใช้เวลา {3} วินาที", es: "Talla {0} añadida: {1} piezas, {2} dm², {3} s." },
    "File \"{0}\" has unsaved changes: Nova Nest did NOT overwrite it, but saved what you see as a new file \"{1}\" in the Nova Nest library. The open window is now this new file; the original file on disk is unchanged.": { vi: "File \"{0}\" có thay đổi chưa lưu: Nova Nest KHÔNG lưu đè, mà lưu đúng nội dung đang thấy thành file mới \"{1}\" trong kho của Nova Nest. Cửa sổ đang mở giờ là file mới này; file gốc trên đĩa giữ nguyên.", th: "ไฟล์ \"{0}\" มีการแก้ไขที่ยังไม่บันทึก: Nova Nest ไม่ได้เขียนทับ แต่บันทึกสิ่งที่เห็นเป็นไฟล์ใหม่ \"{1}\" ในคลังของ Nova Nest หน้าต่างที่เปิดอยู่ตอนนี้คือไฟล์ใหม่ ไฟล์ต้นฉบับบนดิสก์ยังเหมือนเดิม", es: "El archivo \"{0}\" tiene cambios sin guardar: Nova Nest NO lo sobrescribió, sino que guardó lo que ve como un archivo nuevo \"{1}\" en la biblioteca de Nova Nest. La ventana abierta es ahora ese archivo nuevo; el original en disco no cambia." },
    "File \"{0}\" has unsaved changes: Nova Nest did NOT overwrite it, but saved what you see as a new file \"{1}\" in the NovaNest_rap folder. The open window is now this new file; the original file on disk is unchanged.": { vi: "File \"{0}\" có thay đổi chưa lưu: Nova Nest KHÔNG lưu đè, mà lưu đúng nội dung đang thấy thành file mới \"{1}\" trong thư mục NovaNest_rap. Cửa sổ đang mở giờ là file mới này; file gốc trên đĩa giữ nguyên.", th: "ไฟล์ \"{0}\" มีการแก้ไขที่ยังไม่บันทึก: Nova Nest ไม่ได้เขียนทับ แต่บันทึกสิ่งที่เห็นเป็นไฟล์ใหม่ \"{1}\" ในโฟลเดอร์ NovaNest_rap หน้าต่างที่เปิดอยู่ตอนนี้คือไฟล์ใหม่ ไฟล์ต้นฉบับบนดิสก์ยังเหมือนเดิม", es: "El archivo \"{0}\" tiene cambios sin guardar: Nova Nest NO lo sobrescribió, sino que guardó lo que ve como un archivo nuevo \"{1}\" en la carpeta NovaNest_rap. La ventana abierta es ahora ese archivo nuevo; el original en disco no cambia." },
    "The file had never been saved, so it was saved as \"{0}\" in the Nova Nest library.": { vi: "File chưa từng lưu nên được lưu thành \"{0}\" trong kho của Nova Nest.", th: "ไฟล์ยังไม่เคยบันทึก จึงบันทึกเป็น \"{0}\" ในคลังของ Nova Nest", es: "El archivo nunca se había guardado, así que se guardó como \"{0}\" en la biblioteca de Nova Nest." },
    "This file is already in the NovaNest_rap folder; using it directly.": { vi: "Đang quét file trong thư mục NovaNest_rap, dùng luôn file này.", th: "ไฟล์นี้อยู่ในโฟลเดอร์ NovaNest_rap แล้ว จึงใช้ไฟล์นี้เลย", es: "Este archivo ya está en la carpeta NovaNest_rap; se usa directamente." },
    "Saved a new file \"{0}\"": { vi: "Đã lưu file mới \"{0}\"", th: "บันทึกไฟล์ใหม่ \"{0}\" แล้ว", es: "Se guardó un archivo nuevo \"{0}\"" },
    "Using the existing file \"{0}\"": { vi: "Dùng file đã có \"{0}\"", th: "ใช้ไฟล์ที่มีอยู่ \"{0}\"", es: "Usando el archivo existente \"{0}\"" },
    "in the Nova Nest library (the pattern file's folder is not writable)": { vi: "trong kho của Nova Nest (thư mục file rập không ghi được)", th: "ในคลังของ Nova Nest (โฟลเดอร์ของไฟล์แพทเทิร์นเขียนไม่ได้)", es: "en la biblioteca de Nova Nest (la carpeta del archivo de patrones no admite escritura)" },
    "in the NovaNest_rap folder next to the pattern file": { vi: "trong thư mục NovaNest_rap cạnh file rập", th: "ในโฟลเดอร์ NovaNest_rap ข้างไฟล์แพทเทิร์น", es: "en la carpeta NovaNest_rap junto al archivo de patrones" },
    "The original file \"{0}\" is unchanged.": { vi: "File gốc \"{0}\" giữ nguyên.", th: "ไฟล์ต้นฉบับ \"{0}\" ไม่ถูกแก้ไข", es: "El archivo original \"{0}\" no cambia." },
    "{0} groups with several cut lines were kept as one piece each (not split).": { vi: "{0} group có nhiều đường cắt được giữ nguyên là 1 chi tiết (không tách).", th: "{0} กลุ่มที่มีเส้นตัดหลายเส้นถูกเก็บเป็น 1 ชิ้น (ไม่แยก)", es: "{0} grupos con varias líneas de corte se mantuvieron como una pieza (sin dividir)." },
    "(skipped {0} objects without a closed path, such as text)": { vi: "(bỏ qua {0} đối tượng không có đường khép kín, ví dụ chữ)", th: "(ข้าม {0} ออบเจ็กต์ที่ไม่มีเส้นปิด เช่น ตัวอักษร)", es: "(se omitieron {0} objetos sin trazado cerrado, como texto)" },
    "No sizes yet.": { vi: "Chưa có size nào.", th: "ยังไม่มีไซซ์", es: "Aún no hay tallas." },
    "Qty": { vi: "SL", th: "จำนวน", es: "Cant." },
    "Pieces": { vi: "Chi tiết", th: "ชิ้น", es: "Piezas" },
    "Largest piece {0} × {1} cm": { vi: "Chi tiết lớn nhất {0} × {1} cm", th: "ชิ้นใหญ่สุด {0} × {1} ซม.", es: "Pieza más grande {0} × {1} cm" },
    "scanned in {0} s": { vi: "quét {0} giây", th: "สแกน {0} วินาที", es: "escaneada en {0} s" },
    "Design saved in the library": { vi: "Design đã lưu trong kho", th: "บันทึกดีไซน์ในคลังแล้ว", es: "Diseño guardado en la biblioteca" },
    "library": { vi: "kho", th: "คลัง", es: "biblioteca" },
    "Design not saved; the original file is needed when exporting": { vi: "Chưa lưu design, cần file gốc khi xuất", th: "ยังไม่ได้บันทึกดีไซน์ ต้องใช้ไฟล์ต้นฉบับตอนส่งออก", es: "Diseño no guardado; se necesita el archivo original al exportar" },
    "outline only": { vi: "chỉ đường bao", th: "เฉพาะเส้นรอบ", es: "solo contorno" },
    "Size {0}: piece {1} is {2} cm wide, wider than the usable width of {3} cm.": { vi: "Size {0}: chi tiết {1} rộng {2} cm, vượt khổ dùng được {3} cm.", th: "ไซซ์ {0}: ชิ้น {1} กว้าง {2} ซม. เกินหน้าผ้าที่ใช้ได้ {3} ซม.", es: "Talla {0}: la pieza {1} mide {2} cm de ancho, más que el ancho útil de {3} cm." },
    "Nova Nest pattern set": { vi: "Bộ rập Nova Nest", th: "ชุดแพทเทิร์น Nova Nest", es: "Juego de patrones Nova Nest" },
    "Save pattern set (you can paste a folder path)": { vi: "Lưu bộ rập (có thể dán đường dẫn thư mục)", th: "บันทึกชุดแพทเทิร์น (วางพาธโฟลเดอร์ได้)", es: "Guardar juego de patrones (puede pegar una ruta de carpeta)" },
    "Save pattern set ({0} sizes)?": { vi: "Lưu bộ rập ({0} size)?", th: "บันทึกชุดแพทเทิร์น ({0} ไซซ์)?", es: "¿Guardar juego de patrones ({0} tallas)?" },
    "{0} pieces in total": { vi: "tổng {0} chi tiết", th: "รวม {0} ชิ้น", es: "{0} piezas en total" },
    "Error: {0}": { vi: "Lỗi: {0}", th: "ข้อผิดพลาด: {0}", es: "Error: {0}" },
    "Folder: {0}": { vi: "Thư mục: {0}", th: "โฟลเดอร์: {0}", es: "Carpeta: {0}" },
    "Pattern set not saved.": { vi: "Đã hủy lưu bộ rập.", th: "ยกเลิกการบันทึกชุดแพทเทิร์นแล้ว", es: "No se guardó el juego de patrones." },
    "Error saving pattern set: {0}": { vi: "Lỗi lưu bộ rập: {0}", th: "บันทึกชุดแพทเทิร์นผิดพลาด: {0}", es: "Error al guardar el juego de patrones: {0}" },
    "Saved pattern set with {0} sizes: {1}": { vi: "Đã lưu bộ rập {0} size: {1}", th: "บันทึกชุดแพทเทิร์น {0} ไซซ์แล้ว: {1}", es: "Juego de patrones de {0} tallas guardado: {1}" },
    "There are no sizes to save.": { vi: "Chưa có size nào để lưu.", th: "ยังไม่มีไซซ์ให้บันทึก", es: "No hay tallas para guardar." },
    "Error opening pattern set: {0}": { vi: "Lỗi mở bộ rập: {0}", th: "เปิดชุดแพทเทิร์นผิดพลาด: {0}", es: "Error al abrir el juego de patrones: {0}" },
    "Error: cannot read file {0}": { vi: "Lỗi: file không đọc được {0}", th: "ข้อผิดพลาด: อ่านไฟล์ไม่ได้ {0}", es: "Error: no se puede leer el archivo {0}" },
    "Error: not a Nova Nest pattern set {0}": { vi: "Lỗi: không phải bộ rập Nova Nest {0}", th: "ข้อผิดพลาด: ไม่ใช่ชุดแพทเทิร์น Nova Nest {0}", es: "Error: no es un juego de patrones de Nova Nest {0}" },
    "Opened pattern set size {0}: {1} pieces, quantity {2}.": { vi: "Mở bộ rập size {0}: {1} chi tiết, số lượng {2}.", th: "เปิดชุดแพทเทิร์นไซซ์ {0}: {1} ชิ้น จำนวน {2}", es: "Juego abierto, talla {0}: {1} piezas, cantidad {2}." },
    "Opened pattern set size {0}: {1} pieces.": { vi: "Mở bộ rập size {0}: {1} chi tiết.", th: "เปิดชุดแพทเทิร์นไซซ์ {0}: {1} ชิ้น", es: "Juego abierto, talla {0}: {1} piezas." },
    "Warning: design file \"{0}\" for size {1} was not found (moved or deleted?). Scan this size again.": { vi: "Cảnh báo: không thấy file design \"{0}\" của size {1} (đã bị di chuyển hoặc xoá?). Cần quét lại size này.", th: "คำเตือน: ไม่พบไฟล์ดีไซน์ \"{0}\" ของไซซ์ {1} (ถูกย้ายหรือลบ?) ต้องสแกนไซซ์นี้ใหม่", es: "Advertencia: no se encontró el archivo de diseño \"{0}\" de la talla {1} (¿se movió o eliminó?). Escanee esta talla de nuevo." },
    "Warning: size {0} has no saved design; reopen the original Illustrator file \"{1}\" when exporting.": { vi: "Cảnh báo: size {0} chưa có design lưu kèm, cần mở lại file Illustrator gốc \"{1}\" khi xuất.", th: "คำเตือน: ไซซ์ {0} ไม่มีดีไซน์ที่บันทึกไว้ ต้องเปิดไฟล์ Illustrator ต้นฉบับ \"{1}\" ตอนส่งออก", es: "Advertencia: la talla {0} no tiene diseño guardado; vuelva a abrir el archivo de Illustrator original \"{1}\" al exportar." },
    "Warning: file \"{0}\" matches only {1}/{2} pieces of size {3}; scan again if the file was edited.": { vi: "Cảnh báo: file \"{0}\" chỉ khớp {1}/{2} chi tiết của size {3}; cần quét lại nếu file đã bị sửa.", th: "คำเตือน: ไฟล์ \"{0}\" ตรงกันเพียง {1}/{2} ชิ้นของไซซ์ {3} ต้องสแกนใหม่หากไฟล์ถูกแก้ไข", es: "Advertencia: el archivo \"{0}\" solo coincide con {1}/{2} piezas de la talla {3}; escanee de nuevo si se modificó." },
    "No size has a quantity above 0. Enter quantities in the Qty column.": { vi: "Chưa có size nào có số lượng > 0. Hãy điền số lượng ở cột SL.", th: "ยังไม่มีไซซ์ที่มีจำนวนมากกว่า 0 โปรดกรอกจำนวนในคอลัมน์จำนวน", es: "Ninguna talla tiene cantidad mayor que 0. Introduzca las cantidades en la columna Cant." },
    "Cleared the whole size list.": { vi: "Đã xoá toàn bộ danh sách size.", th: "ลบรายการไซซ์ทั้งหมดแล้ว", es: "Se borró toda la lista de tallas." },
    "Reused {0} saved simulation results.": { vi: "Dùng lại {0} kết quả mô phỏng đã lưu.", th: "ใช้ผลการจำลองที่บันทึกไว้ {0} รายการ", es: "Se reutilizaron {0} resultados de simulación guardados." },
    "Simulation": { vi: "Mô phỏng", th: "การจำลอง", es: "Simulación" },
    "Simulation (1–2 sizes)": { vi: "Mô phỏng (1–2 size)", th: "การจำลอง (1–2 ไซซ์)", es: "Simulación (1–2 tallas)" },
    "Simulation (3 sizes)": { vi: "Mô phỏng (3 size)", th: "การจำลอง (3 ไซซ์)", es: "Simulación (3 tallas)" },
    "{0}: {1} combinations with Sparrow, {2} parallel threads (about {3} s)...": { vi: "{0}: {1} tổ hợp bằng Sparrow, {2} luồng song song (khoảng {3} giây)...", th: "{0}: {1} ชุดค่าผสมด้วย Sparrow, {2} เธรดขนาน (ประมาณ {3} วินาที)...", es: "{0}: {1} combinaciones con Sparrow, {2} hilos en paralelo (unos {3} s)..." },
    "{0} threads": { vi: "{0} luồng", th: "{0} เธรด", es: "{0} hilos" },
    "Simulation errors: {0}": { vi: "Lỗi mô phỏng {0}", th: "การจำลองผิดพลาด {0}", es: "Errores de simulación: {0}" },
    "Simulated {0} combinations in {1} s.": { vi: "Đã mô phỏng {0} tổ hợp trong {1} giây.", th: "จำลอง {0} ชุดค่าผสมใน {1} วินาที", es: "Se simularon {0} combinaciones en {1} s." },
    "Re-checking {0} paired markers ({1} s per marker)...": { vi: "Kiểm tra lại {0} sơ đồ đã ghép ({1} giây/sơ đồ)...", th: "กำลังตรวจซ้ำ {0} มาร์กเกอร์ที่จับคู่ ({1} วินาที/มาร์กเกอร์)...", es: "Revisando de nuevo {0} marcadas combinadas ({1} s por marcada)..." },
    "Checked {0} markers in {1} s:": { vi: "Kiểm tra xong {0} sơ đồ trong {1} giây:", th: "ตรวจ {0} มาร์กเกอร์เสร็จใน {1} วินาที:", es: "Se revisaron {0} marcadas en {1} s:" },
    "quantities match": { vi: "đủ số lượng", th: "จำนวนครบ", es: "cantidades completas" },
    "quantities do NOT match": { vi: "CHƯA khớp số lượng", th: "จำนวนยังไม่ตรง", es: "las cantidades NO coinciden" },
    "{0} markers need review": { vi: "{0} sơ đồ cần xem lại", th: "{0} มาร์กเกอร์ต้องตรวจดู", es: "{0} marcadas deben revisarse" },
    "gaps OK": { vi: "khoảng hở đạt", th: "ระยะห่างผ่าน", es: "separación correcta" },
    "order consumption {0} m/garment.": { vi: "định mức toàn đơn {0} m/sp.", th: "อัตราสิ้นเปลืองทั้งออเดอร์ {0} ม./ตัว", es: "consumo del pedido {0} m/prenda." },
    "Check error {0}": { vi: "Lỗi kiểm tra {0}", th: "ตรวจสอบผิดพลาด {0}", es: "Error de revisión {0}" },
    "Some pieces are wider than the fabric; check the size list.": { vi: "Có chi tiết rộng hơn khổ vải, hãy kiểm tra danh sách size.", th: "มีชิ้นที่กว้างกว่าหน้าผ้า โปรดตรวจรายการไซซ์", es: "Hay piezas más anchas que la tela; revise la lista de tallas." },
    "The fabric width or margins are not valid.": { vi: "Khổ vải hoặc lề chưa hợp lệ.", th: "หน้าผ้าหรือขอบไม่ถูกต้อง", es: "El ancho de tela o los márgenes no son válidos." },
    "No size has a quantity above 0.": { vi: "Không có size nào có số lượng > 0.", th: "ไม่มีไซซ์ที่มีจำนวนมากกว่า 0", es: "Ninguna talla tiene cantidad mayor que 0." },
    "Preparing simulation...": { vi: "Chuẩn bị mô phỏng...", th: "กำลังเตรียมการจำลอง...", es: "Preparando la simulación..." },
    "3-size filter: kept {0}/{1} promising combinations.": { vi: "Lọc tổ hợp 3 size: giữ {0}/{1} bộ triển vọng.", th: "กรองชุด 3 ไซซ์: เก็บ {0}/{1} ชุดที่มีแนวโน้มดี", es: "Filtro de 3 tallas: se mantienen {0}/{1} combinaciones prometedoras." },
    "Simulation stopped.": { vi: "Đã dừng mô phỏng.", th: "หยุดการจำลองแล้ว", es: "Simulación detenida." },
    "The simulation did not finish.": { vi: "Mô phỏng không hoàn tất.", th: "การจำลองไม่เสร็จสมบูรณ์", es: "La simulación no terminó." },
    "Finding the pairing with the fewest markers and highest efficiency...": { vi: "Đang tìm cách ghép ít sơ đồ nhất, hiệu suất cao nhất...", th: "กำลังหาการจับคู่ที่ใช้มาร์กเกอร์น้อยที่สุดและประสิทธิภาพสูงสุด...", es: "Buscando la combinación con menos marcadas y mayor eficiencia..." },
    "No pairing was found.": { vi: "Không tìm được cách ghép.", th: "ไม่พบวิธีจับคู่", es: "No se encontró ninguna combinación." },
    "Pairing done: {0} files, order consumption {1} m/garment (simulated).": { vi: "Ghép cặp xong: {0} file, định mức toàn đơn {1} m/sp (theo mô phỏng).", th: "จับคู่เสร็จ: {0} ไฟล์ อัตราสิ้นเปลืองทั้งออเดอร์ {1} ม./ตัว (จากการจำลอง)", es: "Combinación lista: {0} archivos, consumo del pedido {1} m/prenda (simulado)." },
    "Check stopped.": { vi: "Đã dừng kiểm tra.", th: "หยุดการตรวจสอบแล้ว", es: "Revisión detenida." },
    "not tested": { vi: "chưa test", th: "ยังไม่ทดสอบ", es: "sin probar" },
    "gap": { vi: "hở", th: "ระยะห่าง", es: "separación" },
    "File name (editable)": { vi: "Tên file (tự đặt)", th: "ชื่อไฟล์ (แก้ได้)", es: "Nombre del archivo (editable)" },
    "Plies": { vi: "Số lớp", th: "จำนวนชั้น", es: "Capas" },
    "Length (m)": { vi: "Dài (m)", th: "ความยาว (ม.)", es: "Largo (m)" },
    "Length": { vi: "Dài", th: "ยาว", es: "Largo" },
    "Consumption (m/garment)": { vi: "Định mức (m/sp)", th: "อัตราสิ้นเปลือง (ม./ตัว)", es: "Consumo (m/prenda)" },
    "Cons.": { vi: "ĐM", th: "สิ้นเปลือง", es: "Cons." },
    "Efficiency": { vi: "Hiệu suất", th: "ประสิทธิภาพ", es: "Eficiencia" },
    "Eff.": { vi: "HS", th: "ประสิทธิ.", es: "Efic." },
    "Whole order ({0} files, {1} m fabric)": { vi: "Toàn đơn ({0} file, {1} m vải)", th: "ทั้งออเดอร์ ({0} ไฟล์, ผ้า {1} ม.)", es: "Pedido completo ({0} archivos, {1} m de tela)" },
    "{0} garments": { vi: "{0} sp", th: "{0} ตัว", es: "{0} prendas" },
    "qty OK": { vi: "đủ SL", th: "จำนวนครบ", es: "cant. correcta" },
    "Fabric (m)": { vi: "Vải (m)", th: "ผ้า (ม.)", es: "Tela (m)" },
    "Cons. (m/garment)": { vi: "ĐM (m/sp)", th: "สิ้นเปลือง (ม./ตัว)", es: "Cons. (m/prenda)" },
    "Whole order": { vi: "Toàn đơn", th: "ทั้งออเดอร์", es: "Pedido completo" },
    "Order consumption <b>{0} m/garment</b>, total fabric <b>{1} m</b>.": { vi: "Định mức toàn đơn <b>{0} m/sp</b>, tổng vải <b>{1} m</b>.", th: "อัตราสิ้นเปลืองทั้งออเดอร์ <b>{0} ม./ตัว</b> ผ้ารวม <b>{1} ม.</b>", es: "Consumo del pedido <b>{0} m/prenda</b>, tela total <b>{1} m</b>." },
    "Compared with one marker per size: {0} m ({1} m/garment), saving {2} m.": { vi: "So với mỗi size một sơ đồ riêng: {0} m ({1} m/sp), tiết kiệm {2} m.", th: "เทียบกับหนึ่งมาร์กเกอร์ต่อไซซ์: {0} ม. ({1} ม./ตัว) ประหยัด {2} ม.", es: "Frente a una marcada por talla: {0} m ({1} m/prenda), ahorro de {2} m." },
    "Length and efficiency were RE-CHECKED with Sparrow (Test column: ✓ gaps OK, % is the difference from the simulation).": { vi: "Chiều dài và hiệu suất đã được KIỂM TRA lại bằng Sparrow (cột Test: ✓ khoảng hở đạt, % là chênh so với mô phỏng).", th: "ความยาวและประสิทธิภาพถูกตรวจซ้ำด้วย Sparrow แล้ว (คอลัมน์ Test: ✓ ระยะห่างผ่าน, % คือส่วนต่างจากการจำลอง)", es: "El largo y la eficiencia se REVISARON con Sparrow (columna Test: ✓ separación correcta, % es la diferencia con la simulación)." },
    "Length and efficiency come from the Sparrow simulation and are not checked yet.": { vi: "Chiều dài và hiệu suất lấy từ mô phỏng Sparrow, chưa kiểm tra.", th: "ความยาวและประสิทธิภาพมาจากการจำลองของ Sparrow ยังไม่ได้ตรวจ", es: "El largo y la eficiencia provienen de la simulación de Sparrow y aún no se han revisado." },
    "Single-size markers with an even number of plies become 2-garment markers of that size. Consumption per size is split by piece area.": { vi: "Sơ đồ 1 size có số lớp chẵn được đổi thành sơ đồ 2 áo cùng size. Định mức từng size chia theo diện tích chi tiết.", th: "มาร์กเกอร์ไซซ์เดียวที่มีจำนวนชั้นเป็นเลขคู่จะเปลี่ยนเป็นมาร์กเกอร์ 2 ตัวของไซซ์เดียวกัน อัตราสิ้นเปลืองแต่ละไซซ์แบ่งตามพื้นที่ชิ้นงาน", es: "Las marcadas de una talla con número par de capas se convierten en marcadas de 2 prendas de esa talla. El consumo por talla se reparte según el área de las piezas." },
    "Quantities do not match:": { vi: "Chưa khớp số lượng:", th: "จำนวนยังไม่ตรง:", es: "Las cantidades no coinciden:" },
    "{0} short": { vi: "thiếu {0}", th: "ขาด {0}", es: "faltan {0}" },
    "{0} extra": { vi: "dư {0}", th: "เกิน {0}", es: "sobran {0}" },
    "Simulating the hand-edited size pairs...": { vi: "Mô phỏng các cặp size chỉnh tay...", th: "กำลังจำลองคู่ไซซ์ที่แก้เอง...", es: "Simulando las combinaciones editadas a mano..." },
    "No valid files yet.": { vi: "Chưa có file nào hợp lệ.", th: "ยังไม่มีไฟล์ที่ถูกต้อง", es: "Aún no hay archivos válidos." },
    "Hand-edited size pairs applied.": { vi: "Đã áp dụng cặp size chỉnh tay.", th: "ใช้คู่ไซซ์ที่แก้เองแล้ว", es: "Combinaciones manuales aplicadas." },
    "Approved: {0}": { vi: "Đã duyệt: {0}", th: "อนุมัติแล้ว: {0}", es: "Aprobado: {0}" },
    "Size \"{0}\" is not in the list.": { vi: "Không có size \"{0}\" trong danh sách.", th: "ไม่มีไซซ์ \"{0}\" ในรายการ", es: "La talla \"{0}\" no está en la lista." },
    "File {0} has {1} sizes; the maximum is {2}.": { vi: "File {0} có {1} size, tối đa {2}.", th: "ไฟล์ {0} มี {1} ไซซ์ สูงสุด {2}", es: "El archivo {0} tiene {1} tallas; el máximo es {2}." },
    "File {0}: only 2 garments of the same size may repeat.": { vi: "File {0}: chỉ cho phép lặp 2 áo của cùng một size.", th: "ไฟล์ {0}: อนุญาตให้ซ้ำได้เพียง 2 ตัวของไซซ์เดียวกัน", es: "Archivo {0}: solo se permite repetir 2 prendas de la misma talla." },
    "File {0} is missing the number of plies.": { vi: "File {0} thiếu số lớp.", th: "ไฟล์ {0} ไม่มีจำนวนชั้น", es: "Al archivo {0} le falta el número de capas." },
    "initial placement": { vi: "xếp ban đầu", th: "จัดวางเริ่มต้น", es: "colocación inicial" },
    "compressing": { vi: "nén sơ đồ", th: "บีบมาร์กเกอร์", es: "compactación" },
    "exploring": { vi: "khám phá", th: "สำรวจ", es: "exploración" },
    "Starting nesting...": { vi: "Bắt đầu xếp sơ đồ...", th: "เริ่มจัดวางมาร์กเกอร์...", es: "Iniciando el encaje..." },
    "Nesting {0} markers in parallel on {1} threads (about {2} s)...": { vi: "Xếp {0} sơ đồ song song trên {1} luồng (khoảng {2} giây)...", th: "จัดวาง {0} มาร์กเกอร์แบบขนานบน {1} เธรด (ประมาณ {2} วินาที)...", es: "Encajando {0} marcadas en paralelo con {1} hilos (unos {2} s)..." },
    "Sparrow nesting · {0}/{1} done · about {2} s left": { vi: "Sparrow xếp sơ đồ · {0}/{1} xong · còn khoảng {2} giây", th: "Sparrow กำลังจัดวาง · เสร็จ {0}/{1} · เหลือประมาณ {2} วินาที", es: "Sparrow encajando · {0}/{1} listas · quedan unos {2} s" },
    "Sparrow nesting · 0/{0} · {1} threads": { vi: "Sparrow xếp sơ đồ · 0/{0} · {1} luồng", th: "Sparrow กำลังจัดวาง · 0/{0} · {1} เธรด", es: "Sparrow encajando · 0/{0} · {1} hilos" },
    "Nesting stopped.": { vi: "Đã dừng xếp sơ đồ.", th: "หยุดการจัดวางแล้ว", es: "Encaje detenido." },
    "Used the tested layout for {0}/{1} markers (extra nesting skipped).": { vi: "Dùng luôn bố cục đã test cho {0}/{1} sơ đồ (bỏ bước xếp thêm).", th: "ใช้เลย์เอาต์ที่ทดสอบแล้วสำหรับ {0}/{1} มาร์กเกอร์ (ข้ามการจัดวางเพิ่ม)", es: "Se usó la distribución probada en {0}/{1} marcadas (sin encaje adicional)." },
    "Sparrow nested {0} markers in {1} s.": { vi: "Sparrow xếp xong {0} sơ đồ trong {1} giây.", th: "Sparrow จัดวาง {0} มาร์กเกอร์เสร็จใน {1} วินาที", es: "Sparrow encajó {0} marcadas en {1} s." },
    "Marker {0}:": { vi: "Sơ đồ {0}:", th: "มาร์กเกอร์ {0}:", es: "Marcada {0}:" },
    "Engine error: {0}": { vi: "Lỗi engine: {0}", th: "เอนจินผิดพลาด: {0}", es: "Error del motor: {0}" },
    "Engine error ({0}); using the tested layout.": { vi: "Lỗi engine ({0}), dùng bố cục đã test.", th: "เอนจินผิดพลาด ({0}) ใช้เลย์เอาต์ที่ทดสอบแล้ว", es: "Error del motor ({0}); se usa la distribución probada." },
    "The tested layout is {0} cm shorter; using it.": { vi: "Bố cục đã test ngắn hơn {0} cm, dùng bố cục test.", th: "เลย์เอาต์ที่ทดสอบสั้นกว่า {0} ซม. จึงใช้เลย์เอาต์นั้น", es: "La distribución probada es {0} cm más corta; se usa esa." },
    "Extra nesting is {0} cm shorter than the tested layout.": { vi: "Xếp thêm ngắn hơn bố cục test {0} cm.", th: "การจัดวางเพิ่มสั้นกว่าเลย์เอาต์ที่ทดสอบ {0} ซม.", es: "El encaje adicional es {0} cm más corto que la distribución probada." },
    "The marker is too large for Illustrator.": { vi: "Sơ đồ quá lớn cho Illustrator.", th: "มาร์กเกอร์ใหญ่เกินไปสำหรับ Illustrator", es: "La marcada es demasiado grande para Illustrator." },
    "{0} plies": { vi: "{0} lớp", th: "{0} ชั้น", es: "{0} capas" },
    // Short word appended to marker file names (e.g. "M_25ply"), so file names follow the selected
    // language. Kept separate from "{0} plies" above, which is a full sentence fragment used only
    // for text printed on the marker (English in Thai mode, because Illustrator's default font has
    // no Thai glyphs) — file names have no such font limit.
    "ply": { vi: "lop", th: "ชั้น", es: "capas" },
    // Short word used in a file name when a marker is exported at a reduced scale (e.g. "..._scale-1-2").
    "scale": { vi: "ti-le", th: "สเกล", es: "escala" },
    "width {0} cm": { vi: "khổ {0} cm", th: "หน้าผ้า {0} ซม.", es: "ancho {0} cm" },
    "length {0} m": { vi: "dài {0} m", th: "ยาว {0} ม.", es: "largo {0} m" },
    "efficiency {0}%": { vi: "hiệu suất {0}%", th: "ประสิทธิภาพ {0}%", es: "eficiencia {0}%" },
    "scale 1:{0}": { vi: "tỉ lệ 1:{0}", th: "สเกล 1:{0}", es: "escala 1:{0}" },
    "Length {0} m (simulated {1} m), efficiency {2}%.": { vi: "Dài {0} m (mô phỏng {1} m), hiệu suất {2}%.", th: "ยาว {0} ม. (จำลอง {1} ม.) ประสิทธิภาพ {2}%", es: "Largo {0} m (simulado {1} m), eficiencia {2}%." },
    "Building marker files in the background...": { vi: "Dựng file sơ đồ chạy ngầm...", th: "กำลังสร้างไฟล์มาร์กเกอร์เบื้องหลัง...", es: "Creando los archivos de marcada en segundo plano..." },
    "Marker": { vi: "Sơ đồ", th: "มาร์กเกอร์", es: "Marcada" },
    "vs. simulation": { vi: "So mô phỏng", th: "เทียบการจำลอง", es: "vs. simulación" },
    "Not nested": { vi: "Chưa xếp được", th: "ยังจัดวางไม่ได้", es: "No encajada" },
    "Not nested.": { vi: "Chưa xếp được.", th: "ยังจัดวางไม่ได้", es: "No encajada." },
    "Closed {0} pattern files that had to be opened temporarily.": { vi: "Đã đóng {0} file rập phải mở tạm.", th: "ปิดไฟล์แพทเทิร์นที่ต้องเปิดชั่วคราว {0} ไฟล์แล้ว", es: "Se cerraron {0} archivos de patrones abiertos temporalmente." },
    "Error: could not create the work folder: {0}": { vi: "Lỗi: không tạo được thư mục làm việc: {0}", th: "ข้อผิดพลาด: สร้างโฟลเดอร์งานไม่ได้: {0}", es: "Error: no se pudo crear la carpeta de trabajo: {0}" },
    "Preparing pattern designs for {0} size group(s). Illustrator may briefly stop responding while it does this for a size not already prepared this session.": { vi: "Đang chuẩn bị design cho {0} nhóm size. Illustrator có thể tạm ngừng phản hồi vài giây với size chưa chuẩn bị trong phiên này.", th: "กำลังเตรียมดีไซน์สำหรับ {0} กลุ่มไซซ์ Illustrator อาจไม่ตอบสนองชั่วครู่สำหรับไซซ์ที่ยังไม่ได้เตรียมในเซสชันนี้", es: "Preparando los diseños de {0} grupo(s) de talla. Illustrator puede dejar de responder brevemente para una talla que aún no se preparó en esta sesión." },
    "Warning: the pattern files use different color modes ({0}). The marker uses the first size's color mode; colors of other sizes may change in conversion.": { vi: "Cảnh báo: các file rập dùng hệ màu khác nhau ({0}). Sơ đồ dùng hệ màu của size đầu tiên, màu của size khác hệ có thể bị đổi khi chuyển.", th: "คำเตือน: ไฟล์แพทเทิร์นใช้โหมดสีต่างกัน ({0}) มาร์กเกอร์ใช้โหมดสีของไซซ์แรก สีของไซซ์อื่นอาจเปลี่ยนเมื่อแปลง", es: "Advertencia: los archivos de patrones usan modos de color distintos ({0}). La marcada usa el modo de color de la primera talla; los colores de las demás pueden cambiar al convertirse." },
    "Loading design for size {0} ({1}/{2})...": { vi: "Lấy design size {0} ({1}/{2})...", th: "กำลังดึงดีไซน์ไซซ์ {0} ({1}/{2})...", es: "Cargando el diseño de la talla {0} ({1}/{2})..." },
    "Error loading design for size {0}: {1}": { vi: "Lỗi lấy design size {0}: {1}", th: "ดึงดีไซน์ไซซ์ {0} ผิดพลาด: {1}", es: "Error al cargar el diseño de la talla {0}: {1}" },
    "Size {0}: using the copy expanded last time (no need to expand again).": { vi: "Size {0}: dùng bản đã expand từ lần trước (không phải expand lại).", th: "ไซซ์ {0}: ใช้สำเนาที่ expand ไว้ครั้งก่อน (ไม่ต้อง expand ใหม่)", es: "Talla {0}: se usa la copia expandida la vez anterior (no hace falta expandir de nuevo)." },
    "Saved the expanded copy in NovaNest_rap so the next nesting is faster.": { vi: "Đã lưu bản đã expand vào NovaNest_rap để lần xếp sau nhanh hơn.", th: "บันทึกสำเนาที่ expand แล้วใน NovaNest_rap เพื่อให้ครั้งถัดไปเร็วขึ้น", es: "Se guardó la copia expandida en NovaNest_rap para que el próximo encaje sea más rápido." },
    "Size {0}: removed {1} parts of the artwork lying fully outside the pattern outline (not visible; keeps the file light and correctly placed).": { vi: "Size {0}: bỏ {1} phần họa tiết nằm hẳn ngoài đường rập (không hiện ra, giúp file nhẹ và đặt đúng vị trí).", th: "ไซซ์ {0}: ลบลาย {1} ส่วนที่อยู่นอกเส้นแพทเทิร์นทั้งหมด (มองไม่เห็น ช่วยให้ไฟล์เบาและวางถูกตำแหน่ง)", es: "Talla {0}: se quitaron {1} partes del estampado que quedan totalmente fuera del contorno (no se ven; el archivo queda ligero y bien colocado)." },
    "Size {0}: expanded the pattern fill of {1} pieces in the copy (keeps the print in the right place).": { vi: "Size {0}: đã expand họa tiết pattern của {1} chi tiết trong bản chép (giữ đúng vị trí họa tiết).", th: "ไซซ์ {0}: expand ลายแพทเทิร์นของ {1} ชิ้นในสำเนาแล้ว (คงตำแหน่งลายให้ถูกต้อง)", es: "Talla {0}: se expandió el relleno de motivo de {1} piezas en la copia (mantiene el estampado en su sitio)." },
    "ERROR: the pattern fill of {0} pieces of size {1} could not be expanded (the print will shift). Markers with these pieces will be blocked at the Check step.": { vi: "LỖI: {0} chi tiết của size {1} chưa expand được pattern (họa tiết sẽ lệch). Sơ đồ có các chi tiết này sẽ bị chặn ở bước Kiểm tra.", th: "ข้อผิดพลาด: expand ลายแพทเทิร์นของ {0} ชิ้นในไซซ์ {1} ไม่ได้ (ลายจะเคลื่อน) มาร์กเกอร์ที่มีชิ้นเหล่านี้จะถูกระงับในขั้นตรวจสอบ", es: "ERROR: no se pudo expandir el relleno de motivo de {0} piezas de la talla {1} (el estampado se desplazará). Las marcadas con estas piezas se bloquearán en el paso Revisar." },
    "Warning: the pattern fill could not be expanded ({0}); the print may shift.": { vi: "Cảnh báo: không expand được pattern ({0}); họa tiết pattern có thể bị lệch.", th: "คำเตือน: expand ลายแพทเทิร์นไม่ได้ ({0}) ลายอาจเคลื่อน", es: "Advertencia: no se pudo expandir el relleno de motivo ({0}); el estampado puede desplazarse." },
    "{0} pieces of size {1} were not found (library file deleted or old pattern set). Scan this size again.": { vi: "Không tìm thấy {0} chi tiết của size {1} (file kho bị xoá hoặc bộ rập cũ). Hãy quét lại size này.", th: "ไม่พบ {0} ชิ้นของไซซ์ {1} (ไฟล์คลังถูกลบหรือชุดแพทเทิร์นเก่า) โปรดสแกนไซซ์นี้ใหม่", es: "No se encontraron {0} piezas de la talla {1} (archivo de biblioteca eliminado o juego antiguo). Escanee esta talla de nuevo." },
    "Building file {0}/{1}: {2}": { vi: "Dựng file {0}/{1}: {2}", th: "กำลังสร้างไฟล์ {0}/{1}: {2}", es: "Creando archivo {0}/{1}: {2}" },
    "creating...": { vi: "đang tạo...", th: "กำลังสร้าง...", es: "creando..." },
    "finding pieces in a heavy pattern file...": { vi: "đang tìm chi tiết trong file rập nặng...", th: "กำลังค้นหาชิ้นในไฟล์แพทเทิร์นขนาดใหญ่...", es: "buscando piezas en un archivo de patrones pesado..." },
    "placing piece {0}/{1}": { vi: "đặt chi tiết {0}/{1}", th: "กำลังวางชิ้น {0}/{1}", es: "colocando pieza {0}/{1}" },
    "saving...": { vi: "đang lưu...", th: "กำลังบันทึก...", es: "guardando..." },
    "Error building file {0}: {1}": { vi: "Lỗi dựng file {0}: {1}", th: "สร้างไฟล์ {0} ผิดพลาด: {1}", es: "Error al crear el archivo {0}: {1}" },
    "{0} pieces needed a correction move after placing (Illustrator did not move them far enough).": { vi: "{0} chi tiết phải dịch bù sau khi đặt (Illustrator dịch chưa đủ).", th: "{0} ชิ้นต้องเลื่อนชดเชยหลังวาง (Illustrator เลื่อนไม่พอ)", es: "{0} piezas necesitaron un ajuste tras colocarlas (Illustrator no las movió lo suficiente)." },
    "{0} pieces are OUT OF POSITION compared with the layout:": { vi: "{0} chi tiết LỆCH vị trí so với bố cục:", th: "{0} ชิ้นวางคลาดจากเลย์เอาต์:", es: "{0} piezas están DESPLAZADAS respecto a la distribución:" },
    "Pieces outside the fabric width: {0}": { vi: "Chi tiết nằm ngoài khổ: {0}", th: "ชิ้นที่อยู่นอกหน้าผ้า: {0}", es: "Piezas fuera del ancho de tela: {0}" },
    "built, {0} pieces": { vi: "đã dựng, {0} chi tiết", th: "สร้างแล้ว {0} ชิ้น", es: "creada, {0} piezas" },
    "pattern fill re-aligned on {0} paths (offset before {1}, now {2})": { vi: "chỉnh lại vị trí họa tiết pattern cho {0} đường (lệch trước {1}, còn {2})", th: "ปรับตำแหน่งลายแพทเทิร์นของ {0} เส้น (คลาดก่อนหน้า {1} เหลือ {2})", es: "relleno de motivo realineado en {0} trazados (desfase antes {1}, ahora {2})" },
    "{0} pieces could NOT have the pattern fill adjusted (left as is, measured offset {1})": { vi: "{0} chi tiết KHÔNG chỉnh được pattern (đã giữ nguyên, lệch đo được {1})", th: "{0} ชิ้นปรับลายแพทเทิร์นไม่ได้ (คงไว้ตามเดิม คลาดที่วัดได้ {1})", es: "en {0} piezas NO se pudo ajustar el motivo (se dejó igual, desfase medido {1})" },
    "{0} pieces could not be compared for the pattern fill": { vi: "{0} chi tiết không so được pattern", th: "{0} ชิ้นเทียบลายแพทเทิร์นไม่ได้", es: "{0} piezas no se pudieron comparar por el motivo" },
    "pattern diagnostics": { vi: "chẩn đoán pattern", th: "วินิจฉัยลายแพทเทิร์น", es: "diagnóstico del motivo" },
    "Built {0}/{1} marker files in {2} s.": { vi: "Dựng {0}/{1} file sơ đồ trong {2} giây.", th: "สร้างไฟล์มาร์กเกอร์ {0}/{1} ไฟล์ใน {2} วินาที", es: "Se crearon {0}/{1} archivos de marcada en {2} s." },
    "Opening marker {0}/{1} for checking...": { vi: "Mở sơ đồ {0}/{1} để kiểm tra...", th: "กำลังเปิดมาร์กเกอร์ {0}/{1} เพื่อตรวจสอบ...", es: "Abriendo la marcada {0}/{1} para revisarla..." },
    "Error opening result file: {0}": { vi: "Lỗi mở file kết quả: {0}", th: "เปิดไฟล์ผลลัพธ์ผิดพลาด: {0}", es: "Error al abrir el archivo de resultado: {0}" },
    "Could not open {0}": { vi: "Không mở được {0}", th: "เปิดไม่ได้ {0}", es: "No se pudo abrir {0}" },
    "Opened {0} markers in Illustrator for checking.": { vi: "Đã mở {0} sơ đồ trong Illustrator để kiểm tra.", th: "เปิด {0} มาร์กเกอร์ใน Illustrator เพื่อตรวจสอบแล้ว", es: "Se abrieron {0} marcadas en Illustrator para revisarlas." },
    "The marker has {0} pieces but needs {1}.": { vi: "Số chi tiết trong sơ đồ {0} khác số chi tiết cần có {1}.", th: "มาร์กเกอร์มี {0} ชิ้น แต่ต้องมี {1} ชิ้น", es: "La marcada tiene {0} piezas, pero necesita {1}." },
    "The file could not be built: {0}": { vi: "Chưa dựng được file: {0}", th: "สร้างไฟล์ไม่ได้: {0}", es: "No se pudo crear el archivo: {0}" },
    "The marker file could not be built.": { vi: "Chưa dựng được file sơ đồ.", th: "สร้างไฟล์มาร์กเกอร์ไม่ได้", es: "No se pudo crear el archivo de la marcada." },
    "{0} pieces are missing from the file (design not found in the pattern file). Scan the related sizes again, then nest again.": { vi: "Thiếu {0} chi tiết trong file (không tìm thấy design trong file rập). Hãy quét lại size liên quan rồi xếp lại.", th: "ไฟล์ขาด {0} ชิ้น (ไม่พบดีไซน์ในไฟล์แพทเทิร์น) โปรดสแกนไซซ์ที่เกี่ยวข้องใหม่แล้วจัดวางอีกครั้ง", es: "Faltan {0} piezas en el archivo (no se encontró el diseño en el archivo de patrones). Escanee de nuevo las tallas afectadas y vuelva a encajar." },
    "{0} pieces could not have their pattern fill expanded, so the print may shift. Close the pattern file / copy in NovaNest_rap, then nest again.": { vi: "{0} chi tiết chưa expand được họa tiết pattern nên họa tiết có thể lệch. Hãy đóng file rập/bản chép trong NovaNest_rap rồi xếp lại.", th: "{0} ชิ้น expand ลายแพทเทิร์นไม่ได้ ลายอาจเคลื่อน โปรดปิดไฟล์แพทเทิร์น/สำเนาใน NovaNest_rap แล้วจัดวางอีกครั้ง", es: "En {0} piezas no se pudo expandir el relleno de motivo, así que el estampado puede desplazarse. Cierre el archivo de patrones o la copia en NovaNest_rap y vuelva a encajar." },
    "{0} pieces in the file are out of position compared with the nested layout (they may overlap). Nest again; if it still fails, send the Log to support.": { vi: "{0} chi tiết trong file bị lệch so với bố cục đã xếp (có thể chồng nhau). Hãy xếp lại; nếu vẫn lỗi gửi Nhật ký cho người hỗ trợ.", th: "{0} ชิ้นในไฟล์คลาดจากเลย์เอาต์ที่จัดวาง (อาจทับกัน) โปรดจัดวางใหม่ หากยังผิดพลาดให้ส่งบันทึกให้ฝ่ายสนับสนุน", es: "{0} piezas del archivo están desplazadas respecto a la distribución (pueden solaparse). Vuelva a encajar; si sigue fallando, envíe el Registro a soporte." },
    "Pieces outside the fabric width: {0}.": { vi: "Chi tiết nằm ngoài khổ vải: {0}.", th: "ชิ้นที่อยู่นอกหน้าผ้า: {0}", es: "Piezas fuera del ancho de tela: {0}." },
    "{0} pieces were rebuilt from the outline (inner lines, text and notches are lost).": { vi: "{0} chi tiết dựng lại từ đường bao (mất đường nội bộ, chữ, dấu bấm).", th: "{0} ชิ้นถูกสร้างใหม่จากเส้นรอบ (เส้นภายใน ตัวอักษร และรอยบากหายไป)", es: "{0} piezas se reconstruyeron a partir del contorno (se pierden líneas internas, textos y piquetes)." },
    "Smallest gap {0} cm < required {1} cm.": { vi: "Khoảng hở nhỏ nhất {0} cm < yêu cầu {1} cm.", th: "ระยะห่างน้อยสุด {0} ซม. < ที่กำหนด {1} ซม.", es: "Separación mínima {0} cm < requerida {1} cm." },
    "The marker is very long and will be exported at scale 1:{0}.": { vi: "Sơ đồ rất dài, sẽ xuất tỉ lệ 1:{0}.", th: "มาร์กเกอร์ยาวมาก จะส่งออกที่สเกล 1:{0}", es: "La marcada es muy larga y se exportará a escala 1:{0}." },
    "{0}% longer than simulated.": { vi: "Dài hơn mô phỏng {0}%.", th: "ยาวกว่าการจำลอง {0}%", es: "{0} % más larga que la simulación." },
    "Size {0} is no longer in the list.": { vi: "Không còn size {0} trong danh sách.", th: "ไซซ์ {0} ไม่อยู่ในรายการแล้ว", es: "La talla {0} ya no está en la lista." },
    "Pcs": { vi: "CT", th: "ชิ้น", es: "Pzs" },
    "Smallest gap (cm)": { vi: "Khoảng hở nhỏ nhất (cm)", th: "ระยะห่างน้อยสุด (ซม.)", es: "Separación mínima (cm)" },
    "Gap": { vi: "Hở", th: "ระยะห่าง", es: "Sep." },
    "Result": { vi: "KQ", th: "ผล", es: "Res." },
    "error": { vi: "lỗi", th: "ผิดพลาด", es: "error" },
    "OK": { vi: "đạt", th: "ผ่าน", es: "OK" },
    "Open": { vi: "Mở", th: "เปิด", es: "Abrir" },
    "{0} markers:": { vi: "{0} sơ đồ:", th: "{0} มาร์กเกอร์:", es: "{0} marcadas:" },
    "{0} OK": { vi: "{0} đạt", th: "ผ่าน {0}", es: "{0} correctas" },
    "{0} with warnings": { vi: "{0} có cảnh báo", th: "มีคำเตือน {0}", es: "{0} con advertencias" },
    "{0} with errors": { vi: "{0} lỗi", th: "ผิดพลาด {0}", es: "{0} con errores" },
    "There are errors, so the files cannot be exported yet. Fix them, then nest again.": { vi: "Có lỗi nên chưa thể xuất file, hãy sửa rồi xếp lại.", th: "มีข้อผิดพลาดจึงยังส่งออกไม่ได้ โปรดแก้ไขแล้วจัดวางใหม่", es: "Hay errores, así que aún no se puede exportar. Corríjalos y vuelva a encajar." },
    "Review and edit in Illustrator (one layer per size), then go to the Export step.": { vi: "Xem và chỉnh trong Illustrator (mỗi size một layer), rồi sang bước Xuất file.", th: "ตรวจและแก้ใน Illustrator (หนึ่งเลเยอร์ต่อไซซ์) แล้วไปขั้นส่งออกไฟล์", es: "Revise y edite en Illustrator (una capa por talla) y luego pase al paso Exportar." },
    "Check: {0} OK, {1} warnings, {2} errors.": { vi: "Kiểm tra: {0} đạt, {1} cảnh báo, {2} lỗi.", th: "ตรวจสอบ: ผ่าน {0}, คำเตือน {1}, ผิดพลาด {2}", es: "Revisión: {0} correctas, {1} advertencias, {2} errores." },
    "There are no marker files to export yet.": { vi: "Chưa có file sơ đồ nào để xuất.", th: "ยังไม่มีไฟล์มาร์กเกอร์ให้ส่งออก", es: "Aún no hay archivos de marcada para exportar." },
    "CSV report": { vi: "Báo cáo CSV", th: "รายงาน CSV", es: "Informe CSV" },
    "Choose the output folder (paste a folder path, then click Save)": { vi: "Chọn thư mục kết quả (dán đường dẫn thư mục rồi bấm Save)", th: "เลือกโฟลเดอร์ผลลัพธ์ (วางพาธโฟลเดอร์แล้วกด Save)", es: "Elija la carpeta de resultados (pegue una ruta y haga clic en Save)" },
    "Folder selection cancelled.": { vi: "Đã hủy chọn thư mục.", th: "ยกเลิกการเลือกโฟลเดอร์แล้ว", es: "Selección de carpeta cancelada." },
    "Saving and copying {0} marker files...": { vi: "Lưu và chép {0} file sơ đồ...", th: "กำลังบันทึกและคัดลอกไฟล์มาร์กเกอร์ {0} ไฟล์...", es: "Guardando y copiando {0} archivos de marcada..." },
    "Output folder: {0}": { vi: "Thư mục kết quả: {0}", th: "โฟลเดอร์ผลลัพธ์: {0}", es: "Carpeta de resultados: {0}" },
    "Export error: {0}": { vi: "Lỗi xuất file: {0}", th: "ส่งออกไฟล์ผิดพลาด: {0}", es: "Error al exportar: {0}" },
    "Exported {0}/{1} files. Actual total fabric {2} m, order consumption {3} m/garment.": { vi: "Đã xuất {0}/{1} file. Tổng vải thực tế {2} m, định mức toàn đơn {3} m/sp.", th: "ส่งออก {0}/{1} ไฟล์แล้ว ผ้ารวมจริง {2} ม. อัตราสิ้นเปลืองทั้งออเดอร์ {3} ม./ตัว", es: "Se exportaron {0}/{1} archivos. Tela total real {2} m, consumo del pedido {3} m/prenda." },
    "Simulated length (m)": { vi: "Dài mô phỏng (m)", th: "ความยาวจำลอง (ม.)", es: "Largo simulado (m)" },
    "Actual length (m)": { vi: "Dài thực tế (m)", th: "ความยาวจริง (ม.)", es: "Largo real (m)" },
    "Efficiency (%)": { vi: "Hiệu suất (%)", th: "ประสิทธิภาพ (%)", es: "Eficiencia (%)" },
    "Scale": { vi: "Tỉ lệ", th: "สเกล", es: "Escala" },
    "Rebuilt pieces": { vi: "Chi tiết dựng lại", th: "ชิ้นที่สร้างใหม่", es: "Piezas reconstruidas" },
    "Missing pieces": { vi: "Chi tiết thiếu", th: "ชิ้นที่ขาด", es: "Piezas faltantes" },
    "Could not write the report: {0}": { vi: "Không ghi được báo cáo: {0}", th: "เขียนรายงานไม่ได้: {0}", es: "No se pudo escribir el informe: {0}" },
    "Report written: {0}": { vi: "Đã ghi báo cáo: {0}", th: "เขียนรายงานแล้ว: {0}", es: "Informe escrito: {0}" },
    "Rebuilt from outline": { vi: "Dựng lại từ đường bao", th: "สร้างใหม่จากเส้นรอบ", es: "Reconstruida a partir del contorno" },
    "{0} rebuilt": { vi: "{0} dựng lại", th: "สร้างใหม่ {0}", es: "{0} reconstruidas" },
    "(Illustrator took {1} s for {0})": { vi: "(Illustrator xử lý {0} mất {1} giây)", th: "(Illustrator ใช้เวลา {1} วินาทีกับ {0})", es: "(Illustrator tardó {1} s en {0})" },
    "A new version {0} is available.": { vi: "Đã có phiên bản mới {0}.", th: "มีเวอร์ชันใหม่ {0} แล้ว", es: "Hay una nueva versión {0} disponible." },
    "Download {0}": { vi: "Tải về {0}", th: "ดาวน์โหลด {0}", es: "Descargar {0}" },
    "Back to scan and clear this order": { vi: "Quay lại quét và xóa đơn này", th: "กลับไปสแกนและล้างออเดอร์นี้", es: "Volver a escanear y borrar este pedido" },
    "Engine ready: {0} threads.": { vi: "Engine đã sẵn sàng: {0} luồng.", th: "เอนจินพร้อมแล้ว: {0} เธรด", es: "Motor listo: {0} hilos." },
    "Click again to clear this order":{ vi: "Bấm lần nữa để xóa đơn này", th: "กดอีกครั้งเพื่อล้างออเดอร์นี้", es: "Vuelve a pulsar para borrar este pedido" },
    "Update now": { vi: "Cập nhật ngay", th: "อัปเดตตอนนี้", es: "Actualizar ahora" },
    "Updating...": { vi: "Đang cập nhật...", th: "กำลังอัปเดต...", es: "Actualizando..." },
    "Updated to {0}. Restart Illustrator to use the new version.": { vi: "Đã cập nhật lên {0}. Hãy khởi động lại Illustrator để dùng bản mới.", th: "อัปเดตเป็น {0} แล้ว กรุณารีสตาร์ท Illustrator เพื่อใช้เวอร์ชันใหม่", es: "Actualizado a {0}. Reinicie Illustrator para usar la nueva versión." },
    "Automatic update failed. Use the download button instead.": { vi: "Cập nhật tự động không được. Hãy dùng nút tải về.", th: "อัปเดตอัตโนมัติไม่สำเร็จ กรุณาใช้ปุ่มดาวน์โหลด", es: "La actualización automática falló. Use el botón de descarga." },
    "Automatic update failed ({0}).": { vi: "Cập nhật tự động không được ({0}).", th: "อัปเดตอัตโนมัติไม่สำเร็จ ({0})", es: "La actualización automática falló ({0})." },
    "Order cleared. Scan the next order.":{ vi: "Đã xóa đơn. Hãy quét đơn tiếp theo.", th: "ล้างออเดอร์แล้ว สแกนออเดอร์ถัดไปได้เลย", es: "Pedido borrado. Escanee el siguiente pedido." },
    "Connected to Illustrator {0}. Engine: Nest-Pro Sparrow.":{ vi: "Đã kết nối Illustrator {0}. Engine: Nest-Pro Sparrow.", th: "เชื่อมต่อ Illustrator {0} แล้ว เอนจิน: Nest-Pro Sparrow", es: "Conectado a Illustrator {0}. Motor: Nest-Pro Sparrow." },
    "Could not connect to Illustrator yet: {0}": { vi: "Chưa kết nối được Illustrator: {0}", th: "ยังเชื่อมต่อ Illustrator ไม่ได้: {0}", es: "Todavía no se pudo conectar con Illustrator: {0}" }
  };

  // Error fragments from Illustrator (host.jsx), English -> other languages.
  var FRAG = {
    "No pieces are selected. Select all pieces of the size, then click again.": { vi: "Chưa chọn chi tiết nào. Hãy chọn tất cả chi tiết của size rồi bấm lại.", th: "ยังไม่ได้เลือกชิ้นงาน โปรดเลือกชิ้นงานทั้งหมดของไซซ์แล้วกดอีกครั้ง", es: "No hay piezas seleccionadas. Seleccione todas las piezas de la talla y vuelva a hacer clic." },
    "No file is open in Illustrator.": { vi: "Chưa mở file nào trong Illustrator.", th: "ยังไม่ได้เปิดไฟล์ใดใน Illustrator", es: "No hay ningún archivo abierto en Illustrator." },
    "No valid closed path was found in the selection.": { vi: "Không tìm thấy đường khép kín hợp lệ trong vùng chọn.", th: "ไม่พบเส้นปิดที่ถูกต้องในส่วนที่เลือก", es: "No se encontró ningún trazado cerrado válido en la selección." },
    "The selection is too large (": { vi: "Vùng chọn quá lớn (", th: "ส่วนที่เลือกใหญ่เกินไป (", es: "La selección es demasiado grande (" },
    " objects).": { vi: " đối tượng).", th: " ออบเจ็กต์)", es: " objetos)." },
    "Could not find the position of piece": { vi: "Không xác định được vị trí chi tiết", th: "ไม่สามารถระบุตำแหน่งของชิ้น", es: "No se pudo determinar la posición de la pieza" },
    "\" in the file.": { vi: "\" trong file.", th: "\" ในไฟล์", es: "\" en el archivo." },
    "The marker size exceeds the Illustrator limit.": { vi: "Kích thước sơ đồ vượt giới hạn của Illustrator.", th: "ขนาดมาร์กเกอร์เกินขีดจำกัดของ Illustrator", es: "El tamaño de la marcada supera el límite de Illustrator." },
    "Could not create the design library folder: ": { vi: "Không tạo được thư mục kho design: ", th: "สร้างโฟลเดอร์คลังดีไซน์ไม่ได้: ", es: "No se pudo crear la carpeta de la biblioteca de diseños: " },
    "Illustrator could not write the design library: ": { vi: "Illustrator không ghi được kho design: ", th: "Illustrator เขียนคลังดีไซน์ไม่ได้: ", es: "Illustrator no pudo escribir la biblioteca de diseños: " },
    "The file is not saved yet, so there is no folder to save the design in.": { vi: "File chưa lưu nên chưa có thư mục lưu design.", th: "ไฟล์ยังไม่ได้บันทึก จึงไม่มีโฟลเดอร์สำหรับบันทึกดีไซน์", es: "El archivo aún no está guardado, así que no hay carpeta donde guardar el diseño." },
    "No file is being built.": { vi: "Không có file đang tạo.", th: "ไม่มีไฟล์ที่กำลังสร้าง", es: "No se está creando ningún archivo." },
    "Could not switch to the copy to expand the pattern fill.": { vi: "Không chuyển được sang bản chép để expand pattern.", th: "สลับไปยังสำเนาเพื่อ expand ลายแพทเทิร์นไม่ได้", es: "No se pudo pasar a la copia para expandir el motivo." },
    "Could not measure the piece after rotating it.": { vi: "Không đo được kích thước chi tiết sau khi xoay.", th: "วัดขนาดชิ้นหลังหมุนไม่ได้", es: "No se pudo medir la pieza después de girarla." },
    "The output folder does not exist: ": { vi: "Thư mục kết quả không tồn tại: ", th: "ไม่มีโฟลเดอร์ผลลัพธ์: ", es: "La carpeta de resultados no existe: " },
    "The folder does not exist: ": { vi: "Thư mục không tồn tại: ", th: "ไม่มีโฟลเดอร์: ", es: "La carpeta no existe: " },
    "Marker file not found: ": { vi: "Không thấy file sơ đồ: ", th: "ไม่พบไฟล์มาร์กเกอร์: ", es: "No se encontró el archivo de marcada: " },
    "File not found on disk: ": { vi: "Không thấy file trên đĩa: ", th: "ไม่พบไฟล์บนดิสก์: ", es: "No se encontró el archivo en el disco: " },
    "Could not copy the pattern file to the library: ": { vi: "Không chép được file rập vào kho: ", th: "คัดลอกไฟล์แพทเทิร์นเข้าคลังไม่ได้: ", es: "No se pudo copiar el archivo de patrones a la biblioteca: " },
    "Could not copy to ": { vi: "Không chép được vào ", th: "คัดลอกไปยังไม่ได้ ", es: "No se pudo copiar en " },
    "Could not save the new file: ": { vi: "Không lưu được file mới: ", th: "บันทึกไฟล์ใหม่ไม่ได้: ", es: "No se pudo guardar el archivo nuevo: " },
    "Could not save file ": { vi: "Không lưu được file ", th: "บันทึกไฟล์ไม่ได้ ", es: "No se pudo guardar el archivo " },
    "Illustrator could not write the file to ": { vi: "Illustrator không ghi được file vào ", th: "Illustrator เขียนไฟล์ไปยังไม่ได้ ", es: "Illustrator no pudo escribir el archivo en " },
    "Could not create the library folder: ": { vi: "Không tạo được thư mục kho: ", th: "สร้างโฟลเดอร์คลังไม่ได้: ", es: "No se pudo crear la carpeta de la biblioteca: " },
    "Could not create the folder: ": { vi: "Không tạo được thư mục: ", th: "สร้างโฟลเดอร์ไม่ได้: ", es: "No se pudo crear la carpeta: " },
    "The Nova Nest library folder does not exist yet.": { vi: "Chưa có thư mục kho của Nova Nest.", th: "ยังไม่มีโฟลเดอร์คลังของ Nova Nest", es: "La carpeta de la biblioteca de Nova Nest aún no existe." },
    "Could not read the file: ": { vi: "Không đọc được file: ", th: "อ่านไฟล์ไม่ได้: ", es: "No se pudo leer el archivo: " },
    "Could not write the file: ": { vi: "Không ghi được file: ", th: "เขียนไฟล์ไม่ได้: ", es: "No se pudo escribir el archivo: " },
    "File not found: ": { vi: "Không tìm thấy file: ", th: "ไม่พบไฟล์: ", es: "No se encontró el archivo: " },
    "The file name is empty.": { vi: "Tên file trống.", th: "ชื่อไฟล์ว่างเปล่า", es: "El nombre del archivo está vacío." },
    " (line ": { vi: " (dòng ", th: " (บรรทัด ", es: " (línea " },
    "Illustrator was not found (running outside the host).": { vi: "Không tìm thấy Illustrator (đang mở ngoài host).", th: "ไม่พบ Illustrator (เปิดอยู่นอกโฮสต์)", es: "No se encontró Illustrator (se ejecuta fuera del host)." },
    "Host error: ": { vi: "Lỗi host: ", th: "ข้อผิดพลาดของโฮสต์: ", es: "Error del host: " },
    "Could not copy the design library to ": { vi: "Không chép được kho design tới ", th: "คัดลอกคลังดีไซน์ไปยังไม่ได้ ", es: "No se pudo copiar la biblioteca de diseños a " },
    "Design library file not found: ": { vi: "Không tìm thấy file kho design: ", th: "ไม่พบไฟล์คลังดีไซน์: ", es: "No se encontró el archivo de la biblioteca de diseños: " }
  };
  var FRAG_KEYS = Object.keys(FRAG).sort(function (a, b) { return b.length - a.length; });

  function norm(s) { return String(s).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }
  function fill(out, args) {
    if (!args) return out;
    return String(out).replace(/\{(\d+)\}/g, function (m, k) { return args[+k] !== undefined ? args[+k] : m; });
  }
  function lookup(lang, src) {
    if (lang === "en") return src;
    var e = DICT[src] || DICT[norm(src)];
    return e && e[lang] ? e[lang] : src;
  }

  var I = {
    lang: "en",
    langs: LANGS,
    t: function (src, args) { return fill(lookup(I.lang, src), args); },
    tIn: function (lang, src, args) { return fill(lookup(lang, src), args); },
    frag: function (s) {
      s = String(s);
      if (I.lang === "en") return s;
      for (var i = 0; i < FRAG_KEYS.length; i++) {
        var k = FRAG_KEYS[i], v = FRAG[k][I.lang];
        if (v && s.indexOf(k) >= 0) s = s.split(k).join(v);
      }
      return s;
    },
    set: function (l) {
      if (LANGS.indexOf(l) < 0) l = "en";
      I.lang = l;
      try { localStorage.setItem(STORE, l); } catch (e) {}
      try { document.documentElement.setAttribute("lang", l); } catch (e2) {}
    },
    apply: function (rootEl) {
      rootEl = rootEl || document.body;
      var blocks = rootEl.querySelectorAll("[data-i18n-html]");
      for (var b = 0; b < blocks.length; b++) {
        var el = blocks[b];
        if (el.__srcHtml === undefined) el.__srcHtml = norm(el.innerHTML);
        el.innerHTML = I.t(el.__srcHtml);
        el.__done = true;
      }
      walk(rootEl);
      var all = rootEl.querySelectorAll("[title],[alt],[placeholder]");
      for (var a = 0; a < all.length; a++) {
        var x = all[a];
        ["title", "alt", "placeholder"].forEach(function (attr) {
          if (!x.hasAttribute(attr)) return;
          var key = "__src_" + attr, cur = x.getAttribute(attr);
          if (x[key] === undefined) { if (!hasKey(cur)) return; x[key] = cur; }
          else if (x["__out_" + attr] !== cur) { return; }
          var v = I.t(x[key]);
          x.setAttribute(attr, v);
          x["__out_" + attr] = v;
        });
      }
    }
  };

  function hasKey(s) { return !!(DICT[s] || DICT[norm(s)]); }

  function walk(node) {
    for (var c = node.firstChild; c; c = c.nextSibling) {
      if (c.nodeType === 1) {
        var tag = c.tagName;
        if (tag === "SCRIPT" || tag === "STYLE" || tag === "TEXTAREA" || (tag === "SELECT" && c.id === "langSel")) continue;
        if (c.__done) continue;
        walk(c);
      } else if (c.nodeType === 3) {
        var raw = c.nodeValue;
        if (!/\S/.test(raw)) continue;
        if (c.__src === undefined) {
          if (!hasKey(raw)) continue;
          c.__src = norm(raw);
          c.__lead = raw.match(/^\s*/)[0]; c.__trail = raw.match(/\s*$/)[0];
        } else if (c.__out !== raw) {
          continue;
        }
        var v = c.__lead + I.t(c.__src) + c.__trail;
        c.nodeValue = v;
        c.__out = v;
      }
    }
  }

  var saved = null;
  try { saved = localStorage.getItem(STORE); } catch (e) {}
  I.set(saved || "en");
  root.NovaI18n = I;
})(window);
