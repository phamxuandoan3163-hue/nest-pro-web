/* Cầu nối tối giản tới ExtendScript (thay cho CSInterface.js).
 * host(fn, arg): gọi hàm fn(chuỗiJSON) trong host.jsx, trả về object đã parse.
 * Khi mở ngoài Illustrator (để thử giao diện), dùng host giả lập. */
(function (root) {
    'use strict';
    var NN = root.NN = root.NN || {};

    function esc(s) {
        return s.replace(/[\u007f-￿]/g, function (c) {
            return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
        });
    }

    // v2.5.1: thông báo lỗi từ Illustrator (viết không dấu trong host.jsx) -> tiếng Việt có dấu
    var VI = [];  // host.jsx now returns English; other languages via NovaI18n.frag
    NN.vi = function (s) {
        s = String(s); for (var i = 0; i < VI.length; i++) s = s.split(VI[i][0]).join(VI[i][1]);
        // 2.6.0: then into the panel language (EN / TH / ES) by known fragments, see js/i18n.js
        return root.NovaI18n && root.NovaI18n.frag ? root.NovaI18n.frag(s) : s;
    };

    NN.host = function (fn, arg) {
        return new Promise(function (resolve) {
            var lit = esc(JSON.stringify(JSON.stringify(arg === undefined ? {} : arg)));
            var code = fn + '(' + lit + ')';
            if (!root.__adobe_cep__) {
                resolve(NN.mockHost ? NN.mockHost(fn, arg) : { error: NN.vi('Illustrator was not found (running outside the host).') });
                return;
            }
            var t0 = Date.now();
            root.__adobe_cep__.evalScript(code, function (r) {
                var ms = Date.now() - t0;
                if (ms > 3000 && NN.onSlow) { try { NN.onSlow(fn, ms); } catch (eS) { /* bỏ qua */ } }
                try {
                    var o = JSON.parse(r);
                    if (o && o.error) o.error = NN.vi(o.error);
                    if (o && o.errors && o.errors.length) o.errors = o.errors.map(NN.vi);
                    resolve(o);
                } catch (e) {
                    resolve({ error: NN.vi('Host error: ') + r });
                }
            });
        });
    };
})(window);
