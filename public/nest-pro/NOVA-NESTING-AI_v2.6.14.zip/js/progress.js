/* Nova Nest - cửa sổ tiến trình (extension Modeless).
 * Nhận trạng thái từ panel chính qua file NovaNest_progress.json (đọc 8 lần/giây) và sự kiện CEP.
 * Đóng ngay khi nhận lệnh close. Nút Dừng ghi NovaNest_cancel.json + gửi sự kiện. */
(function () {
    'use strict';
    var cep = window.__adobe_cep__;
    var EVT = 'com.novanest.progress';
    var $ = function (id) { return document.getElementById(id); };
    var lastSeq = -1, run = '', closed = false, poll = null, lastSeen = Date.now();
    // hoạt ảnh: hiển thị trượt mượt từ mốc hiện tại tới mốc kế tiếp theo thời gian dự kiến
    var anim = { base: 0, upto: 0, eta: 0, t0: Date.now(), disp: 0, loading: true, label: '' };
    // Fixed words of this window, in the language the panel sends (msg.lang).
    var WORDS = {
        en: { working: 'Working', starting: 'Starting...', stop: 'Stop', stopping: 'Stopping...' },
        vi: { working: 'Đang xử lý', starting: 'Starting...', stop: 'Stop', stopping: 'Đang dừng...' },
        th: { working: 'กำลังทำงาน', starting: 'กำลังเริ่ม...', stop: 'หยุด', stopping: 'กำลังหยุด...' },
        es: { working: 'Procesando', starting: 'Iniciando...', stop: 'Detener', stopping: 'Deteniendo...' }
    };
    var lang = 'en';
    function W(k) { return (WORDS[lang] || WORDS.en)[k]; }
    function setLang(l) {
        if (!WORDS[l] || l === lang) return;
        lang = l;
        document.documentElement.setAttribute('lang', l);
        if (!$('stop').disabled) $('stop').textContent = W('stop');
        if (anim.loading) $('label').textContent = W('working');
    }

    function sysPath(t) {
        try {
            var p = decodeURIComponent(cep.getSystemPath(t)).replace(/^file:\/\//, '');
            if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
            return p;
        } catch (e) { return ''; }
    }
    var PDIR = cep ? sysPath('userData') : '';
    var PFILE = PDIR ? PDIR + '/NovaNest_progress.json' : '';
    var CFILE = PDIR ? PDIR + '/NovaNest_cancel.json' : '';

    function appId() { try { return JSON.parse(cep.getHostEnvironment()).appId; } catch (e) { return 'ILST'; } }
    function send(type, data) {
        try { cep.dispatchEvent({ type: type, scope: 'APPLICATION', appId: appId(), extensionId: '', data: data || '' }); } catch (e) { /* bỏ qua */ }
    }
    function applySkin() {
        try {
            var c = JSON.parse(cep.getHostEnvironment()).appSkinInfo.panelBackgroundColor.color;
            var r = Math.round(c.red), g = Math.round(c.green), b = Math.round(c.blue);
            var st = document.documentElement.style;
            st.setProperty('--bg', 'rgb(' + r + ',' + g + ',' + b + ')');
            st.setProperty('--panel', 'rgb(' + Math.min(255, r + 8) + ',' + Math.min(255, g + 8) + ',' + Math.min(255, b + 8) + ')');
            if (0.299 * r + 0.587 * g + 0.114 * b > 150) {
                st.setProperty('--text', '#1e1e1e'); st.setProperty('--muted', '#555'); st.setProperty('--line', 'rgba(0,0,0,.18)');
                st.setProperty('--track', '#e4e4e4');
            }
        } catch (e) { /* bỏ qua */ }
    }

    function closeNow() {
        if (closed) return;
        closed = true;
        if (poll) clearInterval(poll);
        try { cep.closeExtension(); } catch (e) { try { window.close(); } catch (e2) { /* bỏ qua */ } }
    }

    function handle(m) {
        if (!m || closed) return;
        if (m.run && m.run !== run) { run = m.run; lastSeq = -1; }   // lượt chạy mới
        if (typeof m.seq === 'number') { if (m.seq <= lastSeq) return; lastSeq = m.seq; }
        lastSeen = Date.now();
        if (m.close) { closeNow(); return; }
        if (m.lang) setLang(m.lang);
        if (m.run && anim.run !== m.run) { anim.run = m.run; anim.disp = 0; }
        if (m.frac !== undefined) {
            anim.base = Math.max(0, Math.min(1, m.frac));
            anim.upto = Math.max(anim.base, Math.min(1, m.upto !== undefined ? m.upto : m.frac));
            anim.eta = m.eta || 0;
            anim.t0 = Date.now();
        }
        if (m.label) { anim.label = m.label; anim.loading = m.label.indexOf('LOADING') === 0; $('label').textContent = anim.loading ? W('working') : m.label; }
        if (m.cap !== undefined) $('cap').textContent = m.cap;
    }
    function parse(d) {
        try { return typeof d === 'string' ? (d ? JSON.parse(d) : null) : d; } catch (e) { return null; }
    }
    function readFile() {
        try {
            if (!PFILE || !window.cep || !window.cep.fs) return;
            var r = window.cep.fs.readFile(PFILE);
            if (r && !r.err) handle(parse(r.data));
        } catch (e) { /* bỏ qua */ }
    }

    $('stop').addEventListener('click', function () {
        $('stop').disabled = true;
        $('cap').textContent = W('stopping');
        try { if (CFILE && window.cep && window.cep.fs) window.cep.fs.writeFile(CFILE, JSON.stringify({ run: run, t: Date.now() })); } catch (e) { /* bỏ qua */ }
        send(EVT + '.cancel');
    });

    function frame() {
        if (closed) return;
        var target = anim.base;
        if (anim.eta > 0 && anim.upto > anim.base) {
            var k = Math.min(1, (Date.now() - anim.t0) / anim.eta);
            target = anim.base + (anim.upto - anim.base) * (1 - Math.pow(1 - k, 2)) * 0.97;   // chậm dần, không vượt mốc
        }
        if (target > anim.disp) anim.disp += Math.max(0.0005, (target - anim.disp) * 0.2);
        if (anim.disp > target && target >= anim.base) anim.disp = Math.max(anim.disp, anim.base);
        $('fill').style.width = (anim.disp * 100).toFixed(2) + '%';
        $('pct').textContent = Math.floor(anim.disp * 100) + '%';
    }

    if (cep) {
        setInterval(frame, 40);
        applySkin();
        try { cep.addEventListener(EVT, function (ev) { handle(parse(ev && ev.data)); }); } catch (e) { /* bỏ qua */ }
        readFile();
        poll = setInterval(function () {
            readFile();
            // an toàn: panel chính không cập nhật quá 3 phút (bị đóng / treo) thì tự đóng
            if (Date.now() - lastSeen > 180000) closeNow();
        }, 125);
        send(EVT + '.ready');
    }
})();
