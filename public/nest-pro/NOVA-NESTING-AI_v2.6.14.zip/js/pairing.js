/* Nova Nest - engine ghép cặp size.
 * Ghép BẤT KỲ tổ hợp size nào (không theo thứ tự), mỗi sơ đồ tối đa K size (2 hoặc 3),
 * dùng chiều dài sơ đồ MÔ PHỎNG thật (cfg.simByNames) để chọn cách chia có tổng vải thấp nhất.
 * Một sơ đồ = 1 bản sao mỗi size trong sơ đồ, trải N lớp => N sản phẩm mỗi size.
 * Riêng size lẻ có số lượng chẵn có thể đi sơ đồ 2 áo cùng size (vd L_L_30lop).
 */
(function (root) {
    'use strict';
    var NN = root.NN = root.NN || {};

    // Translated text for marker names and messages. Module scope, so every function here can use it.
    function T(src, args) {
        if (typeof window !== 'undefined' && window.NovaI18n) return window.NovaI18n.t(src, args);
        return args ? String(src).replace(/\{(\d+)\}/g, function (m, k) { return args[+k] !== undefined ? args[+k] : m; }) : src;
    }

    function effFor(cfg, k) {
        var e = (cfg.eff && (cfg.eff[k] || cfg.eff[3])) || 80;
        return e > 1 ? e / 100 : e;
    }

    // ước tính theo diện tích (dự phòng khi chưa có mô phỏng)
    function estLengthCm(sizes, idx, cfg) {
        var area = 0, maxH = 0;
        for (var i = 0; i < idx.length; i++) {
            var s = sizes[idx[i]];
            area += s.areaCm2;
            if (s.maxH > maxH) maxH = s.maxH;
        }
        return Math.max(area / (cfg.widthCm * effFor(cfg, idx.length)), maxH) + (cfg.endLossCm || 0);
    }

    function simOf(sizes, idx, cfg) {
        if (!cfg.simByNames) return null;
        return cfg.simByNames(idx.map(function (i) { return sizes[i].name; })) || null;
    }

    function lenOf(sizes, idx, cfg) {
        var sm = simOf(sizes, idx, cfg);
        return sm && sm.lengthCm > 0 ? sm.lengthCm : estLengthCm(sizes, idx, cfg);
    }

    function unique(idx) {
        return idx.filter(function (v, i) { return idx.indexOf(v) === i; });
    }

    // mọi tổ hợp tối đa K size khác nhau, cộng thêm sơ đồ 2 áo cùng size [i,i]
    function candidateSets(sizes, K) {
        var n = sizes.length, out = [], i, j, k;
        for (i = 0; i < n; i++) { out.push([i]); out.push([i, i]); }
        if (K >= 2) for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) out.push([i, j]);
        if (K >= 3) for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) for (k = j + 1; k < n; k++) out.push([i, j, k]);
        return out;
    }

    function makeMarker(sizes, idx, plies, cfg) {
        var sm = simOf(sizes, idx, cfg);
        var Lcm = sm && sm.lengthCm > 0 ? sm.lengthCm : estLengthCm(sizes, idx, cfg);
        var k = idx.length;
        var names = idx.map(function (i) { return sizes[i].name; });
        var base = names.join('_');
        var repeat = unique(idx).length < idx.length;
        return {
            name: base + '_' + plies + T('ply'),
            base: base,
            copies: repeat ? 2 : 1,
            sizes: names,
            idx: idx,
            plies: plies,
            lengthM: Lcm / 100,
            normM: Lcm / 100 / k,
            fabricM: plies * Lcm / 100,
            garments: plies * k,
            effPct: sm && sm.effPct ? sm.effPct : null,
            simulated: !!(sm && sm.lengthCm > 0)
        };
    }

    function totals(sizes, markers, cfg) {
        var fabric = 0, garments = 0;
        markers.forEach(function (m) { fabric += m.fabricM; garments += m.garments; });
        var base = 0;
        sizes.forEach(function (s, i) { base += s.qty * lenOf(sizes, [i], cfg) / 100; });

        var got = {}, fab = {};
        sizes.forEach(function (s) { got[s.name] = 0; fab[s.name] = 0; });
        markers.forEach(function (m) {
            var areaSum = 0;
            m.idx.forEach(function (i) { areaSum += sizes[i].areaCm2; });
            m.idx.forEach(function (i) {
                got[sizes[i].name] += m.plies;
                fab[sizes[i].name] += m.fabricM * sizes[i].areaCm2 / areaSum;
            });
        });
        var perSize = sizes.map(function (s) {
            return { name: s.name, qty: s.qty, got: got[s.name], diff: s.qty - got[s.name], fabricM: fab[s.name], normM: s.qty ? fab[s.name] / s.qty : 0 };
        });
        return {
            files: markers.length,
            fabricM: fabric,
            garments: garments,
            normM: garments ? fabric / garments : 0,
            baselineM: base,
            baselineNormM: garments ? base / garments : 0,
            savedM: base - fabric,
            perSize: perSize,
            diff: perSize,
            ok: perSize.every(function (d) { return d.diff === 0; })
        };
    }

    /* sizes: [{name, qty, areaCm2, maxH}] theo thứ tự hiển thị; chỉ size qty > 0 được ghép. */
    function solve(allSizes, cfg) {
        var sizes = allSizes.filter(function (s) { return s.qty > 0; });
        var n = sizes.length;
        var K = Math.max(1, Math.min(3, cfg.maxSizes || 3));
        var penalty = cfg.penaltyM || 0;
        var B = cfg.beam || 400;

        var all = candidateSets(sizes, K).filter(function (idx) {
            // requireSim: bỏ các tổ hợp chưa được mô phỏng (vd bộ 3 size đã bị lọc); sơ đồ 1 size luôn giữ
            return !cfg.requireSim || idx.length === 1 || !!simOf(sizes, idx, cfg);
        }).map(function (idx) {
            var u = unique(idx);
            var sm = simOf(sizes, idx, cfg);
            var Lm = lenOf(sizes, idx, cfg) / 100;
            return { idx: idx, uniq: u, dup: u.length < idx.length, k: idx.length, Lm: Lm, norm: Lm / idx.length,
                     eff: sm && sm.effPct ? sm.effPct : 0 };
        });

        // Chỉ giữ tổ hợp có hiệu suất cao: với mỗi size, lấy hiệu suất tốt nhất trong các tổ hợp chứa nó;
        // tổ hợp bị loại nếu thấp hơn mức tốt nhất của bất kỳ size nào trong nó quá "dung sai".
        // Sơ đồ 1 size luôn được giữ để chắc chắn đủ số lượng.
        var tol = cfg.effTol === undefined ? 2 : cfg.effTol;
        var bestEff = sizes.map(function () { return 0; });
        all.forEach(function (c) { c.uniq.forEach(function (i) { if (c.eff > bestEff[i]) bestEff[i] = c.eff; }); });
        var filtered = all.filter(function (c) {
            if (c.idx.length === 1 || tol < 0 || !c.eff) return true;
            for (var q = 0; q < c.uniq.length; q++) if (c.eff < bestEff[c.uniq[q]] - tol) return false;
            return true;
        });

        var expansions = 0;
        var dupOf = {};
        all.forEach(function (c) { if (c.dup) dupOf[c.idx[0]] = c; });
        function search(cands, penalty) {
            var minNorm = Infinity;
            cands.forEach(function (c) { if (c.norm < minNorm) minNorm = c.norm; });
            var byAnchor = [];
            for (var i = 0; i < n; i++) byAnchor[i] = [];
            cands.forEach(function (c) { byAnchor[c.idx[0]].push(c); });
            var beam = [{ rem: sizes.map(function (s) { return s.qty; }), cost: 0, fab: 0, picks: [] }];
            var best = null;
            while (beam.length) {
                var next = {};
                beam.forEach(function (st) {
                    var first = -1;
                    for (var a = 0; a < n; a++) { if (st.rem[a] > 0) { first = a; break; } }
                    if (first < 0) { if (!best || st.cost < best.cost) best = st; return; }
                    byAnchor[first].forEach(function (c) {
                        var p = Infinity, ok = true;
                        for (var u = 0; u < c.uniq.length; u++) {
                            if (st.rem[c.uniq[u]] <= 0) { ok = false; break; }
                            if (st.rem[c.uniq[u]] < p) p = st.rem[c.uniq[u]];
                        }
                        if (!ok) return;
                        var options;
                        if (c.dup) {
                            if (st.rem[c.uniq[0]] % 2 !== 0) return;
                            options = [st.rem[c.uniq[0]] / 2];
                        } else {
                            options = [p];
                            if (p >= 2 && c.uniq.length > 1) options.push(Math.ceil(p / 2));
                        }
                        options.forEach(function (plies) {
                            var rem2 = st.rem.slice();
                            c.idx.forEach(function (ix) { rem2[ix] -= plies; });
                            var reuse = st.picks.some(function (pk) { return pk.c === c; });
                            // sơ đồ 1 size số lớp chẵn sẽ thành 2 áo cùng size -> tính theo chiều dài thật của sơ đồ 2 áo
                            var unitL = c.Lm, n2 = plies;
                            if (c.idx.length === 1 && plies % 2 === 0 && dupOf[c.idx[0]]) { unitL = dupOf[c.idx[0]].Lm; n2 = plies / 2; }
                            var cost = st.cost + n2 * unitL + (reuse ? 0 : penalty);
                            var key = rem2.join(',');
                            expansions++;
                            var ex = next[key];
                            if (!ex || cost < ex.cost) next[key] = { rem: rem2, cost: cost, fab: st.fab + n2 * unitL, picks: st.picks.concat([{ c: c, plies: plies }]) };
                        });
                    });
                });
                var arr = Object.keys(next).map(function (k) { return next[k]; });
                arr.forEach(function (x) {
                    var g = 0;
                    x.rem.forEach(function (v) { g += v; });
                    x.score = x.cost + g * minNorm;
                });
                arr.sort(function (x, y) { return x.score - y.score; });
                beam = arr.slice(0, B);
            }
            return best;
        }

        function fileCount(st) {
            var u = [];
            st.picks.forEach(function (pk) { if (u.indexOf(pk.c) < 0) u.push(pk.c); });
            return u.length;
        }
        // một lần giải với mức phạt cho trước: so bộ lọc hiệu suất cao với toàn bộ, lấy cách rẻ hơn
        function solveWith(pen) {
            var b1 = search(filtered, pen);
            if (filtered.length < all.length) {
                var b2 = search(all, pen);
                if (b2 && (!b1 || b2.cost < b1.cost * 0.998)) b1 = b2;
            }
            return b1;
        }

        // 1) cách tốn ít vải nhất (hiệu suất chung cao nhất)
        var best = solveWith(penalty);
        var minFab = best ? best.fab : 0;
        // 2) giảm số sơ đồ: tăng dần mức phạt mỗi file, chỉ nhận cách có tổng vải không vượt
        //    mức tốt nhất quá "slack" %, rồi chọn cách ít file nhất
        if (best && cfg.fileSlackPct !== 0) {
            var slack = (cfg.fileSlackPct === undefined ? 2 : cfg.fileSlackPct) / 100;
            var limit = minFab * (1 + slack) + 1e-9;
            var singles = all.filter(function (c) { return c.idx.length === 1; });
            var avgL = singles.reduce(function (t, c) { return t + c.Lm; }, 0) / Math.max(1, singles.length);
            [0.1, 0.25, 0.5, 1, 2, 4, 8, 16, 32].forEach(function (k) {
                var cand = solveWith(penalty + k * avgL);
                if (!cand || cand.fab > limit) return;
                var fc = fileCount(cand), fb = fileCount(best);
                if (fc < fb || (fc === fb && cand.fab < best.fab)) best = cand;
            });
        }

        // gộp các lần dùng cùng một tổ hợp thành một file
        if (best) {
            var merged = [];
            best.picks.forEach(function (pk) {
                var ex = merged.filter(function (m) { return m.c === pk.c; })[0];
                if (ex) ex.plies += pk.plies; else merged.push({ c: pk.c, plies: pk.plies });
            });
            best.picks = merged;

            // Quy tắc bắt buộc: sơ đồ 1 size có số lớp chẵn -> sơ đồ 2 áo cùng size, số lớp / 2 (vd L 48 lớp -> L_L 24 lớp)
            var out = [];
            best.picks.forEach(function (pk) {
                var c = pk.c, plies = pk.plies;
                if (c.idx.length === 1 && plies >= 2 && plies % 2 === 0) {
                    var dupC = all.filter(function (x) { return x.dup && x.idx[0] === c.idx[0]; })[0];
                    if (dupC) { c = dupC; plies = plies / 2; }
                }
                var ex = out.filter(function (m) { return m.c === c; })[0];
                if (ex) ex.plies += plies; else out.push({ c: c, plies: plies });
            });
            best.picks = out;
        }

        var markers = [];
        if (best) {
            best.picks.forEach(function (pk) { markers.push(makeMarker(sizes, pk.c.idx, pk.plies, cfg)); });
        }
        markers.sort(function (a, b) { return a.idx[0] - b.idx[0] || a.idx.length - b.idx.length; });
        var t = totals(sizes, markers, cfg);
        t.objective = best ? best.cost : 0;
        t.minFabricM = minFab;
        t.states = expansions;
        return { sizes: sizes, markers: markers, totals: t };
    }

    /* Đánh giá cặp do người dùng chỉnh tay: specs = [{sizes:[tên...], plies}] */
    function evaluate(allSizes, specs, cfg) {
        var sizes = allSizes.filter(function (s) { return s.qty > 0; });
        var byName = {};
        sizes.forEach(function (s, i) { byName[s.name] = i; });
        var K = Math.max(1, Math.min(3, cfg.maxSizes || 3));
        var markers = [];
        var errors = [];
        specs.forEach(function (sp) {
            var idx = [];
            sp.sizes.forEach(function (nm) {
                if (byName[nm] === undefined) errors.push(T('Size "{0}" is not in the list.', [nm]));
                else idx.push(byName[nm]);
            });
            if (idx.length === 0) return;
            idx.sort(function (a, b) { return a - b; });
            var distinct = unique(idx).length;
            if (distinct > K) errors.push(T('File {0} has {1} sizes; the maximum is {2}.', [sp.sizes.join('_'), distinct, K]));
            if (idx.length > distinct && !(distinct === 1 && idx.length === 2)) errors.push(T('File {0}: only 2 garments of the same size may repeat.', [sp.sizes.join('_')]));
            if (!(sp.plies > 0)) errors.push(T('File {0} is missing the number of plies.', [sp.sizes.join('_')]));
            markers.push(makeMarker(sizes, idx, sp.plies, cfg));
        });
        return { sizes: sizes, markers: markers, totals: totals(sizes, markers, cfg), errors: errors };
    }

    /* "S_M 100" mỗi dòng -> specs. Tên size có thể chứa "_" nên khớp theo danh sách size. */
    function parseSpec(text, allSizes) {
        var names = allSizes.map(function (s) { return s.name; });
        var specs = [];
        text.split(/\r?\n/).forEach(function (line) {
            line = line.trim();
            if (!line) return;
            var m = line.match(/^(\S+)\s+(\d+)$/);
            if (!m) { specs.push({ sizes: [line], plies: 0 }); return; }
            var file = m[1].replace(/_\d+lop$/, '');
            specs.push({ sizes: splitNames(file, names), plies: parseInt(m[2], 10) });
        });
        return specs;
    }

    function splitNames(file, names) {
        var sorted = names.slice().sort(function (a, b) { return b.length - a.length; });
        function rec(str) {
            if (str === '') return [];
            for (var i = 0; i < sorted.length; i++) {
                var nm = sorted[i];
                if (str === nm) return [nm];
                if (str.indexOf(nm + '_') === 0) {
                    var r = rec(str.slice(nm.length + 1));
                    if (r) return [nm].concat(r);
                }
            }
            return null;
        }
        return rec(file) || file.split('_');
    }

    NN.pairing = {
        solve: solve, evaluate: evaluate, parseSpec: parseSpec,
        candidateSets: candidateSets, estLengthCm: estLengthCm
    };
})(typeof window !== 'undefined' ? window : globalThis);
