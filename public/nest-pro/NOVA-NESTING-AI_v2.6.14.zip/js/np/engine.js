/* ===== Nest-Pro Sparrow engine (CEP) - sinh tu dong tu Nest-Pro_Illustrator_PolygonNest (engine V1.45: mo hinh hinh thang) =====
   Chay trong Web Worker / trang panel (V8), nhanh hon ExtendScript ~100 lan.
   THONG SO CHINH (chinh tai day):                                                                                         */
var NP_SP_T_BASE = 5000;      /* thoi gian xep = NP_SP_T_BASE + NP_SP_T_PIECE x so chi tiet (ms), kep [MIN, MAX]       */
var NP_SP_T_PIECE = 1000;
var NP_SP_T_MIN = 10000;
var NP_SP_T_MAX = 45000;
var NP_SP_RATE_DEFAULT = 90000;/* toc do gia dinh (lan thu/giay) cho lan chay dau; sau do panel luu toc do do duoc       */
var NP_SP_CS = 8, NP_SP_PH = 8, NP_SP_FINE = 0.5, NP_SP_TZ_TOL = 0.7;   /* luoi cot 8pt, vi tri ngang 1pt, hinh thang (da thu min hon: +0.3-1% hieu suat nhung do lech giua cac lan chay tang tu 0.25% len 1.5% -> giu muc nay vi on dinh quan trong hon) */
var NP_SP_SEED = 20240611, NP_SP_MOVE_CAP = 900, NP_SP_LBF_RUNS = 10;
var NP_FLAT_TOL = 0.15, NP_MAX_PIECES = 200, NP_MAX_SELECTION = 600, NP_BIG = 1e9, NP_PT_PER_CM = 28.346456692913385;
var NP_DEBUG = 0, NP_TRACE = 0, NP_PUMP_MS = 0, NP_PUMP_MAX_MS = 150, NP_SP_STEP_MS = 150, NP_SP_STEP_MAX = 300, NP_VERSION = "CEP-1.0.0";
    var WK = {};

WK.prepContainsRef = function (arr, item) {
    var i, len = arr.length;
    for (i = 0; i < len; i++) {
        if (arr[i] === item) return true;
    }
    return false;
};
WK.prepSafeBounds = function (item) {
    var b=null;
    try { b=item.geometricBounds; } catch(e1) { try { b=item.visibleBounds; } catch(e2) { return null; } }
    if(!b||b.length<4) return null;
    var l=Number(b[0]), t=Number(b[1]), r=Number(b[2]), bot=Number(b[3]);
    if(isNaN(l)||isNaN(t)||isNaN(r)||isNaN(bot)) return null;
    return {left:l,top:t,right:r,bottom:bot,w:Math.abs(r-l),h:Math.abs(t-bot),area:Math.abs(r-l)*Math.abs(t-bot)};
};
WK.prepItemName = function (item, idx) { try { if(item.name && String(item.name).length) return String(item.name); } catch(e) {} return "Piece_"+(idx+1); };
WK.prepIsClosedShape = function (item) {
    var type=""; try { type=item.typename; } catch(e) { return false; }
    if(type==="PathItem") { try { return !!item.closed; } catch(e1) { return false; } }
    if(type==="CompoundPathItem") {
        try { if(!item.pathItems || item.pathItems.length<1) return false; for(var i=0;i<item.pathItems.length;i++) if(!item.pathItems[i].closed) return false; return true; } catch(e2) { return false; }
    }
    return false;
};
WK.prepIsCompoundClip = function (item) {
    if(!item || item.typename!=="CompoundPathItem") return false;
    try { for(var i=0;i<item.pathItems.length;i++) if(item.pathItems[i].clipping) return true; } catch(e) {}
    return false;
};
WK.prepIsClipShape = function (item) {
    if(!item) return false;
    if(item.typename==="PathItem") { try { return !!item.clipping && !!item.closed; } catch(e) { return false; } }
    if(item.typename==="CompoundPathItem") return prepIsClosedShape(item) && prepIsCompoundClip(item);
    return false;
};
WK.prepDirectChildren = function (group) {
    var out=[], all=null, seen=[], i, child, parent;
    if(!group || group.typename!=="GroupItem") return out;
    try {
        all=group.pageItems;
        var n=Math.min(all.length,5000);
        for(i=0;i<n;i++) {
            child=all[i]; parent=null; try { parent=child.parent; } catch(eParent) {}
            if(parent===group && !prepContainsRef(seen,child)) { out.push(child); seen.push(child); }
        }
    } catch(eAll) {}
    if(out.length) return out;
    var props=["groupItems","pathItems","compoundPathItems"];
    for(var p=0;p<props.length;p++) {
        try {
            all=group[props[p]]; var lim=Math.min(all.length,5000);
            for(i=0;i<lim;i++) {
                child=all[i]; parent=null; try { parent=child.parent; } catch(eP2) {}
                if(parent===group && !prepContainsRef(seen,child)) { out.push(child); seen.push(child); }
            }
        } catch(eProp) {}
    }
    return out;
};
WK.prepFindGroupClipShapes = function (group, depth) {
    var out=[], kids, i, child, all, n;
    if(!group || depth>8) return out;
    kids=prepDirectChildren(group);
    for(i=0;i<kids.length;i++) {
        child=kids[i];
        if(prepIsClipShape(child)) { if(!prepContainsRef(out,child)) out.push(child); }
        else if(child && child.typename==="GroupItem" && child.clipped) {
            var nested=prepFindGroupClipShapes(child,depth+1);
            for(var ni=0;ni<nested.length;ni++) if(!prepContainsRef(out,nested[ni])) out.push(nested[ni]);
        }
    }
    if(out.length) return out;
    try {
        all=group.compoundPathItems; n=Math.min(all.length,5000);
        for(i=0;i<n;i++) if(prepIsCompoundClip(all[i])) { out.push(all[i]); }
    } catch(eCP) {}
    try {
        all=group.pathItems; n=Math.min(all.length,5000);
        for(i=0;i<n;i++) {
            child=all[i]; if(!child || child.typename!=="PathItem" || !child.clipping || !child.closed) continue;
            var par=null; try { par=child.parent; } catch(ePar) {}
            if(par && par.typename==="CompoundPathItem") continue;
            if(!prepContainsRef(out,child)) out.push(child);
        }
    } catch(ePath) {}
    return out;
};
WK.prepCollectRawShapes = function (node, raw, warnings, depth, visited) {
    if(!node || depth>24 || prepContainsRef(visited,node)) return;
    visited.push(node);
    var type=""; try { type=node.typename; } catch(eType) { return; }
    if(type==="PathItem" || type==="CompoundPathItem") {
        if(prepIsClosedShape(node) && !prepContainsRef(raw,node)) raw.push(node);
        return;
    }
    if(type!=="GroupItem") return;
    var clipped=false; try { clipped=!!node.clipped; } catch(eClip) {}
    if(clipped) {
        var masks=prepFindGroupClipShapes(node,0);
        if(masks.length) { for(var mi=0;mi<masks.length;mi++) if(!prepContainsRef(raw,masks[mi])) raw.push(masks[mi]); return; }
        warnings.push("A clipped group had no explicit clipping flag; outline fallback used.");
    }
    var kids=prepDirectChildren(node);
    if(!kids.length) {
        try {
            var paths=node.pathItems, lim=Math.min(paths.length,5000);
            for(var pi=0;pi<lim;pi++) if(prepIsClosedShape(paths[pi]) && !prepContainsRef(raw,paths[pi])) raw.push(paths[pi]);
        } catch(ePaths) {}
        try {
            var cps=node.compoundPathItems, lim2=Math.min(cps.length,1000);
            for(var ci=0;ci<lim2;ci++) if(prepIsClosedShape(cps[ci]) && !prepContainsRef(raw,cps[ci])) raw.push(cps[ci]);
        } catch(eCps) {}
        return;
    }
    for(var i=0;i<kids.length;i++) prepCollectRawShapes(kids[i],raw,warnings,depth+1,visited);
};
WK.prepFilterOuterShapes = function (raw) {
    var rows = [], i, b, j, contained, len = raw.length;
    for (i = 0; i < len; i++) {
        b = prepSafeBounds(raw[i]); if (!b || b.w < 1 || b.h < 1) continue;
        rows.push({ item: raw[i], b: b });
    }
    rows.sort(function (a, b) {
        var diffArea = b.b.area - a.b.area;
        if (Math.abs(diffArea) > 0.5) return diffArea;
        return (b.b.w + b.b.h) - (a.b.w + a.b.h);
    });
    var out = [], bounds = [], rLen = rows.length;
    for (i = 0; i < rLen; i++) {
        contained = false;
        var c = rows[i].b;
        var cl = c.left, cr = c.right, ct = c.top, cb = c.bottom;
        for (j = 0; j < bounds.length; j++) {
            var a = bounds[j];
            /* OPT: "inside" kiem tra ca truong hop trung vi tri; da loai bo nhanh "same" thua */
            if (cl >= a.left - 0.5 && cr <= a.right + 0.5 && ct <= a.top + 0.5 && cb >= a.bottom - 0.5) {
                contained = true; break;
            }
        }
        if (!contained) { out.push(rows[i].item); bounds.push(c); }
    }
    return out;
};
WK.prepExtractRoot = function (root) {
    var warnings=[], raw=[], visited=[];
    if(!root) return {items:[],warnings:["Empty selection item."]};
    if(prepIsClosedShape(root)) return {items:[root],warnings:[]};
    if(root.typename==="GroupItem" && root.clipped) {
        var directMasks=prepFindGroupClipShapes(root,0);
        if(directMasks.length) return {items:directMasks,warnings:[]};
    }
    prepCollectRawShapes(root,raw,warnings,0,visited);
    var clipOnly=[], i;
    for(i=0;i<raw.length;i++) if(prepIsClipShape(raw[i])) clipOnly.push(raw[i]);
    var items=[];
    if(clipOnly.length) {
        var nonClip=[], clipBounds=[], nb, cb, inside, ci;
        for(i=0;i<clipOnly.length;i++) { cb=prepSafeBounds(clipOnly[i]); if(cb) clipBounds.push(cb); if(!prepContainsRef(items,clipOnly[i])) items.push(clipOnly[i]); }
        for(i=0;i<raw.length;i++) {
            if(prepContainsRef(clipOnly,raw[i]) || prepIsClipShape(raw[i])) continue;
            nb=prepSafeBounds(raw[i]); if(!nb || nb.w<1 || nb.h<1) continue;
            inside=false;
            for(ci=0;ci<clipBounds.length;ci++) {
                cb=clipBounds[ci];
                if(nb.left>=cb.left-0.5 && nb.right<=cb.right+0.5 && nb.top<=cb.top+0.5 && nb.bottom>=cb.bottom-0.5) { inside=true; break; }
            }
            if(!inside) nonClip.push(raw[i]);
        }
        var exterior=prepFilterOuterShapes(nonClip);
        for(i=0;i<exterior.length;i++) if(!prepContainsRef(items,exterior[i])) items.push(exterior[i]);
    } else items=prepFilterOuterShapes(raw);
    if(items.length>1 && !clipOnly.length) warnings.push("Group without clipping masks: nested inner paths were filtered by bounds; review silhouette.");
    return {items:items,warnings:warnings};
};
WK.prepGetSelectionRoots = function (doc) {
    var raw=[], out=[], i, it, count=0;
    try { if(!doc.selection || !doc.selection.length) return {items:[],overflow:0}; count=Number(doc.selection.length)||0; } catch(eSel) { return {items:[],overflow:0}; }
    if(count>NP_MAX_SELECTION) return {items:[],overflow:count};
    for(i=0;i<count;i++) { try { it=doc.selection[i]; if(it) raw.push(it); } catch(eItem) {} }
    for(i=0;i<raw.length;i++) {
        var p=null, guard=0, ancestor=false;
        try { p=raw[i].parent; } catch(ePar) {}
        while(p && guard<100) { if(prepContainsRef(raw,p)) { ancestor=true; break; } try { p=p.parent; } catch(eP) { p=null; } guard++; }
        if(!ancestor && !prepContainsRef(out,raw[i])) out.push(raw[i]);
    }
    return {items:out,overflow:0};
};
WK.prepAscii = function (v) { return String(v===undefined||v===null?"":v).replace(/[^\x20-\x7E]/g,"?").replace(/[|\r\n]/g," ").substring(0,240); };
WK.prepDocSpace = function (doc) { try { return doc.documentColorSpace; } catch(e) { return DocumentColorSpace.RGB; } };
WK.prepColor = function (doc, mode) {
    if(prepDocSpace(doc)===DocumentColorSpace.CMYK) {
        var c=new CMYKColor();
        if(mode===0) { c.cyan=18; c.magenta=0; c.yellow=24; c.black=0; }
        else { c.cyan=92; c.magenta=55; c.yellow=0; c.black=0; }
        return c;
    }
    var r=new RGBColor();
    if(mode===0) { r.red=180; r.green=220; r.blue=235; }
    else { r.red=25; r.green=90; r.blue=210; }
    return r;
};
WK.prepStyleShape = function (item, cfg, doc) {
    var type=item.typename, fill=cfg.displayMode===0, color=prepColor(doc,fill?0:1), paths=[];
    if(type==="PathItem") paths=[item];
    else if(type==="CompoundPathItem") { for(var i=0;i<item.pathItems.length;i++) paths.push(item.pathItems[i]); }
    else throw new Error("Unsupported silhouette type: "+type);
    try { item.hidden=false; } catch(eHidden) {}
    try { item.locked=false; } catch(eLocked) {}
    try { item.opacity=100; } catch(eOpacity) {}
    for(var p=0;p<paths.length;p++) {
        try { paths[p].clipping=false; } catch(eClip) {}
        if(fill) {
            paths[p].filled=true; paths[p].fillColor=color; paths[p].stroked=false;
        } else {
            paths[p].filled=false; paths[p].stroked=true; paths[p].strokeColor=color; paths[p].strokeWidth=cfg.strokeWidth;
        }
    }
    return true;
};
WK.prepCopyPathGeometry = function (src, dstParent) {
    var dst=dstParent.pathItems.add(), srcPts=src.pathPoints, dstPt, i, sp;
    for(i=0;i<srcPts.length;i++) {
        sp=srcPts[i]; dstPt=dst.pathPoints.add();
        dstPt.anchor=[Number(sp.anchor[0]),Number(sp.anchor[1])];
        dstPt.leftDirection=[Number(sp.leftDirection[0]),Number(sp.leftDirection[1])];
        dstPt.rightDirection=[Number(sp.rightDirection[0]),Number(sp.rightDirection[1])];
        try { dstPt.pointType=sp.pointType; } catch(eType) {}
    }
    dst.closed=!!src.closed;
    dst.clipping=false;
    return dst;
};
WK.prepNow = function () { return (new Date()).getTime(); };

WK.prepLog = function (job, msg) {
    var f;
    if (!NP_DEBUG) return;
    try {
        f = new File(Folder.desktop + "/NestPro_debug_log.txt");
        f.open("a"); f.writeln((new Date()).toString() + " | " + (job ? job.phase : "-") + " | " + msg); f.close();
    } catch (eLog) {}
};

/* V1.36: nhat ky chan doan (Desktop/NestPro_trace.txt, ghi de moi lan chay): moi buoc ghi "B" luc bat dau va "E" luc ket thuc.
   Neu Illustrator treo ma dong cuoi la "B ..." -> engine dang ket trong buoc do; neu cac dong van tang deu -> chi giao dien bi dong bang. */
WK.prepTrace = function (job, line, reset) {
    var f;
    if (!NP_TRACE) return;
    try {
        f = new File(Folder.desktop + "/NestPro_trace.txt");
        f.encoding = "UTF-8";
        f.open(reset ? "w" : "a");
        f.writeln(((prepNow() - (job.t0 || prepNow())) / 1000).toFixed(2) + "s " + line);
        f.close();
    } catch (eTr) {}
};
WK.prepTraceState = function (job) {
    var S = job.sp, t = job.phase;
    if (t === "prepare") t += " piece " + job.prepIdx + "/" + job.candidates.length;
    if (S) {
        t += " stage=" + S.stage;
        if (S.stage === "lbf" && S.lb) t += " order=" + S.lb.k + " pos=" + S.lb.pos;
        else t += " L=" + (S.L / NP_PT_PER_CM).toFixed(1) + "cm passes=" + S.passes + " moves=" + S.moves + " evals=" + S.evals;
    }
    if (t === "verify" && job.vf) t += " pair " + (job.vf.k / 2) + "/" + (job.vf.pairs.length / 2);
    if (job.phase === "copy" || job.phase === "finish") t += " piece " + job.copyIndex + "/" + job.layout.length;
    return t;
};

WK.prepAngles = function (mode) {
    var out = [], step, a;
    mode = Number(mode);
    if (mode === 0) return [0];
    if (mode === 1) return [0, 180];
    if (mode === 3) step = 45;
    else if (mode === 4) step = 30;
    else step = 90;
    for (a = 0; a < 360; a += step) out.push(a);
    return out;
};

/* ---------- one DOM pass per path: keep raw anchors/handles for the copy phase, flatten only for layout ---------- */
WK.prepReadPath = function (path) {
    var pp, n, i, a, an, ld, rd, P = [], closed = true;
    try { pp = path.pathPoints; n = pp.length; } catch (e0) { return null; }
    if (n < 3) return null;
    for (i = 0; i < n; i++) {
        try {
            /* V1.38: moi thuoc tinh DOM doc MOT lan (truoc day a.anchor[0], a.anchor[1]... = 7 lan goi DOM/diem, nay 4) */
            a = pp[i]; an = a.anchor; ld = a.leftDirection; rd = a.rightDirection;
            P.push({ ax: Number(an[0]), ay: Number(an[1]), lx: Number(ld[0]), ly: Number(ld[1]), rx: Number(rd[0]), ry: Number(rd[1]) });
        } catch (e1) { return null; }
    }
    try { closed = !!path.closed; } catch (e2) {}
    return { P: P, closed: closed };
};

WK.prepFlatFromP = function (P, tol) {
    var out = [], n = P.length, i, a, b, k, steps, invSteps, t, mt, mt2, t2, c0, c1, c2, c3, straight, m, m1, m2, d1x, d1y, d2x, d2y, x, y, res, last, outLen;
    for (i = 0; i < n; i++) {
        a = P[i]; b = P[(i + 1) % n];
        out.push({ x: a.ax, y: a.ay });
        straight = (Math.abs(a.rx - a.ax) < 1e-6 && Math.abs(a.ry - a.ay) < 1e-6 && Math.abs(b.lx - b.ax) < 1e-6 && Math.abs(b.ly - b.ay) < 1e-6);
        if (!straight) {
            d1x = a.ax - 2 * a.rx + b.lx; d1y = a.ay - 2 * a.ry + b.ly;
            d2x = a.rx - 2 * b.lx + b.ax; d2y = a.ry - 2 * b.ly + b.ay;
            m1 = Math.sqrt(d1x * d1x + d1y * d1y); m2 = Math.sqrt(d2x * d2x + d2y * d2y);
            m = m1 > m2 ? m1 : m2;
            steps = Math.ceil(Math.sqrt(0.75 * m / tol));
            if (steps < 2) steps = 2;
            if (steps > 48) steps = 48;
            invSteps = 1 / steps;
            /* OPT: Cache he so Bernstein polynomial: giam tu 16 phep nhan + 2 phep chia xuong 6 phep nhan / buoc */
            for (k = 1; k < steps; k++) {
                t = k * invSteps; mt = 1 - t;
                mt2 = mt * mt; t2 = t * t;
                c0 = mt2 * mt;
                c1 = 3 * mt2 * t;
                c2 = 3 * mt * t2;
                c3 = t2 * t;
                x = c0 * a.ax + c1 * a.rx + c2 * b.lx + c3 * b.ax;
                y = c0 * a.ay + c1 * a.ry + c2 * b.ly + c3 * b.ay;
                out.push({ x: x, y: y });
            }
        }
    }
    res = [];
    outLen = out.length;
    for (i = 0; i < outLen; i++) {
        last = res.length ? res[res.length - 1] : null;
        if (last && Math.abs(last.x - out[i].x) < 1e-7 && Math.abs(last.y - out[i].y) < 1e-7) continue;
        res.push(out[i]);
    }
    while (res.length > 1 && Math.abs(res[0].x - res[res.length - 1].x) < 1e-7 && Math.abs(res[0].y - res[res.length - 1].y) < 1e-7) res.pop();
    return res.length >= 3 ? res : [];
};

WK.prepOutline = function (item, tol) {
    var polys = [], raws = [], subs = [], i, rd, poly;
    try {
        if (item.typename === "PathItem") subs.push(item);
        else if (item.typename === "CompoundPathItem") { for (i = 0; i < item.pathItems.length; i++) subs.push(item.pathItems[i]); }
    } catch (e) {}
    for (i = 0; i < subs.length; i++) {
        rd = prepReadPath(subs[i]);
        if (!rd) continue;
        poly = prepFlatFromP(rd.P, tol);
        if (poly.length > 2) { polys.push(poly); raws.push(rd); }
    }
    return { polys: polys, raws: raws };
};

WK.prepOutlineBounds = function (outline) {
    var i, j, q, minX = 1e30, maxX = -1e30, minY = 1e30, maxY = -1e30;
    for (i = 0; i < outline.length; i++) for (j = 0; j < outline[i].length; j++) {
        q = outline[i][j];
        if (q.x < minX) minX = q.x; if (q.x > maxX) maxX = q.x;
        if (q.y < minY) minY = q.y; if (q.y > maxY) maxY = q.y;
    }
    if (minX > maxX) return null;
    return { minX: minX, maxX: maxX, minY: minY, maxY: maxY, w: maxX - minX, h: maxY - minY };
};

WK.prepPolyArea = function (poly) {
    var s = 0, i, j = poly.length - 1;
    for (i = 0; i < poly.length; j = i++) s += (poly[j].x * poly[i].y - poly[i].x * poly[j].y);
    return s / 2;
};

WK.prepPointInPoly = function (px, py, poly) {
    var inside = false, i, j = poly.length - 1, a, b;
    for (i = 0; i < poly.length; j = i++) {
        a = poly[i]; b = poly[j];
        if (((a.y > py) !== (b.y > py)) && px < (b.x - a.x) * (py - a.y) / (b.y - a.y) + a.x) inside = !inside;
    }
    return inside;
};

WK.prepNetArea = function (outline) {
    var i, a, areas = [], big = -1, bigA = -1, total;
    for (i = 0; i < outline.length; i++) {
        a = Math.abs(prepPolyArea(outline[i])); areas.push(a);
        if (a > bigA) { bigA = a; big = i; }
    }
    if (big < 0) return 0;
    total = bigA;
    for (i = 0; i < outline.length; i++) {
        if (i === big) continue;
        if (prepPointInPoly(outline[i][0].x, outline[i][0].y, outline[big])) total -= areas[i]; else total += areas[i];
    }
    return total < 0 ? 0 : total;
};

/* rotate every sub-path about the origin and shift so the bounding box starts at (0,0) */
WK.prepRotatePolys = function (outline, angle) {
    var a = ((angle % 360) + 360) % 360, c, s, rad, polys = [], i, j, q, x, y, minX = 1e30, maxX = -1e30, minY = 1e30, maxY = -1e30, poly;
    if (a === 0) { c = 1; s = 0; }
    else if (a === 90) { c = 0; s = 1; }
    else if (a === 180) { c = -1; s = 0; }
    else if (a === 270) { c = 0; s = -1; }
    else { rad = a * Math.PI / 180; c = Math.cos(rad); s = Math.sin(rad); }
    for (i = 0; i < outline.length; i++) {
        poly = [];
        for (j = 0; j < outline[i].length; j++) {
            q = outline[i][j]; x = q.x * c - q.y * s; y = q.x * s + q.y * c;
            poly.push({ x: x, y: y });
            if (x < minX) minX = x; if (x > maxX) maxX = x;
            if (y < minY) minY = y; if (y > maxY) maxY = y;
        }
        polys.push(poly);
    }
    for (i = 0; i < polys.length; i++) for (j = 0; j < polys[i].length; j++) { polys[i][j].x -= minX; polys[i][j].y -= minY; }
    return { polys: polys, w: maxX - minX, h: maxY - minY, mx: minX, my: minY };
};

/*
  Orientation profile on a column grid (cell width cs):
    T[c]  highest boundary y inside column c  (what the piece adds to the sheet height-map)
    B[c]  lowest boundary y inside column c
    Bd[j] lowest boundary y of the piece DILATED by a disk of radius r (clearance), j = c + R
  All are conservative (min / max over each column interval), so a placement is never tighter than r.
*/
/* ================= V1.7: BO GIAI MA "KHONG GIAN TRONG THAT" (bottom-left-fill) =================
   Thay cho height-map (moi cot chi nho mot do cao): moi cot cua so do luu DANH SACH cac doan [lo,hi] dang bi chiem.
   Nho do chi tiet co the roi vao hoc kin, vao cho lom (nach ao...) ma height-map khong thay duoc. */
WK.prepMergeIv = function (list) {
    var out = [], i, iv, last;
    if (list.length > 1) list.sort(function (p, q) { return p[0] - q[0]; });
    for (i = 0; i < list.length; i++) {
        iv = list[i]; last = out.length ? out[out.length - 1] : null;
        if (last && iv[0] <= last[1] + 1e-9) { if (iv[1] > last[1]) last[1] = iv[1]; }
        else out.push([iv[0], iv[1]]);
    }
    return out;
};

/* Voi moi cot (be rong cs) lay cac doan "ben trong chi tiet" tai 5 vi tri lay mau roi hop nhat (bao loi, an toan).
   Sau do tinh ban "no" (dilated) de dam bao khoang cach r theo ca hai phuong. */
/* V1.28: profile cot MIN (rong f pt) CHINH XAC: moi cot = hop doan cat tai 3 vi tri mau + khoang y cua tung canh cat qua cot
   -> khong bo sot dinh nhon / canh doc nam giua hai diem mau. */
/* V1.38: gop cac doan [lo, hi] dang MANG PHANG (a = [lo0, hi0, lo1, hi1, ...]): sap xep chen tai cho + gop,
   khong tao mang con -> nhanh hon nhieu trong ExtendScript so voi danh sach mang 2 phan tu. */
WK.spMergeFlat = function (a) {
    var n = a.length, k, j, lo, hi, out = [], m;
    for (k = 2; k < n; k += 2) {
        lo = a[k]; hi = a[k + 1]; j = k - 2;
        while (j >= 0 && a[j] > lo) { a[j + 2] = a[j]; a[j + 3] = a[j + 1]; j -= 2; }
        a[j + 2] = lo; a[j + 3] = hi;
    }
    for (k = 0; k < n; k += 2) {
        m = out.length;
        if (m && a[k] <= out[m - 1] + 1e-9) { if (a[k + 1] > out[m - 1]) out[m - 1] = a[k + 1]; }
        else out.push(a[k], a[k + 1]);
    }
    return out;
};
WK.spRawCols = function (polys, w, f) {
    /* V1.38: 1 diem mau giua cot + khoang y cua tung canh cat qua cot la DU de phu dung phan rap trong cot
       (dai ngang khong co canh nao di qua thi nam tron trong hoac tron ngoai rap -> diem mau giua cot quyet dinh).
       Truoc day 3 diem mau/cot: gap 3 lan so mang + sap xep, la phan ton thoi gian nhat cua buoc chuan bi. */
    var nf = Math.ceil(w / f - 1e-9), c, pi, ei, n, poly, p, q, x0, y0, x1, y1, xs, i, ys, out = [], cross = [], spans = [];
    var sl, cx0, cx1, ya, yb, all, cA, cB;
    if (nf < 1) nf = 1;
    for (c = 0; c < nf; c++) { cross.push(null); spans.push(null); }
    for (pi = 0; pi < polys.length; pi++) {
        poly = polys[pi]; n = poly.length;
        /* Nova 2.2.2: to dac TUNG duong rieng roi hop lai (union) - chi tiet gom nhieu duong cat chong/long nhau
           khong bi hieu nham thanh lo trong (truoc day chan-le tren tat ca duong). Lo that cua chi tiet cung duoc to kin (an toan). */
        cross = [];
        for (c = 0; c < nf; c++) cross.push(null);
        for (ei = 0; ei < n; ei++) {
            p = poly[ei]; q = poly[(ei + 1) % n];
            if (p.x === q.x) {
                c = Math.floor(p.x / f); if (c < 0) c = 0; if (c >= nf) c = nf - 1;
                if (!spans[c]) spans[c] = [];
                if (p.y < q.y) spans[c].push(p.y, q.y); else spans[c].push(q.y, p.y);
                continue;
            }
            if (p.x < q.x) { x0 = p.x; y0 = p.y; x1 = q.x; y1 = q.y; } else { x0 = q.x; y0 = q.y; x1 = p.x; y1 = p.y; }
            sl = (y1 - y0) / (x1 - x0);
            cA = Math.floor(x0 / f); if (cA < 0) cA = 0;
            cB = Math.floor(x1 / f); if (cB >= nf) cB = nf - 1;
            for (c = cA; c <= cB; c++) {
                cx0 = c * f; if (cx0 < x0) cx0 = x0;
                cx1 = (c + 1) * f; if (cx1 > x1) cx1 = x1;
                if (cx0 <= cx1) {
                    ya = y0 + (cx0 - x0) * sl; yb = y0 + (cx1 - x0) * sl;
                    if (!spans[c]) spans[c] = [];
                    if (ya < yb) spans[c].push(ya, yb); else spans[c].push(yb, ya);
                }
                xs = (c + 0.5) * f; if (xs > w - 1e-6) xs = w - 1e-6;
                if (xs >= x0 && xs < x1) { if (!cross[c]) cross[c] = []; cross[c].push(y0 + (xs - x0) * sl); }
            }
        }
        for (c = 0; c < nf; c++) {
            ys = cross[c];
            if (!ys) continue;
            if (ys.length > 1) ys.sort(function (m1, m2) { return m1 - m2; });
            if (!spans[c]) spans[c] = [];
            for (i = 0; i + 1 < ys.length; i += 2) spans[c].push(ys[i], ys[i + 1]);
        }
    }
    for (c = 0; c < nf; c++) {
        all = spans[c] || [];
        out.push(all.length > 2 ? spMergeFlat(all) : all);
    }
    return out;
};


/* V1.28: profile cot THO (cs) da gian no rh, tinh tu profile min theo khoang cach ngang THAT (sai so <= f pt)
   thay cho "cot ke ben gian no ca cot" (truoc day hai chi tiet dat canh nhau bi ep cach ~2 cot). shiftF = lech pha (so cot min). */
/* V1.28: profile cot THO (cs) da gian no rh, tinh tu profile min theo khoang cach ngang THAT (sai so <= f pt)
   thay cho "cot ke ben gian no ca cot" (truoc day hai chi tiet dat canh nhau bi ep cach ~2 cot). shiftF = lech pha (so cot min). */
/* V1.42: moi doan trong cot luu them PHAM VI NGANG [xa, xb] (tinh tu mep trai cot) cua phan gian no nam trong cot (mang dx song song dv).
   Hai doan chi va cham khi chong nhau ca theo y LAN theo x -> hai chi tiet dung sat nhau van co the cung cham mot cot 8pt.
   Cung voi luoi vi tri ngang min (SP_PH) va le phu nho, mot HANG chi tiet chay het kho (vd 3 than ao tren kho 150cm) moi vua duoc. */
/* V1.43: profile gian no o do phan giai MIN (f pt), tinh 1 lan cho moi goc: fd[s + Rf] = cac doan y (mang phang) cua vung
   gian no tai cot min s (s co the am / vuot be rong do gian no). */
WK.spFineDilate = function (fine, f, rh) {
    var nf = fine.length, Rf = Math.ceil(rh / f) + 1, fd = [], s, q, d, b, list, t, all, rr = rh * rh, dist;
    for (s = -Rf; s < nf + Rf; s++) {
        all = [];
        for (q = s - Rf; q <= s + Rf; q++) {
            if (q < 0 || q >= nf) continue;
            list = fine[q]; if (!list.length) continue;
            d = q > s ? q - s : s - q; dist = d > 0 ? (d - 1) * f : 0;
            if (dist >= rh) continue;
            b = Math.sqrt(rr - dist * dist);
            for (t = 0; t < list.length; t += 2) all.push(list[t] - b, list[t + 1] + b);
        }
        fd.push(all.length > 2 ? spMergeFlat(all) : all);
    }
    return { fd: fd, Rf: Rf, nf: nf };
};
/* V1.43: moi doan trong cot tho (cs) la mot HINH THANG: pham vi ngang [xa, xb] (tinh tu mep trai cot), canh duoi la duong thang
   y = la + (lb - la) * (x - xa) / (xb - xa), canh tren tuong tu voi (ua, ub). Do doc lay theo hai cot min dau/cuoi cua nhom; duong thang
   duoc dich ra ngoai vua du de bao tron moi cot min (moi cot min la mot bac ngang) -> bao toan, sai so <= 1 cot min theo chieu ngang.
   Nho vay canh xien (suon ao, vai, nach) cua hai chi tiet xoay nguoc nhau long vao nhau duoc trong cung mot cot 8pt.
   tz = [xa, xb, la, lb, ua, ub] x so doan; dv = [min(la, lb), max(ua, ub)] dung cho loc nhanh. */
/* khop mot duong thang bao toan cho cac bac [k0, k1) (mang slot: [x0, lo, hi] x m) ; tra ve sai so lon nhat (pt) va ghi ket qua vao out */
WK.spFitRun = function (sl3, k0, k1, f, out) {
    var xL = sl3[k0], xR = sl3[k1 - 3], k, x0, v, s, c, err = 0, e, xa = xL, xb = xR + f, nrm;
    /* canh duoi: duong thang <= lo cua moi bac tren ca be rong bac */
    s = xR > xL ? (sl3[k1 - 2] - sl3[k0 + 1]) / (xR - xL) : 0; c = 1e30;
    for (k = k0; k < k1; k += 3) { x0 = sl3[k]; v = sl3[k + 1] - s * (s > 0 ? x0 + f : x0); if (v < c) c = v; }
    nrm = Math.sqrt(1 + s * s);   /* sai so do VUONG GOC voi canh: canh thang doc khong bi tinh la lech do bac thang cua cot min */
    for (k = k0; k < k1; k += 3) { x0 = sl3[k]; e = (sl3[k + 1] - (c + s * (s > 0 ? x0 : x0 + f))) / nrm; if (e > err) err = e; }
    out[0] = xa; out[1] = xb; out[2] = c + s * xa; out[3] = c + s * xb;
    s = xR > xL ? (sl3[k1 - 1] - sl3[k0 + 2]) / (xR - xL) : 0; c = -1e30;
    for (k = k0; k < k1; k += 3) { x0 = sl3[k]; v = sl3[k + 2] - s * (s > 0 ? x0 : x0 + f); if (v > c) c = v; }
    nrm = Math.sqrt(1 + s * s);
    for (k = k0; k < k1; k += 3) { x0 = sl3[k]; e = ((c + s * (s > 0 ? x0 + f : x0)) - sl3[k + 2]) / nrm; if (e > err) err = e; }
    out[4] = c + s * xa; out[5] = c + s * xb;
    return err;
};
/* V1.44: moi doan trong cot tho (cs) la mot hoac vai HINH THANG [xa, xb, la, lb, ua, ub] (x tinh tu mep trai cot).
   Cac bac (cot min) cua mot nhom duoc chia thanh cac doan lien tiep sao cho mot duong thang bao toan lech khong qua NP_SP_TZ_TOL pt:
   cot tron (canh thang/xien deu) = 1 hinh thang; cot co GOC/BAC = them hinh thang. Nho vay canh xien va goc cua hai chi tiet
   long vao nhau duoc trong cung cot 8pt ma khong can cot nho (cot nho lam cham tim kiem). Luon bao toan (bao tron hinh that). */
WK.spDilate = function (FD, f, shiftF, w, cs, rh) {
    var fd = FD.fd, Rf = FD.Rf, wS = w + shiftF * f, nc = Math.ceil(wS / cs - 1e-9), R = Math.floor(rh / cs) + 1, nd, j, c, xl, s0, sIdx, list, t, a, n, k, m, per = Math.round(cs / f);
    var doff = [0], dv = [], tz = [], lo = 1e30, hi = -1e30, e0 = [], e1 = [], g0, g1, gHi, lo4, hi4, sx, first, mn, mx, sl3, q, r0, r1, out = [0, 0, 0, 0, 0, 0], keep = [0, 0, 0, 0, 0, 0], err, tol = NP_SP_TZ_TOL, z;
    if (nc < 1) nc = 1;
    nd = nc + 2 * R;
    for (j = 0; j < nd; j++) {
        c = j - R; xl = c * cs; s0 = c * per - shiftF;      /* cot min s nam tai x = (s + shiftF) * f */
        a = [];   /* [lo, hi, x0] x n */
        for (sIdx = s0; sIdx < s0 + per; sIdx++) {
            if (sIdx < -Rf || sIdx >= FD.nf + Rf) continue;
            list = fd[sIdx + Rf]; sx = (sIdx + shiftF) * f - xl;
            for (t = 0; t < list.length; t += 2) a.push(list[t], list[t + 1], sx);
        }
        n = a.length;
        for (k = 3; k < n; k += 3) {      /* sap xep chen theo lo */
            lo4 = a[k]; hi4 = a[k + 1]; sx = a[k + 2]; m = k - 3;
            while (m >= 0 && a[m] > lo4) { a[m + 3] = a[m]; a[m + 4] = a[m + 1]; a[m + 5] = a[m + 2]; m -= 3; }
            a[m + 3] = lo4; a[m + 4] = hi4; a[m + 5] = sx;
        }
        first = dv.length; g0 = 0;
        while (g0 < n) {
            g1 = g0 + 3; gHi = a[g0 + 1];
            while (g1 < n && a[g1] <= gHi + 1e-9) { if (a[g1 + 1] > gHi) gHi = a[g1 + 1]; g1 += 3; }
            /* gop theo cot min: sl3 = [x0, lo, hi] sap theo x (moi cot min mot bac = bao cua cac doan cua no trong nhom) */
            sl3 = [];
            for (k = g0; k < g1; k += 3) {
                sx = a[k + 2];
                for (q = 0; q < sl3.length; q += 3) if (sl3[q] === sx) break;
                if (q < sl3.length) { if (a[k] < sl3[q + 1]) sl3[q + 1] = a[k]; if (a[k + 1] > sl3[q + 2]) sl3[q + 2] = a[k + 1]; }
                else {
                    q = sl3.length; sl3.push(sx, a[k], a[k + 1]);
                    while (q >= 3 && sl3[q - 3] > sl3[q]) { z = sl3[q]; sl3[q] = sl3[q - 3]; sl3[q - 3] = z; z = sl3[q + 1]; sl3[q + 1] = sl3[q - 2]; sl3[q - 2] = z; z = sl3[q + 2]; sl3[q + 2] = sl3[q - 1]; sl3[q - 1] = z; q -= 3; }
                }
            }
            /* chia thanh cac doan lien tiep, moi doan mot hinh thang voi sai so <= tol */
            r0 = 0;
            while (r0 < sl3.length) {
                r1 = r0 + 3; spFitRun(sl3, r0, r1, f, keep);
                while (r1 < sl3.length && sl3[r1] - sl3[r1 - 3] <= f * 1.001) {
                    err = spFitRun(sl3, r0, r1 + 3, f, out);
                    if (err > tol) break;
                    r1 += 3; for (q = 0; q < 6; q++) keep[q] = out[q];
                }
                mn = keep[2] < keep[3] ? keep[2] : keep[3]; mx = keep[4] > keep[5] ? keep[4] : keep[5];
                dv.push(mn, mx); z = keep[1] - keep[0];
                tz.push(keep[0], keep[1], keep[2], z > 0 ? (keep[3] - keep[2]) / z : 0, keep[4], z > 0 ? (keep[5] - keep[4]) / z : 0);   /* [xa, xb, la, doc duoi, ua, doc tren] */
                r0 = r1;
            }
            g0 = g1;
        }
        doff.push(dv.length);
        if (dv.length > first) {
            mn = 1e30; mx = -1e30;
            for (k = first; k < dv.length; k += 2) { if (dv[k] < mn) mn = dv[k]; if (dv[k + 1] > mx) mx = dv[k + 1]; }
            e0.push(mn); e1.push(mx); if (mn < lo) lo = mn; if (mx > hi) hi = mx;
        } else { e0.push(1e30); e1.push(-1e30); }
    }
    if (lo > hi) { lo = 0; hi = 0; }
    return { nc: nc, nd: nd, R: R, cs: cs, doff: doff, dv: dv, tz: tz, e0: e0, e1: e1, dy0: lo, dy1: hi };
};





WK.prepSetup = function (job) {
    var cfg = job.cfg, nPc = job.candidates.length, ms, rate;
    /* V1.30: thoi gian toi uu CO DINH theo so chi tiet (khong con o nhap): ms = base + perPiece * n, kep trong [min, max] */
    ms = NP_SP_T_BASE + NP_SP_T_PIECE * nPc;
    if (ms < NP_SP_T_MIN) ms = NP_SP_T_MIN;
    if (ms > NP_SP_T_MAX) ms = NP_SP_T_MAX;
    /* V1.40: ngan sach xep tinh bang SO LAN THU (khong phu thuoc dong ho) = toc do may (lan thu/giay, do 1 lan roi luu) x thoi gian */
    rate = spReadRate();
    job.rateKnown = rate > 0; if (!(rate > 0)) rate = NP_SP_RATE_DEFAULT;
    job.rate = rate;
    job.angles = prepAngles(cfg.rotationMode);
    job.strokeExtra = (cfg.displayMode === 1 ? cfg.strokeWidth : 0);
    job.edgePad = (cfg.displayMode === 1 ? cfg.strokeWidth / 2 + 0.5 : 0.05);   /* V1.42: che do to dac khong can le phu 0.5pt */
    job.leftPad = cfg.marginL + job.edgePad;
    job.topPad = cfg.marginT + job.edgePad;
    job.usableW = cfg.rollW - cfg.marginL - cfg.marginR - 2 * job.edgePad;
    if (job.usableW <= 0) throw new Error("Invalid usable width.");
    job.reqGap = cfg.gap + job.strokeExtra;
    job.r = job.reqGap + 0.6;
    /* moi chi tiet gian no rh moi ben -> hai chi tiet cach nhau >= 2*rh = reqGap + 0.5pt */
    job.rh = job.reqGap / 2 + 0.25;   /* V1.28: profile chinh xac -> chi them sai so flatten Bezier (0.15pt) + an toan */
    job.set = {
        cs: NP_SP_CS, ph: NP_SP_PH, searchMs: ms, evBudget: Math.round(rate * ms / 1000), nFoc: 8, nCont: 14, nCD: 3, pre0: 0.25, preL: 0.03, fin0: 0.01, finL: 0.002, lbfFrac: 0.2, explFrac: 0.7, lbfRuns: NP_SP_LBF_RUNS, step0: 0.01, stepMin: 0.0015, maxFail: 2, cmpr0: 0.002, cmpr1: 0.0003,
        sepExpl: { noImp: 14, strikes: 3, maxIter: 60 }, sepCmpr: { noImp: 8, strikes: 2, maxIter: 30 }
    };
    job.rh = job.reqGap / 2 + 0.05 + NP_FLAT_TOL;   /* gia tri lon nhat (cho chi tiet co Bezier) */
    job.R = Math.floor(job.rh / job.set.cs) + 1;
    job.prepIdx = 0;
    job.pieces = [];
};

WK.prepPrepareStep = function (job, budgetMs) {
    var t0 = prepNow(), cand, outline, oo, b, i, np, totalA = 0;
    while (job.prepIdx < job.candidates.length) {
        cand = job.candidates[job.prepIdx];
        if (!cand.spBusy) {
            oo = prepOutline(cand.item, NP_FLAT_TOL);
            outline = oo.polys;
            b = outline.length ? prepOutlineBounds(outline) : null;
            if (!b || b.w < 1 || b.h < 1) { job.skipped.push(cand.name); job.prepIdx++; continue; }
            np = 0; for (i = 0; i < oo.raws.length; i++) np += oo.raws[i].P.length;
            cand.raws = oo.raws; cand.npts = np;
            cand.outline = outline; cand.area = prepNetArea(outline); cand.w0 = b.w; cand.h0 = b.h; cand.index = job.prepIdx;
            spPrepBegin(job, cand); cand.spBusy = true;
            if (prepNow() - t0 > budgetMs) break;
        }
        while (cand.spAi < job.angles.length) {
            spPrepAngle(job, cand);
            if (prepNow() - t0 > budgetMs && cand.spAi < job.angles.length) { job.pc = job.prepIdx + cand.spAi / job.angles.length; job.pt = job.candidates.length; job.info = ""; return ""; }
        }
        spPrepEnd(job, cand); cand.spBusy = false;
        cand.pi = job.pieces.length; job.pieces.push(cand);
        job.prepIdx++;
        if (prepNow() - t0 > budgetMs) break;
    }
    job.pc = job.prepIdx; job.pt = job.candidates.length;
    job.info = "";
    if (job.prepIdx >= job.candidates.length) {
        if (!job.pieces.length) return "NO_CONTOUR";
        if (job.pieces.length > NP_MAX_PIECES) return "TOO_MANY_PIECES";
        for (i = 0; i < job.pieces.length; i++) totalA += job.pieces[i].area;
        job.netArea = totalA;
        spInitState(job);
        job.tLay0 = prepNow();
        job.phase = "layout";
    }
    return "";
};
/* V1.40: so ngau nhien co HAT GIONG CO DINH (xorshift32) -> cung dau vao cho cung ket qua */
WK.spRnd = function (S) {
    var x = S.rs | 0;
    x ^= (x << 13); x ^= (x >>> 17); x ^= (x << 5);
    S.rs = x | 0;
    return (x >>> 0) / 4294967296;
};
WK.spNormal = function (S, sd) {
    var u = 1 - spRnd(S), v = spRnd(S);
    return sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(6.283185307179586 * v);
};
WK.spShuffle = function (S, a) {
    var i, j, t;
    for (i = a.length - 1; i > 0; i--) { j = Math.floor(spRnd(S) * (i + 1)); t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
};

/* ---------- hinh hoc phu tro: convex hull, duong kinh, tam ---------- */
WK.spHullInfo = function (outline) {
    var pts = [], i, j, lo = [], up = [], hull, k, a, b, dm = 0, d, cr;
    for (i = 0; i < outline.length; i++) for (j = 0; j < outline[i].length; j++) pts.push(outline[i][j]);
    pts.sort(function (p, q) { return (p.x - q.x) || (p.y - q.y); });
    cr = function (o, p, q) { return (p.x - o.x) * (q.y - o.y) - (p.y - o.y) * (q.x - o.x); };
    for (k = 0; k < pts.length; k++) { while (lo.length >= 2 && cr(lo[lo.length - 2], lo[lo.length - 1], pts[k]) <= 0) lo.pop(); lo.push(pts[k]); }
    for (k = pts.length - 1; k >= 0; k--) { while (up.length >= 2 && cr(up[up.length - 2], up[up.length - 1], pts[k]) <= 0) up.pop(); up.push(pts[k]); }
    lo.pop(); up.pop(); hull = lo.concat(up);
    for (i = 0; i < hull.length; i++) for (j = i + 1; j < hull.length; j++) {
        a = hull[i].x - hull[j].x; b = hull[i].y - hull[j].y; d = Math.sqrt(a * a + b * b); if (d > dm) dm = d;
    }
    return { ch: Math.max(1, Math.abs(prepPolyArea(hull))), diam: Math.max(1, dm) };
};
WK.spCentroid = function (outline) {
    var big = 0, bigA = -1, i, a, poly, s = 0, cx = 0, cy = 0, j, p, q, f, n;
    for (i = 0; i < outline.length; i++) { a = Math.abs(prepPolyArea(outline[i])); if (a > bigA) { bigA = a; big = i; } }
    poly = outline[big]; n = poly.length;
    for (i = 0, j = n - 1; i < n; j = i++) {
        p = poly[j]; q = poly[i]; f = p.x * q.y - q.x * p.y; s += f; cx += (p.x + q.x) * f; cy += (p.y + q.y) * f;
    }
    if (Math.abs(s) < 1e-9) { cx = 0; cy = 0; for (i = 0; i < n; i++) { cx += poly[i].x; cy += poly[i].y; } return { x: cx / n, y: cy / n }; }
    return { x: cx / (3 * s), y: cy / (3 * s) };
};
/* V1.31: chuan bi chi tiet chia theo TUNG GOC XOAY (moi goc co the ton thoi gian voi rap cong lon) */
/* V1.40: HUONG CHUAN cua chi tiet trong nhom goc cho phep: xoay chi tiet trong file goc mot goc thuoc nhom (vd 180 do khi cho
   phep 0/180) thi engine van thay CUNG mot bai toan -> cung ket qua. Chon goc c lam nho (cao, rong, tam theo x, tam theo y) cua
   hinh da xoay (lam tron 0.01pt); toa do chuan lam tron 0.001pt de hai cach xoay cho ra hinh hoc giong het. */
WK.spCanon = function (job, cand) {
    var A = job.angles, k, rp, cen = spCentroid(cand.outline), rad, c, s, cx, cy, key, best = null, bestK = null, i, j, poly, polys = [], r = function (v) { return Math.round(v * 100 + 0.371); };
    for (k = 0; k < A.length; k++) {
        rp = prepRotatePolys(cand.outline, A[k]);
        rad = ((A[k] % 360) + 360) % 360 * Math.PI / 180; c = Math.cos(rad); s = Math.sin(rad);
        cx = cen.x * c - cen.y * s - rp.mx; cy = cen.x * s + cen.y * c - rp.my;
        key = [r(rp.h), r(rp.w), r(cx), r(cy)];
        if (!bestK || key[0] < bestK[0] || (key[0] === bestK[0] && (key[1] < bestK[1] || (key[1] === bestK[1] && (key[2] < bestK[2] || (key[2] === bestK[2] && key[3] < bestK[3])))))) { bestK = key; best = { a: A[k], rp: rp }; }
    }
    for (i = 0; i < best.rp.polys.length; i++) {
        poly = [];
        for (j = 0; j < best.rp.polys[i].length; j++) poly.push({ x: Math.round(best.rp.polys[i][j].x * 1000 + 0.371) / 1000, y: Math.round(best.rp.polys[i][j].y * 1000 + 0.371) / 1000 });   /* luoi lam tron lech 0.371: toa do co 3-4 chu so thap phan khong roi dung ranh gioi */
        polys.push(poly);
    }
    cand.canon = best.a; cand.cOutline = polys;
    cand.w0 = Math.round(best.rp.w * 1000 + 0.371) / 1000; cand.h0 = Math.round(best.rp.h * 1000 + 0.371) / 1000;
    cand.area = prepNetArea(polys);   /* dien tich tinh tren hinh chuan (lam tron) -> chi tiet giong nhau co dien tich giong het */
};
WK.spPrepBegin = function (job, cand) {
    var k, q, curved = false;
    spCanon(job, cand);
    cand.spHi = spHullInfo(cand.cOutline); cand.spCen = spCentroid(cand.cOutline);
    if (cand.curved !== undefined) curved = !!cand.curved;
    else for (k = 0; k < cand.raws.length && !curved; k++) for (q = 0; q < cand.raws[k].P.length; q++) if (prepIsCurved(cand.raws[k].P[q])) { curved = true; break; }
    /* bien an toan theo tung chi tiet: chi cong sai so flatten (NP_FLAT_TOL) khi chi tiet co doan cong Bezier */
    cand.spRh = job.reqGap / 2 + 0.05 + (curved ? NP_FLAT_TOL : 0);
    cand.V = []; cand.spAi = 0; cand.spSub = 0; cand.spW = null; cand.spFit = false; cand.minH = 1e30;
};
/* V1.32: mot goc xoay chia thanh cac buoc nho: (0) xoay + profile min, (1..PH) gian no tung pha */
WK.spPrepAngle = function (job, cand) {
    var PH = job.set.ph, cs = job.set.cs, csu = cs / PH, ai = cand.spAi, ang = job.angles[ai], rp, rad, c, s, cen = cand.spCen, ph, g, w;
    var sF = Math.max(1, Math.round(csu / NP_SP_FINE)), fw = csu / sF;
    if (!cand.spSub) {
        rp = prepRotatePolys(cand.cOutline, ang);
        rad = ((ang % 360) + 360) % 360 * Math.PI / 180;
        c = Math.cos(rad); s = Math.sin(rad);
        w = { rp: rp, fits: (rp.w <= job.usableW + 1e-6), rx: cen.x * c - cen.y * s - rp.mx, ry: cen.x * s + cen.y * c - rp.my, fine: null };
        if (w.fits) w.fine = spFineDilate(spRawCols(rp.polys, rp.w, fw), fw, cand.spRh);
        cand.spW = w; cand.spSub = 1;
        return;
    }
    w = cand.spW; rp = w.rp; ph = cand.spSub - 1;
    if (!w.fits) cand.V.push({ ok: false, w: rp.w, h: rp.h, ai: ai, ph: ph, angle: ang, maxU: -1 });
    else {
        g = spDilate(w.fine, fw, ph * sF, rp.w, cs, cand.spRh);
        g.ok = true; g.w = rp.w; g.h = rp.h; g.ai = ai; g.ph = ph; g.angle = ang; g.rx = w.rx; g.ry = w.ry;
        g.maxU = Math.max(0, Math.floor((job.usableW - rp.w) / csu + 1e-9));
        cand.V.push(g);
    }
    cand.spSub++;
    if (cand.spSub > PH) {
        if (w.fits) { cand.spFit = true; if (rp.h < cand.minH) cand.minH = rp.h; }
        cand.spW = null; cand.spSub = 0; cand.spAi++;
    }
};
WK.spPrepEnd = function (job, cand) {
    if (!cand.spFit) throw new Error("PIECE_TOO_WIDE: " + cand.name);
    cand.A = job.angles.length; cand.ch = cand.spHi.ch; cand.dm = cand.spHi.diam; cand.pk = Math.pow(cand.spHi.ch, 0.25);
    cand.minDim = Math.max(1, Math.min(cand.w0, cand.h0));
};
WK.spPreparePiece = function (job, cand) {
    spPrepBegin(job, cand);
    while (cand.spAi < job.angles.length) spPrepAngle(job, cand);
    spPrepEnd(job, cand);
};
WK.spLbfKey = function (pc, k) {
    if (k === 0) return pc.ch * pc.dm;
    if (k === 1) return pc.area;
    if (k === 2) return Math.min(pc.w0, pc.h0);
    if (k === 3) return pc.dm;
    return Math.max(pc.w0, pc.h0);
};
/* V1.41: nhieu DIEM XUAT PHAT LBF hon (diem xuat phat quyet dinh nhieu den ket qua cuoi):
     k = 0..4   : 5 thu tu theo khoa (nhu truoc)
     k = 5..9   : cung 5 khoa nhung chi tiet GIONG NHAU xep lien nhau, chi tiet thu hai xoay nguoc 180 do (hoc tu so do mau:
                  dau tay ap dau tay, nach than ap nach than)
     k >= 10    : xao tron 1-3 cap vi tri trong thu tu tot nhat (hat giong co dinh -> tat dinh)
   Moi luot bi bo ngay khi dinh bo cuc vuot bo cuc tot nhat, nen cac luot them kha re. */
WK.spSimilar = function (a, b) {
    var t = 0.04;
    return Math.abs(a.area - b.area) <= t * Math.max(a.area, b.area) &&
        ((Math.abs(a.w0 - b.w0) <= t * Math.max(a.w0, b.w0) && Math.abs(a.h0 - b.h0) <= t * Math.max(a.h0, b.h0)) ||
         (Math.abs(a.w0 - b.h0) <= t * Math.max(a.w0, b.h0) && Math.abs(a.h0 - b.w0) <= t * Math.max(a.h0, b.w0)));
};
WK.spPairOrder = function (job, order) {
    var P = job.pieces, used = [], out = [], partner = [], i, j, a, best, bd, d;
    for (i = 0; i < P.length; i++) { used.push(false); partner.push(-1); }
    for (i = 0; i < order.length; i++) {
        a = order[i]; if (used[a]) continue;
        used[a] = true; out.push(a); best = -1; bd = 1e30;
        for (j = i + 1; j < order.length; j++) {
            if (used[order[j]] || !spSimilar(P[a], P[order[j]])) continue;
            d = Math.abs(P[a].area - P[order[j]].area);
            if (d < bd) { bd = d; best = order[j]; }
        }
        if (best >= 0) { used[best] = true; out.push(best); partner[best] = a; }
    }
    return { order: out, partner: partner };
};
/* goc bat buoc cho chi tiet thu hai cua cap: nguoc 180 do voi chi tiet dau (neu goc do duoc phep va vua kho), -1 = tu do */
WK.spPairAngle = function (lb, pc) {
    var a, first, ang, k, V = pc.V, PH;
    if (!lb.partner) return -1;
    a = lb.partner[pc.pi]; if (a < 0 || !lb.res[a]) return -1;
    first = lb.res[a]; PH = V.length / pc.A;
    ang = (V[first.ai * PH].angle + 180) % 360;
    for (k = 0; k < pc.A; k++) if (V[k * PH].ok && Math.abs(((V[k * PH].angle % 360) + 360) % 360 - ang) < 0.01) return k;
    return -1;
};
WK.spLbfBegin = function (job, k) {
    var S = job.sp, n = job.pieces.length, order = [], i, lb, ncol, kk = k % 5, po = null, m, a, b, t;
    if (k >= 10 && S.lbBest && S.lbBest.order) {
        order = S.lbBest.order.slice(0); po = S.lbBest.partner ? { partner: S.lbBest.partner } : null;
        m = 1 + Math.floor(spRnd(S) * 3);
        for (i = 0; i < m && n > 1; i++) {
            a = Math.floor(spRnd(S) * n); b = Math.floor(spRnd(S) * n); if (a === b) b = (a + 1) % n;
            t = order[a]; order[a] = order[b]; order[b] = t;
        }
        po = null;   /* thu tu da xao tron: khong ep goc theo cap */
    } else {
        for (i = 0; i < n; i++) order.push(i);
        order.sort(function (x, y) { return (spLbfKey(job.pieces[y], kk) - spLbfKey(job.pieces[x], kk)) || (x - y); });
        if (k >= 5) { po = spPairOrder(job, order); order = po.order; }
    }
    lb = { order: order, pos: 0, off: job.R + 1, oZ: [], top: 0, fl: [], fh: [], ord: [0, 4, 2, 6, 1, 5, 3, 7], res: [], k: k, partner: po ? po.partner : null };
    ncol = Math.floor(job.usableW / job.set.cs) + 2 + 2 * lb.off + 2 * job.R + 4;
    for (i = 0; i < ncol; i++) lb.oZ.push([]);
    for (i = 0; i < n; i++) lb.res.push(null);
    S.lb = lb;
};


/* y thap nhat (>=0) de dat profile G o cot i0 ma khong chong len doan nao da chiem; tra ve cut neu khong co y < cut */
WK.spLowestY = function (lb, G, i0, cut) {
    var doff = G.doff, tz = G.tz, R = G.R, nd = G.nd, oZ = lb.oZ, off = lb.off, fl = lb.fl, fh = lb.fh, ORD = lb.ord;
    var cnt = 0, lastMove = 0, j, c, oz, t, t1, m, u, fa, fb, y = 0, moved, q, ph, p, xa, xb, sL, sU, la, ua, qa, qb, xs, xe, w, v1, v2, lo, uo;
    for (ph = 0; ph < 8; ph++) {
        for (j = ORD[ph]; j < nd; j += 8) {
            t = doff[j]; t1 = doff[j + 1]; if (t === t1) continue;
            c = i0 - R + j + off;
            oz = oZ[c]; m = oz.length; if (!m) continue;
            for (; t < t1; t += 2) {
                p = t * 3; xa = tz[p]; xb = tz[p + 1]; la = tz[p + 2]; sL = tz[p + 3]; ua = tz[p + 4]; sU = tz[p + 5];
                for (u = 0; u < m; u += 6) {
                    qa = oz[u]; qb = oz[u + 1];
                    xs = xa > qa ? xa : qa; xe = xb < qb ? xb : qb; w = xe - xs;
                    if (w <= 0) continue;
                    /* tai xs: canh tren vat can - canh duoi chi tiet ; tai xe: cong them do doc x w */
                    uo = oz[u + 4] + oz[u + 5] * (xs - qa); v1 = uo - (la + sL * (xs - xa)); v2 = v1 + (oz[u + 5] - sL) * w;
                    fb = v1 > v2 ? v1 : v2; if (fb <= y) continue;
                    lo = oz[u + 2] + oz[u + 3] * (xs - qa); v1 = lo - (ua + sU * (xs - xa)); v2 = v1 + (oz[u + 3] - sU) * w;
                    fa = v1 < v2 ? v1 : v2; if (fa >= cut || fa >= fb) continue;
                    fl[cnt] = fa; fh[cnt] = fb; cnt++;
                    if (fa < y && y < fb) { y = fb; lastMove = cnt; if (y >= cut) return cut; }
                }
            }
        }
    }
    if (lastMove > 1) {
        moved = false;
        for (q = 0; q < lastMove - 1; q++) {
            if (fl[q] < y && y < fh[q]) { y = fh[q]; moved = true; if (y >= cut) return cut; }
        }
        while (moved) {
            moved = false;
            for (q = 0; q < cnt; q++) {
                if (fl[q] < y && y < fh[q]) { y = fh[q]; moved = true; if (y >= cut) return cut; }
            }
        }
    }
    return y;
};



WK.spLbfScore = function (S, lb, G, u, y) {
    var yTop = y + G.h, peak = yTop > lb.top ? (yTop - lb.top) : 0, x1 = u * S.csu, xr = S.usableW - (x1 + G.w), edgeTie;
    if (xr < 0) xr = 0;
    edgeTie = 0.003 * (x1 < xr ? x1 : xr) + 0.0004 * x1;
    return yTop + 0.12 * peak + edgeTie;
};

WK.spLbfPlaceStep = function (job, lb, pc, t0, budgetMs) {
    var S = job.sp, PH = S.PH, V = pc.V, st = lb.ps, stride = Math.max(1, Math.round(24 / S.csu)), G, Gu, maxU, u, y, cutY, sc, ph, i1, cnt = 0, b;
    if (!st) st = lb.ps = { ai: 0, k: 0, mode: 0, i1: 0, hi: -1, best: null, only: spPairAngle(lb, pc) };
    while (st.ai < pc.A) {
        G = V[st.ai * PH];
        if (!G.ok || (st.only >= 0 && st.ai !== st.only)) { st.ai++; st.k = 0; st.mode = 0; continue; }
        maxU = G.maxU; b = st.best;
        if (st.mode === 0) {
            u = st.k * stride; if (u > maxU) u = maxU;
            cutY = b ? (b.sc - G.h) : 1e9;
            if (cutY > 0) {
                ph = u % PH; Gu = V[st.ai * PH + ph];
                y = spLowestY(lb, Gu, (u - ph) / PH, cutY);
                if (y < cutY) {
                    sc = spLbfScore(S, lb, G, u, y);
                    if (!b || sc < b.sc - 1e-9) st.best = { ai: st.ai, u: u, y: y, sc: sc };
                }
            }
            if (u >= maxU) {
                b = st.best;
                if (b && b.ai === st.ai) { st.mode = 1; st.i1 = b.u - stride + 1; if (st.i1 < 0) st.i1 = 0; st.hi = b.u + stride - 1; if (st.hi > maxU) st.hi = maxU; }
                else { st.ai++; st.k = 0; st.mode = 0; }
            } else st.k++;
        } else {
            if (st.i1 > st.hi) { st.ai++; st.k = 0; st.mode = 0; continue; }
            i1 = st.i1++;
            if (i1 !== b.u) {
                cutY = b.sc - G.h;
                if (cutY <= 0) { st.i1 = st.hi + 1; continue; }
                ph = i1 % PH; Gu = V[st.ai * PH + ph];
                y = spLowestY(lb, Gu, (i1 - ph) / PH, cutY);
                if (y < cutY) {
                    sc = spLbfScore(S, lb, G, i1, y);
                    if (sc < b.sc - 1e-9) st.best = { ai: st.ai, u: i1, y: y, sc: sc };
                }
            }
        }
        if ((++cnt & 3) === 0 && prepNow() - t0 > budgetMs) return null;
    }
    lb.ps = null;
    return st.best ? st.best : false;
};

WK.spLbfCommit = function (job, lb, pc, pl) {
    var S = job.sp, PH = S.PH, G = pc.V[pl.ai * PH + (pl.u % PH)], i0 = (pl.u - (pl.u % PH)) / PH, j, t, c, t1, k;
    for (j = 0; j < G.nd; j++) {
        t = G.doff[j]; t1 = G.doff[j + 1]; c = i0 - G.R + j + lb.off;
        for (; t < t1; t += 2) { k = t * 3; lb.oZ[c].push(G.tz[k], G.tz[k + 1], pl.y + G.tz[k + 2], G.tz[k + 3], pl.y + G.tz[k + 4], G.tz[k + 5]); }
    }
    if (pl.y + G.h > lb.top) lb.top = pl.y + G.h;
};

/* true khi xong toan bo cac thu tu LBF */
WK.spLbfAdvance = function (job, budgetMs) {
    var S = job.sp, lb, t0 = prepNow(), pc, pl, i, p, best;
    for (;;) {
        lb = S.lb;
        while (lb.pos < lb.order.length) {
            pc = job.pieces[lb.order[lb.pos]];
            pl = spLbfPlaceStep(job, lb, pc, t0, budgetMs);
            if (pl === null) { job.pc = lb.pos; job.pt = lb.order.length; return false; }
            if (!pl) throw new Error("SPARROW_LBF: khong dat duoc " + pc.name);
            spLbfCommit(job, lb, pc, pl);
            lb.res[lb.order[lb.pos]] = pl;
            lb.pos++;
            if (S.lbBest && lb.top >= S.lbBest.top - 1e-6) break;   /* V1.29: khong the thang bo cuc tot nhat -> bo som */
            if (prepNow() - t0 > budgetMs && lb.pos < lb.order.length) { job.pc = lb.pos; job.pt = lb.order.length; return false; }
        }
        if (lb.pos >= lb.order.length && (!S.lbBest || lb.top < S.lbBest.top - 1e-6)) S.lbBest = { top: lb.top, res: lb.res, k: lb.k, order: lb.order, partner: lb.partner };
        S.lbTried = lb.k + 1;
        if (lb.k + 1 < job.set.lbfRuns) {
            spLbfBegin(job, lb.k + 1);
            if (prepNow() - t0 > budgetMs) { job.pc = 0; job.pt = S.n; return false; }
            continue;
        }
        break;
    }
    best = S.lbBest; S.L = best.top;
    for (i = 0; i < S.n; i++) { p = best.res[i]; spSetG(S, S.P[i], p.ai * S.PH + (p.u % S.PH), p.u, p.y); }
    S.lbfL = best.top; S.lb = null;
    return true;
};

/* ---------- trang thai tim kiem (placement + tracker GLS) ---------- */
WK.spSetG = function (S, p, vi, u, y) {
    var G = p.pc.V[vi], i0 = (u - (u % S.PH)) / S.PH;
    p.vi = vi; p.u = u; p.y = y; p.G = G; p.g0 = i0 - G.R; p.g1 = p.g0 + G.nd;
    p.yl = y + G.dy0; p.yh = y + G.dy1; p.x0 = u * S.csu; p.x1 = p.x0 + G.w; p.y1 = y + G.h;
};

WK.spInitState = function (job) {
    var n = job.pieces.length, S, i, PH = job.set.ph, cm = NP_PT_PER_CM;
    S = {
        n: n, P: [], pl: [], pw: [], PH: PH, cs: job.set.cs, csu: job.set.cs / PH, usableW: job.usableW, rs: NP_SP_SEED | 0,
        cfg: { nFoc: job.set.nFoc, nCont: job.set.nCont, nCD: job.set.nCD, pre0: job.set.pre0, preL: job.set.preL, fin0: job.set.fin0, finL: job.set.finL }, L: 0, stage: "lbf", evals: 0, moves: 0, passes: 0, lbfL: 0, tmp: { G: null, g0: 0, g1: 0, y: 0, yl: 0, yh: 0 },
        best: null, lb: null, lbL: 0, tStart: 0, total: job.set.searchMs, sep: null, ex: null, cm: null, netArea: 0
    };
    for (i = 0; i < n; i++) {
        S.P.push({ pc: job.pieces[i], id: i, vi: 0, u: 0, y: 0, G: job.pieces[i].V[0], g0: 0, g1: 0, yl: 0, yh: 0, x0: 0, x1: 0, y1: 0 });
        S.netArea += job.pieces[i].area;
    }
    for (i = 0; i < n * n; i++) { S.pl.push(0); S.pw.push(1); }
    S.hit = []; for (i = 0; i < n; i++) S.hit.push(-1);
    job.sp = S;
    job.sr = { iter: 0, greedyTop: 0, bestTop: 0, bestUtil: 0, skip: false };
    S.tLbf0 = prepNow(); S.lbBest = null;
    spLbfBegin(job, 0);
    job.info = "st=lbf;it=0;best=0;util=0;g=0";
};

/* ---------- va cham giua hai placement: tong chieu dai chong lan cua hai profile (doi xung) ---------- */
/* dien tich chong lan (xap xi) cua hai hinh thang trong cung cot; 0 neu tach roi. ta/tb = vi tri (x6) trong mang tz; d = lech y cua A so voi B. */
/* dien tich chong lan (xap xi) cua hai hinh thang trong cung cot, 0 neu tach roi. tz = [xa, xb, la, sL, ua, sU]; d = lech y cua A so voi B. */
WK.spTzOv = function (zA, ta, d, zB, tb) {
    var aa = zA[ta], ab = zA[ta + 1], ba = zB[tb], bb = zB[tb + 1], xs = aa > ba ? aa : ba, xe = ab < bb ? ab : bb, w = xe - xs;
    var sLA, sUA, sLB, sUB, la, ua, lb, ub, o1, o2, x, o, cnt, sum;
    if (w <= 0) return 0;
    sLA = zA[ta + 3]; sUA = zA[ta + 5]; sLB = zB[tb + 3]; sUB = zB[tb + 5];
    la = zA[ta + 2] + sLA * (xs - aa) + d; ua = zA[ta + 4] + sUA * (xs - aa) + d; lb = zB[tb + 2] + sLB * (xs - ba); ub = zB[tb + 4] + sUB * (xs - ba);
    o1 = (ua < ub ? ua : ub) - (la > lb ? la : lb);
    la += sLA * w; ua += sUA * w; lb += sLB * w; ub += sUB * w;
    o2 = (ua < ub ? ua : ub) - (la > lb ? la : lb);
    if (o1 > 0 && o2 > 0) return w * (o1 + o2) * 0.5;                       /* chong lan tren ca doan */
    if (o1 > 0) return 0.5 * w * o1 * o1 / (o1 - o2);                         /* chi phan dau */
    if (o2 > 0) return 0.5 * w * o2 * o2 / (o2 - o1);                         /* chi phan cuoi */
    /* hai dau tach roi: chi co the chong lan o giua neu hai canh tren hoac hai canh duoi cat nhau */
    sum = 0; cnt = 0;
    if (sUA !== sUB) {
        x = ((zB[tb + 4] - sUB * ba) - (zA[ta + 4] - sUA * aa + d)) / (sUA - sUB);
        if (x > xs && x < xe) { ua = zA[ta + 4] + sUA * (x - aa) + d; la = zA[ta + 2] + sLA * (x - aa) + d; lb = zB[tb + 2] + sLB * (x - ba); o = ua - (la > lb ? la : lb); if (o > 0) { sum += o; cnt++; } }
    }
    if (sLA !== sLB) {
        x = ((zB[tb + 2] - sLB * ba) - (zA[ta + 2] - sLA * aa + d)) / (sLA - sLB);
        if (x > xs && x < xe) { la = zA[ta + 2] + sLA * (x - aa) + d; ua = zA[ta + 4] + sUA * (x - aa) + d; ub = zB[tb + 4] + sUB * (x - ba); o = (ua < ub ? ua : ub) - la; if (o > 0) { sum += o; cnt++; } }
    }
    return cnt ? 0.25 * w * sum / cnt : 0;
};

WK.spOv = function (A, B, cap) {
    var GA = A.G, GB = B.G, g0 = A.g0 > B.g0 ? A.g0 : B.g0, g1 = A.g1 < B.g1 ? A.g1 : B.g1;
    var offA = GA.doff, vA = GA.dv, zA = GA.tz, offB = GB.doff, vB = GB.dv, zB = GB.tz, a0 = GA.e0, a1 = GA.e1, b0 = GB.e0, b1 = GB.e1, ics = 1 / GA.cs;
    var d = A.y - B.y, tot = 0, c, ja, jb, ta, ta1, tb, tb0, tb1, alo, ahi, ag = A.g0, bg = B.g0;
    for (c = g0; c < g1; c++) {
        ja = c - ag; jb = c - bg;
        alo = a0[ja] + d; if (alo >= b1[jb]) continue;
        ahi = a1[ja] + d; if (ahi <= b0[jb]) continue;
        ta = offA[ja]; ta1 = offA[ja + 1]; tb0 = offB[jb]; tb1 = offB[jb + 1];
        for (; ta < ta1; ta += 2) {
            alo = vA[ta] + d; ahi = vA[ta + 1] + d;
            for (tb = tb0; tb < tb1; tb += 2) {
                if (alo >= vB[tb + 1] || ahi <= vB[tb]) continue;
                tot += spTzOv(zA, ta * 3, d, zB, tb * 3) * ics;
            }
        }
        if (tot > cap) return tot;
    }
    return tot;
};



WK.spPairLoss = function (S, i, j) {
    var a = S.P[i], b = S.P[j], ov, e;
    if (a.g0 >= b.g1 || b.g0 >= a.g1 || a.yl >= b.yh || b.yl >= a.yh) return 0;
    ov = spOv(a, b, 1e30);
    if (ov <= 0) return 0;
    e = (a.pc.dm > b.pc.dm ? a.pc.dm : b.pc.dm) * 0.01;
    return Math.sqrt(ov * S.cs + e * e) * a.pc.pk * b.pc.pk;
};

WK.spRecompute = function (S, i) {
    var n = S.n, j, l, pl = S.pl;
    for (j = 0; j < n; j++) { if (j === i) continue; l = spPairLoss(S, i, j); pl[i * n + j] = l; pl[j * n + i] = l; }
};
WK.spRecomputeAll = function (S) {
    var n = S.n, i, j, l, pl = S.pl;
    for (i = 0; i < n; i++) { pl[i * n + i] = 0; for (j = i + 1; j < n; j++) { l = spPairLoss(S, i, j); pl[i * n + j] = l; pl[j * n + i] = l; } }
};
WK.spResetW = function (S) { var k, m = S.n * S.n; for (k = 0; k < m; k++) S.pw[k] = 1; };
WK.spTotal = function (S) {
    var n = S.n, i, j, t = 0, pl = S.pl;
    for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) t += pl[i * n + j];
    return t;
};
WK.spRowLoss = function (S, i) {
    var n = S.n, j, t = 0, pl = S.pl, b = i * n;
    for (j = 0; j < n; j++) t += pl[b + j];
    return t;
};
/* Alg. 8: cap nhat trong so GLS */
WK.spUpdateWeights = function (S) {
    var n = S.n, i, j, k, l, mx = 0, pl = S.pl, pw = S.pw, m, w;
    for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) { l = pl[i * n + j]; if (l > mx) mx = l; }
    for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) {
        k = i * n + j; l = pl[k]; w = pw[k];
        if (l === 0) { if (w === 1) continue; m = 0.95; }
        else m = 1.2 + 0.8 * (l / mx);
        w = w * m; if (w < 1) w = 1;
        pw[k] = w; pw[j * n + i] = w;
    }
};

WK.spSave = function (S) {
    var sol = { L: S.L, vi: [], u: [], y: [] }, i, p;
    for (i = 0; i < S.n; i++) { p = S.P[i]; sol.vi.push(p.vi); sol.u.push(p.u); sol.y.push(p.y); }
    return sol;
};
/* pl != null: giu nguyen trong so, chi chep loss (rollback kem snapshot); pl == null: tinh lai va reset trong so */
WK.spRestore = function (S, sol, pl) {
    var i, k, m = S.n * S.n;
    S.L = sol.L;
    for (i = 0; i < S.n; i++) spSetG(S, S.P[i], sol.vi[i], sol.u[i], sol.y[i]);
    if (pl) { for (k = 0; k < m; k++) S.pl[k] = pl[k]; }
    else { spRecomputeAll(S); spResetW(S); }
};

/* ---------- danh gia mot vi tri ung vien cho chi tiet i (Alg. 7): tra ve loss co trong so, hoac -1 neu vuot bound ---------- */
WK.spEval = function (S, i, vi, u, y, bound) {
    var P = S.P, n = S.n, t = S.tmp, pw = S.pw, pc = P[i].pc, Q, j, k, j0, nb, nn, ov, loss = 0, cap, e, pen, ya, yb, base = i * n, qc, cs = S.cs, unb = bound > 1e29, G, i0, tg0, tg1, pk = pc.pk, dm = pc.dm;
    S.evals++;
    G = pc.V[vi]; i0 = (u - (u % S.PH)) / S.PH;
    t.G = G; t.y = y; t.g0 = i0 - G.R; t.g1 = t.g0 + G.nd; tg0 = t.g0; tg1 = t.g1;
    ya = y + G.dy0; yb = y + G.dy1;
    /* V1.29: chi tiet gay vuot nguong o lan truoc duoc kiem tra TRUOC -> thoat som nhanh hon (ket qua khong doi) */
    j0 = S.hit[i];
    /* V1.39: trong luc tinh chinh, chi duyet DANH SACH LAN CAN lap san (neu vi tri thu nam trong vung cua danh sach) */
    nb = null;
    if (S.nbI === i && tg0 >= S.nbC0 && tg1 <= S.nbC1 && ya >= S.nbY0 && yb <= S.nbY1) { nb = S.nbList; nn = nb.length; }
    else nn = n;
    for (k = -1; k < nn; k++) {
        if (k < 0) { j = j0; if (j < 0) continue; }
        else { j = nb ? nb[k] : k; if (j === j0) continue; }
        if (j === i) continue;
        Q = P[j];
        if (Q.g0 >= tg1 || tg0 >= Q.g1 || Q.yl >= yb || ya >= Q.yh) continue;
        qc = Q.pc;
        pen = pk * qc.pk * pw[base + j];
        e = (dm > qc.dm ? dm : qc.dm) * 0.01;
        if (unb) cap = 1e30;
        else { cap = (bound - loss) / pen; cap = (cap * cap - e * e) / cs; if (cap < 0) cap = 0; }
        ov = spOv(t, Q, cap);
        if (ov <= 0) continue;
        loss += Math.sqrt(ov * cs + e * e) * pen;
        if (loss > bound) { S.hit[i] = j; return -1; }
    }
    return loss;
};

/* ---------- BestSamples ---------- */
WK.spBsReport = function (S, bs, ai, vi, u, y, loss, th) {
    var size = S.cfg.nCD, k, s, sim = false, allBetter = true, nb;
    if (bs.length >= size && !(loss < bs[size - 1].loss)) return;
    for (k = 0; k < bs.length; k++) {
        s = bs[k];
        if (s.ai === ai && Math.abs(s.u - u) * S.csu < th && Math.abs(s.y - y) < th) { sim = true; if (!(loss < s.loss)) allBetter = false; }
    }
    if (sim) {
        if (!allBetter) return;
        nb = [];
        for (k = 0; k < bs.length; k++) { s = bs[k]; if (!(s.ai === ai && Math.abs(s.u - u) * S.csu < th && Math.abs(s.y - y) < th)) nb.push(s); }
        bs.length = 0; for (k = 0; k < nb.length; k++) bs.push(nb[k]);
    } else if (bs.length === size) bs.pop();
    bs.push({ ai: ai, vi: vi, u: u, y: y, loss: loss });
    bs.sort(function (a, b) { return a.loss - b.loss; });
};

/* thu mot ung vien (da kep vao khoang hop le) va bao cao vao bs */
WK.spTry = function (S, i, bs, ai, u, y, th) {
    var pc = S.P[i].pc, PH = S.PH, G0 = pc.V[ai * PH], ymax, vi, ub, loss;
    if (!G0.ok) return;
    ymax = S.L - G0.h; if (ymax < 0) return;
    u = Math.round(u); if (u < 0) u = 0; else if (u > G0.maxU) u = G0.maxU;
    if (y < 0) y = 0; else if (y > ymax) y = ymax;
    vi = ai * PH + (u % PH);
    ub = bs.length >= S.cfg.nCD ? bs[bs.length - 1].loss : 1e30;
    loss = spEval(S, i, vi, u, y, ub);
    if (loss < 0) return;
    spBsReport(S, bs, ai, vi, u, y, loss, th);
};

/* coordinate descent (Alg. 6) tu mot mau; truc: ngang(u) / doc(y) / hai duong cheo; buoc x tinh theo don vi u */
WK.spRefine = function (S, i, st, t0, tl) {
    var pc = S.P[i].pc, PH = S.PH, csu = S.csu, ai = st.ai, G0 = pc.V[ai * PH], maxU = G0.maxU, ymax = S.L - G0.h;
    var u = st.u, y = st.y, loss = st.loss, sx = t0, sy = t0, txl = tl > csu ? tl : csu, axis = Math.floor(spRnd(S) * 4), guard = 0;
    var du, dy, u1, y1, u2, y2, l1, l2, bl, bu, by, tol, better, worse, m, s2;
    if (loss <= 0) return st;
    spNbBuild(S, i, ai, u, y, 3 * t0 + csu);
    while (!(sx < txl && sy < tl) && guard++ < 500) {
        if ((guard & 7) === 0 && S.evals - S.mvEv0 > NP_SP_MOVE_CAP) break;
        du = Math.round(sx / csu); if (du < 1) du = 1; dy = sy;
        if (axis === 0) { u1 = u + du; y1 = y; u2 = u - du; y2 = y; }
        else if (axis === 1) { u1 = u; y1 = y + dy; u2 = u; y2 = y - dy; }
        else if (axis === 2) { u1 = u + du; y1 = y + dy; u2 = u - du; y2 = y - dy; }
        else { u1 = u - du; y1 = y + dy; u2 = u + du; y2 = y - dy; }
        if (u1 < 0) u1 = 0; else if (u1 > maxU) u1 = maxU;
        if (u2 < 0) u2 = 0; else if (u2 > maxU) u2 = maxU;
        if (y1 < 0) y1 = 0; else if (y1 > ymax) y1 = ymax;
        if (y2 < 0) y2 = 0; else if (y2 > ymax) y2 = ymax;
        l1 = (u1 === u && y1 === y) ? -1 : spEval(S, i, ai * PH + (u1 % PH), u1, y1, loss);
        l2 = (u2 === u && y2 === y) ? -1 : spEval(S, i, ai * PH + (u2 % PH), u2, y2, (l1 >= 0 && l1 < loss) ? l1 : loss);
        bl = -1; bu = u; by = y;
        if (l1 >= 0) { bl = l1; bu = u1; by = y1; }
        if (l2 >= 0 && (bl < 0 || l2 < bl)) { bl = l2; bu = u2; by = y2; }
        tol = 1e-9 * (1 + loss);
        better = (bl >= 0 && bl < loss - tol);
        worse = (bl < 0 || bl > loss + tol);
        if (!worse) { u = bu; y = by; loss = bl; }
        m = better ? 1.1 : 0.5;
        if (axis === 0) sx *= m; else if (axis === 1) sy *= m; else { s2 = Math.sqrt(m); sx *= s2; sy *= s2; }
        if (!better) axis = Math.floor(spRnd(S) * 4);
        if (loss <= 0) break;
    }
    S.nbI = -1;
    return { ai: ai, vi: ai * PH + (u % PH), u: u, y: y, loss: loss };
};
/* danh sach chi tiet co the cham vung [vi tri hien tai +- M] (theo cot va theo y), dung cho spEval trong luc tinh chinh */
WK.spNbBuild = function (S, i, ai, u, y, M) {
    var pc = S.P[i].pc, G = pc.V[ai * S.PH], i0 = Math.floor(u / S.PH), mc = Math.ceil(M / S.cs) + 1, j, Q, list = [], c0, c1, y0, y1;
    c0 = i0 - G.R - mc; c1 = i0 - G.R + G.nd + 1 + mc; y0 = y + G.dy0 - M; y1 = y + G.dy1 + M;
    for (j = 0; j < S.n; j++) {
        if (j === i) continue;
        Q = S.P[j];
        if (Q.g0 >= c1 || c0 >= Q.g1 || Q.yl >= y1 || y0 >= Q.yh) continue;
        list.push(j);
    }
    S.nbList = list; S.nbC0 = c0; S.nbC1 = c1; S.nbY0 = y0; S.nbY1 = y1; S.nbI = i;
};

/* Alg. 6: tim vi tri moi cho chi tiet i. Tra ve {vi,u,y,loss} (luon co, vi vi tri hien tai duoc dua vao ung vien) */
WK.spSearch = function (S, i) {
    var p = S.P[i], pc = p.pc, PH = S.PH, csu = S.csu, cfg = S.cfg, bs = [], th = pc.minDim * 0.05, k, ai, Gn, cx, cy, ow, oh, u, y, cur, bestL, s, m = pc.minDim, fit = [], a2;
    var cLoss;
    S.mvEv0 = S.evals;   /* V1.40: mot lan doi bi cat khi vuot NP_SP_MOVE_CAP lan thu (tat dinh, khong theo dong ho) */
    cLoss = spEval(S, i, p.vi, p.u, p.y, 1e30);
    spBsReport(S, bs, p.G.ai, p.vi, p.u, p.y, cLoss, th);
    for (a2 = 0; a2 < pc.A; a2++) { Gn = pc.V[a2 * PH]; if (Gn.ok && S.L - Gn.h >= 0) fit.push(a2); }
    cx = p.x0 + p.G.w / 2; cy = p.y + p.G.h / 2; ow = p.G.w; oh = p.G.h;
    for (k = 0; k < cfg.nFoc && !(bs.length && bs[0].loss <= 0); k++) {
        if ((k & 3) === 3 && S.evals - S.mvEv0 > NP_SP_MOVE_CAP) return bs[0];
        ai = fit[Math.floor(spRnd(S) * fit.length)]; Gn = pc.V[ai * PH];
        u = ((cx + (spRnd(S) - 0.5) * ow) - Gn.w / 2) / csu;
        y = (cy + (spRnd(S) - 0.5) * oh) - Gn.h / 2;
        spTry(S, i, bs, ai, u, y, th);
    }
    for (k = 0; k < cfg.nCont && !(bs.length && bs[0].loss <= 0); k++) {
        if ((k & 3) === 3 && S.evals - S.mvEv0 > NP_SP_MOVE_CAP) return bs[0];
        ai = fit[Math.floor(spRnd(S) * fit.length)]; Gn = pc.V[ai * PH];
        u = spRnd(S) * Gn.maxU; y = spRnd(S) * (S.L - Gn.h);
        spTry(S, i, bs, ai, u, y, th);
    }
    if (bs[0].loss > 0) {
        for (k = 0; k < bs.length; k++) {
            if (S.evals - S.mvEv0 > NP_SP_MOVE_CAP) return bs[0];
            s = spRefine(S, i, bs[k], Math.max(m * cfg.pre0, csu * 4), Math.max(m * cfg.preL, 0.6));
            spBsReport(S, bs, s.ai, s.vi, s.u, s.y, s.loss, th);
        }
        if (S.evals - S.mvEv0 > NP_SP_MOVE_CAP) return bs[0];
        s = spRefine(S, i, bs[0], Math.max(m * cfg.fin0, csu), Math.max(m * cfg.finL, 0.15));
        spBsReport(S, bs, s.ai, s.vi, s.u, s.y, s.loss, th);
    }
    return bs[0];
};

WK.spMoveOne = function (S, i) {
    var r = spSearch(S, i), p = S.P[i];
    if (r.vi !== p.vi || r.u !== p.u || r.y !== p.y) { spSetG(S, p, r.vi, r.u, r.y); spRecompute(S, i); }
    S.moves++;
};

/* ---------- Alg. 9: separate (GLS + strike), co the tam dung ---------- */
WK.spKill = function (job) {
    var S = job.sp;
    return !!(job.sr && job.sr.skip) || S.evals >= S.evStop || prepNow() > S.hardCap;
};

WK.spSepBegin = function (S, cfg) {
    var loss = spTotal(S);
    S.sep = { cfg: cfg, minSol: spSave(S), minPl: S.pl.slice(0), minLoss: loss, strikes: 0, noImp: 0, iter: 0, initStrike: loss, stage: 0, inPass: false, cand: null, k: 0, success: false, sol: null };
};
WK.spSepEnd = function (S, success) {
    var sp = S.sep;
    sp.success = success; sp.sol = sp.minSol;
    if (!success) spRestore(S, sp.minSol, sp.minPl);
    return true;
};
/* true khi ket thuc (thanh cong/that bai); false = het ngan sach, goi lai */
WK.spSepStep = function (job, t0, budgetMs) {
    var S = job.sp, sp = S.sep, cfg = sp.cfg, loss, i, c, n = S.n;
    for (;;) {
        if (spKill(job)) return spSepEnd(S, false);
        if (!sp.inPass) {
            if (sp.stage === 0) {
                if (sp.strikes >= cfg.strikes) return spSepEnd(S, false);
                sp.noImp = 0; sp.initStrike = spTotal(S); sp.stage = 1;
            }
            sp.cand = [];
            for (i = 0; i < n; i++) if (spRowLoss(S, i) > 0) sp.cand.push(i);
            spShuffle(S, sp.cand); sp.k = 0; sp.inPass = true;
        }
        while (sp.k < sp.cand.length) {
            c = sp.cand[sp.k];
            if (spRowLoss(S, c) > 0) spMoveOne(S, c);
            sp.k++;
            if (prepNow() - t0 >= budgetMs && sp.k < sp.cand.length) return false;
            if (spKill(job)) return spSepEnd(S, false);
        }
        sp.inPass = false; S.passes++; job.sr.iter = S.passes;
        loss = spTotal(S);
        if (loss === 0) { sp.minSol = spSave(S); sp.minLoss = 0; return spSepEnd(S, true); }
        if (loss < sp.minLoss) {
            if (loss < sp.minLoss * 0.98) sp.noImp = 0;
            sp.minSol = spSave(S); sp.minPl = S.pl.slice(0); sp.minLoss = loss;
        } else sp.noImp++;
        spUpdateWeights(S); sp.iter++;
        if (sp.noImp >= cfg.noImp || sp.iter >= cfg.maxIter) {
            if (sp.initStrike * 0.98 <= sp.minLoss) sp.strikes++; else sp.strikes = 0;
            spRestore(S, sp.minSol, sp.minPl);
            sp.stage = 0;
            if (sp.iter >= cfg.maxIter) return spSepEnd(S, false);
        }
        if (prepNow() - t0 >= budgetMs) return false;
    }
};

/* ---------- doi chieu dai kho (Alg. 11/12/13): chi tiet nam sau vi tri cat bi doi xuong ---------- */
WK.spFixTall = function (S, i) {
    var p = S.P[i], pc = p.pc, PH = S.PH, a, G, bestA = -1, bh = 1e30, u, ymax;
    if (p.G.h <= S.L + 1e-9) return;
    for (a = 0; a < pc.A; a++) { G = pc.V[a * PH]; if (G.ok && G.h < bh) { bh = G.h; bestA = a; } }
    G = pc.V[bestA * PH]; u = Math.min(p.u, G.maxU);
    spSetG(S, p, bestA * PH + (u % PH), u, 0);
};
WK.spChangeLength = function (S, newL, split) {
    var i, p, delta = newL - S.L, sp = (split === undefined || split === null) ? S.L / 2 : split, y, ymax;
    for (i = 0; i < S.n; i++) {
        p = S.P[i];
        y = p.y; if (p.y + p.G.h / 2 > sp) y += delta;
        if (y !== p.y) spSetG(S, p, p.vi, p.u, y);
    }
    S.L = newL;
    for (i = 0; i < S.n; i++) {
        p = S.P[i]; spFixTall(S, i); p = S.P[i];
        ymax = S.L - p.G.h; y = p.y;
        if (y > ymax) y = ymax; if (y < 0) y = 0;
        if (y !== p.y) spSetG(S, p, p.vi, p.u, y);
    }
    spRecomputeAll(S); spResetW(S);
};

/* dat chi tiet i voi goc ai sao cho diem tham chieu (tam) trung (rx, ry); kep vao kho */
WK.spPlaceAtRef = function (S, i, ai, rx, ry) {
    var p = S.P[i], pc = p.pc, PH = S.PH, G = pc.V[ai * PH], u, y, ymax;
    if (!G.ok || G.h > S.L + 1e-9) { ai = p.G.ai; G = pc.V[ai * PH]; }
    u = Math.round((rx - G.rx) / S.csu); if (u < 0) u = 0; if (u > G.maxU) u = G.maxU;
    y = ry - G.ry; ymax = S.L - G.h; if (y > ymax) y = ymax; if (y < 0) y = 0;
    spSetG(S, p, ai * PH + (u % PH), u, y);
};
WK.spInside = function (S, p, px, py) {
    var c = Math.floor(px / S.cs), j = c - p.g0, G = p.G, t, t1;
    if (j < 0 || j >= G.nd) return false;
    t = G.doff[j]; t1 = G.doff[j + 1];
    for (; t < t1; t += 2) if (py >= p.y + G.dv[t] && py <= p.y + G.dv[t + 1]) return true;
    return false;
};

/* disrupt: hoan doi hai chi tiet "lon" (theo dien tich convex hull) va dua cac chi tiet nam trong chung sang cho trong */
WK.spDisrupt = function (S) {
    var P = S.P, n = S.n, i, k, tot = 0, thr, cum = 0, cut = 0, order = [], large = [], cand = [], i1, i2, a, pa, pb, st = [], A, step, tmp;
    if (n < 2) return;
    for (i = 0; i < n; i++) { tot += P[i].pc.ch; order.push(i); }
    thr = tot * 0.75;
    order.sort(function (x, y) { return P[y].pc.ch - P[x].pc.ch; });
    for (k = 0; k < n; k++) { cum += P[order[k]].pc.ch; if (cum > thr) { cut = P[order[k]].pc.ch; break; } }
    for (i = 0; i < n; i++) if (P[i].pc.ch >= cut) large.push(i);
    i1 = large[Math.floor(spRnd(S) * large.length)]; a = P[i1].pc;
    for (k = 0; k < large.length; k++) {
        i = large[k];
        if (i !== i1 && Math.abs(P[i].pc.area - a.area) >= a.area * 0.01 && Math.abs(P[i].pc.dm - a.dm) >= a.dm * 0.01) cand.push(i);
    }
    if (!cand.length) for (i = 0; i < n; i++) if (i !== i1) cand.push(i);
    i2 = cand[Math.floor(spRnd(S) * cand.length)];
    A = P[i1].pc.A;
    /* vi tri cu: goc + diem tham chieu tuyet doi */
    st[0] = { i: i1, ai: P[i1].G.ai, rx: P[i1].x0 + P[i1].G.rx, ry: P[i1].y + P[i1].G.ry };
    st[1] = { i: i2, ai: P[i2].G.ai, rx: P[i2].x0 + P[i2].G.rx, ry: P[i2].y + P[i2].G.ry };
    spPlaceAtRef(S, i1, st[1].ai, st[1].rx, st[1].ry);
    spPlaceAtRef(S, i2, st[0].ai, st[0].rx, st[0].ry);
    for (k = 0; k < 2; k++) {
        var me = st[k], other = st[1 - k], pm = P[me.i], dAi, ang, cs, sn, nref, j, q, dx, dy, nax, nay, nai, G2;
        /* chi tiet nam trong me (o vi tri MOI) -> chuyen sang vi tri CU cua me (xoay theo chenh lech goc) */
        nref = { x: pm.x0 + pm.G.rx, y: pm.y + pm.G.ry };
        dAi = ((me.ai - pm.G.ai) % A + A) % A;
        ang = dAi * (2 * Math.PI / A); cs = Math.cos(ang); sn = Math.sin(ang);
        for (j = 0; j < n; j++) {
            if (j === i1 || j === i2) continue;
            q = P[j];
            if (!spInside(S, pm, q.x0 + q.G.rx, q.y + q.G.ry)) continue;
            dx = (q.x0 + q.G.rx) - nref.x; dy = (q.y + q.G.ry) - nref.y;
            nax = me.rx + (cs * dx - sn * dy); nay = me.ry + (sn * dx + cs * dy);
            nai = (q.G.ai + dAi) % q.pc.A;
            spPlaceAtRef(S, j, nai, nax, nay);
        }
    }
    spRecomputeAll(S);
};

/* ---------- giai doan: explore (Alg. 12) va compress (Alg. 13) ---------- */
/* toc do may (so lan danh gia vi tri moi giay) luu tai Folder.userData/NestPro_speed.txt; xoa file de do lai */
WK.spReadRate = function () {
    var f, v = 0;
    try { f = new File(Folder.userData + "/NestPro_speed.txt"); if (f.exists) { f.open("r"); v = parseFloat(f.read()); f.close(); } } catch (eR) { v = 0; }
    return (v > 50 && v < 1e7) ? v : 0;
};
WK.spWriteRate = function (v) {
    var f;
    try { f = new File(Folder.userData + "/NestPro_speed.txt"); f.open("w"); f.write(String(Math.round(v))); f.close(); } catch (eW) {}
};
WK.spLowerBound = function (job) {
    var S = job.sp, i, lb = 0, area = 0, pc;
    for (i = 0; i < S.n; i++) { pc = S.P[i].pc; area += pc.area; if (pc.minH > lb) lb = pc.minH; }
    area = (area / job.usableW) * (1 - 1e-6);
    return area > lb ? area : lb;
};

WK.spBeginSearch = function (job) {
    var S = job.sp, now = prepNow();
    S.tStart = now; S.evStart = S.evals; S.evBudget = Math.max(1000, job.set.evBudget);
    S.evExpl = Math.round(S.evBudget * job.set.explFrac); S.evStop = S.evStart + S.evExpl;
    S.hardCap = now + 3 * S.total + 10000;   /* chot an toan theo dong ho (chi khi may cham bat thuong) */
    S.best = spSave(S); S.bestL = S.L; S.lbL = spLowerBound(job); S.lastImp = now; S.hist = [[0, S.L]];
    job.sr.greedyTop = S.lbfL; job.sr.bestTop = S.L;
    spRecomputeAll(S); spResetW(S);
    job.sr.bestUtil = 100 * S.netArea / (job.usableW * S.L);
    if (S.n < 2) { S.stage = "done"; return; }
    S.stage = "expl";
    S.ex = { step: job.set.step0, fails: 0, pool: [], phase: "shrink" };
};

WK.spPoolPick = function (S, pool) {
    var idx = Math.floor(Math.min(Math.abs(spNormal(S, 0.25)), 0.999) * pool.length);
    return pool[idx];
};

WK.spExplAdvance = function (job, t0, budgetMs) {
    var S = job.sp, ex = S.ex, next, fin, pick, at, loss;
    if (S.evals >= S.evStart + S.evExpl || prepNow() > S.hardCap) { spCmprBegin(job); return; }
    S.evStop = S.evStart + S.evExpl;
    if (ex.phase === "shrink") {
        next = S.bestL * (1 - ex.step);
        if (next < S.lbL * 1.000001) { spCmprBegin(job); return; }
        spRestore(S, S.best, null);
        spChangeLength(S, next, null);
        spSepBegin(S, job.set.sepExpl); ex.phase = "sep";
    }
    fin = spSepStep(job, t0, budgetMs);
    if (!fin) return;
    if (S.sep.success) {
        S.best = S.sep.sol; S.bestL = S.best.L; job.sr.bestTop = S.bestL; S.lastImp = prepNow(); S.hist.push([S.lastImp - S.tStart, S.bestL]);
        job.sr.bestUtil = 100 * S.netArea / (job.usableW * S.bestL);
        ex.fails = 0; ex.pool = []; ex.phase = "shrink";
        return;
    }
    if (S.evals >= S.evStart + S.evExpl || prepNow() > S.hardCap || job.sr.skip) { spCmprBegin(job); return; }
    /* that bai: dua nghiem it vi pham nhat vao pool, rollback ngau nhien + disrupt, thu lai cung chieu dai */
    loss = S.sep.minLoss;
    for (at = 0; at < ex.pool.length; at++) if (ex.pool[at].loss > loss) break;
    ex.pool.splice(at, 0, { sol: S.sep.minSol, loss: loss });
    ex.fails++;
    if (ex.fails < job.set.maxFail) {
        pick = spPoolPick(S, ex.pool);
        spRestore(S, pick.sol, null);
        spDisrupt(S);
        spSepBegin(S, job.set.sepExpl);
        return;
    }
    /* khong ep noi buoc nay: giam buoc thu hep mot nua va thu lai tu nghiem tot nhat */
    ex.step = ex.step * 0.5; ex.fails = 0; ex.pool = []; ex.phase = "shrink";
    if (ex.step < job.set.stepMin) spCmprBegin(job);
};

WK.spCmprBegin = function (job) {
    var S = job.sp;
    S.stage = "cmpr"; S.evStop = S.evStart + S.evBudget;
    S.cm = { ev0: S.evals, phase: "shrink", nfail: 0 };
    spRestore(S, S.best, null);
};
WK.spCmprAdvance = function (job, t0, budgetMs) {
    var S = job.sp, cm = S.cm, now = prepNow(), ratio, step, next, fin, r0 = job.set.cmpr0, r1 = job.set.cmpr1;
    if (S.evals >= S.evStop || now > S.hardCap) { S.stage = "done"; return; }
    if (cm.phase === "shrink") {
        ratio = (S.evals - cm.ev0) / Math.max(1, S.evStop - cm.ev0); if (ratio > 1) ratio = 1;
        step = r0 + ratio * (r1 - r0);
        if (step < r1) { S.stage = "done"; return; }
        next = S.bestL * (1 - step);
        if (next < S.lbL * 1.000001) { S.stage = "done"; return; }
        spRestore(S, S.best, null);
        spChangeLength(S, next, spRnd(S) * S.L);
        spSepBegin(S, job.set.sepCmpr); cm.phase = "sep";
    }
    fin = spSepStep(job, t0, budgetMs);
    if (!fin) return;
    if (S.sep.success) {
        S.best = S.sep.sol; S.bestL = S.best.L; job.sr.bestTop = S.bestL; S.lastImp = prepNow(); S.hist.push([S.lastImp - S.tStart, S.bestL]);
        job.sr.bestUtil = 100 * S.netArea / (job.usableW * S.bestL);
    } else cm.nfail++;
    cm.phase = "shrink";
};

WK.spInfo = function (job) {
    var S = job.sp, cm = NP_PT_PER_CM, st = S.stage;
    if (st === "lbf") { job.info = "st=lbf;it=0;best=0;util=0;g=0"; return; }
    job.pc = Math.max(0, Math.min(S.evBudget, S.evals - S.evStart)); job.pt = S.evBudget;
    job.info = "st=" + st + ";it=" + S.passes + ";mv=" + S.moves + ";best=" + (S.bestL / cm).toFixed(1) + ";util=" + job.sr.bestUtil.toFixed(1) + ";g=" + (S.lbfL / cm).toFixed(1);
};

/* true khi xong toan bo tim kiem */
WK.spStep = function (job, budgetMs) {
    var S = job.sp, t0 = prepNow();
    if (S.stage === "lbf") {
        if (spLbfAdvance(job, budgetMs)) spBeginSearch(job);
        if (S.stage === "lbf") { job.info = "st=lbf;it=0;mv=0;best=0;util=0;g=0"; return false; }
    }
    while (S.stage !== "done") {
        if (job.sr.skip) { S.stage = "done"; break; }
        if (S.stage === "expl") spExplAdvance(job, t0, budgetMs);
        else if (S.stage === "cmpr") spCmprAdvance(job, t0, budgetMs);
        if (prepNow() - t0 >= budgetMs) break;
    }
    if (S.stage === "done") { spFinalize(job); return true; }
    spInfo(job);
    return false;
};

WK.spFinalize = function (job) {
    var S = job.sp, best = S.best, rows = [], i, pc, G, area = 0, top = 0, y;
    for (i = 0; i < S.n; i++) {
        pc = S.P[i].pc; G = pc.V[best.vi[i]]; y = best.y[i]; if (y < 0) y = 0;
        rows.push({ item: pc.item, name: pc.name, index: pc.index, angle: ((pc.canon || 0) + G.angle) % 360, w: G.w, h: G.h, x: job.leftPad + best.u[i] * S.csu, y: y, outline: pc.outline, raws: pc.raws, npts: pc.npts, area: pc.area });
        area += pc.area; if (y + G.h > top) top = y + G.h;
    }
    rows.sort(function (a, b) { return a.index - b.index; });
    job.layout = rows; job.contentH = top; job.netArea = area; job.sheetW = job.cfg.rollW;
    job.sheetH = job.topPad + top + job.cfg.marginB + job.edgePad;
    if (job.sheetH < 100) job.sheetH = 100;
    if (job.sheetW > 16000 || job.sheetH > 16000) throw new Error("SHEET_TOO_LARGE: split the selected pieces into smaller groups.");
    job.sparrowMoved = S.moves;
    if (S.tStart && !job.rateKnown) {
        var secs = (prepNow() - S.tStart) / 1000, rt = (S.evals - S.evStart) / Math.max(0.5, secs);
        if (secs > 3 && rt > 50) spWriteRate(rt);
    }
    job.sr.bestTop = top;
    job.info = "st=done";
};

/* ---------- verification: measure the real minimum distance between neighbouring pieces ---------- */
WK.prepPtSeg2 = function (px, py, sx, sy, ex, ey) {
    var vx = ex - sx, vy = ey - sy, l = vx * vx + vy * vy, k = l ? ((px - sx) * vx + (py - sy) * vy) / l : 0, qx, qy;
    if (k < 0) k = 0; if (k > 1) k = 1;
    qx = px - (sx + k * vx); qy = py - (sy + k * vy);
    return qx * qx + qy * qy;
};

WK.prepSegDist2 = function (ax, ay, bx, by, cx, cy, dx, dy) {
    var o1 = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax), o2 = (bx - ax) * (dy - ay) - (by - ay) * (dx - ax);
    var o3 = (dx - cx) * (ay - cy) - (dy - cy) * (ax - cx), o4 = (dx - cx) * (by - cy) - (dy - cy) * (bx - cx), m, v;
    if (((o1 > 0 && o2 < 0) || (o1 < 0 && o2 > 0)) && ((o3 > 0 && o4 < 0) || (o3 < 0 && o4 > 0))) return 0;
    m = prepPtSeg2(ax, ay, cx, cy, dx, dy);
    v = prepPtSeg2(bx, by, cx, cy, dx, dy); if (v < m) m = v;
    v = prepPtSeg2(cx, cy, ax, ay, bx, by); if (v < m) m = v;
    v = prepPtSeg2(dx, dy, ax, ay, bx, by); if (v < m) m = v;
    return m;
};

WK.prepEdgesInRegion = function (G, rx0, ry0, rx1, ry1) {
    var out = [], i, j, n, p, q, poly, ex0, ex1, ey0, ey1, gx = G.x, gy = G.y;
    for (i = 0; i < G.polys.length; i++) {
        poly = G.polys[i]; n = poly.length;
        for (j = 0; j < n; j++) {
            p = poly[j]; q = poly[(j + 1) % n];
            ex0 = (p.x < q.x ? p.x : q.x) + gx; ex1 = (p.x < q.x ? q.x : p.x) + gx;
            ey0 = (p.y < q.y ? p.y : q.y) + gy; ey1 = (p.y < q.y ? q.y : p.y) + gy;
            if (ex1 < rx0 || ex0 > rx1 || ey1 < ry0 || ey0 > ry1) continue;
            /* Luu them min/max de phuc vu bounding box pruning nhanh */
            out.push({ x0: p.x + gx, y0: p.y + gy, x1: q.x + gx, y1: q.y + gy, minX: ex0, maxX: ex1, minY: ey0, maxY: ey1 });
        }
    }
    return out;
};

/* minimum boundary distance between two placed pieces, or `limit` if they are at least that far apart */
/* V1.31: khoang cach nho nhat giua hai chi tiet, dung LUOI tra cuu canh cua B (truoc day so moi canh A voi moi canh B:
   rap cong nhieu diem -> hang trieu phep tinh/cap -> Illustrator dung hinh). Ket qua giong het cach cu. */
WK.prepPairGap = function (A, B, limit) {
    var rx0 = Math.max(A.x, B.x) - limit, rx1 = Math.min(A.x + A.w, B.x + B.w) + limit, ry0 = Math.max(A.y, B.y) - limit, ry1 = Math.min(A.y + A.h, B.y + B.h) + limit;
    var ea, eb, i, k, d2, best = limit * limit, dBest = limit, a, b, cz, nx, ny, cells, cx0, cx1, cy0, cy1, cx, cy, list, stamp = 0, gx0, gy0;
    if (rx0 > rx1 || ry0 > ry1) return limit;
    ea = prepEdgesInRegion(A, rx0, ry0, rx1, ry1); if (!ea.length) return limit;
    eb = prepEdgesInRegion(B, rx0, ry0, rx1, ry1); if (!eb.length) return limit;
    cz = limit > 4 ? limit : 4; gx0 = rx0 - cz; gy0 = ry0 - cz;
    nx = Math.floor((rx1 - gx0 + cz) / cz) + 1; ny = Math.floor((ry1 - gy0 + cz) / cz) + 1;
    cells = [];
    for (k = 0; k < eb.length; k++) {
        b = eb[k]; b.st = -1;
        cx0 = Math.floor((b.minX - gx0) / cz); cx1 = Math.floor((b.maxX - gx0) / cz);
        cy0 = Math.floor((b.minY - gy0) / cz); cy1 = Math.floor((b.maxY - gy0) / cz);
        if (cx0 < 0) cx0 = 0; if (cy0 < 0) cy0 = 0; if (cx1 >= nx) cx1 = nx - 1; if (cy1 >= ny) cy1 = ny - 1;
        for (cy = cy0; cy <= cy1; cy++) for (cx = cx0; cx <= cx1; cx++) { i = cy * nx + cx; if (!cells[i]) cells[i] = []; cells[i].push(b); }
    }
    for (i = 0; i < ea.length; i++) {
        a = ea[i]; stamp++;
        cx0 = Math.floor((a.minX - dBest - gx0) / cz); cx1 = Math.floor((a.maxX + dBest - gx0) / cz);
        cy0 = Math.floor((a.minY - dBest - gy0) / cz); cy1 = Math.floor((a.maxY + dBest - gy0) / cz);
        if (cx0 < 0) cx0 = 0; if (cy0 < 0) cy0 = 0; if (cx1 >= nx) cx1 = nx - 1; if (cy1 >= ny) cy1 = ny - 1;
        for (cy = cy0; cy <= cy1; cy++) for (cx = cx0; cx <= cx1; cx++) {
            list = cells[cy * nx + cx]; if (!list) continue;
            for (k = 0; k < list.length; k++) {
                b = list[k]; if (b.st === stamp) continue; b.st = stamp;
                if (b.minX > a.maxX + dBest || b.maxX < a.minX - dBest || b.minY > a.maxY + dBest || b.maxY < a.minY - dBest) continue;
                d2 = prepSegDist2(a.x0, a.y0, a.x1, a.y1, b.x0, b.y0, b.x1, b.y1);
                if (d2 < best) { best = d2; if (best <= 0) return 0; dBest = Math.sqrt(best); }
            }
        }
    }
    return dBest;
};
/* V1.31: do khoang ho chia nho theo cap chi tiet (moi buoc BridgeTalk chi lam trong ngan sach thoi gian) */
WK.prepVerifyBegin = function (job) {
    var G = [], i, j, rp, row, a, b, lim = job.reqGap + 10, pairs = [];
    for (i = 0; i < job.layout.length; i++) {
        row = job.layout[i]; rp = prepRotatePolys(row.outline, row.angle);
        G.push({ polys: rp.polys, x: row.x, y: row.y, w: rp.w, h: rp.h });
    }
    for (i = 0; i < G.length; i++) for (j = i + 1; j < G.length; j++) {
        a = G[i]; b = G[j];
        if (a.x > b.x + b.w + lim || b.x > a.x + a.w + lim || a.y > b.y + b.h + lim || b.y > a.y + a.h + lim) continue;
        pairs.push(i, j);
    }
    job.vf = { G: G, pairs: pairs, k: 0, minGap: lim, limit: lim, t0: prepNow() };
};
/* true khi xong */
WK.prepVerifyStep = function (job, budgetMs) {
    var vf = job.vf, t0 = prepNow(), G = vf.G, P = vf.pairs, a, b, d, m;
    while (vf.k < P.length) {
        a = G[P[vf.k]]; b = G[P[vf.k + 1]]; vf.k += 2; m = vf.minGap;
        if (!(a.x > b.x + b.w + m || b.x > a.x + a.w + m || a.y > b.y + b.h + m || b.y > a.y + a.h + m)) {
            d = prepPairGap(a, b, m);
            if (d < vf.minGap) vf.minGap = d;
        }
        if (prepNow() - t0 > budgetMs && vf.k < P.length) return false;
    }
    prepVerifyFinish(job);
    return true;
};
WK.prepVerifyFinish = function (job) {
    var vf = job.vf, minGap = vf.minGap, limit = vf.limit;
    job.minGap = minGap; job.gapLimit = limit;
    job.effPct = (job.contentH > 0) ? (100 * job.netArea / (job.usableW * job.contentH)) : 0;
    job.info = "len=" + job.contentH.toFixed(2) + ";eff=" + job.effPct.toFixed(1) + ";gap=" + minGap.toFixed(2) + ";req=" + job.reqGap.toFixed(2) + ";lim=" + limit.toFixed(2) + ";n=" + job.layout.length + ";it=" + (job.sr ? job.sr.iter : 0) + ";g=" + (job.sr ? (job.sr.greedyTop / NP_PT_PER_CM).toFixed(2) : "0") + ";b=" + (job.sr ? (job.sr.bestTop / NP_PT_PER_CM).toFixed(2) : "0") + ";sp=" + (job.sparrowMoved || 0) + ";sw=" + (job.sparrowWarning || "") + ";skip=" + job.skipped.length + ";warn=" + job.warnings.length;
    job.vf = null;
};
/* giu ham cu (dung trong kiem thu): do toan bo mot lan */
WK.prepVerify = function (job) {
    prepVerifyBegin(job);
    while (!prepVerifyStep(job, 1e9)) {}
};
WK.prepCopyFallback = function (dst, rd, job, ri) {
    var i, q, pt;
    for (i = 0; i < rd.P.length; i++) {
        job.copyStage = "fallback:add:" + ri + ":" + i;
        q = rd.P[i]; pt = dst.pathPoints.add();
        job.copyStage = "fallback:anchor:" + ri + ":" + i;
        pt.anchor = [q.ax, q.ay];
        job.copyStage = "fallback:left:" + ri + ":" + i;
        pt.leftDirection = [q.lx, q.ly];
        job.copyStage = "fallback:right:" + ri + ":" + i;
        pt.rightDirection = [q.rx, q.ry];
    }
};

WK.prepCopyToFallback = function (job, p, st, ri) {
    var rd=p.raws[ri], old=st.dsts[ri], dst;
    try { if(old) old.remove(); } catch(eRemove) { try { if(old) old.hidden=true; } catch(eHide) {} }
    dst=st.compound ? st.container.pathItems.add() : job.outLayer.pathItems.add();
    prepCopyFallback(dst,rd,job,ri);
    try { dst.closed=rd.closed; } catch(eClosed) {}
    try { dst.clipping=false; } catch(eClip) {}
    st.dsts[ri]=dst; st.skipH[ri]=true; st.pps[ri]=null;
    st.fallbackCount++;
};

WK.prepIsCurved = function (q) {
    return (Math.abs(q.lx - q.ax) > 1e-6 || Math.abs(q.ly - q.ay) > 1e-6 || Math.abs(q.rx - q.ax) > 1e-6 || Math.abs(q.ry - q.ay) > 1e-6);
};

WK.prepCopyBuild = function (job, p, st) {
    var i, k, rd, P, anchors, dst, ok, pointCount;
    st.dsts = []; st.skipH = []; st.pps = []; st.ri = 0; st.hi = 0; st.hdone = 0; st.htotal = 0; st.fallbackCount = 0;
    st.compound = (p.item.typename === "CompoundPathItem");
    st.container = st.compound ? job.outLayer.compoundPathItems.add() : null;
    for (i = 0; i < p.raws.length; i++) {
        rd = p.raws[i]; P = rd.P; anchors = [];
        for (k = 0; k < P.length; k++) anchors.push([P[k].ax, P[k].ay]);
        dst = st.compound ? st.container.pathItems.add() : job.outLayer.pathItems.add();
        ok = true;
        try { dst.setEntirePath(anchors); } catch (eSet) { ok = false; }
        if (ok) { try { pointCount=dst.pathPoints.length; if(pointCount!==P.length) ok=false; } catch(eCount) { ok=false; } }
        if (!ok) {
            try { dst.remove(); } catch(eRemove) { try { dst.hidden=true; } catch(eHide) {} }
            dst = st.compound ? st.container.pathItems.add() : job.outLayer.pathItems.add();
            prepCopyFallback(dst, rd, job, i);
            st.fallbackCount++;
        }
        try { dst.closed = rd.closed; } catch (eClosed) {}
        try { dst.clipping = false; } catch (eClip) {}
        st.dsts.push(dst); st.skipH.push(!ok);
        if (ok) { for (k = 0; k < P.length; k++) if (prepIsCurved(P[k])) st.htotal++; }
    }
    st.stage = "handles";
};

/* returns true when every handle has been written; false when the time budget ran out */
WK.prepCopyHandles = function (job, p, st, t0, budgetMs) {
    var P, q, n = 0, pts, point, fallback;
    while (st.ri < st.dsts.length) {
        if (st.skipH[st.ri]) { st.ri++; st.hi = 0; continue; }
        P = p.raws[st.ri].P;
        fallback=false;
        job.copyStage = "handles:get-collection:" + st.ri;
        if (!st.pps[st.ri]) {
            try { st.pps[st.ri] = st.dsts[st.ri].pathPoints; } catch(ePoints) { fallback=true; }
        }
        pts = st.pps[st.ri];
        job.copyStage = "handles:check-count:" + st.ri + ":" + (pts ? pts.length : -1) + ":" + P.length;
        if (!pts || pts.length !== P.length) fallback=true;
        if (fallback) { prepCopyToFallback(job,p,st,st.ri); st.ri++; st.hi=0; continue; }
        while (st.hi < P.length) {
            q = P[st.hi];
            if (prepIsCurved(q)) {
                job.copyStage = "handles:point:" + st.ri + ":" + st.hi;
                try {
                    point=pts[st.hi]; if(!point) throw new Error("Path point index is missing.");
                    job.copyStage = "handles:left:" + st.ri + ":" + st.hi;
                    point.leftDirection = [q.lx, q.ly];
                    job.copyStage = "handles:right:" + st.ri + ":" + st.hi;
                    point.rightDirection = [q.rx, q.ry];
                } catch(eHandle) { prepCopyToFallback(job,p,st,st.ri); st.ri++; st.hi=0; fallback=true; break; }
                st.hdone++; n++;
                if (n % 25 === 0 && prepNow() - t0 > budgetMs) { st.hi++; return false; }
            }
            st.hi++;
        }
        if (fallback) continue;
        st.ri++; st.hi = 0;
    }
    return true;
};

/* V1.29: sao chep NHANH = duplicate chi tiet goc sang layer ket qua (1 lenh DOM giu nguyen moi diem neo + tay nam),
   thay cho dung lai path roi dat tay nam tung diem (hang nghin lenh DOM voi rap nhieu diem neo).
   Kiem tra so diem/so path; neu khong khop hoac loi -> xoa ban sao va dung cach cu (an toan). */
WK.prepCopyDuplicate = function (job, p) {
    var d = null, ok = false, n;
    try {
        job.copyStage = "duplicate:" + p.name;
        d = p.item.duplicate(job.outLayer, ElementPlacement.PLACEATEND);
        if (d && d.typename === "PathItem") { n = d.pathPoints.length; ok = (p.raws.length === 1 && n === p.raws[0].P.length); }
        else if (d && d.typename === "CompoundPathItem") { ok = (d.pathItems.length === p.raws.length); }
    } catch (eDup) { ok = false; }
    if (!ok) {
        try { if (d) d.remove(); } catch (eRm) { try { if (d) d.hidden = true; } catch (eHide) {} }
        job.dupFail = (job.dupFail || 0) + 1;
        if (job.dupFail >= 3 && !job.dupOk) job.noDup = true;
        return null;
    }
    job.dupOk = (job.dupOk || 0) + 1;
    return d;
};

WK.prepCopyInfo = function (job) {
    var p = job.layout[job.copyIndex], st = job.cp, nm;
    if (!p) { return; }
    nm = prepAscii(p.name).replace(/[;=|]/g, "_").substring(0, 40);
    job.info = "cur=" + nm + ";pts=" + p.npts + ";hd=" + (st ? st.hdone : 0) + ";ht=" + (st ? st.htotal : 0) + ";fb=" + (st ? st.fallbackCount : 0) + ";dup=" + (job.dupOk || 0);
};

WK.prepCopyAdvance = function (job, budgetMs) {
    var t0 = prepNow(), p, st, clone, b2, targetBottom;
    while (job.copyIndex < job.layout.length) {
        p = job.layout[job.copyIndex];
        if (!job.cp) { job.cp = { stage: "build" }; prepLog(job, "copy " + (job.copyIndex + 1) + "/" + job.layout.length + " begin: " + p.name + " points=" + p.npts); }
        st = job.cp;
        if (st.stage === "build") {
            st.dup = job.noDup ? null : prepCopyDuplicate(job, p);
            if (st.dup) { st.stage = "finish"; st.hdone = 0; st.htotal = 0; st.fallbackCount = 0; }
            else {
                job.copyStage = "build-paths:" + p.name;
                prepCopyBuild(job, p, st);
                if (prepNow() - t0 > budgetMs) { prepCopyInfo(job); return; }
            }
        }
        if (st.stage === "handles") {
            job.copyStage = "set-handles:" + p.name;
            if (!prepCopyHandles(job, p, st, t0, budgetMs)) { prepCopyInfo(job); return; }
            st.stage = "finish";
        }
        if (st.stage === "finish") {
            clone = st.dup ? st.dup : (st.compound ? st.container : st.dsts[0]);
            job.copyStage = "apply-fill-style";
            prepStyleShape(clone, job.cfg, job.outDoc);
            if (p.angle) { job.copyStage = "rotate"; clone.rotate(p.angle); }
            job.copyStage = "measure-after-rotation";
            b2 = prepSafeBounds(clone);
            if (!b2) throw new Error("DUPLICATE_FAILED: output contour has no measurable bounds: " + p.name);
            targetBottom = job.cfg.marginB + job.edgePad + p.y;
            job.copyStage = "translate-to-layout";
            clone.translate(p.x - b2.left, targetBottom - b2.bottom);
            try { clone.name = "SILHOUETTE_" + ('000' + (job.copyIndex + 1)).slice(-3) + " | " + prepAscii(p.name).substring(0, 80); } catch (eName) {}
            job.outItems.push(clone);
            job.copyIndex++; job.cp = null;
            prepLog(job, "copy " + job.copyIndex + " done");
        }
        if (prepNow() - t0 > budgetMs) break;
    }
    prepCopyInfo(job);
};

/* ---------- job control ---------- */
WK.prepCloseOutput = function (job) {
    try { if (job && job.outDoc && job.outDoc.isValid !== false) job.outDoc.close(SaveOptions.DONOTSAVECHANGES); } catch (eClose) {}
    try { if (job && job.srcDoc) job.srcDoc.activate(); } catch (eActivate) {}
};

WK.prepFail = function (job, code, detail) {
    prepLog(job, "FAIL " + code + ": " + detail);
    job.errorCode = String(code || "ERROR"); job.errorDetail = prepAscii(detail || ""); job.phase = "failed"; job.done = true;
    if (job.outDoc && !job.completed) prepCloseOutput(job);
    try { if ($.global.NestProSparrowV140Job === job) delete $.global.NestProSparrowV140Job; } catch (eDel) {}
    return prepStepResult(job);
};

WK.prepInitJob = function (cfg, jobId) {
    var doc = null, selection, job;
    try { if (app.documents.length > 0) doc = app.activeDocument; } catch (eDoc) { doc = null; }
    if (!doc) return "ERR|NO_DOCUMENT|No active document.";
    selection = prepGetSelectionRoots(doc);
    if (selection.overflow) return "ERR|TOO_MANY_SELECTED|count=" + selection.overflow;
    if (!selection.items.length) return "ERR|NO_SELECTION|No selected PageItems at button press.";
    job = { id: String(jobId), srcDoc: doc, roots: selection.items, rootIndex: 0, candidates: [], warnings: [], skipped: [], cfg: cfg, phase: "extract", layout: [], copyIndex: 0, outDoc: null, outLayer: null, outItems: [], cp: null, done: false, completed: false, errorCode: "", errorDetail: "", sheetW: 0, sheetH: 0, pc: 0, pt: 0, info: "", copyStage: "" };
    job.t0 = prepNow();
    prepTrace(job, "INIT Nest-Pro " + NP_VERSION + " | roll=" + cfg.rollW.toFixed(1) + "pt gap=" + cfg.gap.toFixed(2) + "pt rot=" + cfg.rotationMode, true);
    $.global.NestProSparrowV140Job = job;
    return "INIT_OK|" + job.roots.length;
};

/* V1.31: tien do theo THOI GIAN THUC = da chay / (da chay + con lai uoc tinh).
   Pha xep dung dung moc ket thuc cua bo hen gio; cac pha khac dung toc do do duoc ngay trong lan chay nay. */
WK.prepProgress = function (job) {
    var now = prepNow(), el = now - job.t0, n = job.candidates.length || 1, ph = job.phase, rem = 0, rate, end, S = job.sp, vf = job.vf;
    var srch = job.set ? job.set.searchMs : NP_SP_T_MIN, perV = 40, perC = 150, left;
    if (ph === "done") return "1000|0";
    if (ph === "extract") return String(Math.round(30 * (job.roots.length ? job.rootIndex / job.roots.length : 0))) + "|-1";
    if (ph === "prepare") {
        rate = (job.pc > 0.2) ? (now - job.tPrep0) / job.pc : 400;
        rem = rate * Math.max(0, n - job.pc) + srch + n * (perV + perC);
    } else if (ph === "layout") {
        if (S && S.stage !== "lbf" && S.evBudget) {
            rate = (S.evals - S.evStart) / Math.max(1, now - S.tStart);   /* lan thu / ms do tai cho */
            if (!(rate > 0)) rate = job.rate / 1000;
            rem = Math.max(0, S.evStart + S.evBudget - S.evals) / rate;
        } else rem = srch;
        rem += n * (perV + perC);
    } else if (ph === "verify") {
        left = vf ? (vf.pairs.length - vf.k) / 2 : n;
        rate = (vf && vf.k > 0) ? (now - vf.t0) / (vf.k / 2) : perV;
        rem = rate * left + n * perC + 500;
    } else if (ph === "create-doc") {
        rem = n * perC + 500;
    } else {
        rate = (job.copyIndex > 0 && job.tCopy0) ? (now - job.tCopy0) / job.copyIndex : perC;
        rem = rate * Math.max(0, job.layout.length - job.copyIndex) + 200;
    }
    return String(Math.min(999, Math.round(1000 * el / Math.max(1, el + rem)))) + "|" + String(Math.round(rem / 1000));
};
/* V1.33: ngan sach moi buoc TU THICH NGHI: do khoang nghi giua hai buoc (BridgeTalk + cap nhat panel),
   chon ngan sach ~4 lan khoang nghi -> ~80% thoi gian cho tinh toan, nhung khong qua NP_SP_STEP_MAX (giu Illustrator muot). */
/* V1.36: cho Illustrator xu ly su kien cua so dinh ky (~1.5 s) de Windows khong gan "Not Responding" khi chuoi buoc chay lien tuc.
   Do thoi gian app.redraw(); neu > NP_PUMP_MAX_MS (tai lieu nang) thi tu tat de khong lam cham. */
WK.prepPump = function (job) {
    var t, d;
    if (job.noPump || !NP_PUMP_MS) return;
    t = prepNow();
    if (job.lastPump && t - job.lastPump < NP_PUMP_MS) return;
    try { app.redraw(); } catch (ePump) { job.noPump = true; return; }
    d = prepNow() - t; job.lastPump = prepNow();
    if (d > NP_PUMP_MAX_MS) { job.noPump = true; prepTrace(job, "pump off (redraw " + Math.round(d) + "ms)"); }
};
WK.prepBudget = function (job) {
    var b = 3 * (job.ovh || 60);
    if (b < NP_SP_STEP_MS) b = NP_SP_STEP_MS;
    if (b > NP_SP_STEP_MAX) b = NP_SP_STEP_MAX;
    return b;
};
WK.prepStepResult = function (job) {
    if (!job) return "ERR|JOB_MISSING|No job state.";
    prepPump(job);
    job.lastStepEnd = prepNow();
    if (job.stepT0 && job.lastStepEnd - job.stepT0 > (job.tmax || 0)) { job.tmax = job.lastStepEnd - job.stepT0; job.tmaxPh = job.stepPh; }
    if (job.stepT0) prepTrace(job, "E #" + job.stepNo + " " + Math.round(job.lastStepEnd - job.stepT0) + "ms " + prepTraceState(job));
    var detail = job.errorCode ? job.errorDetail : job.info, pr = "0|-1";
    try { pr = prepProgress(job); } catch (ePr) {}
    return "STEP|" + job.phase + "|" + (job.pc || 0) + "|" + (job.pt || 0) + "|" + job.candidates.length + "|" + job.copyIndex + "|" + job.layout.length + "|" + (job.done ? "1" : "0") + "|" + (job.errorCode || "") + "|" + pr + "|" + prepAscii(detail || "");
};

WK.prepJobStep = function (job) {
    var r, i, ref, wi, code, cs, p, clone, b2, targetLeft, targetBottom, raw, msg, fin;
    if (!job || job.done) return prepStepResult(job);
    prepLog(job, "step begin");
    if (job.lastStepEnd) { var gapMs = prepNow() - job.lastStepEnd; if (gapMs >= 0 && gapMs < 5000) job.ovh = job.ovh ? 0.7 * job.ovh + 0.3 * gapMs : gapMs; }
    job.stepT0 = prepNow(); job.stepPh = job.phase + (job.sp && job.sp.stage ? ":" + job.sp.stage : "");
    job.stepNo = (job.stepNo || 0) + 1;
    prepTrace(job, "B #" + job.stepNo + " " + prepTraceState(job) + " budget=" + Math.round(prepBudget(job)) + "ms gap=" + Math.round(job.ovh || 0) + "ms");
    try {
        if (job.phase === "extract") {
            var tEx = prepNow();
            while (job.rootIndex < job.roots.length) {
                r = prepExtractRoot(job.roots[job.rootIndex]);
                for (i = 0; i < r.items.length; i++) {
                    ref = r.items[i];
                    var dupCand = false;
                    for (var ci = 0; ci < job.candidates.length; ci++) {
                        if (job.candidates[ci].item === ref) { dupCand = true; break; }
                    }
                    if (!dupCand) job.candidates.push({ item: ref, name: prepItemName(ref, job.candidates.length) });
                }
                for (wi = 0; wi < r.warnings.length; wi++) if (!prepContainsRef(job.warnings, r.warnings[wi])) job.warnings.push(r.warnings[wi]);
                if (!r.items.length) job.skipped.push(prepItemName(job.roots[job.rootIndex], job.rootIndex));
                job.rootIndex++;
                if (prepNow() - tEx > prepBudget(job)) break;
            }
            job.pc = job.rootIndex; job.pt = job.roots.length;
            if (job.rootIndex >= job.roots.length) {
                if (!job.candidates.length) return prepFail(job, "NO_CONTOUR", "No closed PathItem or CompoundPathItem could be extracted.");
                if (job.candidates.length > NP_MAX_PIECES) return prepFail(job, "TOO_MANY_PIECES", "count=" + job.candidates.length + ";max=" + NP_MAX_PIECES);
                prepSetup(job); job.tPrep0 = prepNow();
                job.phase = "prepare"; job.pc = 0; job.pt = job.candidates.length;
            }
            return prepStepResult(job);
        }
        if (job.phase === "prepare") {
            code = prepPrepareStep(job, prepBudget(job));
            if (code === "NO_CONTOUR") return prepFail(job, "NO_CONTOUR", "No measurable closed contour.");
            if (code === "TOO_MANY_PIECES") return prepFail(job, "TOO_MANY_PIECES", "count=" + job.pieces.length + ";max=" + NP_MAX_PIECES);
            return prepStepResult(job);
        }
        if (job.phase === "layout") {
            try { fin = spStep(job, prepBudget(job)); }
            catch (eSp) {
                if (job.sp && job.sp.best) {
                    job.sparrowWarning = prepAscii(String(eSp && eSp.message ? eSp.message : eSp));
                    spFinalize(job); fin = true;
                    prepLog(job, "Sparrow stopped safely; keeping best layout: " + job.sparrowWarning);
                } else throw eSp;
            }
            if (fin) { job.tLay1 = prepNow(); job.phase = "verify"; job.info = ""; }
            return prepStepResult(job);
        }
        if (job.phase === "verify") {
            if (!job.vf) prepVerifyBegin(job);
            if (!prepVerifyStep(job, prepBudget(job))) { job.info = ""; return prepStepResult(job); }
            job.report = job.info;
            for (i = 0; i < job.layout.length; i++) job.layout[i].outline = null;
            for (i = 0; i < job.candidates.length; i++) { job.candidates[i].outline = null; job.candidates[i].or = null; job.candidates[i].V = null; job.candidates[i].raws = null; }
            job.sp = null;
            job.pieces = null;
            prepLog(job, "verify done; minGap=" + job.minGap + "; sheet=" + job.sheetW + "x" + job.sheetH);
            job.phase = "create-doc";
            return prepStepResult(job);
        }
        if (job.phase === "create-doc") {
            job.tCopy0 = prepNow();
            job.copyStage = "create-doc:check-size";
            if (!(job.sheetW > 0 && job.sheetH > 0 && job.sheetW <= 16000 && job.sheetH <= 16000)) throw new Error("SHEET_TOO_LARGE: invalid sheet size " + job.sheetW + " x " + job.sheetH);
            job.copyStage = "create-doc:add-document";
            prepLog(job, "documents.add begin " + job.sheetW + " x " + job.sheetH);
            cs = prepDocSpace(job.srcDoc);
            job.outDoc = app.documents.add(cs, job.sheetW, job.sheetH);
            prepLog(job, "documents.add returned");
            job.copyStage = "create-doc:artboard";
            job.outDoc.artboards[0].artboardRect = [0, job.sheetH, job.sheetW, 0];
            job.copyStage = "create-doc:layer";
            job.outLayer = job.outDoc.layers[0];
            job.outLayer.name = "NEST-PRO | LIGHT CONTOURS";
            try { job.outLayer.visible = true; job.outLayer.locked = false; } catch (eLayer) {}
            job.phase = "copy"; job.copyIndex = 0; job.copyStage = ""; job.cp = null;
            prepLog(job, "output document ready");
            prepCopyInfo(job);
            return prepStepResult(job);
        }
        if (job.phase === "copy") {
            prepCopyAdvance(job, prepBudget(job));
            job.pc = job.copyIndex; job.pt = job.layout.length;
            if (job.copyIndex >= job.layout.length) { job.phase = "finish"; job.info = ""; }
            return prepStepResult(job);
        }
        if (job.phase === "finish") {
            job.outDoc.artboards[0].artboardRect = [0, job.sheetH, job.sheetW, 0];
            try { job.outDoc.artboards[0].name = "NEST-PRO NEST PREVIEW"; } catch (eAbName) {}
            try { job.outDoc.selection = null; } catch (eSelection) {}
            job.outDoc.activate();
            job.completed = true; job.done = true; job.phase = "done";
            job.info = (job.report || "") + ";tp=" + ((job.tLay0 - job.t0) / 1000).toFixed(1) + ";tl=" + ((job.tLay1 - job.tLay0) / 1000).toFixed(1) + ";tc=" + ((prepNow() - job.tCopy0) / 1000).toFixed(1) + ";dup=" + (job.dupOk || 0) + ";tmx=" + ((job.tmax || 0) / 1000).toFixed(2) + ";tmp=" + (job.tmaxPh || "");
            prepLog(job, "finished");
            try { delete $.global.NestProSparrowV140Job; } catch (eDelete) {}
            return prepStepResult(job);
        }
        return prepFail(job, "UNKNOWN_PHASE", job.phase);
    } catch (eStep) {
        raw = String(eStep && eStep.message ? eStep.message : eStep);
        code = "EXPORT_FAILED";
        if (raw.indexOf("PIECE_TOO_WIDE:") === 0) code = "TOO_WIDE";
        else if (raw.indexOf("SHEET_TOO_LARGE:") === 0) code = "SHEET_TOO_LARGE";
        else if (raw.indexOf("DUPLICATE_FAILED:") === 0) code = "DUPLICATE_FAILED";
        else if (raw.indexOf("SPARROW_") === 0) code = "SPARROW_LAYOUT";
        if (code !== "EXPORT_FAILED") raw = raw.replace(/^[A-Z_]+:\s*/, "");
        var errLine = ""; try { if (eStep && eStep.line) errLine = String(eStep.line); } catch (eLine) {}
        var errName = ""; try { if (eStep && eStep.name) errName = String(eStep.name); } catch (eName) {}
        msg = "phase=" + job.phase + "; step=" + String(job.pc || 0) + "/" + String(job.pt || 0) + "; copy=" + String(job.copyIndex + 1) + "/" + String(job.layout ? job.layout.length : 0) + "; stage=" + String(job.copyStage || "unknown") + "; name=" + errName + "; line=" + errLine + "; " + raw;
        return prepFail(job, code, code === "EXPORT_FAILED" ? msg : raw);
    }
};

WK.prepCancelJob = function (jobId) {
    var job = null;
    try { job = $.global.NestProSparrowV140Job; } catch (eGet) {}
    if (job && String(job.id) === String(jobId)) {
        if (!job.completed) prepCloseOutput(job);
        job.done = true; job.phase = "cancelled";
        try { delete $.global.NestProSparrowV140Job; } catch (eDel) {}
    }
    return "CANCELLED";
};



for (var npK in WK) self[npK] = WK[npK];
