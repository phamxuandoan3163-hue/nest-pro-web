/* Nest-Pro Sparrow: chay toan bo engine tren du lieu do host.jsx doc tu Illustrator. Dung chung cho Web Worker va che do du phong.
   V1.2: CHI MOT che do xep (thoi gian = cong thuc "Chuan" cu: NP_SP_T_BASE + NP_SP_T_PIECE x so chi tiet, kep [MIN, MAX]).
   Ngan sach so lan thu duoc TU HIEU CHINH ngay trong moi lan chay: do toc do THAT cua may trong ~150ms dau cua pha tim
   kiem that (sau khi LBF xong), roi dieu chinh lai so lan thu muc tieu cho khop voi "ms" o tren. Khong con phu thuoc
   gia tri doan truoc (90000 lan/giay) hay file toc do luu tu lan chay truoc -> thoi gian thuc te luon dung ngay tu
   LAN CHAY DAU TIEN va on dinh tren moi may, khong con tinh trang lan nhanh lan cham do hieu chinh sai. */
function NP_runPipeline(input, emit, ctl) {
    return new Promise(function (resolve, reject) {
        var job, i = 0, T0 = Date.now(), tSearch = 0, lastEmit = 0;
        /* tu hieu chinh LIEN TUC toc do tim kiem that tren may nay, ngay khi qua khoi LBF: bo qua ~20000 lan thu
           dau (JIT/ham moi chua "nong"), roi moi vong lap deu tinh lai toc do TRUNG BINH TICH LUY tu moc do va
           dieu chinh lai so lan thu muc tieu cho khop voi "ms". NGUNG dieu chinh khi da qua ~85% thoi gian muc
           tieu (giu nguyen moc da dat) de tranh rung lac dung sai so nho luc gan cuoi lan chay. Lam ngay tu dau
           (khong cho rieng pha nao) vi co bai toan pha "kham pha" ket thuc rat nhanh (<1 giay, da tim duoc bo
           cuc hop le va thu hep het muc), khong kip cho mot phep do rieng cho tung pha. */
        var calib = { ref: null, rate: 0 };
        function fail(e) { reject(e && e.message ? e.message : String(e)); }
        try {
            job = { id: "cep", cfg: input.cfg, candidates: input.pieces, warnings: [], skipped: [], layout: [], copyIndex: 0, pc: 0, pt: 0, info: "" };
            prepSetup(job);
            /* Nova Nest: cho phep dat thoi gian xep rieng (mo phong ngan); 0 = cong thuc chuan cua Nest-Pro */
            if (input.cfg.searchMs > 0) job.set.searchMs = input.cfg.searchMs;
            var ms = job.set.searchMs;
            job.set.evBudget = Math.round(NP_SP_RATE_DEFAULT * ms / 1000);   /* phong doan ban dau; se duoc hieu chinh lai o duoi bang toc do do THAT */
            job.pieces = [];
        } catch (e0) { fail(e0); return; }
        function prepStep() {
            try {
                if (ctl.cancel) { reject("CANCELLED"); return; }
                var ts = Date.now();
                while (i < input.pieces.length && Date.now() - ts < 60) {
                    var p = input.pieces[i], outline = [], k, j, poly;
                    for (k = 0; k < p.outline.length; k++) { poly = []; for (j = 0; j < p.outline[k].length; j++) poly.push({ x: p.outline[k][j][0], y: p.outline[k][j][1] }); outline.push(poly); }
                    var bb = prepOutlineBounds(outline);
                    var c = { name: p.name, item: null, outline: outline, raws: [], curved: !!p.curved, npts: p.npts, area: prepNetArea(outline), w0: bb.w, h0: bb.h, index: p.index };
                    spPreparePiece(job, c); c.pi = job.pieces.length; job.pieces.push(c); i++;
                }
                emit({ phase: "prepare", done: i, total: input.pieces.length, ms: ms });
                if (i < input.pieces.length) setTimeout(prepStep, 0);
                else { var a = 0; for (k = 0; k < job.pieces.length; k++) a += job.pieces[k].area; job.netArea = a; spInitState(job); tSearch = Date.now(); setTimeout(searchStep, 0); }
            } catch (e1) { fail(e1); }
        }
        function searchStep() {
            try {
                if (ctl.cancel) { reject("CANCELLED"); return; }
                if (ctl.skip && job.sr) job.sr.skip = true;
                var fin = spStep(job, 120), S = job.sp, now = Date.now();
                if (S && S.stage && S.stage !== "lbf" && S.evStart !== undefined && (now - tSearch) < ms * 0.85) {
                    if (!calib.ref && S.evals - S.evStart >= 20000) calib.ref = { t: now, ev: S.evals };
                    if (calib.ref) {
                        var cElapsed = now - calib.ref.t, cEv = S.evals - calib.ref.ev;
                        if (cElapsed >= 60) {
                            var measRate = cEv / Math.max(0.05, cElapsed / 1000);
                            var newBudget = Math.max(2000, Math.round(measRate * ms / 1000));
                            S.evBudget = newBudget;
                            if (S.stage === "expl") S.evExpl = Math.round(newBudget * job.set.explFrac);   /* S.evStop duoc chinh engine tu tinh lai moi vong lap pha kham pha */
                            else S.evStop = S.evStart + newBudget;   /* dang o pha nen: dat lai moc dung ngay */
                            calib.rate = measRate;
                        }
                    }
                }
                if (fin || now - lastEmit > 100) {
                    lastEmit = now;
                    emit({ phase: "layout", stage: S ? S.stage : "", ev: S && S.evStart !== undefined ? S.evals - S.evStart : 0, budget: S && S.evBudget ? S.evBudget : job.set.evBudget,
                           bestL: S ? S.bestL : 0, lbfL: S ? S.lbfL : 0, passes: S ? S.passes : 0, ms: ms, elapsed: now - tSearch });
                }
                if (!fin) { setTimeout(searchStep, 0); return; }
                var secs = (Date.now() - tSearch) / 1000, used = S.evals - (S.evStart || 0);
                prepVerify(job);
                var rows = [], r;
                for (k = 0; k < job.layout.length; k++) { r = job.layout[k]; rows.push({ index: r.index, name: r.name, angle: r.angle, x: r.x, y: r.y, w: r.w, h: r.h }); }
                resolve({ rows: rows, sheetW: job.sheetW, sheetH: job.sheetH, contentH: job.contentH, edgePad: job.edgePad, topPad: job.topPad, cfg: input.cfg,
                          minGap: job.minGap, reqGap: job.reqGap, effPct: job.effPct, lbfL: S.lbfL, bestL: S.bestL, passes: S.passes, moves: S.moves,
                          searchSecs: secs, totalSecs: (Date.now() - T0) / 1000, skipped: !!(job.sr && job.sr.skip), calibRate: calib.rate || 0 });
            } catch (e2) { fail(e2); }
        }
        var k;
        setTimeout(prepStep, 0);
    });
}
