/* Nova Nest: Web Worker chay engine Nest-Pro Sparrow (nhieu worker chay song song khi mo phong). */
importScripts("engine.js", "pipeline.js");
var ctls = {};
onmessage = function (e) {
    var m = e.data;
    if (m.cmd === "run") {
        var ctl = { cancel: false, skip: false }, last = 0;
        ctls[m.id] = ctl;
        NP_runPipeline(m.input, function (p) {
            var now = Date.now();
            if (now - last > 250) { last = now; postMessage({ type: "progress", id: m.id, p: p }); }
        }, ctl).then(function (r) {
            delete ctls[m.id];
            postMessage({ type: "done", id: m.id, r: r });
        }, function (err) {
            delete ctls[m.id];
            postMessage({ type: "error", id: m.id, msg: String(err) });
        });
    } else if (m.cmd === "cancel" && ctls[m.id]) {
        ctls[m.id].cancel = true;
    }
};
postMessage({ type: "ready" });
