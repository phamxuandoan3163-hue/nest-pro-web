@echo off
chcp 65001 >nul
rem Install once as a link: point Illustrator's extensions folder at THIS folder.
rem Then to update, just unzip the new build over this folder and reopen the panel.
echo Installing Nova Nesting AI (link mode)...
for %%v in (9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
set "DEST=%APPDATA%\Adobe\CEP\extensions\NovaNest"
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
if exist "%DEST%" rmdir "%DEST%" >nul 2>&1
if exist "%DEST%" rmdir /s /q "%DEST%"
mklink /J "%DEST%" "%SRC%"
if errorlevel 1 (
  echo Could not create the link. Please try again.
  pause
  exit /b 1
)
echo.
echo Done. Source folder: %SRC%
echo Restart Illustrator once, then open Window ^> Extensions ^> Nova Nesting AI.
echo To update: unzip a new build over the source folder, then reopen the panel.
pause
