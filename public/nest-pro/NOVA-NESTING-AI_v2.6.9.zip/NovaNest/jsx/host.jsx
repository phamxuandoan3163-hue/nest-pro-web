//@target illustrator
/* Nova Nest host.jsx: cac ham doc rap lay tu Nest-Pro Sparrow CEP 1.2.2 (rut gon, chi giu phan Nova dung) + phan Nova. */
/* Nest-Pro Sparrow (CEP) - host.jsx: chay trong ExtendScript cua Illustrator.
   Chi lam 2 viec bat buoc phai lam trong tai lieu: (1) doc rap dang chon -> JSON; (2) tao file ket qua (duplicate + xoay + dat vi tri).
   Toan bo tinh toan xep nam o panel (Web Worker). */
var NP_FLAT_TOL = 0.15, NP_MAX_PIECES = 200, NP_MAX_SELECTION = 600, NP_BIG = 1e9, NP_PT_PER_CM = 28.346456692913385;
var NP_DEBUG = 0, NP_TRACE = 0, NP_PUMP_MS = 0, NP_PUMP_MAX_MS = 150, NP_SP_STEP_MS = 200, NP_SP_STEP_MAX = 450, NP_VERSION = "CEP-1.0.0";
var NP_SP_T_BASE = 5000, NP_SP_T_PIECE = 1000, NP_SP_T_MIN = 10000, NP_SP_T_MAX = 45000, NP_SP_FAST = 0.5, NP_SP_FAST_MIN = 6000, NP_SP_RATE_DEFAULT = 90000;
var NP_SP_CS = 8, NP_SP_PH = 8, NP_SP_FINE = 0.5, NP_SP_TZ_TOL = 0.7, NP_SP_SEED = 20240611, NP_SP_MOVE_CAP = 900, NP_SP_LBF_RUNS = 10;
    var WK = {};

WK.prepContainsRef = function (arr, item) {
    var i, len = arr.length;
    for (i = 0; i < len; i++) {
        if (arr[i] === item) return true;
    }
    return false;
};

WK.prepSafeBounds = function (item) {
    var b=null;
    try { b=item.geometricBounds; } catch(e1) { try { b=item.visibleBounds; } catch(e2) { return null; } }
    if(!b||b.length<4) return null;
    var l=Number(b[0]), t=Number(b[1]), r=Number(b[2]), bot=Number(b[3]);
    if(isNaN(l)||isNaN(t)||isNaN(r)||isNaN(bot)) return null;
    return {left:l,top:t,right:r,bottom:bot,w:Math.abs(r-l),h:Math.abs(t-bot),area:Math.abs(r-l)*Math.abs(t-bot)};
};

WK.prepItemName = function (item, idx) { try { if(item.name && String(item.name).length) return String(item.name); } catch(e) {} return "Piece_"+(idx+1); };
/* V1.2.2: kiem tra MOT LAN xem ban goc co dang an/khoa/mo khong trong suot khong (hau het chi tiet dang chon tren canvas deu KHONG dinh vao truong hop nay)
   -> ban sao qua duplicate() ke thua y het cac trang thai nay, nen co the BO QUA cac lenh dat lai thua o buoc tao file, giam so lenh goi toi Illustrator moi chi tiet. */

WK.prepIsClosedShape = function (item) {
    var type=""; try { type=item.typename; } catch(e) { return false; }
    if(type==="PathItem") { try { return !!item.closed; } catch(e1) { return false; } }
    if(type==="CompoundPathItem") {
        try { if(!item.pathItems || item.pathItems.length<1) return false; for(var i=0;i<item.pathItems.length;i++) if(!item.pathItems[i].closed) return false; return true; } catch(e2) { return false; }
    }
    return false;
};

WK.prepIsCompoundClip = function (item) {
    if(!item || item.typename!=="CompoundPathItem") return false;
    try { for(var i=0;i<item.pathItems.length;i++) if(item.pathItems[i].clipping) return true; } catch(e) {}
    return false;
};

WK.prepIsClipShape = function (item) {
    if(!item) return false;
    if(item.typename==="PathItem") { try { return !!item.clipping && !!item.closed; } catch(e) { return false; } }
    if(item.typename==="CompoundPathItem") return prepIsClosedShape(item) && prepIsCompoundClip(item);
    return false;
};

WK.prepDirectChildren = function (group) {
    var out=[], all=null, seen=[], i, child, parent;
    if(!group || group.typename!=="GroupItem") return out;
    try {
        all=group.pageItems;
        var n=Math.min(all.length,5000);
        for(i=0;i<n;i++) {
            child=all[i]; parent=null; try { parent=child.parent; } catch(eParent) {}
            if(parent===group) out.push(child);   /* v2.2: moi item chi xuat hien 1 lan trong collection -> bo kiem tra trung O(n^2) */
        }
    } catch(eAll) {}
    if(out.length) return out;
    var props=["groupItems","pathItems","compoundPathItems"];
    for(var p=0;p<props.length;p++) {
        try {
            all=group[props[p]]; var lim=Math.min(all.length,5000);
            for(i=0;i<lim;i++) {
                child=all[i]; parent=null; try { parent=child.parent; } catch(eP2) {}
                if(parent===group && !prepContainsRef(seen,child)) { out.push(child); seen.push(child); }
            }
        } catch(eProp) {}
    }
    return out;
};

WK.prepFindGroupClipShapes = function (group, depth) {
    var out=[], kids, i, child, all, n;
    if(!group || depth>8) return out;
    /* v2.2: duong cat cua clipping group luon la item tren cung -> doc 1 item thay vi duyet ca design ben trong */
    try {
        var top=group.pageItems[0], tp=null;
        try { tp=top.parent; } catch(eTp) {}
        if(top && tp===group && prepIsClipShape(top)) return [top];
    } catch(eTop) {}
    kids=prepDirectChildren(group);
    for(i=0;i<kids.length;i++) {
        child=kids[i];
        if(prepIsClipShape(child)) { if(!prepContainsRef(out,child)) out.push(child); }
        else if(child && child.typename==="GroupItem" && child.clipped) {
            var nested=prepFindGroupClipShapes(child,depth+1);
            for(var ni=0;ni<nested.length;ni++) if(!prepContainsRef(out,nested[ni])) out.push(nested[ni]);
        }
    }
    if(out.length) return out;
    try {
        all=group.compoundPathItems; n=Math.min(all.length,5000);
        for(i=0;i<n;i++) if(prepIsCompoundClip(all[i])) { out.push(all[i]); }
    } catch(eCP) {}
    try {
        all=group.pathItems; n=Math.min(all.length,5000);
        for(i=0;i<n;i++) {
            child=all[i]; if(!child || child.typename!=="PathItem" || !child.clipping || !child.closed) continue;
            var par=null; try { par=child.parent; } catch(ePar) {}
            if(par && par.typename==="CompoundPathItem") continue;
            if(!prepContainsRef(out,child)) out.push(child);
        }
    } catch(ePath) {}
    return out;
};

WK.prepCollectRawShapes = function (node, raw, warnings, depth, visited) {
    if(!node || depth>24 || prepContainsRef(visited,node)) return;
    visited.push(node);
    var type=""; try { type=node.typename; } catch(eType) { return; }
    if(type==="PathItem" || type==="CompoundPathItem") {
        if(prepIsClosedShape(node) && !prepContainsRef(raw,node)) raw.push(node);
        return;
    }
    if(type!=="GroupItem") return;
    var clipped=false; try { clipped=!!node.clipped; } catch(eClip) {}
    if(clipped) {
        var masks=prepFindGroupClipShapes(node,0);
        if(masks.length) { for(var mi=0;mi<masks.length;mi++) if(!prepContainsRef(raw,masks[mi])) raw.push(masks[mi]); return; }
        warnings.push("A clipped group had no explicit clipping flag; outline fallback used.");
    }
    var kids=prepDirectChildren(node);
    if(!kids.length) {
        try {
            var paths=node.pathItems, lim=Math.min(paths.length,5000);
            for(var pi=0;pi<lim;pi++) if(prepIsClosedShape(paths[pi]) && !prepContainsRef(raw,paths[pi])) raw.push(paths[pi]);
        } catch(ePaths) {}
        try {
            var cps=node.compoundPathItems, lim2=Math.min(cps.length,1000);
            for(var ci=0;ci<lim2;ci++) if(prepIsClosedShape(cps[ci]) && !prepContainsRef(raw,cps[ci])) raw.push(cps[ci]);
        } catch(eCps) {}
        return;
    }
    for(var i=0;i<kids.length;i++) prepCollectRawShapes(kids[i],raw,warnings,depth+1,visited);
};

WK.prepFilterOuterShapes = function (raw) {
    var rows = [], i, b, j, contained, len = raw.length;
    for (i = 0; i < len; i++) {
        b = prepSafeBounds(raw[i]); if (!b || b.w < 1 || b.h < 1) continue;
        rows.push({ item: raw[i], b: b });
    }
    rows.sort(function (a, b) {
        var diffArea = b.b.area - a.b.area;
        if (Math.abs(diffArea) > 0.5) return diffArea;
        return (b.b.w + b.b.h) - (a.b.w + a.b.h);
    });
    var out = [], bounds = [], rLen = rows.length;
    for (i = 0; i < rLen; i++) {
        contained = false;
        var c = rows[i].b;
        var cl = c.left, cr = c.right, ct = c.top, cb = c.bottom;
        for (j = 0; j < bounds.length; j++) {
            var a = bounds[j];
            /* OPT: "inside" kiem tra ca truong hop trung vi tri; da loai bo nhanh "same" thua */
            if (cl >= a.left - 0.5 && cr <= a.right + 0.5 && ct <= a.top + 0.5 && cb >= a.bottom - 0.5) {
                contained = true; break;
            }
        }
        if (!contained) { out.push(rows[i].item); bounds.push(c); }
    }
    return out;
};

/* v2.2: group (khong clip) gom duong cat + design: neu co 1 duong khep kin la con truc tiep, bao tron moi con khac
   thi lay luon duong do, khong duyet hang nghin duong cua design ben trong. Khong thoa thi tra null (dung cach cu). */
WK.prepFastOuter = function (group) {
    var kids=prepDirectChildren(group), best=null, bb=null, i, b, k, c;
    if(kids.length<2 || kids.length>400) return null;
    var bs=[];
    for(i=0;i<kids.length;i++) {
        k=kids[i]; b=prepSafeBounds(k); bs.push(b);
        if(!b) continue;
        c=k;
        try { if(k.typename==="GroupItem" && k.clipped) { var m=prepFindGroupClipShapes(k,0); c=m.length===1?m[0]:null; } } catch(eC) { c=null; }
        if(!c || !prepIsClosedShape(c)) continue;
        if(c!==k) { b=prepSafeBounds(c); if(!b) continue; }
        if(!bb || b.area>bb.area) { best=c; bb=b; }
    }
    if(!best) return null;
    for(i=0;i<kids.length;i++) {
        b=bs[i]; if(!b || kids[i]===best) continue;
        try { if(best.parent===kids[i]) continue; } catch(eP) {}
        if(b.left<bb.left-0.5 || b.right>bb.right+0.5 || b.top>bb.top+0.5 || b.bottom<bb.bottom-0.5) return null;
    }
    return best;
};

WK.prepExtractRoot = function (root) {
    var warnings=[], raw=[], visited=[];
    if(!root) return {items:[],warnings:["Empty selection item."]};
    if(prepIsClosedShape(root)) return {items:[root],warnings:[]};
    if(root.typename==="GroupItem" && root.clipped) {
        var directMasks=prepFindGroupClipShapes(root,0);
        if(directMasks.length) return {items:directMasks,warnings:[]};
    }
    prepCollectRawShapes(root,raw,warnings,0,visited);
    var clipOnly=[], i;
    for(i=0;i<raw.length;i++) if(prepIsClipShape(raw[i])) clipOnly.push(raw[i]);
    var items=[];
    if(clipOnly.length) {
        var nonClip=[], clipBounds=[], nb, cb, inside, ci;
        for(i=0;i<clipOnly.length;i++) { cb=prepSafeBounds(clipOnly[i]); if(cb) clipBounds.push(cb); if(!prepContainsRef(items,clipOnly[i])) items.push(clipOnly[i]); }
        for(i=0;i<raw.length;i++) {
            if(prepContainsRef(clipOnly,raw[i]) || prepIsClipShape(raw[i])) continue;
            nb=prepSafeBounds(raw[i]); if(!nb || nb.w<1 || nb.h<1) continue;
            inside=false;
            for(ci=0;ci<clipBounds.length;ci++) {
                cb=clipBounds[ci];
                if(nb.left>=cb.left-0.5 && nb.right<=cb.right+0.5 && nb.top<=cb.top+0.5 && nb.bottom>=cb.bottom-0.5) { inside=true; break; }
            }
            if(!inside) nonClip.push(raw[i]);
        }
        var exterior=prepFilterOuterShapes(nonClip);
        for(i=0;i<exterior.length;i++) if(!prepContainsRef(items,exterior[i])) items.push(exterior[i]);
    } else items=prepFilterOuterShapes(raw);
    if(items.length>1 && !clipOnly.length) warnings.push("Group without clipping masks: nested inner paths were filtered by bounds; review silhouette.");
    return {items:items,warnings:warnings};
};

WK.prepGetSelectionRoots = function (doc) {
    var raw=[], out=[], i, it, count=0;
    var sel=null;   /* v2.2: doc.selection tao lai ca mang moi lan goi -> chi lay 1 lan */
    try { sel=doc.selection; if(!sel || !sel.length) return {items:[],overflow:0}; count=Number(sel.length)||0; } catch(eSel) { return {items:[],overflow:0}; }
    if(count>NP_MAX_SELECTION) return {items:[],overflow:count};
    for(i=0;i<count;i++) { try { it=sel[i]; if(it) raw.push(it); } catch(eItem) {} }
    for(i=0;i<raw.length;i++) {
        var p=null, guard=0, ancestor=false;
        try { p=raw[i].parent; } catch(ePar) {}
        while(p && guard<100) { if(prepContainsRef(raw,p)) { ancestor=true; break; } try { p=p.parent; } catch(eP) { p=null; } guard++; }
        if(!ancestor && !prepContainsRef(out,raw[i])) out.push(raw[i]);
    }
    return {items:out,overflow:0};
};

WK.prepDocSpace = function (doc) { try { return doc.documentColorSpace; } catch(e) { return DocumentColorSpace.RGB; } };

WK.prepReadPath = function (path) {
    var pp, n, i, a, an, ld, rd, P = [], closed = true;
    try { pp = path.pathPoints; n = pp.length; } catch (e0) { return null; }
    if (n < 3) return null;
    for (i = 0; i < n; i++) {
        try {
            /* V1.38: moi thuoc tinh DOM doc MOT lan (truoc day a.anchor[0], a.anchor[1]... = 7 lan goi DOM/diem, nay 4) */
            a = pp[i]; an = a.anchor; ld = a.leftDirection; rd = a.rightDirection;
            P.push({ ax: Number(an[0]), ay: Number(an[1]), lx: Number(ld[0]), ly: Number(ld[1]), rx: Number(rd[0]), ry: Number(rd[1]) });
        } catch (e1) { return null; }
    }
    try { closed = !!path.closed; } catch (e2) {}
    return { P: P, closed: closed };
};

WK.prepFlatFromP = function (P, tol) {
    var out = [], n = P.length, i, a, b, k, steps, invSteps, t, mt, mt2, t2, c0, c1, c2, c3, straight, m, m1, m2, d1x, d1y, d2x, d2y, x, y, res, last, outLen;
    for (i = 0; i < n; i++) {
        a = P[i]; b = P[(i + 1) % n];
        out.push({ x: a.ax, y: a.ay });
        straight = (Math.abs(a.rx - a.ax) < 1e-6 && Math.abs(a.ry - a.ay) < 1e-6 && Math.abs(b.lx - b.ax) < 1e-6 && Math.abs(b.ly - b.ay) < 1e-6);
        if (!straight) {
            d1x = a.ax - 2 * a.rx + b.lx; d1y = a.ay - 2 * a.ry + b.ly;
            d2x = a.rx - 2 * b.lx + b.ax; d2y = a.ry - 2 * b.ly + b.ay;
            m1 = Math.sqrt(d1x * d1x + d1y * d1y); m2 = Math.sqrt(d2x * d2x + d2y * d2y);
            m = m1 > m2 ? m1 : m2;
            steps = Math.ceil(Math.sqrt(0.75 * m / tol));
            if (steps < 2) steps = 2;
            if (steps > 48) steps = 48;
            invSteps = 1 / steps;
            /* OPT: Cache he so Bernstein polynomial: giam tu 16 phep nhan + 2 phep chia xuong 6 phep nhan / buoc */
            for (k = 1; k < steps; k++) {
                t = k * invSteps; mt = 1 - t;
                mt2 = mt * mt; t2 = t * t;
                c0 = mt2 * mt;
                c1 = 3 * mt2 * t;
                c2 = 3 * mt * t2;
                c3 = t2 * t;
                x = c0 * a.ax + c1 * a.rx + c2 * b.lx + c3 * b.ax;
                y = c0 * a.ay + c1 * a.ry + c2 * b.ly + c3 * b.ay;
                out.push({ x: x, y: y });
            }
        }
    }
    res = [];
    outLen = out.length;
    for (i = 0; i < outLen; i++) {
        last = res.length ? res[res.length - 1] : null;
        if (last && Math.abs(last.x - out[i].x) < 1e-7 && Math.abs(last.y - out[i].y) < 1e-7) continue;
        res.push(out[i]);
    }
    while (res.length > 1 && Math.abs(res[0].x - res[res.length - 1].x) < 1e-7 && Math.abs(res[0].y - res[res.length - 1].y) < 1e-7) res.pop();
    return res.length >= 3 ? res : [];
};

WK.prepOutline = function (item, tol) {
    var polys = [], raws = [], subs = [], i, rd, poly;
    try {
        if (item.typename === "PathItem") subs.push(item);
        else if (item.typename === "CompoundPathItem") { for (i = 0; i < item.pathItems.length; i++) subs.push(item.pathItems[i]); }
    } catch (e) {}
    for (i = 0; i < subs.length; i++) {
        rd = prepReadPath(subs[i]);
        if (!rd) continue;
        poly = prepFlatFromP(rd.P, tol);
        if (poly.length > 2) { polys.push(poly); raws.push(rd); }
    }
    return { polys: polys, raws: raws };
};

WK.prepOutlineBounds = function (outline) {
    var i, j, q, minX = 1e30, maxX = -1e30, minY = 1e30, maxY = -1e30;
    for (i = 0; i < outline.length; i++) for (j = 0; j < outline[i].length; j++) {
        q = outline[i][j];
        if (q.x < minX) minX = q.x; if (q.x > maxX) maxX = q.x;
        if (q.y < minY) minY = q.y; if (q.y > maxY) maxY = q.y;
    }
    if (minX > maxX) return null;
    return { minX: minX, maxX: maxX, minY: minY, maxY: maxY, w: maxX - minX, h: maxY - minY };
};

WK.prepIsCurved = function (q) {
    return (Math.abs(q.lx - q.ax) > 1e-6 || Math.abs(q.ly - q.ay) > 1e-6 || Math.abs(q.rx - q.ax) > 1e-6 || Math.abs(q.ry - q.ay) > 1e-6);
};

for (var npK in WK) $.global[npK] = WK[npK];


/* =====================================================================================
   NOVA NEST - phan rieng cua Nova (ghep sau ma host cua Nest-Pro Sparrow o tren).
   Dung lai prepGetSelectionRoots / prepExtractRoot / prepOutline cua Nest-Pro de doc rap,
   va cong thuc dat vi tri cua prepCopyAdvance (xoay quanh tam, dat day trai cua silhouette).
   Khac Nest-Pro: chep NGUYEN chi tiet goc (ca duong noi, chu, dau bam) va giu nguyen mau.
   ===================================================================================== */
var NN_CACHE = {};

function nn_esc(s) {
    return String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t');
}
function nn_ser(v) {
    var t = typeof v, i, a, k;
    if (v === null || v === undefined) return 'null';
    if (t === 'number') return isFinite(v) ? String(Math.round(v * 10000) / 10000) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') return '"' + nn_esc(v) + '"';
    if (v instanceof Array) {
        a = [];
        for (i = 0; i < v.length; i++) a.push(nn_ser(v[i]));
        return '[' + a.join(',') + ']';
    }
    a = [];
    for (k in v) if (v.hasOwnProperty(k)) a.push('"' + nn_esc(k) + '":' + nn_ser(v[k]));
    return '{' + a.join(',') + '}';
}
function nn_parse(s) { return eval('(' + s + ')'); }
function nn_fail(e) {
    var msg = (e && e.message) ? e.message : String(e);
    if (e && e.line) msg += ' (line ' + e.line + ')';
    return nn_ser({ error: msg });
}
function nn_ping(s) { return nn_ser({ ok: true, version: app.version }); }
function nn_reset(s) { NN_CACHE = {}; return nn_ser({ ok: true }); }

function nn_tag(item, uid) {
    var n = '', nm = '';
    try { n = item.note || ''; } catch (e) { n = ''; }
    n = n.replace(/\s*#nn:\S+/g, '');
    item.note = n + ' #nn:' + uid;
    // v2.2: gan them vao TEN de tim lai bang getByName (nhanh voi file design nang)
    try { nm = String(item.name || ''); } catch (e2) { nm = ''; }
    nm = nm.replace(/\s*#nn:\S+/g, '');
    var tag = (nm ? nm + ' ' : '') + '#nn:' + uid;
    try { item.name = tag; } catch (e3) { tag = ''; }
    return tag;
}

/* Kho design: sao chep chi tiet (kem design) vao 1 file .ai rieng, luu trong thu muc kho.
   Ban sao duoc gan ghi chu #nn:uid de tim lai. File rap goc khong bi sua va co the dong. */
function nn_safe_name(t) { return String(t).replace(/[^A-Za-z0-9_\-]/g, '_'); }

function nn_make_holder(srcDoc, cars, libDir, sizeName, batch) {
    var units = null, oldUI = null, hdoc = null, i;
    try {
        var lib = new Folder(libDir);
        if (!lib.exists && !lib.create()) throw new Error('Could not create the design library folder: ' + libDir);
        var cs = DocumentColorSpace.CMYK, ru = null;
        try { cs = srcDoc.documentColorSpace; } catch (eC) {}
        try { ru = srcDoc.rulerUnits; } catch (eR) { ru = null; }
        units = nn_units_save();
        try {
            var pre = new DocumentPreset();
            pre.width = 1000; pre.height = 1000;
            pre.colorMode = cs;
            if (ru !== null) pre.units = ru;
            pre.numArtboards = 1;
            hdoc = app.documents.addDocument('Print', pre);
        } catch (ePre) { hdoc = null; }
        if (!hdoc) hdoc = app.documents.add(cs, 1000, 1000);
        nn_units_restore(units);
        var layer = hdoc.layers[0];
        layer.name = 'KHO DESIGN';
        for (i = 0; i < cars.length; i++) {
            var dup = cars[i].item.duplicate(layer, ElementPlacement.PLACEATEND);
            try { if (dup.hidden) dup.hidden = false; } catch (eH) {}
            try { if (dup.locked) dup.locked = false; } catch (eL) {}
            nn_tag(dup, cars[i].uid);
        }
        var name = 'kho_' + batch + '_' + nn_safe_name(sizeName) + '.ai';
        var f = new File(lib.fullName + '/' + name);
        try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
        var ao = new IllustratorSaveOptions();
        try { ao.pdfCompatible = false; } catch (e1) {}
        try { ao.compressed = true; } catch (e2) {}
        try { ao.embedLinkedFiles = true; } catch (e3) {}
        try { ao.embedICCProfile = false; } catch (e4) {}
        hdoc.saveAs(f, ao);
        if (!f.exists) throw new Error('Illustrator could not write the design library: ' + f.fsName);
        hdoc.close(SaveOptions.DONOTSAVECHANGES);
        hdoc = null;
        try { srcDoc.activate(); } catch (eA) {}
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
        nn_units_restore(units);
        return { ok: true, name: name, path: f.fsName };
    } catch (e) {
        try { if (hdoc) hdoc.close(SaveOptions.DONOTSAVECHANGES); } catch (e5) {}
        try { srcDoc.activate(); } catch (e6) {}
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (e7) {}
        try { if (units) nn_units_restore(units); } catch (e8) {}
        return { ok: false, error: (e && e.message) ? e.message : String(e) };
    }
}

/* Luu file rap dang mo: file .ai co san -> luu de len chinh no; chua luu / dinh dang khac -> luu thanh .ai trong thu muc lib. */
function nn_save_source(doc, P, batch) {
    var oldUI = null;
    try {
        try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
        var f = null, how = 'save';
        try { f = doc.fullName; } catch (eF) { f = null; }
        if (f && /\.ai$/i.test(f.name)) {
            doc.save();
        } else {
            if (!P.lib) throw new Error('The file is not saved yet, so there is no folder to save the design in.');
            var lib = new Folder(P.lib);
            if (!lib.exists && !lib.create()) throw new Error('Could not create the folder: ' + P.lib);
            var target = new File(lib.fullName + '/rap_' + batch + '_' + nn_safe_name(P.size || 'X') + '.ai');
            var ao = new IllustratorSaveOptions();
            try { ao.pdfCompatible = false; } catch (e1) {}
            try { ao.compressed = true; } catch (e2) {}
            doc.saveAs(target, ao);
            how = 'saveas';
        }
        var p = doc.fullName.fsName;
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
        return { ok: true, path: p, how: how };
    } catch (e) {
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return { ok: false, error: (e && e.message) ? e.message : String(e) };
    }
}

/* Quet vung chon: moi chi tiet = 1 silhouette (duong bao ngoai) theo cach doc cua Nest-Pro.
   Tham so (JSON): size = ten size, lib = thu muc kho design. Co lib thi luu ca design vao kho. */
function nn_scan(s) {
    try {
        var P = {};
        try { P = nn_parse(s || '{}'); } catch (eP0) { P = {}; }
        if (app.documents.length === 0) return nn_ser({ error: 'No file is open in Illustrator.' });
        var doc = app.activeDocument;
        var sel = prepGetSelectionRoots(doc);
        if (sel.overflow) return nn_ser({ error: 'The selection is too large (' + sel.overflow + ' objects).' });
        if (!sel.items.length) return nn_ser({ error: 'No pieces are selected. Select all pieces of the size, then click again.' });
        var batch = (new Date()).getTime().toString(36);
        var pieces = [], cars = [], skipped = 0, warnings = 0;
        for (var i = 0; i < sel.items.length; i++) {
            var root = sel.items[i], tn = '';
            try { tn = root.typename; } catch (eT) { tn = ''; }
            if (tn === 'TextFrame') { skipped++; continue; }
            var r = prepExtractRoot(root);
            warnings += r.warnings.length;
            if (!r.items.length) { skipped++; continue; }
            // v2.2.2: MOI DOI TUONG CHON (group) = 1 CHI TIET. Nhieu duong cat trong cung group (vd than + bo lai)
            // duoc gop chung 1 chi tiet: duong bao = tat ca cac duong, design di chuyen nguyen group.
            var polys = [], curved = false, np = 0, sb = null, q, k, PP, j;
            for (j = 0; j < r.items.length; j++) {
                var sil = r.items[j];
                var oo = prepOutline(sil, NP_FLAT_TOL);
                if (!oo.polys.length) continue;
                for (k = 0; k < oo.raws.length; k++) {
                    PP = oo.raws[k].P; np += PP.length;
                    for (q = 0; q < PP.length && !curved; q++) if (prepIsCurved(PP[q])) curved = true;
                }
                for (k = 0; k < oo.polys.length; k++) {
                    var poly = [];
                    for (q = 0; q < oo.polys[k].length; q++) poly.push([Math.round(oo.polys[k][q].x * 100) / 100, Math.round(oo.polys[k][q].y * 100) / 100]);
                    polys.push(poly);
                }
                var gs0 = prepSafeBounds(sil);
                if (gs0) {
                    if (!sb) sb = { left: gs0.left, right: gs0.right, top: gs0.top, bottom: gs0.bottom };
                    else { if (gs0.left < sb.left) sb.left = gs0.left; if (gs0.right > sb.right) sb.right = gs0.right; if (gs0.top > sb.top) sb.top = gs0.top; if (gs0.bottom < sb.bottom) sb.bottom = gs0.bottom; }
                }
            }
            if (!polys.length || !sb) { skipped++; continue; }
            var bw = sb.right - sb.left, bh = sb.top - sb.bottom;
            if (bw < 1 || bh < 1) { skipped++; continue; }
            var gc = prepSafeBounds(root);
            if (!gc) { skipped++; continue; }
            var off = { l: sb.left - gc.left, r: gc.right - sb.right, b: sb.bottom - gc.bottom, t: gc.top - sb.top };
            var uid = batch + '_' + i + '_0';
            cars.push({ uid: uid, item: root, pi: pieces.length });
            var pname = String(prepItemName(r.items.length === 1 ? r.items[0] : root, pieces.length)).replace(/\s*#nn:\S+/g, '') || ('Piece_' + (pieces.length + 1));
            pieces.push({ uid: uid, name: pname, outline: polys, parts: r.items.length, curved: curved, npts: np, w: bw, h: bh, off: off });
        }
        if (!pieces.length) return nn_ser({ error: 'No valid closed path was found in the selection.' });
        var dpath = '';
        try { dpath = doc.fullName.fsName; } catch (eP) { dpath = ''; }
        // v2.3: KHONG sua, KHONG luu de file rap. Chep nguyen file (tren dia) vao kho cua Nova Nest; chi tiet duoc
        // tim lai trong ban chep bang vi tri trong cay doi tuong (loc) + kiem tra loai & kich thuoc.
        var kc = nn_kho_copy(doc, dpath, P);
        if (kc.error) return nn_ser({ error: kc.error });
        for (var ci = 0; ci < cars.length; ci++) {
            var pc = pieces[cars[ci].pi], it0 = cars[ci].item;
            pc.loc = nn_locate(it0);
            try { pc.tn = it0.typename; } catch (eTn) { pc.tn = ''; }
            var g0 = prepSafeBounds(it0);
            pc.gb = g0 ? { l: Math.round(g0.left * 100) / 100, t: Math.round(g0.top * 100) / 100, w: Math.round(g0.w * 100) / 100, h: Math.round(g0.h * 100) / 100 } : null;
            if (!pc.loc) return nn_ser({ error: 'Could not find the position of piece "' + pc.name + '" in the file.' });
        }
        var csName = ''; try { csName = String(doc.documentColorSpace); } catch (eCs) {}
        return nn_ser({ cs: csName, doc: doc.name, docPath: kc.path, srcPath: kc.src, src: doc.name, design: true, copied: kc.copied, savedAs: kc.how, where: kc.where || '', orig: kc.orig || '',
                        pieces: pieces, skipped: skipped, warnings: warnings });
    } catch (e) {
        return nn_fail(e);
    }
}

function nn_pick_folder(s) {
    try {
        var P = {};
        try { P = nn_parse(s || '{}'); } catch (eP) { P = {}; }
        var title = P.title || 'Choose folder';
        var st = P.start ? new Folder(P.start) : null, f;
        if (P.save) {
            // v2.3.9: hop thoai SAVE (co o dia chi de dan duong dan thu muc + o ten file) thay cho hop chon thu muc
            var base = (st && st.exists) ? st : Folder.myDocuments;
            var df = new File(base.fullName + '/' + (P.name || 'NovaNest'));
            var flt = $.os.indexOf('Windows') >= 0 ? (P.filter || 'All files:*.*') : null;
            f = flt ? df.saveDlg(title, flt) : df.saveDlg(title);
            if (!f) return nn_ser({ path: '' });
            var nm = ''; try { nm = decodeURI(f.name); } catch (eN) { nm = f.name; }
            return nn_ser({ path: f.parent.fsName, name: nm, file: f.fsName });
        }
        if (st && st.exists) f = st.selectDlg(title); else f = Folder.selectDialog(title);
        return nn_ser({ path: f ? f.fsName : '' });
    } catch (e) {
        return nn_fail(e);
    }
}

/* ---- luu / mo bo rap (JSON) ---- */
function nn_write_set(s) {
    try {
        var P = nn_parse(s);
        var dir = new Folder(P.dir);
        if (!dir.exists) return nn_ser({ error: 'The folder does not exist: ' + P.dir });
        var nm = String(P.name).replace(/[\\\/:*?"<>|]/g, '_').replace(/^\s+|\s+$/g, '');
        if (!nm) return nn_ser({ error: 'The file name is empty.' });
        if (!/\.nnset\.json$/i.test(nm)) nm += '.nnset.json';
        var f = new File(dir.fullName + '/' + nm);
        if (f.exists && !P.overwrite) return nn_ser({ exists: true, file: f.fsName });
        f.encoding = 'UTF-8';
        if (!f.open('w')) return nn_ser({ error: 'Could not write the file: ' + f.fsName });
        f.write(P.text);
        f.close();
        return nn_ser({ ok: true, path: f.fsName });
    } catch (e) {
        return nn_fail(e);
    }
}

function nn_pick_sets(s) {
    try {
        // Windows: bo loc phai la CHUOI (ham chi chay tren Mac, tren Windows se hien thanh "FUNCTION (F) {" va an het file)
        var flt;
        if ($.os.toLowerCase().indexOf('windows') >= 0) flt = 'Nova Nest pattern set (*.json):*.json,All files:*.*';
        else flt = function (f) { return (f instanceof Folder) || /\.json$/i.test(f.name); };
        var arr = File.openDialog('Choose a saved pattern set (you can select several files)', flt, true);
        var out = [], i;
        if (arr) {
            if (!(arr instanceof Array)) arr = [arr];
            for (i = 0; i < arr.length; i++) out.push(arr[i].fsName);
        }
        return nn_ser({ paths: out });
    } catch (e) {
        return nn_fail(e);
    }
}

function nn_read_set(s) {
    try {
        var P = nn_parse(s);
        var f = new File(P.path);
        if (!f.exists) return nn_ser({ error: 'File not found: ' + P.path });
        f.encoding = 'UTF-8';
        if (!f.open('r')) return nn_ser({ error: 'Could not read the file: ' + P.path });
        var t = f.read();
        f.close();
        if (t.charCodeAt(0) === 0xFEFF) t = t.substring(1);
        return nn_ser({ ok: true, text: t, path: f.fsName });
    } catch (e) {
        return nn_fail(e);
    }
}

/* Kiem tra / mo lai file rap goc, tra ve danh sach chi tiet khong tim thay (miss).
   Neu file goc da dong va con duong dan thi mo lai (opened = true) de lay chi tiet nguyen ban. */
function nn_ensure_src(s) {
    var oldUI = null;
    try {
        var P = nn_parse(s), i, open = false, opened = false, miss = [], found = 0;
        for (i = 0; i < app.documents.length; i++) if (app.documents[i].name === P.doc) open = true;
        if (!open && P.path) {
            try {
                var f = new File(P.path);
                if (f.exists) {
                    try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
                    app.open(f);
                    opened = true; open = true;
                }
            } catch (eO) { open = false; opened = false; }
            try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
        }
        NN_CACHE[P.doc] = null;
        for (i = 0; i < P.uids.length; i++) {
            if (open && nn_find(P.doc, P.uids[i])) found++; else miss.push(P.uids[i]);
        }
        return nn_ser({ open: open, opened: opened, found: found, total: P.uids.length, miss: miss });
    } catch (e) {
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return nn_fail(e);
    }
}
function nn_bind(s) { return nn_ensure_src(s); }

/* dong lai cac file rap goc ma panel da tu mo (khong luu thay doi) */
function nn_close_opened(s) {
    try {
        var P = nn_parse(s), i, k, n = 0;
        for (k = 0; k < P.names.length; k++) {
            for (i = 0; i < app.documents.length; i++) {
                if (app.documents[i].name === P.names[k]) { app.documents[i].close(SaveOptions.DONOTSAVECHANGES); n++; break; }
            }
        }
        NN_CACHE = {};
        return nn_ser({ ok: true, closed: n });
    } catch (e) {
        return nn_fail(e);
    }
}

/* dung lai chi tiet tu duong bao da quet (khi file goc khong con): mat duong noi, chu, dau bam */
function nn_build_outline(layer, polys) {
    var i, j, pts, it, cp = null;
    if (polys.length > 1) cp = layer.compoundPathItems.add();
    for (i = 0; i < polys.length; i++) {
        pts = [];
        for (j = 0; j < polys[i].length; j++) pts.push([polys[i][j][0], polys[i][j][1]]);
        if (pts.length < 3) continue;
        it = cp ? cp.pathItems.add() : layer.pathItems.add();
        it.setEntirePath(pts);
        it.closed = true;
        try { it.filled = false; it.stroked = true; it.strokeWidth = 1; it.strokeColor = nn_black(); } catch (eS) {}
    }
    return cp ? cp : it;
}

/* copy file kho design canh bo rap da luu */
function nn_copy_file(s) {
    try {
        var P = nn_parse(s);
        var f = new File(P.from);
        if (!f.exists) return nn_ser({ error: 'Design library file not found: ' + P.from });
        var t = new File(P.to);
        if (t.exists && f.fsName === t.fsName) return nn_ser({ ok: true, path: t.fsName });
        if (!f.copy(P.to)) return nn_ser({ error: 'Could not copy the design library to ' + P.to });
        return nn_ser({ ok: true, path: (new File(P.to)).fsName });
    } catch (e) {
        return nn_fail(e);
    }
}

function nn_check_files(s) {
    try {
        var P = nn_parse(s), out = [], i;
        for (i = 0; i < P.paths.length; i++) out.push(P.paths[i] ? (new File(P.paths[i])).exists : false);
        return nn_ser({ ok: true, exists: out });
    } catch (e) {
        return nn_fail(e);
    }
}

/* don kho design cu (khong dung toi trong keep, qua keepDays ngay) */
function nn_lib_clean(s) {
    try {
        var P = nn_parse(s), n = 0, i, k;
        var dir = new Folder(P.dir);
        if (!dir.exists) return nn_ser({ ok: true, removed: 0 });
        var keep = {};
        for (k = 0; k < (P.keep || []).length; k++) keep[(new File(P.keep[k])).fsName.toLowerCase()] = true;
        var files = dir.getFiles('kho_*.ai');
        var limit = (new Date()).getTime() - (P.days || 30) * 86400000;
        for (i = 0; i < files.length; i++) {
            var f = files[i];
            if (!(f instanceof File)) continue;
            if (keep[f.fsName.toLowerCase()]) continue;
            var m = null;
            try { m = f.modified; } catch (eM) { m = null; }
            if (m && m.getTime() < limit) { if (f.remove()) n++; }
        }
        return nn_ser({ ok: true, removed: n });
    } catch (e) {
        return nn_fail(e);
    }
}

function nn_alive(it) {
    try { var t = it.typename; return !!t; } catch (e) { return false; }
}

/* tim item goc: uu tien bo nho luc quet (nhanh), neu mat thi tim theo ghi chu #nn: */
function nn_find(docName, uid) {
    var reg = $.global.NN_REG;
    if (reg && reg[uid] && nn_alive(reg[uid])) return reg[uid];
    if (!NN_CACHE[docName]) {
        var d = null, i, k;
        for (i = 0; i < app.documents.length; i++) if (app.documents[i].name === docName) d = app.documents[i];
        var idx = {};
        if (d) {
            var items = d.pageItems;
            for (k = 0; k < items.length; k++) {
                var n = '';
                try { n = items[k].note; } catch (e) { n = ''; }
                if (n && n.indexOf('#nn:') >= 0) {
                    var m = n.match(/#nn:(\S+)/);
                    if (m) idx[m[1]] = items[k];
                }
            }
        }
        NN_CACHE[docName] = idx;
    }
    return NN_CACHE[docName][uid] || null;
}

/* giu nguyen cai dat don vi cua nguoi dung: doc truoc, tra lai sau khi tao/luu file */
var NN_UNIT_KEYS = ['rulerType', 'strokeUnits', 'text/units', 'text/asianunits'];
function nn_units_save() {
    var o = {};
    for (var i = 0; i < NN_UNIT_KEYS.length; i++) {
        try { o[NN_UNIT_KEYS[i]] = app.preferences.getIntegerPreference(NN_UNIT_KEYS[i]); } catch (e) {}
    }
    return o;
}
function nn_units_restore(o) {
    if (!o) return;
    for (var k in o) if (o.hasOwnProperty(k)) { try { app.preferences.setIntegerPreference(k, o[k]); } catch (e) {} }
}

function nn_black() { var g = new GrayColor(); g.gray = 100; return g; }

/* dua toan bo chi tiet ve dang duong stroke (bo fill), giu chu */
function nn_strokeify(it, black, depth) {
    if (depth > 30) return;
    var tn = '';
    try { tn = it.typename; } catch (e) { return; }
    var i;
    if (tn === 'PathItem') {
        try { if (it.clipping) return; } catch (e1) {}
        try { it.filled = false; } catch (e2) {}
        try {
            if (!it.stroked) { it.stroked = true; it.strokeWidth = 1; it.strokeColor = black; }
        } catch (e3) {}
    } else if (tn === 'CompoundPathItem') {
        for (i = 0; i < it.pathItems.length; i++) nn_strokeify(it.pathItems[i], black, depth + 1);
    } else if (tn === 'GroupItem') {
        var kids = [];
        try { for (i = 0; i < it.pageItems.length; i++) if (it.pageItems[i].parent === it) kids.push(it.pageItems[i]); } catch (e4) {}
        for (i = 0; i < kids.length; i++) nn_strokeify(kids[i], black, depth + 1);
    }
}

/* ===== v2.1: dung so do "chay ngam" =====
   - Khong mo file rap da quet len man hinh: lay design bang cach nhung (place + embed) file rap vao
     chinh file so do, neu khong duoc thi moi mo file rap tam thoi (xong chi tiet cua size do la dong ngay).
   - Moi size nam tren 1 layer rieng, ten layer = ten size.
   - Chi ghi vao thu muc lam viec; thu muc ket qua chi nhan file khi "Xuat file". */
function nn_norm(p) { return String(p || '').replace(/\\/g, '/').toLowerCase(); }

function nn_open_doc_by(path, name) {
    var i, d, fp;
    for (i = 0; i < app.documents.length; i++) {
        d = app.documents[i]; fp = '';
        try { fp = d.fullName.fsName; } catch (e) { fp = ''; }
        if (path) { if (fp && nn_norm(fp) === nn_norm(path)) return d; }
        else if (d.name === name) return d;
    }
    return null;
}

/* chi muc cac chi tiet theo ghi chu #nn:, dung som khi du so luong can tim */
function nn_index(container, want) {
    var idx = {}, got = 0, items = container.pageItems, n = items.length, k, it, nt, m;
    for (k = 0; k < n && got < want.n; k++) {
        try { it = items[k]; nt = it.note; } catch (e) { continue; }
        if (nt && nt.indexOf('#nn:') >= 0) {
            m = nt.match(/#nn:(\S+)/);
            if (m && want.u[m[1]] && !idx[m[1]]) { idx[m[1]] = it; got++; }
        }
    }
    idx.__n = got;
    return idx;
}

/* ===== v2.3: kho = BAN CHEP file rap (file goc khong bi sua / luu de) ===== */
function nn_kho_copy(doc, dpath, P) {
    var oldUI = null;
    try {
        if (!P.lib) return { error: 'The Nova Nest library folder does not exist yet.' };
        var lib = new Folder(P.lib);
        if (!lib.exists && !lib.create()) return { error: 'Could not create the library folder: ' + P.lib };
        if (!dpath) {   // file chua tung luu (Untitled): luu thanh .ai trong kho (khong co file goc nao bi anh huong)
            try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
            var nf = new File(lib.fullName + '/rap_' + (new Date()).getTime().toString(36) + '_' + nn_safe_name(P.size || 'X') + '.ai');
            var ao = new IllustratorSaveOptions();
            try { ao.pdfCompatible = false; } catch (e1) {}
            doc.saveAs(nf, ao);
            try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
            return { path: nf.fsName, src: '', copied: true, how: 'saveas' };
        }
        var dirty = false;
        try { dirty = !doc.saved; } catch (eS) { dirty = false; }
        if (dirty) {
            // v2.3.3: file co thay doi chua luu -> KHONG luu de file goc; luu dung noi dung dang thay tren man hinh
            // thanh FILE MOI trong NovaNest_rap. Cua so dang mo chuyen sang file moi nay; file goc tren dia giu nguyen.
            var sf0 = new File(dpath), nm0 = '';
            try { nm0 = sf0.displayName; } catch (eDn0) { nm0 = ''; }
            if (!nm0) { try { nm0 = decodeURI(sf0.name); } catch (eDc0) { nm0 = sf0.name; } }
            var b0 = (nm0.lastIndexOf('.') > 0 ? nm0.substring(0, nm0.lastIndexOf('.')) : nm0).replace(/[\\\/:*?"<>|]/g, '_');
            b0 = b0.replace(/(_\d{6}-\d{6})+$/, '');      // v2.4.2: bo moc gio cu, ten khong dai dan
            var n0 = new Date(), q2 = function (v) { return (v < 10 ? '0' : '') + v; };
            var st0 = String(n0.getFullYear()).substring(2) + q2(n0.getMonth() + 1) + q2(n0.getDate()) + '-' + q2(n0.getHours()) + q2(n0.getMinutes()) + q2(n0.getSeconds());
            var d0 = null, w0 = 'here';
            var pn0 = ''; try { pn0 = decodeURI(sf0.parent.name); } catch (ePn) { pn0 = ''; }
            try { d0 = pn0 === 'NovaNest_rap' ? sf0.parent : new Folder(sf0.parent.fullName + '/NovaNest_rap'); if (!d0.exists) d0.create(); if (!d0.exists) d0 = null; } catch (eD0) { d0 = null; }   // file da nam trong NovaNest_rap: luu canh no, khong tao thu muc long
            if (!d0) { d0 = lib; w0 = 'kho'; }
            var f0 = new File(d0.fullName + '/' + (w0 === 'kho' ? nn_safe_name(b0).substring(0, 60) : b0) + '_' + st0 + '.ai');
            try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU0) {}
            var ao0 = new IllustratorSaveOptions();
            try { ao0.pdfCompatible = true; } catch (e10) {}
            doc.saveAs(f0, ao0);
            try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU1) {}
            if (!f0.exists) return { error: 'Could not save the new file: ' + f0.fsName };
            return { path: f0.fsName, src: f0.fsName, orig: sf0.fsName, copied: true, how: 'saveas-dirty', where: w0 };
        }
        var src = new File(dpath);
        if (!src.exists) return { error: 'File not found on disk: ' + dpath };
        var md = null; try { md = src.modified; } catch (eM) {}
        var p2 = function (v) { return (v < 10 ? '0' : '') + v; };
        var stamp = md ? String(md.getFullYear()).substring(2) + p2(md.getMonth() + 1) + p2(md.getDate()) + '-' + p2(md.getHours()) + p2(md.getMinutes()) + p2(md.getSeconds()) : 'x';
        var nm = ''; try { nm = src.displayName; } catch (eDn) { nm = ''; }
        if (!nm) { try { nm = decodeURI(src.name); } catch (eDc) { nm = src.name; } }
        var dot = nm.lastIndexOf('.'), base = dot > 0 ? nm.substring(0, dot) : nm, ext = dot > 0 ? nm.substring(dot) : '.ai';
        base = base.replace(/[\\\/:*?"<>|]/g, '_');
        var baseNoStamp = base.replace(/(_\d{6}-\d{6})+$/, '');
        var pdir = ''; try { pdir = decodeURI(src.parent.name); } catch (ePd) { pdir = ''; }
        if (/_NovaNest_/.test(base) || pdir === 'NovaNest_rap') return { path: src.fsName, src: src.fsName, copied: false, how: 'copy', where: 'self' };   // dang quet chinh file Nova Nest da tao
        // v2.3.1: luu FILE MOI ngay trong thu muc cua file dang mo: <ten file>_NovaNest_<ngay sua file>.<duoi>
        // (file goc khong bi dong toi; cung 1 phien ban file goc thi dung lai file moi da co)
        // v2.3.2: luu vao thu muc con "NovaNest_rap" nam trong thu muc cua file dang mo
        var dir = null, dst = null;
        try { dir = new Folder(src.parent.fullName + '/NovaNest_rap'); if (!dir.exists) dir.create(); if (dir.exists) dst = new File(dir.fullName + '/' + baseNoStamp + '_' + stamp + ext); } catch (eDir) { dst = null; }
        var where = 'here';
        if (dst && !(dst.exists && dst.length === src.length)) {
            var okc = false;
            try { okc = src.copy(dst) && dst.exists; } catch (eCp) { okc = false; }
            if (!okc) dst = null;            // thu muc khong ghi duoc -> luu vao kho cua Nova Nest
            else return { path: dst.fsName, src: src.fsName, copied: true, how: 'copy', where: where };
        }
        if (dst) return { path: dst.fsName, src: src.fsName, copied: false, how: 'copy', where: where };
        where = 'kho';
        dst = new File(lib.fullName + '/' + nn_safe_name(base).substring(0, 60) + '_NovaNest_' + stamp + ext);
        var copied = false;
        if (!dst.exists || dst.length !== src.length) {
            if (!src.copy(dst) || !dst.exists) return { error: 'Could not copy the pattern file to the library: ' + dst.fsName };
            copied = true;
        }
        return { path: dst.fsName, src: src.fsName, copied: copied, how: 'copy', where: where };
    } catch (e) {
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return { error: (e && e.message) ? e.message : String(e) };
    }
}

/* vi tri trong cay doi tuong: [{k:'L'|'I', i}] tu Document xuong item */
function nn_locate(item) {
    var path = [], cur = item, guard = 0;
    while (cur && guard < 80) {
        var par = null, tn = '';
        try { par = cur.parent; tn = cur.typename; } catch (e) { return null; }
        if (!par) return null;
        var isL = tn === 'Layer', coll = isL ? par.layers : par.pageItems, n = coll.length, k, idx = -1;
        for (k = 0; k < n; k++) { if (coll[k] === cur) { idx = k; break; } }
        if (idx < 0) return null;
        path.unshift({ k: isL ? 'L' : 'I', i: idx });
        var ptn = '';
        try { ptn = par.typename; } catch (e2) { return null; }
        if (ptn === 'Document') return path;
        cur = par; guard++;
    }
    return null;
}

function nn_resolve(doc, pc, noGb) {
    var c = doc, L = pc.loc, i, it = null;
    if (L && L.length) {
        try { for (i = 0; i < L.length; i++) c = L[i].k === 'L' ? c.layers[L[i].i] : c.pageItems[L[i].i]; it = c; } catch (e) { it = null; }
        if (it && pc.tn) { try { if (it.typename !== pc.tn) it = null; } catch (e1) { it = null; } }
        if (it && pc.gb && !noGb) {
            var b = prepSafeBounds(it);
            if (!b || Math.abs(b.left - pc.gb.l) > 0.6 || Math.abs(b.top - pc.gb.t) > 0.6 || Math.abs(b.w - pc.gb.w) > 0.6 || Math.abs(b.h - pc.gb.h) > 0.6) it = null;
        }
        if (it) return it;
    }
    if (pc.tag) { try { it = doc.pageItems.getByName(pc.tag); if (it) return it; } catch (eN) {} }   // bo rap 2.1/2.2
    return null;
}

/* ===== v2.3.8: Expand pattern =====
   Bien design to bang Pattern Swatch thanh hinh ve thuong (Object > Expand > Fill) NGAY TRONG BAN CHEP cua file rap
   (dung khung toa do goc) truoc khi nhan ban sang file khac -> hoa tiet giu dung vi tri tuyet doi, khong con phu thuoc
   goc thuoc cua tung file. Chay bang 1 Action tao tu dong (Illustrator khong co lenh script truc tiep cho Expand). */
function nn_hex(s) { var o = '', i, h; for (i = 0; i < s.length; i++) { h = s.charCodeAt(i).toString(16); o += (h.length < 2 ? '0' : '') + h; } return o; }
function nn_unload_action() {
    if (!$.global.NN_ACT_OK) return;
    try { app.unloadAction('NovaNest', ''); } catch (e) {}
    $.global.NN_ACT_OK = false;
}
/* don file tam NN_* con sot lai (Illustrator bi tat giua chung) */
function nn_tmp_clean(s) {
    var n = 0;
    try {
        var fl = Folder.temp.getFiles('NN_*'), now = (new Date()).getTime(), i;
        for (i = 0; i < fl.length; i++) {
            try { if (fl[i] instanceof File && (now - fl[i].modified.getTime()) > 3600000 && !nn_open_doc_by(fl[i].fsName, '')) { if (fl[i].remove()) n++; } } catch (e1) {}
        }
    } catch (e) {}
    return nn_ser({ ok: true, removed: n });
}
function nn_expand_action() {
    if ($.global.NN_ACT_OK) return true;
    var set = 'NovaNest', act = 'Expand';
    var txt = '/version 3\n/name [ ' + set.length + '\n\t' + nn_hex(set) + '\n]\n/isOpen 1\n/actionCount 1\n/action-1 {\n' +
        '\t/name [ ' + act.length + '\n\t\t' + nn_hex(act) + '\n\t]\n\t/keyIndex 0\n\t/colorIndex 0\n\t/isOpen 1\n\t/eventCount 1\n' +
        '\t/event-1 {\n\t\t/useRulersIn1stQuadrant 0\n\t\t/internalName (ai_plugin_expand)\n\t\t/localizedName [ 6\n\t\t\t457870616e64\n\t\t]\n' +
        '\t\t/isOpen 0\n\t\t/isOn 1\n\t\t/hasDialog 1\n\t\t/showDialog 0\n\t\t/parameterCount 3\n' +
        '\t\t/parameter-1 {\n\t\t\t/key 1868720756\n\t\t\t/showInPalette -1\n\t\t\t/type (boolean)\n\t\t\t/value 1\n\t\t}\n' +
        '\t\t/parameter-2 {\n\t\t\t/key 1718185068\n\t\t\t/showInPalette -1\n\t\t\t/type (boolean)\n\t\t\t/value 1\n\t\t}\n' +
        '\t\t/parameter-3 {\n\t\t\t/key 1937011307\n\t\t\t/showInPalette -1\n\t\t\t/type (boolean)\n\t\t\t/value 0\n\t\t}\n\t}\n}\n';
    var f = new File(Folder.temp.fullName + '/NovaNest_expand.aia');
    f.encoding = 'UTF-8'; f.open('w'); f.write(txt); f.close();
    try { app.unloadAction(set, ''); } catch (eU) {}
    app.loadAction(f);
    $.global.NN_ACT_OK = true;
    return true;
}
/* expand pattern cua cac chi tiet trong ban chep dang mo; tra ve so chi tiet da expand hoac loi */
function nn_expand_items(doc, list) {
    nn_expand_action();
    doc.activate();
    try { app.redraw(); } catch (eRd) {}
    if (app.activeDocument !== doc) { doc.activate(); try { app.redraw(); } catch (eRd2) {} }
    if (app.activeDocument !== doc) throw new Error('Could not switch to the copy to expand the pattern fill.');
    try { doc.selection = null; } catch (eS) {}
    var i, n = 0;
    for (i = 0; i < list.length; i++) {
        var it = list[i];
        try { var ly = it.layer; if (ly.locked) ly.locked = false; if (!ly.visible) ly.visible = true; } catch (eL) {}
        try { if (it.locked) it.locked = false; if (it.hidden) it.hidden = false; } catch (eI) {}
        try { it.selected = true; n++; } catch (eSel) {}
    }
    if (!n) return 0;
    app.doScript('Expand', 'NovaNest', false);
    try { doc.selection = null; } catch (eS2) {}
    return n;
}

/* ===== kho tam cho 1 lan dung so do =====
   Nap design: moi file rap MOT lan. Neu file goc dang mo va chua bi sua thi lay thang tu do; neu khong thi mo tam
   BAN CHEP trong kho (khung nhin thu nho), nhan ban cac chi tiet sang kho tam (an), dong ban chep ngay.
   Cach nay giu nguyen design 100% (khong nhung/place file nhu 2.1-2.2 - cach do lam lech hoa tiet). */
/* ===== v2.3.6: giu dung vi tri hoa tiet PATTERN =====
   Illustrator neo luoi pattern theo goc thuoc (ruler origin) cua tung file, nen khi nhan ban chi tiet sang file khac
   (kho tam, so do) hoa tiet bi truot so voi duong rap. Cach sua: luc lay chi tiet tu file rap, ghi vi tri trong
   "khong gian pattern" cua 1 diem neo tren moi duong to pattern (q = M^-1 * diem neo); sau khi dat chi tiet vao so do,
   doc lai q, lech bao nhieu thi dich RIENG pattern (khong dich chi tiet) dung bay nhieu -> hoa tiet ve dung cho cu. */
function nn_kids(g) {
    var out = [], all = null, i, n, c;
    try { all = g.pageItems; n = all.length; } catch (e) { return out; }
    for (i = 0; i < n; i++) { try { c = all[i]; out.push(c); } catch (e2) {} }
    // neu collection tra ca doi tuong long nhau (khong phai con truc tiep) thi loc lai theo parent
    if (n > 1) { try { if (out[n - 1].parent !== g) { var f = []; for (i = 0; i < n; i++) { try { if (out[i].parent === g) f.push(out[i]); } catch (e3) {} } return f; } } catch (e4) {} }
    return out;
}
// v2.5.2: BO phan design nam HOAN TOAN ngoai mat na (vd o pattern sau khi expand trai rong hang nghin pt quanh chi tiet).
// Phan do von khong bao gio hien ra nen ket qua nhin y het, nhung file nhe hon nhieu va chi tiet khong con "vo hinh" vuot
// ra ngoai canvas cua Illustrator (lam lenh dich/xoay bi ep lai -> chi tiet lech, nam ngoai kho). Chi chay tren BAN CHEP.
function nn_bx(it) { try { var b = it.geometricBounds; return { l: b[0], t: b[1], r: b[2], b: b[3] }; } catch (e) { return null; } }
function nn_hit(a, m) { return !(a.r < m.l - 1 || a.l > m.r + 1 || a.t < m.b - 1 || a.b > m.t + 1); }
function nn_in(a, m) { return a.l >= m.l - 1 && a.r <= m.r + 1 && a.t <= m.t + 1 && a.b >= m.b - 1; }
function nn_prune(it, mb, st, depth) {
    if (depth > 12 || (new Date()).getTime() > st.until) return;
    var tn = ''; try { tn = it.typename; } catch (e) { return; }
    if (tn !== 'GroupItem') return;
    var clipped = false; try { clipped = it.clipped; } catch (e1) {}
    var m2 = mb, masks = [], kids = nn_kids(it);
    if (clipped) {
        for (var j = 0; j < kids.length; j++) {     // chi lay mat na la con TRUC TIEP cua clip group
            try { if (kids[j].clipping || (kids[j].typename === 'CompoundPathItem' && kids[j].pathItems.length && kids[j].pathItems[0].clipping)) masks.push(kids[j]); } catch (e2) {}
        }
        for (var k = 0; k < masks.length; k++) {
            var b = nn_bx(masks[k]); if (!b) continue;
            if (m2 === mb) m2 = b; else m2 = { l: Math.min(m2.l, b.l), t: Math.max(m2.t, b.t), r: Math.max(m2.r, b.r), b: Math.min(m2.b, b.b) };
        }
        if (mb && m2 !== mb) m2 = { l: Math.max(m2.l, mb.l), t: Math.min(m2.t, mb.t), r: Math.min(m2.r, mb.r), b: Math.max(m2.b, mb.b) };   // giao 2 mat na
    }
    for (var i = kids.length - 1; i >= 0; i--) {
        var c = kids[i], isMask = false;
        for (var q = 0; q < masks.length; q++) if (masks[q] === c) { isMask = true; break; }
        try { if (!isMask && (c.clipping || (c.typename === 'CompoundPathItem' && c.pathItems.length && c.pathItems[0].clipping))) isMask = true; } catch (e3) {}
        if (isMask) continue;
        var cb = nn_bx(c); if (!cb) continue;
        if (m2 && !nn_hit(cb, m2)) { try { c.remove(); st.n++; } catch (e4) {} continue; }
        if (m2 && nn_in(cb, m2)) { var ccl = false; try { ccl = c.typename === 'GroupItem' && c.clipped; } catch (e5) {} if (!ccl) continue; }
        nn_prune(c, m2, st, depth + 1);
    }
}
function nn_prune_item(it, ms) {
    var st = { n: 0, until: (new Date()).getTime() + (ms || 20000) };
    try { nn_prune(it, null, st, 0); } catch (e) {}
    return st.n;
}
function nn_pat_q(col, pt) {
    var m = col.matrix, a = m.mValueA, b = m.mValueB, c = m.mValueC, d = m.mValueD, det = a * d - b * c;
    if (Math.abs(det) < 1e-12) return null;
    var x = pt[0] - m.mValueTX, y = pt[1] - m.mValueTY;
    return { x: (d * x - c * y) / det, y: (-b * x + a * y) / det, a: a, b: b, c: c, d: d, tx: m.mValueTX, ty: m.mValueTY, px: pt[0], py: pt[1] };
}
function nn_pat_walk(it, out, depth) {
    if (depth > 40 || out.length > 5000) return;
    var tn = '';
    try { tn = it.typename; } catch (e) { return; }
    var p = null, i, kids;
    if (tn === 'PathItem') p = it;
    else if (tn === 'CompoundPathItem') { try { p = it.pathItems[0]; } catch (e1) { p = null; } }
    else if (tn === 'GroupItem') { kids = nn_kids(it); for (i = 0; i < kids.length; i++) nn_pat_walk(kids[i], out, depth + 1); return; }
    if (!p) return;
    var fp = false, sp = false, pt = null;           // v2.4.1: doc mau truoc, chi doc diem neo khi dung la pattern
    try { fp = p.filled && p.fillColor.typename === 'PatternColor'; } catch (e3) {}
    try { sp = p.stroked && p.strokeColor.typename === 'PatternColor'; } catch (e4) {}
    if (!fp && !sp) return;
    try { pt = p.pathPoints[0].anchor; } catch (e2) { pt = [0, 0]; }
    if (fp) { try { var qf = nn_pat_q(p.fillColor, pt); out.push({ node: it, k: 'f', q: qf || {} }); } catch (e5) { out.push({ node: it, k: 'f', q: {} }); } }
    if (sp) { try { var qs = nn_pat_q(p.strokeColor, pt); out.push({ node: it, k: 's', q: qs || {} }); } catch (e6) { out.push({ node: it, k: 's', q: {} }); } }
}
/* co con duong to pattern nao khong (dung ngay khi thay 1 duong) */
function nn_pat_has(it, depth) {
    if (depth > 40) return false;
    var tn = '', p = null, i, kids;
    try { tn = it.typename; } catch (e) { return false; }
    if (tn === 'GroupItem') { kids = nn_kids(it); for (i = 0; i < kids.length; i++) if (nn_pat_has(kids[i], depth + 1)) return true; return false; }
    if (tn === 'PathItem') p = it;
    else if (tn === 'CompoundPathItem') { try { p = it.pathItems[0]; } catch (e1) { p = null; } }
    if (!p) return false;
    try { if (p.filled && p.fillColor.typename === 'PatternColor') return true; } catch (e2) {}
    try { if (p.stroked && p.strokeColor.typename === 'PatternColor') return true; } catch (e3) {}
    return false;
}
function nn_doc_has_pat(d) { try { return d.patterns.length > 0; } catch (e) { return true; } }
/* sua pattern cua chi tiet dup theo danh sach q goc (ref); tra { n: so duong da sua, res: lech con lai lon nhat (pt) } */
function nn_pat_fix(dup, ref) {
    var cur = [], i, n = 0, res = 0, dbg = [], done = [], before = 0;
    nn_pat_walk(dup, cur, 0);
    if (cur.length !== ref.length) return { n: 0, res: -1, bad: true };
    for (i = 0; i < cur.length; i++) { var e0 = Math.abs(cur[i].q.x - ref[i].x) + Math.abs(cur[i].q.y - ref[i].y); if (e0 > before) before = e0; }
    for (i = 0; i < cur.length; i++) {
        var A = cur[i].q, R = ref[i], dx = A.x - R.x, dy = A.y - R.y;
        if (cur[i].k !== R.k || Math.abs(dx) + Math.abs(dy) < 0.001) continue;
        var vx = A.a * dx + A.c * dy, vy = A.b * dx + A.d * dy;
        try { cur[i].node.translate(vx, vy, false, cur[i].k === 'f', false, cur[i].k === 's'); n++; done.push({ node: cur[i].node, k: cur[i].k, vx: vx, vy: vy }); } catch (eT) {}
        if (dbg.length < 2) dbg.push({ src: R.raw, before: A, v: [vx, vy] });
    }
    if (n) {
        var chk = [];
        nn_pat_walk(dup, chk, 0);
        for (i = 0; i < chk.length && i < ref.length; i++) {
            var e = Math.abs(chk[i].q.x - ref[i].x) + Math.abs(chk[i].q.y - ref[i].y);
            if (e > res) res = e;
            if (i < dbg.length) dbg[i].after = chk[i].q;
        }
    }
    // khong cai thien duoc (Illustrator bao ma tran pattern khac voi gia dinh) -> tra lai nhu cu, khong lam xau them
    if (n && res > 0.5 && res >= before * 0.5) {
        for (i = done.length - 1; i >= 0; i--) { try { done[i].node.translate(-done[i].vx, -done[i].vy, false, done[i].k === 'f', false, done[i].k === 's'); } catch (eR) {} }
        return { n: 0, res: res, before: before, reverted: true, dbg: dbg };
    }
    return { n: n, res: res, before: before, dbg: dbg };
}

function nn_stock_reg() {
    if (!$.global.NN_STOCK) $.global.NN_STOCK = { doc: null, layer: null, idx: {}, load: null, pat: {}, adj: {} };
    if (!$.global.NN_STOCK.pat) $.global.NN_STOCK.pat = {};
    if (!$.global.NN_STOCK.adj) $.global.NN_STOCK.adj = {};
    return $.global.NN_STOCK;
}
/* v2.3.5: giu dung mau: file moi dung CUNG he mau voi file rap (RGB/CMYK) va xoa swatch/pattern/gradient/symbol mac dinh,
   de mau, spot, pattern mang tu file rap sang khong bi gop vao swatch trung ten cua file moi (doi mau). */
function nn_cs(v) {
    var s = String(v || '');
    if (/RGB/i.test(s)) return DocumentColorSpace.RGB;
    if (/CMYK/i.test(s)) return DocumentColorSpace.CMYK;
    return null;
}
function nn_clean_doc(d) {
    var cols = ['symbols', 'graphicStyles', 'swatches', 'gradients', 'patterns', 'spots'], i, c, k;
    for (i = 0; i < cols.length; i++) {
        try { c = d[cols[i]]; } catch (e0) { c = null; }
        if (!c) continue;
        try { c.removeAll(); continue; } catch (e1) {}
        try { for (k = c.length - 1; k >= 0; k--) { try { c[k].remove(); } catch (e2) {} } } catch (e3) {}
    }
}

function nn_stock(csWant) {
    var S = nn_stock_reg();
    if (S.doc) { try { var t = S.doc.name; if (t) return S; } catch (e) {} }
    var keep = null;
    try { keep = app.activeDocument; } catch (eA) {}
    var cs = nn_cs(csWant);
    if (!cs) { cs = DocumentColorSpace.CMYK; try { if (keep) cs = keep.documentColorSpace; } catch (eC) {} }
    var d = app.documents.add(cs, 1000, 1000);
    nn_clean_doc(d);
    try { d.views[0].zoom = 0.03125; } catch (eZ) {}
    try { d.views[0].centerPoint = [500, 70000]; } catch (eV) {}
    S.doc = d; S.layer = d.layers[0]; S.layer.name = 'NOVA KHO TAM'; S.idx = {};
    try { if (keep) keep.activate(); } catch (eK) {}
    return S;
}

/* file "_expanded" canh ban chep: luu ban da expand pattern de lan xep sau dung lai */
function nn_exp_file(kf) {
    var nm = ''; try { nm = decodeURI(kf.name); } catch (e) { nm = kf.name; }
    var dot = nm.lastIndexOf('.'), base = dot > 0 ? nm.substring(0, dot) : nm;
    base = base.replace(/_expanded$/, '');
    return new File(kf.parent.fullName + '/' + base + '_expanded.ai');
}
function nn_stock_add(s) {
    var oldUI = null;
    try {
        var P = nn_parse(s), S = nn_stock(P.cs), i, miss = [], items = [], d = null, opened = null, nPat = 0, idoc = [], nExp = 0, expErr = '', badPat = [], savedX = false, usedX = false, nPrune = 0;
        try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
        var keep = null; try { keep = app.activeDocument; } catch (eA) {}
        var todo = [];
        for (i = 0; i < P.pieces.length; i++) if (!S.idx[P.pieces[i].uid]) todo.push(P.pieces[i]);
        var wantExp = P.expand !== false;
        if (todo.length && P.src) {                       // 1) file goc dang mo (khong mo them gi)
            d = nn_open_doc_by(P.src, '');
            if (d && wantExp && nn_doc_has_pat(d)) d = null;   // co pattern: phai expand -> dung ban chep, khong dong vao file goc
            if (d) for (i = 0; i < todo.length; i++) { items[i] = nn_resolve(d, todo[i]); if (items[i]) idoc[i] = d; }
        }
        var need = false;
        for (i = 0; i < todo.length; i++) if (!items[i]) need = true;
        if (need && P.kho && (new File(P.kho)).exists) {  // 2) mo tam ban chep trong kho
            var kf = new File(P.kho), xf = nn_exp_file(kf), fromX = false, mine = true;
            // v2.5: da co ban "_expanded" (expand tu lan xep truoc, moi hon ban chep) -> mo luon, khong expand lai
            var useX = false;
            try { useX = wantExp && xf.exists && xf.modified.getTime() >= kf.modified.getTime(); } catch (eX0) { useX = false; }
            var src2 = useX ? xf : kf;
            opened = nn_open_doc_by(src2.fsName, '');
            if (opened) {                                   // dang mo san (cua so cua nguoi dung) -> mo 1 file tam, khong dong vao cua so do
                var tf = new File(Folder.temp.fullName + '/NN_' + (new Date()).getTime().toString(36) + '_' + src2.name);
                if (src2.copy(tf) && tf.exists) { opened = app.open(tf); S.tmp = tf; } else mine = false;
            } else opened = app.open(src2);
            fromX = useX;
            try { opened.views[0].zoom = 0.03125; opened.views[0].centerPoint = [0, 70000]; } catch (eV) {}
            for (i = 0; i < todo.length; i++) if (!items[i]) { items[i] = nn_resolve(opened, todo[i], fromX); if (items[i]) idoc[i] = opened; }
            if (mine && wantExp && nn_doc_has_pat(opened)) {
                var exl = [], exi = [], changed = false;
                for (i = 0; i < todo.length; i++) if (items[i] && idoc[i] === opened && nn_pat_has(items[i], 0)) { exl.push(items[i]); exi.push(i); }
                try {
                    for (var round = 0; round < 3 && exl.length; round++) {
                        nExp += nn_expand_items(opened, exl); changed = true;
                        var again = [], againI = [];
                        for (var xi = 0; xi < exi.length; xi++) {
                            var k = exi[xi], it2 = nn_resolve(opened, todo[k], true);
                            if (!it2) continue;
                            items[k] = it2;
                            if (nn_pat_has(it2, 0)) { again.push(it2); againI.push(k); }
                        }
                        exl = again; exi = againI;
                    }
                    for (var bi = 0; bi < exi.length; bi++) { badPat.push(todo[exi[bi]].uid); }
                } catch (eX) { expErr = (eX && eX.message) ? eX.message : String(eX); for (var ei = 0; ei < exi.length; ei++) badPat.push(todo[exi[ei]].uid); }
                // v2.5.2: cat bo phan hoa tiet nam ngoai mat na (trong ban chep) truoc khi do khung
                for (i = 0; i < todo.length; i++) if (items[i] && idoc[i] === opened) { var np0 = nn_prune_item(items[i], 15000); if (np0) { nPrune += np0; changed = true; } }
                // do lech khung so voi luc quet (expand lam doi khung) -> can mat na theo duong rap
                if (changed || fromX) for (i = 0; i < todo.length; i++) {
                    if (!items[i] || idoc[i] !== opened || !todo[i].gb) continue;
                    var nb = prepSafeBounds(items[i]), g = todo[i].gb;
                    if (nb) S.adj[todo[i].uid] = { dl: nb.left - g.l, dr: nb.right - (g.l + g.w), dt: nb.top - g.t, db: nb.bottom - (g.t - g.h) };
                }
                // luu ban da expand de lan sau khoi expand lai
                if (changed && !badPat.length && !expErr && P.cacheExp !== false) {
                    try {
                        var so = new IllustratorSaveOptions();
                        try { so.pdfCompatible = false; } catch (eS1) {}
                        try { so.compressed = true; } catch (eS2) {}
                        opened.saveAs(xf, so); savedX = true;
                    } catch (eSX) {}
                }
            } else if (fromX) {
                var npX = 0;
                if (mine) for (i = 0; i < todo.length; i++) if (items[i] && idoc[i] === opened) npX += nn_prune_item(items[i], 15000);
                nPrune += npX;
                if (npX && P.cacheExp !== false) {       // ban _expanded cu (chua cat) -> luu lai ban da cat cho lan sau
                    try { var so2 = new IllustratorSaveOptions(); try { so2.pdfCompatible = false; } catch (eS3) {} try { so2.compressed = true; } catch (eS4) {} opened.saveAs(xf, so2); savedX = true; } catch (eSX2) {}
                }
                for (i = 0; i < todo.length; i++) {
                    if (!items[i] || idoc[i] !== opened || !todo[i].gb) continue;
                    var nb2 = prepSafeBounds(items[i]), g2 = todo[i].gb;
                    if (nb2) S.adj[todo[i].uid] = { dl: nb2.left - g2.l, dr: nb2.right - (g2.l + g2.w), dt: nb2.top - g2.t, db: nb2.bottom - (g2.t - g2.h) };
                }
            }
            usedX = fromX;
            if (!mine) opened = null; else S.load = opened;
        }
        try { S.layer.visible = true; S.layer.locked = false; } catch (eL) {}
        var t0 = (new Date()).getTime();
        for (i = 0; i < todo.length; i++) {
            if (!items[i]) { miss.push(todo[i].uid); continue; }
            if (P.pat === true) {          // (2.3.6, da tat) ghi vi tri hoa tiet pattern tai FILE RAP (truoc khi nhan ban sang file khac)
                var hp = true;
                try { hp = idoc[i] ? nn_doc_has_pat(idoc[i]) : true; } catch (eHp) { hp = true; }
                if (hp) {
                    var lst = []; nn_pat_walk(items[i], lst, 0);
                    if (lst.length) { var qs0 = []; for (var qi = 0; qi < lst.length; qi++) qs0.push({ k: lst[qi].k, x: lst[qi].q.x, y: lst[qi].q.y, raw: qi < 2 ? lst[qi].q : null }); S.pat[todo[i].uid] = qs0; nPat += lst.length; }
                }
            }
            var dup = items[i].duplicate(S.layer, ElementPlacement.PLACEATEND);
            try { if (dup.hidden) dup.hidden = false; } catch (eH) {}
            try { if (dup.locked) dup.locked = false; } catch (eLk) {}
            S.idx[todo[i].uid] = dup;
        }
        try { S.layer.visible = false; } catch (eH2) {}
        if (S.load) { try { S.load.close(SaveOptions.DONOTSAVECHANGES); } catch (eC) {} S.load = null; }
        if (S.tmp) { try { S.tmp.remove(); } catch (eTm) {} S.tmp = null; }
        try { if (keep) keep.activate(); } catch (eK) {}
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
        return nn_ser({ ok: true, found: todo.length - miss.length, missing: miss, fromOpen: !!d, opened: !!opened, pat: nPat, expanded: nExp, expErr: expErr, badPat: badPat, cachedExp: usedX, savedExp: savedX, pruned: nPrune });
    } catch (e) {
        try { var S2 = nn_stock_reg(); if (S2.load) { S2.load.close(SaveOptions.DONOTSAVECHANGES); S2.load = null; } } catch (e2) {}
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return nn_fail(e);
    }
}

function nn_stock_end(s) {
    var S = $.global.NN_STOCK;
    $.global.NN_STOCK = null;
    if (!S) { nn_unload_action(); return nn_ser({ ok: true }); }
    try { if (S.load) S.load.close(SaveOptions.DONOTSAVECHANGES); } catch (e1) {}
    try { if (S.doc) S.doc.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
    try { if (S.tmp) S.tmp.remove(); } catch (e3) {}
    nn_unload_action();
    return nn_ser({ ok: true });
}

/* luu cac file rap dang mo con thay doi chua luu (quet file nang: luu 1 lan truoc khi xep) */
function nn_save_docs(s) {
    var oldUI = null;
    try {
        var P = nn_parse(s), i, saved = 0, missing = [];
        try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
        for (i = 0; i < P.paths.length; i++) {
            var d = nn_open_doc_by(P.paths[i], '');
            if (!d) { missing.push(P.paths[i]); continue; }
            try { if (!d.saved) { d.save(); saved++; } } catch (eS) { missing.push(P.paths[i]); }
        }
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
        return nn_ser({ ok: true, saved: saved, missing: missing });
    } catch (e) {
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return nn_fail(e);
    }
}

function nn_file_begin(s) {
    var oldUI = null;
    try {
        var P = nn_parse(s), sc = P.scale;
        var W = P.sheetW * sc, H = P.sheetH * sc;
        if (W > 16000 || H > 16000) return nn_ser({ error: 'The marker size exceeds the Illustrator limit.' });
        var i, order = [], groups = {}, jobs = [];
        for (i = 0; i < P.placements.length; i++) {
            var pl = P.placements[i], key = pl.path || pl.doc;
            if (!groups[key]) { groups[key] = []; order.push(key); }
            groups[key].push(pl);
        }
        for (i = 0; i < order.length; i++) for (var q = 0; q < groups[order[i]].length; q++) jobs.push({ key: order[i], pl: groups[order[i]][q] });
        var cs = DocumentColorSpace.CMYK, ru = null, ref = null;
        try { ref = nn_open_doc_by(P.placements[0].path, P.placements[0].doc); } catch (eR0) {}
        try { if (ref) cs = ref.documentColorSpace; } catch (eC) {}
        if (nn_cs(P.cs)) cs = nn_cs(P.cs);              // he mau cua file rap luc quet
        try { if (ref) ru = ref.rulerUnits; } catch (eRu) { ru = null; }
        try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
        var units = nn_units_save();
        var doc = null;
        try {
            var pre = new DocumentPreset();
            pre.width = W; pre.height = H;
            pre.colorMode = cs;
            if (ru !== null) pre.units = ru;
            pre.numArtboards = 1;
            doc = app.documents.addDocument('Print', pre);
        } catch (ePre) { doc = null; }
        if (!doc) doc = app.documents.add(cs, W, H);
        nn_units_restore(units);
        if (P.design) nn_clean_doc(doc);
        doc.artboards[0].artboardRect = [0, H, W, 0];
        // One layer per size; when the same size repeats (one-size marker turned into 2 garments of
        // that size), each copy gets its own layer (M, M1) so every layer holds the full piece set of
        // one garment, instead of both copies landing in a single "M" layer.
        var layers = {}, plan = P.layers || [], first = true;
        for (i = 0; i < plan.length; i++) {
            var pit = plan[i];
            if (layers[pit.key]) continue;
            var ly = first ? doc.layers[0] : doc.layers.add();
            first = false;
            ly.name = String(pit.name);
            layers[pit.key] = ly;
        }
        if (first) { doc.layers[0].name = 'NOVA NEST'; }
        // thu nho khung nhin va dua tam nhin ra xa de Illustrator khong phai ve lai tung chi tiet
        try { doc.views[0].zoom = 0.03125; } catch (eZ) {}
        try { doc.views[0].centerPoint = [W / 2, H + 60000]; } catch (eC2) {}
        NN_CACHE = {};
        $.global.NN_JOB = { units: units, oldUI: oldUI, P: P, jobs: jobs, i: 0, doc: doc, layers: layers, W: W, H: H, missing: 0, rebuilt: 0,
                            black: nn_black(), design: !!P.design, how: {}, wait: false, patN: 0, patRes: 0, patBad: 0, patRev: 0, patBefore: 0, fix: 0, pos: [], out: [], trace: [] };
        return nn_ser({ ok: true, n: jobs.length });
    } catch (e) {
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return nn_fail(e);
    }
}

function nn_file_step(s) {
    var J = $.global.NN_JOB;
    try {
        if (!J) return nn_ser({ error: 'No file is being built.' });
        var P = J.P, sc = P.scale, t0 = (new Date()).getTime();
        while (J.i < J.jobs.length) {
            var jb = J.jobs[J.i], p = jb.pl, o = p.off, dup, it = null;
            var SK = nn_stock_reg();
            it = SK.idx[p.uid] || null;
            if (it && !nn_alive(it)) it = null;
            var AJ = SK.adj[p.uid];                    // khung chi tiet doi sau khi expand pattern -> chinh lai do lech duong rap
            if (it && AJ) o = { l: o.l - AJ.dl, r: o.r + AJ.dr, b: o.b - AJ.db, t: o.t + AJ.dt };
            var lkey = p.size + (p.copy && p.copy > 1 ? '#' + p.copy : '');
            var layer = J.layers[lkey] || J.doc.layers[0];
            if (!it) {
                if (!J.design && p.ol && p.ol.length) { J.rebuilt++; dup = nn_build_outline(layer, p.ol); o = { l: 0, r: 0, t: 0, b: 0 }; }
                else { J.missing++; J.i++; continue; }
            } else {
                try { dup = it.duplicate(layer, ElementPlacement.PLACEATEND); }
                catch (eDup) {          // Illustrator khong cho nhan ban tu layer an: hien tam layer kho roi thu lai
                    if (!SK.layer) throw eDup;
                    SK.layer.visible = true;
                    try { dup = it.duplicate(layer, ElementPlacement.PLACEATEND); } finally { try { SK.layer.visible = false; } catch (eV2) {} }
                }
            }
            try { if (dup.hidden) dup.hidden = false; } catch (eH) {}
            try { if (dup.locked) dup.locked = false; } catch (eL) {}
            try { dup.note = ''; } catch (eNt) {}
            if (!J.design) nn_strokeify(dup, J.black, 0);
            // v2.3.4: cat design theo DUONG RAP da quet (clipping mask moi tu duong bao) -> design luon nam gon trong
            // chi tiet, du file goc dung clipping o cap layer, opacity mask hay cau truc khac.
            var mref = null, art = dup;
            if (J.design && P.clip !== false && it && p.ol && p.ol.length) {
                var g0 = prepSafeBounds(dup);
                var mk = nn_build_outline(layer, p.ol);
                var mb = prepSafeBounds(mk);
                if (g0 && mb) {
                    mk.translate((g0.left + o.l) - mb.left, (g0.bottom + o.b) - mb.bottom);
                    var cg = layer.groupItems.add();
                    dup.move(cg, ElementPlacement.PLACEATEND);
                    mk.move(cg, ElementPlacement.PLACEATBEGINNING);
                    try { if (mk.typename === 'CompoundPathItem') mk.pathItems[0].clipping = true; else mk.clipping = true; } catch (eCl) {}
                    cg.clipped = true;
                    dup = cg; mref = mk; o = { l: 0, r: 0, t: 0, b: 0 };
                } else { try { mk.remove(); } catch (eRm) {} }
            }
            // v2.5.2: dua chi tiet ve giua kho TRUOC khi xoay (chi tiet nam xa ngoai artboard trong file rap + xoay quanh tam
            // group co the vuot canvas cua Illustrator -> lenh dich bi ep, chi tiet lech/ra ngoai kho)
            var gc0 = prepSafeBounds(mref || dup);
            if (gc0) dup.translate(J.W / 2 - (gc0.left + gc0.right) / 2, J.H / 2 - (gc0.top + gc0.bottom) / 2, true, true, true, true);
            var a = Number(p.angle) % 360;
            if (a < 0) a += 360;
            var ra = Math.round(a / 90) * 90;
            var ortho = Math.abs(a - ra) < 0.01;
            if (ortho) a = ra % 360;
            if (a) dup.rotate(a, true, true, true, true, Transformation.CENTER);
            if (sc !== 1) dup.resize(sc * 100, sc * 100, true, true, true, true, sc * 100, Transformation.CENTER);
            var g = prepSafeBounds(mref || dup);    // co mat na: do theo duong rap (khung cua clip group co the tinh ca phan bi cat)
            if (!g) throw new Error('Could not measure the piece after rotating it.');
            var L, B;
            if (!ortho) { L = 0; B = 0; }
            else if (a === 180) { L = o.r; B = o.t; }
            else if (a === 90) { L = o.t; B = o.l; }
            else if (a === 270) { L = o.b; B = o.r; }
            else { L = o.l; B = o.b; }
            var tx = p.x * sc, ty = (P.marginB + P.edgePad + p.y) * sc;
            var g1 = g;
            dup.translate(tx - (g.left + L * sc), ty - (g.bottom + B * sc), true, true, true, true);
            // v2.5.2: DO LAI vi tri that sau khi dat (Illustrator co the khong dich du / ep vao canvas voi design rat lon)
            // -> dich bu toi da 3 lan; van lech thi ghi loi de buoc Kiem tra chan lai.
            var gF = null, ex = 0, ey = 0, tries = 0;
            while (tries < 4) {
                gF = prepSafeBounds(mref || dup);
                if (!gF) break;
                ex = tx - (gF.left + L * sc); ey = ty - (gF.bottom + B * sc);
                if (Math.abs(ex) <= 0.3 && Math.abs(ey) <= 0.3) break;
                tries++;
                if (tries < 4) dup.translate(ex, ey, true, true, true, true);
            }
            if (tries) J.fix++;
            var tr = p.size + '|' + p.name + ' a=' + a + ' want=' + Math.round(tx * 10) / 10 + ',' + Math.round(ty * 10) / 10 +
                     ' rot=' + (g1 ? Math.round(g1.left) + ',' + Math.round(g1.bottom) : '-') + ' got=' + (gF ? Math.round(gF.left * 10) / 10 + ',' + Math.round(gF.bottom * 10) / 10 + ' wh=' + Math.round(gF.w) + 'x' + Math.round(gF.h) : '-') + ' tries=' + tries;
            J.trace.push(tr);
            if (gF && (Math.abs(ex) > 0.3 || Math.abs(ey) > 0.3)) J.pos.push(tr);
            var wantW = (a === 90 || a === 270) ? p.h : p.w, wantH = (a === 90 || a === 270) ? p.w : p.h;
            if (gF && mref && ortho && wantW > 0 && (Math.abs(gF.w - wantW * sc) > 2 || Math.abs(gF.h - wantH * sc) > 2)) J.pos.push(tr + ' (kich thuoc khac ' + Math.round(wantW) + 'x' + Math.round(wantH) + ')');
            if (gF && (gF.left < -1 || gF.right > J.W + 1 || gF.bottom < -1 || gF.top > J.H + 1)) J.out.push(p.size + '|' + p.name);
            try { dup.name = String(p.size) + ' | ' + p.name; } catch (eN) {}
            if (J.design && it && SK.pat[p.uid]) {      // dua hoa tiet pattern ve dung vi tri nhu file rap
                var pf = nn_pat_fix(art, SK.pat[p.uid]);
                J.patN += pf.n; if (pf.res > J.patRes) J.patRes = pf.res; if (pf.reverted) J.patRev++; if (pf.before > J.patBefore) J.patBefore = pf.before; if (pf.bad) J.patBad++; if (!J.patDbg && pf.dbg && pf.dbg.length) J.patDbg = pf.dbg;
            }

            if (!J.design) {
                var tf = layer.textFrames.add();
                tf.contents = String(p.size).toUpperCase();
                try { tf.textRange.characterAttributes.size = 40 * sc; tf.textRange.characterAttributes.fillColor = J.black; } catch (eT) {}
                var tb = tf.geometricBounds, g2 = prepSafeBounds(dup);
                var cx = g2 ? (g2.left + g2.right) / 2 : tx, cy = g2 ? (g2.top + g2.bottom) / 2 : ty;
                tf.translate(cx - (tb[0] + tb[2]) / 2, cy - (tb[1] + tb[3]) / 2);
                var gp = layer.groupItems.add();
                dup.move(gp, ElementPlacement.PLACEATEND);
                tf.move(gp, ElementPlacement.PLACEATBEGINNING);
                try { gp.name = String(p.size) + ' | ' + p.name; } catch (eN2) {}
            }
            J.i++;
            if ((new Date()).getTime() - t0 > 150) break;
        }
        var done = J.i >= J.jobs.length;
        return nn_ser({ ok: true, i: J.i, n: J.jobs.length, done: done, wait: !!J.wait });
    } catch (e) {
        nn_job_abort(J);
        return nn_fail(e);
    }
}

function nn_job_abort(J) {
    try { if (J && J.doc) J.doc.close(SaveOptions.DONOTSAVECHANGES); } catch (e1) {}
    try { if (J) nn_units_restore(J.units); } catch (e2) {}
    try { if (J && J.oldUI !== null && J.oldUI !== undefined) app.userInteractionLevel = J.oldUI; } catch (e3) {}
    $.global.NN_JOB = null;
}

/* luu file so do vao thu muc lam viec (P.out), dong file. Thu muc ket qua khong bi dong toi. */
function nn_file_finish(s) {
    var J = $.global.NN_JOB;
    try {
        if (!J) return nn_ser({ error: 'No file is being built.' });
        var P = J.P;
        if (!J.design) {
            var kl = J.doc.layers.add(); kl.name = 'KHUNG';
            var rect = kl.pathItems.rectangle(J.H, 0, J.W, J.H);
            rect.filled = false; rect.stroked = true; rect.strokeWidth = 1; rect.strokeColor = J.black;
            try { rect.name = 'KHUNG SO DO'; } catch (eR) {}
            var info = kl.textFrames.add();
            info.contents = P.label;
            info.position = [0, J.H + 40];
            try { info.textRange.characterAttributes.size = 12; } catch (eS) {}
        }
        try { J.doc.activate(); } catch (eAct) {}
        try { app.executeMenuCommand('fitall'); } catch (eF) {}   // luu khung nhin vua man hinh de mo len thay ngay
        var aiFile = new File(P.out);
        var ao = new IllustratorSaveOptions();
        try { ao.pdfCompatible = false; } catch (e1) {}
        try { ao.compressed = false; } catch (e2) {}       // v2.5.1: file tam -> khong nen cho luu nhanh (file xuat moi nen)
        try { ao.embedICCProfile = false; } catch (e3) {}
        try { ao.embedLinkedFiles = false; } catch (e4) {}
        try { J.doc.saveAs(aiFile, ao); } catch (eSave) { throw new Error('Could not save file ' + aiFile.fsName + ': ' + (eSave.message || eSave)); }
        if (!aiFile.exists) throw new Error('Illustrator could not write the file to ' + aiFile.fsName);
        // v2.5.1: KHONG dong file so do (buoc Kiem tra mo lai ngay sau do -> do mat thoi gian dong/mo lai file nang)
        if (P.keepOpen === false) J.doc.close(SaveOptions.DONOTSAVECHANGES);
        try { if (J.oldUI !== null && J.oldUI !== undefined) app.userInteractionLevel = J.oldUI; } catch (eU2) {}
        nn_units_restore(J.units);
        var hs = {}, hk;
        for (hk in J.how) if (J.how.hasOwnProperty(hk)) hs[J.how[hk]] = (hs[J.how[hk]] || 0) + 1;
        var res = { ok: true, path: aiFile.fsName, placed: J.jobs.length - J.missing, missing: J.missing, rebuilt: J.rebuilt, how: hs, patN: J.patN, patRes: Math.round(J.patRes * 1000) / 1000, patBad: J.patBad, patRev: J.patRev, patBefore: Math.round(J.patBefore * 1000) / 1000, patDbg: J.patDbg || null,
                    fix: J.fix, pos: J.pos, out: J.out };
        try {           // v2.5.2: nhat ky vi tri tung chi tiet (de do loi) canh file so do tam
            var tf = new File(aiFile.fsName.replace(/\.ai$/i, '') + '_vitri.txt');
            tf.encoding = 'UTF-8'; tf.open('w'); tf.write(J.trace.join('\n')); tf.close();
        } catch (eTr) {}
        $.global.NN_JOB = null;
        return nn_ser(res);
    } catch (e) {
        nn_job_abort(J);
        return nn_fail(e);
    }
}

function nn_file_cancel(s) {
    nn_job_abort($.global.NN_JOB);
    return nn_ser({ ok: true });
}

/* thu muc lam viec (nam trong userData, nguoi dung khong phai thay) */
function nn_make_dir(s) {
    try {
        var P = nn_parse(s), f = new Folder(P.path);
        if (!f.exists) f.create();
        if (!f.exists) throw new Error('Could not create the folder: ' + P.path);
        return nn_ser({ ok: true, path: f.fsName });
    } catch (e) { return nn_fail(e); }
}

function nn_work_clean(s) {
    try {
        var P = nn_parse(s), root = new Folder(P.dir), removed = 0;
        if (!root.exists) return nn_ser({ ok: true, removed: 0 });
        var subs = root.getFiles(), now = (new Date()).getTime(), i, j;
        for (i = 0; i < subs.length; i++) {
            var sf = subs[i];
            if (!(sf instanceof Folder)) continue;
            if (P.keep && nn_norm(sf.fsName) === nn_norm(P.keep)) continue;
            var age = 1e12;
            try { age = (now - sf.modified.getTime()) / 86400000; } catch (eM) {}
            if (P.all || age > (P.days || 2)) {
                var fl = sf.getFiles();
                for (j = 0; j < fl.length; j++) { try { if (fl[j] instanceof File) fl[j].remove(); } catch (eF) {} }
                try { if (sf.remove()) removed++; } catch (eD) {}
            }
        }
        return nn_ser({ ok: true, removed: removed });
    } catch (e) { return nn_fail(e); }
}

/* mo cac file ket qua trong Illustrator de kiem tra */
function nn_open_files(s) {
    var oldUI = null;
    try {
        var P = nn_parse(s), i, opened = 0, errs = [], last = null;
        try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
        for (i = 0; i < P.paths.length; i++) {
            try {
                var d = nn_open_doc_by(P.paths[i], '');
                if (!d) { d = app.open(new File(P.paths[i])); opened++; }
                last = d;
            } catch (eO) { errs.push(P.paths[i] + ': ' + (eO.message || eO)); }
        }
        try { if (last) last.activate(); } catch (eA) {}
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
        return nn_ser({ ok: true, opened: opened, errors: errs });
    } catch (e) {
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return nn_fail(e);
    }
}

function nn_close_files(s) {
    try {
        var P = nn_parse(s), i, closed = 0;
        for (i = 0; i < P.paths.length; i++) {
            var d = nn_open_doc_by(P.paths[i], '');
            if (d) { try { d.close(SaveOptions.DONOTSAVECHANGES); closed++; } catch (eC) {} }
        }
        return nn_ser({ ok: true, closed: closed });
    } catch (e) { return nn_fail(e); }
}

/* Xuat file: luu file dang mo (neu nguoi dung da sua), roi chep vao thu muc ket qua. Chi chep file so do (+PDF neu chon). */
function nn_publish(s) {
    var oldUI = null;
    try {
        var P = nn_parse(s), i, done = [], errs = [];
        var dir = new Folder(P.dir);
        if (!dir.exists) throw new Error('The output folder does not exist: ' + P.dir);
        try { oldUI = app.userInteractionLevel; app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS; } catch (eU) {}
        for (i = 0; i < P.files.length; i++) {
            var fi = P.files[i], d = null, mine = false;
            try {
                // v2.5.1: luu thang (Save As) tu file dang mo vao thu muc ket qua, co PDF Compatible de xem truoc /
                // phan mem in (RIP) doc duoc; truoc day chep file tam khong co PDF nen Explorer khong hien hinh.
                d = nn_open_doc_by(fi.path, '');
                if (!d) {
                    var src = new File(fi.path);
                    if (!src.exists) throw new Error('Marker file not found: ' + fi.path);
                    d = app.open(src); mine = true;
                }
                var dst = new File(dir.fullName + '/' + fi.name + '.ai');
                var ao = new IllustratorSaveOptions();
                try { ao.pdfCompatible = P.pdfCompat !== false; } catch (e1) {}
                try { ao.compressed = true; } catch (e2) {}
                try { ao.embedICCProfile = true; } catch (e3) {}
                try { ao.embedLinkedFiles = true; } catch (e4) {}
                d.saveAs(dst, ao);
                if (!dst.exists) throw new Error('Could not copy to ' + dst.fsName);
                if (P.pdf) {
                    var po = new PDFSaveOptions();
                    try { po.preserveEditability = false; } catch (e5) {}
                    d.saveAs(new File(dir.fullName + '/' + fi.name + '.pdf'), po);
                }
                if (P.close || mine) { try { d.close(SaveOptions.DONOTSAVECHANGES); } catch (eC) {} }
                done.push(dst.fsName);
            } catch (eF) {
                errs.push(fi.name + ': ' + (eF.message || eF));
                if (mine && d) { try { d.close(SaveOptions.DONOTSAVECHANGES); } catch (eC2) {} }
            }
        }
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU2) {}
        return nn_ser({ ok: true, done: done, errors: errs });
    } catch (e) {
        try { if (oldUI !== null) app.userInteractionLevel = oldUI; } catch (eU3) {}
        return nn_fail(e);
    }
}

function nn_write_text(s) {
    try {
        var P = nn_parse(s);
        var f = new File(P.path);
        f.encoding = 'UTF-8';
        f.open('w');
        f.write(String.fromCharCode(0xFEFF) + P.text);
        f.close();
        return nn_ser({ ok: true, path: f.fsName });
    } catch (e) {
        return nn_fail(e);
    }
}
