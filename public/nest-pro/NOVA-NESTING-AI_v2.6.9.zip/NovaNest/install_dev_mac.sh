#!/bin/bash
# Install once as a link: point Illustrator's extensions folder at THIS folder.
# Then to update, just unzip the new build over this folder and reopen the panel.
for v in 9 10 11 12; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
SRC="$(cd "$(dirname "$0")" && pwd)"
EXT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$EXT/NovaNest"
mkdir -p "$EXT"
if [ -L "$DEST" ]; then rm "$DEST"; elif [ -e "$DEST" ]; then rm -rf "$DEST"; fi
ln -s "$SRC" "$DEST"
echo "Done. Source folder: $SRC"
echo "Restart Illustrator once, then open Window > Extensions > Nova Nesting AI."
echo "To update: unzip a new build over the source folder, then reopen the panel."
