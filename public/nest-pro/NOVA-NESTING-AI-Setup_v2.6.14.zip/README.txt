NOVA NESTING AI 2.6.14 - SETUP

WINDOWS   Double-click  Install-NovaNest-Windows.bat
MAC       Double-click  Install-NovaNest-Mac.command
          (if macOS says it cannot be opened: right-click the file > Open > Open)

Then restart Adobe Illustrator and open  Window > Extensions > Nova Nesting AI.
Requires Adobe Illustrator 2022 (v26) or newer. No administrator rights are needed.

The panel is digitally signed. If it opens EMPTY (grey) on your computer, run  Fix-Blank-Panel.bat  (Windows)
and restart Illustrator.

To remove the panel, delete the folder  NovaNest  from
  Windows: %APPDATA%\Adobe\CEP\extensions
  Mac:     ~/Library/Application Support/Adobe/CEP/extensions

Support: https://www.ainovanesting.pro/support
