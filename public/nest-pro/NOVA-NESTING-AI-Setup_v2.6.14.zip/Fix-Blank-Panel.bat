@echo off
echo.
echo  Fix for an empty Nova Nesting AI panel
echo  --------------------------------------
echo  This lets Adobe load the panel even when it cannot confirm its signature (your user account only).
for %%v in (9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo  Done. Restart Illustrator and open the panel again.
echo.
if not defined NN_NOPAUSE pause
